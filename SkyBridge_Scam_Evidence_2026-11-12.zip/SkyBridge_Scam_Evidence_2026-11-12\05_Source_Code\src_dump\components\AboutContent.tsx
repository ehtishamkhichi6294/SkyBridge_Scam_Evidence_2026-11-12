import React from "react";
import {
  Star,
  Users,
  Award,
  TrendingUp,
  Globe,
  Shield,
  Clock,
  Zap,
  CheckCircle,
  DollarSign,
  Play,
  BookOpen,
  Monitor,
  ShoppingCart,
  Gift,
  CreditCard,
  Eye,
  Target,
  Lightbulb,
} from "lucide-react";
import { Link } from "react-router-dom";

const AboutContent: React.FC = () => {
  return (
    <div>
      {/* About Us Hero Section */}
      <div className="relative overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12">
          <div className="text-center mb-8 sm:mb-12">
            <div className="inline-flex items-center px-4 py-2 sm:px-6 sm:py-3 bg-gradient-to-r from-sky-100 to-blue-100 text-sky-800 rounded-full text-xs sm:text-sm font-semibold mb-4 sm:mb-6 shadow-sm">
              <Globe className="w-4 h-4 sm:w-5 sm:h-5 mr-2" />
              About Us – SkyBridge International
            </div>
            <h1 className="text-2xl sm:text-4xl md:text-5xl font-bold text-gray-900 mb-4 sm:mb-6 leading-tight">
              Welcome to
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-sky-600 to-blue-600 block sm:inline">
                {" "}
                SkyBridge International
              </span>
            </h1>
            <div className="max-w-4xl mx-auto">
              <p className="text-sm sm:text-lg text-gray-700 mb-3 sm:mb-4 leading-relaxed">
                A digital platform built to empower people with earning
                opportunities, skills development, and modern digital
                solutions.
              </p>
              <p className="text-sm sm:text-lg text-gray-700 leading-relaxed">
                We believe success today comes from the right mix of
                knowledge, technology, and financial freedom. That's why we
                created a unique system where users can learn valuable skills
                and also generate consistent income through our platform.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Mission Section */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 sm:py-8">
        <div className="bg-white/80 backdrop-blur-sm rounded-2xl sm:rounded-3xl p-4 sm:p-6 md:p-8 shadow-xl border border-sky-100">
          <div className="flex items-center justify-center mb-4 sm:mb-6">
            <div className="bg-gradient-to-r from-sky-500 to-blue-500 p-3 sm:p-4 rounded-xl sm:rounded-2xl shadow-lg">
              <Target className="w-6 h-6 sm:w-8 sm:h-8 text-white" />
            </div>
          </div>
          <h2 className="text-xl sm:text-3xl md:text-4xl font-bold text-center text-gray-900 mb-3 sm:mb-4">
            🚀 Our Mission
          </h2>
          <p className="text-sm sm:text-lg text-gray-700 text-center leading-relaxed max-w-4xl mx-auto">
            To create a bridge between skills and income by offering digital
            services, professional courses, and a transparent reward system
            that benefits every user.
          </p>
        </div>
      </div>

      {/* Vision Section */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 sm:py-8">
        <div className="bg-white/80 backdrop-blur-sm rounded-2xl sm:rounded-3xl p-4 sm:p-6 md:p-8 shadow-xl border border-sky-100">
          <div className="flex items-center justify-center mb-4 sm:mb-6">
            <div className="bg-gradient-to-r from-blue-500 to-sky-500 p-3 sm:p-4 rounded-xl sm:rounded-2xl shadow-lg">
              <Eye className="w-6 h-6 sm:w-8 sm:h-8 text-white" />
            </div>
          </div>
          <h2 className="text-xl sm:text-3xl md:text-4xl font-bold text-center text-gray-900 mb-4 sm:mb-6">
            🎯 Our Vision
          </h2>
          <p className="text-sm sm:text-lg text-gray-700 text-center leading-relaxed max-w-4xl mx-auto mb-4 sm:mb-6">
            We aim to become a leading international platform where millions
            of people can access:
          </p>

          <div className="grid grid-cols-1 gap-4 sm:gap-6 sm:grid-cols-3 mt-4 sm:mt-6">
            <div className="bg-gradient-to-br from-sky-50 to-blue-50 rounded-xl sm:rounded-2xl p-4 sm:p-6 border border-sky-200">
              <div className="flex items-center mb-3 sm:mb-4">
                <BookOpen className="w-5 h-5 sm:w-6 sm:h-6 text-sky-600 mr-2 sm:mr-3" />
                <h3 className="font-semibold text-gray-900 text-sm sm:text-base">
                  ✨ Skill-based courses
                </h3>
              </div>
              <p className="text-gray-700 text-xs sm:text-sm">
                Digital Marketing, Instagram Growth, Forex Trading, Google
                AdSense, E-Commerce And Many More
              </p>
            </div>

            <div className="bg-gradient-to-br from-sky-50 to-cyan-50 rounded-xl sm:rounded-2xl p-4 sm:p-6 border border-sky-200">
              <div className="flex items-center mb-3 sm:mb-4">
                <DollarSign className="w-5 h-5 sm:w-6 sm:h-6 text-sky-600 mr-2 sm:mr-3" />
                <h3 className="font-semibold text-gray-900 text-sm sm:text-base">
                  ✨ Earning opportunities
                </h3>
              </div>
              <p className="text-gray-700 text-xs sm:text-sm">
                Through ad-based and e-commerce systems
              </p>
            </div>

            <div className="bg-gradient-to-br from-blue-50 to-indigo-50 rounded-xl sm:rounded-2xl p-4 sm:p-6 border border-sky-200">
              <div className="flex items-center mb-3 sm:mb-4">
                <Shield className="w-5 h-5 sm:w-6 sm:h-6 text-sky-600 mr-2 sm:mr-3" />
                <h3 className="font-semibold text-gray-900 text-sm sm:text-base">
                  ✨ Financial independence
                </h3>
              </div>
              <p className="text-gray-700 text-xs sm:text-sm">
                With simple, secure, and trusted withdrawals
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* What We Offer Section */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 sm:py-8">
        <div className="bg-white/80 backdrop-blur-sm rounded-2xl sm:rounded-3xl p-4 sm:p-6 md:p-8 shadow-xl border border-sky-100">
          <div className="flex items-center justify-center mb-4 sm:mb-6">
            <div className="bg-gradient-to-r from-cyan-500 to-sky-500 p-3 sm:p-4 rounded-xl sm:rounded-2xl shadow-lg">
              <Lightbulb className="w-6 h-6 sm:w-8 sm:h-8 text-white" />
            </div>
          </div>
          <h2 className="text-xl sm:text-3xl md:text-4xl font-bold text-center text-gray-900 mb-6 sm:mb-8">
            💡 What We Offer
          </h2>

          <div className="grid grid-cols-1 gap-4 sm:gap-6 sm:grid-cols-2 lg:grid-cols-3">
            <div className="bg-gradient-to-br from-sky-50 to-blue-50 rounded-xl sm:rounded-2xl p-4 sm:p-6 border border-sky-200 hover:shadow-lg transition-all duration-300">
              <div className="flex items-center mb-3 sm:mb-4">
                <BookOpen className="w-5 h-5 sm:w-6 sm:h-6 text-sky-600 mr-2 sm:mr-3" />
                <h3 className="font-semibold text-gray-900 text-sm sm:text-base">
                  📚 Learn & Earn Together
                </h3>
              </div>
              <p className="text-gray-700 text-xs sm:text-sm">
                Career-focused courses for online success
              </p>
            </div>

            <div className="bg-gradient-to-br from-sky-50 to-cyan-50 rounded-xl sm:rounded-2xl p-4 sm:p-6 border border-sky-200 hover:shadow-lg transition-all duration-300">
              <div className="flex items-center mb-3 sm:mb-4">
                <Monitor className="w-5 h-5 sm:w-6 sm:h-6 text-sky-600 mr-2 sm:mr-3" />
                <h3 className="font-semibold text-gray-900 text-sm sm:text-base">
                  📺 Ad-Based Income
                </h3>
              </div>
              <p className="text-gray-700 text-xs sm:text-sm">
                Watch ads daily and earn with fair distribution
              </p>
            </div>

            <div className="bg-gradient-to-br from-blue-50 to-indigo-50 rounded-xl sm:rounded-2xl p-4 sm:p-6 border border-sky-200 hover:shadow-lg transition-all duration-300">
              <div className="flex items-center mb-3 sm:mb-4">
                <ShoppingCart className="w-5 h-5 sm:w-6 sm:h-6 text-sky-600 mr-2 sm:mr-3" />
                <h3 className="font-semibold text-gray-900 text-sm sm:text-base">
                  🛒 E-Commerce Store
                </h3>
              </div>
              <p className="text-gray-700 text-xs sm:text-sm">
                Sell products easily while we manage the system
              </p>
            </div>

            <div className="bg-gradient-to-br from-cyan-50 to-sky-50 rounded-xl sm:rounded-2xl p-4 sm:p-6 border border-sky-200 hover:shadow-lg transition-all duration-300">
              <div className="flex items-center mb-3 sm:mb-4">
                <Gift className="w-5 h-5 sm:w-6 sm:h-6 text-sky-600 mr-2 sm:mr-3" />
                <h3 className="font-semibold text-gray-900 text-sm sm:text-base">
                  🎁 Bonuses & Rewards
                </h3>
              </div>
              <p className="text-gray-700 text-xs sm:text-sm">
                Extra earnings for active achievers
              </p>
            </div>

            <div className="bg-gradient-to-br from-sky-50 to-blue-50 rounded-xl sm:rounded-2xl p-4 sm:p-6 border border-sky-200 hover:shadow-lg transition-all duration-300 sm:col-span-2 lg:col-span-1">
              <div className="flex items-center mb-3 sm:mb-4">
                <CreditCard className="w-5 h-5 sm:w-6 sm:h-6 text-sky-600 mr-2 sm:mr-3" />
                <h3 className="font-semibold text-gray-900 text-sm sm:text-base">
                  💳 Safe Withdrawals
                </h3>
              </div>
              <p className="text-gray-700 text-xs sm:text-sm">
                Easypaisa, JazzCash, Sadapay, NayaPay, BEP20
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Features Section */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 sm:py-8">
        <div className="grid grid-cols-1 gap-6 sm:gap-8 lg:grid-cols-2">
          <div className="bg-white/70 backdrop-blur-sm rounded-xl p-4 sm:p-6 border border-sky-200">
            <h3 className="text-lg sm:text-2xl font-bold text-gray-900 mb-4 sm:mb-6 flex items-center">
              <Zap className="w-5 h-5 sm:w-7 sm:h-7 text-sky-500 mr-2 sm:mr-3" />
              Platform Features
            </h3>
            <ul className="space-y-2 sm:space-y-3">
              <li className="flex items-center text-gray-700 text-sm sm:text-base">
                <CheckCircle className="w-4 h-4 sm:w-5 sm:h-5 text-sky-500 mr-2 sm:mr-3 flex-shrink-0" />
                <span>Watch video ads and earn rewards instantly</span>
              </li>
              <li className="flex items-center text-gray-700 text-sm sm:text-base">
                <CheckCircle className="w-4 h-4 sm:w-5 sm:h-5 text-sky-500 mr-2 sm:mr-3 flex-shrink-0" />
                <span>Complete daily tasks and challenges</span>
              </li>
              <li className="flex items-center text-gray-700 text-sm sm:text-base">
                <CheckCircle className="w-4 h-4 sm:w-5 sm:h-5 text-sky-500 mr-2 sm:mr-3 flex-shrink-0" />
                <span>Participate in leaderboard competitions</span>
              </li>
              <li className="flex items-center text-gray-700 text-sm sm:text-base">
                <CheckCircle className="w-4 h-4 sm:w-5 sm:h-5 text-sky-500 mr-2 sm:mr-3 flex-shrink-0" />
                <span>Claim daily bonuses and rewards</span>
              </li>
              <li className="flex items-center text-gray-700 text-sm sm:text-base">
                <CheckCircle className="w-4 h-4 sm:w-5 sm:h-5 text-sky-500 mr-2 sm:mr-3 flex-shrink-0" />
                <span>Multiple withdrawal methods available</span>
              </li>
              <li className="flex items-center text-gray-700 text-sm sm:text-base">
                <CheckCircle className="w-4 h-4 sm:w-5 sm:h-5 text-sky-500 mr-2 sm:mr-3 flex-shrink-0" />
                <span>Real-time earnings tracking</span>
              </li>
            </ul>
          </div>

          <div className="bg-white/70 backdrop-blur-sm rounded-xl p-4 sm:p-6 border border-sky-200">
            <h3 className="text-lg sm:text-2xl font-bold text-gray-900 mb-4 sm:mb-6 flex items-center">
              <Shield className="w-5 h-5 sm:w-7 sm:h-7 text-sky-500 mr-2 sm:mr-3" />
              Why Choose Us
            </h3>
            <ul className="space-y-2 sm:space-y-3">
              <li className="flex items-center text-gray-700 text-sm sm:text-base">
                <Star className="w-4 h-4 sm:w-5 sm:h-5 text-sky-500 mr-2 sm:mr-3 flex-shrink-0" />
                <span>Secure and reliable platform</span>
              </li>
              <li className="flex items-center text-gray-700 text-sm sm:text-base">
                <Clock className="w-4 h-4 sm:w-5 sm:h-5 text-sky-500 mr-2 sm:mr-3 flex-shrink-0" />
                <span>Fast 24-48 hour withdrawals</span>
              </li>
              <li className="flex items-center text-gray-700 text-sm sm:text-base">
                <Shield className="w-4 h-4 sm:w-5 sm:h-5 text-sky-500 mr-2 sm:mr-3 flex-shrink-0" />
                <span>SSL encrypted transactions</span>
              </li>
              <li className="flex items-center text-gray-700 text-sm sm:text-base">
                <Users className="w-4 h-4 sm:w-5 sm:h-5 text-sky-500 mr-2 sm:mr-3 flex-shrink-0" />
                <span>24/7 customer support</span>
              </li>
              <li className="flex items-center text-gray-700 text-sm sm:text-base">
                <TrendingUp className="w-4 h-4 sm:w-5 sm:h-5 text-sky-500 mr-2 sm:mr-3 flex-shrink-0" />
                <span>Regular platform updates</span>
              </li>
              <li className="flex items-center text-gray-700 text-sm sm:text-base">
                <Award className="w-4 h-4 sm:w-5 sm:h-5 text-sky-500 mr-2 sm:mr-3 flex-shrink-0" />
                <span>Proven track record since 2020</span>
              </li>
            </ul>
          </div>
        </div>
      </div>

      {/* Values Section */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 sm:py-8">
        <div className="bg-white/80 backdrop-blur-sm rounded-2xl sm:rounded-3xl p-4 sm:p-6 md:p-8 shadow-xl border border-sky-100">
          <div className="flex items-center justify-center mb-4 sm:mb-6">
            <div className="bg-gradient-to-r from-sky-500 to-blue-500 p-3 sm:p-4 rounded-xl sm:rounded-2xl shadow-lg">
              <Shield className="w-6 h-6 sm:w-8 sm:h-8 text-white" />
            </div>
          </div>
          <h2 className="text-xl sm:text-3xl md:text-4xl font-bold text-center text-gray-900 mb-6 sm:mb-8">
            🛡️ Our Values
          </h2>

          <div className="grid grid-cols-1 gap-4 sm:gap-6 sm:grid-cols-2">
            <div className="bg-gradient-to-br from-sky-50 to-blue-50 rounded-xl sm:rounded-2xl p-4 sm:p-6 border border-sky-200 hover:shadow-lg transition-all duration-300">
              <div className="flex items-center mb-3 sm:mb-4">
                <CheckCircle className="w-5 h-5 sm:w-6 sm:h-6 text-sky-600 mr-2 sm:mr-3" />
                <h3 className="font-semibold text-gray-900 text-sm sm:text-base">
                  ✔ Transparency
                </h3>
              </div>
              <p className="text-gray-700 text-xs sm:text-sm">
                Clear systems, no hidden terms
              </p>
            </div>

            <div className="bg-gradient-to-br from-sky-50 to-cyan-50 rounded-xl sm:rounded-2xl p-4 sm:p-6 border border-sky-200 hover:shadow-lg transition-all duration-300">
              <div className="flex items-center mb-3 sm:mb-4">
                <Shield className="w-5 h-5 sm:w-6 sm:h-6 text-sky-600 mr-2 sm:mr-3" />
                <h3 className="font-semibold text-gray-900 text-sm sm:text-base">
                  ✔ Trust
                </h3>
              </div>
              <p className="text-gray-700 text-xs sm:text-sm">
                User-first approach with secure payouts
              </p>
            </div>

            <div className="bg-gradient-to-br from-blue-50 to-indigo-50 rounded-xl sm:rounded-2xl p-4 sm:p-6 border border-sky-200 hover:shadow-lg transition-all duration-300">
              <div className="flex items-center mb-3 sm:mb-4">
                <TrendingUp className="w-5 h-5 sm:w-6 sm:h-6 text-sky-600 mr-2 sm:mr-3" />
                <h3 className="font-semibold text-gray-900 text-sm sm:text-base">
                  ✔ Growth
                </h3>
              </div>
              <p className="text-gray-700 text-xs sm:text-sm">
                Helping users upgrade skills & income
              </p>
            </div>

            <div className="bg-gradient-to-br from-cyan-50 to-sky-50 rounded-xl sm:rounded-2xl p-4 sm:p-6 border border-sky-200 hover:shadow-lg transition-all duration-300">
              <div className="flex items-center mb-3 sm:mb-4">
                <Zap className="w-5 h-5 sm:w-6 sm:h-6 text-sky-600 mr-2 sm:mr-3" />
                <h3 className="font-semibold text-gray-900 text-sm sm:text-base">
                  ✔ Innovation
                </h3>
              </div>
              <p className="text-gray-700 text-xs sm:text-sm">
                Always introducing smarter digital opportunities
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Community Message */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 sm:py-8">
        <div className="bg-gradient-to-r from-sky-600 to-blue-600 rounded-2xl sm:rounded-3xl p-4 sm:p-6 md:p-8 text-center text-white shadow-2xl">
          <div className="flex items-center justify-center mb-3 sm:mb-4">
            <div className="bg-white/20 p-3 sm:p-4 rounded-xl sm:rounded-2xl">
              <Users className="w-6 h-6 sm:w-8 sm:h-8 text-white" />
            </div>
          </div>
          <h2 className="text-lg sm:text-2xl md:text-3xl font-bold mb-3 sm:mb-4">
            🎗️ Building a Community of Achievers
          </h2>
          <p className="text-sm sm:text-lg md:text-xl leading-relaxed max-w-4xl mx-auto">
            At SkyBridge International, we don't just offer a platform — we
            are building a community of achievers ready to shape the future of
            the digital economy.
          </p>
        </div>
      </div>

      {/* Call to Action */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 sm:py-8">
        <div className="text-center bg-gradient-to-r from-sky-600 to-blue-600 rounded-xl p-6 sm:p-8 text-white">
          <h3 className="text-xl sm:text-3xl font-bold mb-3 sm:mb-4">
            Ready to Start Earning?
          </h3>
          <p className="text-sm sm:text-xl mb-4 sm:mb-6 opacity-90">
            Join thousands of users who are already earning with SkyBridge
            International
          </p>
          <Link
            to="/register"
            className="inline-flex items-center space-x-2 bg-white text-sky-600 px-6 py-3 sm:px-8 sm:py-4 rounded-xl font-semibold text-base sm:text-lg hover:bg-gray-100 transition-colors"
          >
            <Play className="w-4 h-4 sm:w-5 sm:h-5" />
            <span>Get Started Today</span>
          </Link>
        </div>
      </div>
    </div>
  );
};

export default AboutContent;
