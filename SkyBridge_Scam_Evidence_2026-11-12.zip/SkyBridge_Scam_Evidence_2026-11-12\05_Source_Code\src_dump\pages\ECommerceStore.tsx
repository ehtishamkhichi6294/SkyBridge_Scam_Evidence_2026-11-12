import React, { useState, useEffect, useCallback, useMemo } from "react";
import { useCurrency, type Currency } from "../contexts/CurrencyContext";
import {
  Store,
  ShoppingBag,
  Clock,
  CheckCircle,
  PackageSearch,
  X,
  Filter,
  ChevronDown,
} from "lucide-react";
import { useNavigate } from "react-router-dom";
import {
  productService,
  purchaseRequestService,
  type Product as ProductType,
  type PurchaseRequest as PurchaseRequestType,
} from "../services";
import { parseEmojis } from "../utils/emojiUtils";
import { API_ENDPOINTS } from "../config/api";
import { apiClient } from "../services/apiClient";
import VideoTutorialSection from "../components/VideoTutorialSection";
// Downloads disabled: removing direct download support for product images

// Extended product type for display (with computed fields)
type DisplayProduct = Omit<ProductType, "price" | "original_price"> & {
  price: number; // Override to number for formatting
  original_price?: number; // Convert to number
  image?: string;
  earningPerSale?: number;
  inStock?: boolean;
};

// Extended purchase request type for display (with computed fields)
type DisplayPurchaseRequest = PurchaseRequestType & {
  productName: string; // Required for display
  createdAt: string; // Required for display
};

const PRODUCTS_PER_PAGE = 10;

const mapApiProduct = (product: ProductType): DisplayProduct => {
  const priceNum = parseFloat(product.price || "0");
  const originalPriceNum = product.original_price
    ? parseFloat(product.original_price)
    : undefined;
  const profitPercentage = parseFloat(product.user_profit_percentage || "0");
  const earningPerSaleUSD = (priceNum * profitPercentage) / 100;

  return {
    ...product,
    image:
      product.images && product.images.length > 0
        ? product.images[0]
        : undefined,
    price: priceNum,
    original_price: originalPriceNum,
    earningPerSale: earningPerSaleUSD,
    inStock: product.is_out_of_stock ? false : true,
  } as DisplayProduct;
};

const ECommerceStore: React.FC = () => {
  const { currency, setCurrency, formatCurrency } = useCurrency();
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState<"products" | "requests">(
    "products",
  );
  const [selectedCategory, setSelectedCategory] = useState<string>("all");
  const [products, setProducts] = useState<DisplayProduct[]>([]);
  const [requests, setRequests] = useState<DisplayPurchaseRequest[]>([]);
  const [requestingProduct, setRequestingProduct] =
    useState<DisplayProduct | null>(null);
  const [note, setNote] = useState<string>("");
  const [fullName, setFullName] = useState<string>("");
  const [phone, setPhone] = useState<string>("");
  const [address, setAddress] = useState<string>("");
  const [secondPhoneNumber, setSecondPhoneNumber] = useState<string>("");
  const [paymentScreenshot, setPaymentScreenshot] = useState<File | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [loading, setLoading] = useState(true);
  const [loadingRequests, setLoadingRequests] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [fieldErrors, setFieldErrors] = useState<Record<string, string>>({});
  const [totalEarnings, setTotalEarnings] = useState<number>(0);
  const [loadingEarnings, setLoadingEarnings] = useState(false);
  const [productAccountsList, setProductAccountsList] = useState<any[]>([]);
  const [productsPage, setProductsPage] = useState(1);
  const [productsLastPage, setProductsLastPage] = useState(1);
  const [productsTotal, setProductsTotal] = useState(0);
  const [categoryOptions, setCategoryOptions] = useState<string[]>([]);
  const fetchProducts = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);
      const response = await productService.listProducts({
        page: productsPage,
        per_page: PRODUCTS_PER_PAGE,
        category: selectedCategory !== "all" ? selectedCategory : undefined,
      });
      if (response.success && response.data) {
        const paginatedData = response.data;

        let productsArray: ProductType[] = [];

        if (Array.isArray(paginatedData)) {
          productsArray = paginatedData;
          setProductsLastPage(1);
          setProductsTotal(productsArray.length);
        } else if (
          paginatedData &&
          typeof paginatedData === "object" &&
          "data" in paginatedData &&
          Array.isArray(paginatedData.data)
        ) {
          productsArray = paginatedData.data;
          setProductsLastPage(paginatedData.last_page ?? 1);
          setProductsTotal(paginatedData.total ?? productsArray.length);
        }

        setProducts(productsArray.map(mapApiProduct));
      }
    } catch (err: any) {
      setError(err.message || "Failed to load products");
      console.error("Error fetching products:", err);
    } finally {
      setLoading(false);
    }
  }, [productsPage, selectedCategory]);

  const fetchCategoryOptions = useCallback(async () => {
    try {
      const response = await productService.listProducts({
        page: 1,
        per_page: 100,
      });
      if (response.success && response.data) {
        const paginatedData = response.data;
        let productsArray: ProductType[] = [];
        if (Array.isArray(paginatedData)) {
          productsArray = paginatedData;
        } else if (
          paginatedData &&
          typeof paginatedData === "object" &&
          "data" in paginatedData &&
          Array.isArray(paginatedData.data)
        ) {
          productsArray = paginatedData.data;
        }
        const uniqueCategories = Array.from(
          new Set(productsArray.map((p) => p.category || "").filter(Boolean)),
        ).sort((a, b) => a.localeCompare(b));
        setCategoryOptions(uniqueCategories);
      }
    } catch (err) {
      console.error("Error fetching categories:", err);
    }
  }, []);

  // Fetch total earnings from API
  const fetchEarnings = useCallback(async () => {
    try {
      setLoadingEarnings(true);
      setError(null);
      const response = await purchaseRequestService.getEarnings();
      if (response.success && response.data) {
        // Handle both nested data.data structure and direct data structure
        const earningsData = response.data?.data || response.data;
        // API returns total_earnings in USD
        setTotalEarnings(earningsData?.total_earnings || 0);
      } else {
        console.warn("Earnings response not successful:", response);
        setTotalEarnings(0);
      }
    } catch (err: any) {
      console.error("Error fetching earnings:", err);
      // Don't set error state for earnings fetch to avoid blocking UI
      // Just set earnings to 0 and log the error
      setTotalEarnings(0);
    } finally {
      setLoadingEarnings(false);
    }
  }, []);

  // Fetch purchase requests
  const fetchPurchaseRequests = useCallback(async () => {
    try {
      setLoadingRequests(true);
      const response = await purchaseRequestService.getPurchaseHistory();
      if (response.success && response.data) {
        // Handle paginated response - purchase requests are in data.data
        const paginatedData = response.data;

        // Check if it's a paginated response (has 'data' array property) or direct array
        let requestsArray: PurchaseRequestType[] = [];

        if (Array.isArray(paginatedData)) {
          // Direct array response (unlikely but handle it)
          requestsArray = paginatedData;
        } else if (
          paginatedData &&
          typeof paginatedData === "object" &&
          "data" in paginatedData &&
          Array.isArray(paginatedData.data)
        ) {
          // Paginated response with nested data.data
          requestsArray = paginatedData.data;
        }

        // Map API purchase requests to include computed fields
        const mappedRequests: DisplayPurchaseRequest[] = requestsArray.map(
          (request: PurchaseRequestType) => {
            return {
              ...request,
              // Extract product name from nested product object
              productName:
                request.product?.name ||
                request.productName ||
                "Unknown Product",
              // Map field names for display (use created_at from API, fallback to createdAt if exists)
              createdAt:
                request.created_at ||
                request.createdAt ||
                new Date().toISOString(),
              // Keep original fields for backward compatibility
              fullName: request.full_name || request.fullName,
              phone: request.phone_number || request.phone,
              secondPhoneNumber:
                (request as any).second_phone_number ||
                (request as any).secondPhoneNumber,
            } as DisplayPurchaseRequest;
          },
        );

        setRequests(mappedRequests);
      }
    } catch (err: any) {
      console.error("Error fetching purchase requests:", err);
    } finally {
      setLoadingRequests(false);
    }
  }, []);

  // Fetch product_request account details on mount
  useEffect(() => {
    (async () => {
      try {
        const res = await apiClient.get<any>(
          `${API_ENDPOINTS.ACCOUNT}?type=product_request`,
        );
        if (res.data) {
          const d = res.data;
          setProductAccountsList(Array.isArray(d) ? d : [d]);
        }
      } catch (err) {
        console.error("Failed to load product request accounts:", err);
      }
    })();
  }, []);

  useEffect(() => {
    fetchCategoryOptions();
  }, [fetchCategoryOptions]);

  useEffect(() => {
    fetchProducts();
  }, [fetchProducts]);

  // Fetch earnings on mount
  useEffect(() => {
    fetchEarnings();
  }, [fetchEarnings]);

  // Fetch purchase requests on mount
  useEffect(() => {
    fetchPurchaseRequests();
  }, [fetchPurchaseRequests]);

  // Also fetch when switching to requests tab to ensure fresh data
  useEffect(() => {
    if (activeTab === "requests") {
      fetchPurchaseRequests();
      // Refresh earnings when switching to requests tab
      fetchEarnings();
    }
  }, [activeTab, fetchPurchaseRequests, fetchEarnings]);

  const categories = useMemo(() => {
    return ["all", ...categoryOptions];
  }, [categoryOptions]);

  const getStatusStyles = (status: PurchaseRequestType["status"]) => {
    if (status === "approved")
      return "bg-emerald-100 text-emerald-700 border-emerald-200";
    if (status === "rejected") return "bg-red-100 text-red-700 border-red-200";
    return "bg-amber-50 text-amber-700 border-amber-200";
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-sky-50 to-indigo-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-8">
          <div>
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-sky-100 text-sky-700 border border-sky-200 text-xs sm:text-sm font-semibold mb-3">
              <Store className="w-4 h-4" />
              <span>E-Commerce Store</span>
            </div>
            <h1 className="text-2xl sm:text-3xl lg:text-4xl font-extrabold text-gray-900 tracking-tight">
              Discover SkyBridge Products
            </h1>
            <p className="mt-2 text-gray-600 max-w-2xl text-sm sm:text-base">
              Browse products added by the admin and track your purchase
              requests in one place.
            </p>
          </div>
          {/* Currency Dropdown */}
          <div className="flex items-center gap-2">
            <label
              htmlFor="currency-select"
              className="text-sm font-medium text-gray-700 whitespace-nowrap"
            >
              Currency:
            </label>
            <div className="relativ  flex items-center gap-2">
              <select
                id="currency-select"
                value={currency}
                onChange={(e) => setCurrency(e.target.value as Currency)}
                className="appearance-none bg-white border border-slate-300 rounded-lg px-4 py-2 pr-10 text-sm font-semibold text-gray-700 focus:outline-none focus:ring-2 focus:ring-sky-500 focus:border-sky-500 hover:border-sky-400 transition-colors cursor-pointer shadow-sm"
              >
                <option value="PKR">PKR (₨)</option>
                <option value="USD">USD ($)</option>
              </select>
              <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500 pointer-events-none" />
              <VideoTutorialSection
                buttonOnly
                navigateTo="/affiliate-course/43"
                buttonLabel="Watch Tutorials"
                buttonClassName="inline-flex items-center justify-center gap-2 px-4 sm:px-5 py-2 sm:py-2.5 rounded-full bg-white border border-sky-600 text-sky-600 font-medium text-xs sm:text-sm hover:bg-sky-50 transition-all active:scale-95"
              />
            </div>
          </div>
        </div>

        {/* User earning info card */}
        <div className="mb-6">
          <div className="w-full bg-white rounded-2xl shadow-lg px-5 py-4 sm:px-6 sm:py-5 flex items-center gap-4">
            <div className="w-12 h-12 sm:w-14 sm:h-14 rounded-full bg-sky-600 flex items-center justify-center shadow-md flex-shrink-0">
              <CheckCircle className="w-6 h-6 text-white" />
            </div>
            <div className="flex flex-col">
              {loadingEarnings ? (
                <span className="text-2xl sm:text-3xl font-extrabold text-gray-400">
                  Loading...
                </span>
              ) : (
                <span className="text-2xl sm:text-3xl font-extrabold text-gray-900">
                  {formatCurrency(totalEarnings)}
                </span>
              )}
              <span className="mt-1 text-xs sm:text-sm font-semibold tracking-wide text-sky-700 uppercase">
                Total Earnings Earned
              </span>
            </div>
          </div>
        </div>

        {/* Tabs */}
        <div className="bg-white rounded-2xl shadow-sm border border-slate-200 mb-8">
          <div className="flex border-b border-slate-200">
            <button
              type="button"
              onClick={() => setActiveTab("products")}
              className={`flex-1 px-4 sm:px-6 py-3 sm:py-4 text-sm sm:text-base font-semibold flex items-center justify-center gap-2 border-b-2 transition-colors ${
                activeTab === "products"
                  ? "border-sky-500 text-sky-700 bg-sky-50"
                  : "border-transparent text-gray-500 hover:text-sky-600 hover:bg-slate-50"
              }`}
            >
              <ShoppingBag className="w-4 h-4" />
              <span>Products</span>
            </button>
            <button
              type="button"
              onClick={() => setActiveTab("requests")}
              className={`flex-1 px-4 sm:px-6 py-3 sm:py-4 text-sm sm:text-base font-semibold flex items-center justify-center gap-2 border-b-2 transition-colors ${
                activeTab === "requests"
                  ? "border-sky-500 text-sky-700 bg-sky-50"
                  : "border-transparent text-gray-500 hover:text-sky-600 hover:bg-slate-50"
              }`}
            >
              <Clock className="w-4 h-4" />
              <span>My Purchase Requests</span>
            </button>
          </div>

          {/* Content */}
          <div className="p-4 sm:p-6 lg:p-8">
            {activeTab === "products" ? (
              <>
                {loading ? (
                  <div className="py-12 flex flex-col items-center text-center text-gray-500">
                    <PackageSearch className="w-10 h-10 mb-3 text-sky-400 animate-pulse" />
                    <p className="font-semibold">Loading products...</p>
                  </div>
                ) : error ? (
                  <div className="py-12 flex flex-col items-center text-center text-red-500">
                    <PackageSearch className="w-10 h-10 mb-3 text-red-400" />
                    <p className="font-semibold">Error loading products</p>
                    <p className="text-sm text-red-400 mt-1">{error}</p>
                    <button
                      type="button"
                      onClick={() => fetchProducts()}
                      className="mt-4 px-4 py-2 rounded-lg bg-sky-600 text-white text-sm font-semibold hover:bg-sky-700"
                    >
                      Retry
                    </button>
                  </div>
                ) : products.length === 0 ? (
                  <div className="py-12 flex flex-col items-center text-center text-gray-500">
                    <PackageSearch className="w-10 h-10 mb-3 text-sky-400" />
                    <p className="font-semibold">No products available yet.</p>
                    <p className="text-sm text-gray-400 mt-1">
                      Please check back later.
                    </p>
                  </div>
                ) : (
                  <>
                    <div className="mb-4 flex items-center gap-3">
                      <label
                        htmlFor="category-filter"
                        className="flex items-center gap-2 text-sm font-semibold text-gray-700 whitespace-nowrap"
                      >
                        <Filter className="w-4 h-4 text-sky-600" />
                        <span>Filter by Category:</span>
                      </label>
                      <div className="relative flex-1 max-w-xs">
                        <select
                          id="category-filter"
                          value={selectedCategory}
                          onChange={(e) => {
                            setSelectedCategory(e.target.value);
                            setProductsPage(1);
                          }}
                          className="w-full appearance-none bg-white border border-slate-300 rounded-lg px-4 py-2.5 pr-10 text-sm font-medium text-gray-700 focus:outline-none focus:ring-2 focus:ring-sky-500 focus:border-sky-500 hover:border-sky-400 transition-colors cursor-pointer"
                        >
                          {categories.map((cat) => (
                            <option key={cat} value={cat}>
                              {cat === "all" ? "All Categories" : cat}
                            </option>
                          ))}
                        </select>
                        <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500 pointer-events-none" />
                      </div>
                      <span className="text-xs text-gray-500">
                        {productsTotal}{" "}
                        {productsTotal === 1 ? "product" : "products"} total
                      </span>
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                      {products.map((product) => (
                        <div
                          key={product.id}
                          className="bg-white border border-slate-200 rounded-2xl shadow-sm hover:shadow-md transition-shadow flex flex-col cursor-pointer"
                          onClick={() =>
                            navigate(`/ecommerce-store/${product.id}`)
                          }
                        >
                          {/* Product image section - taller height for better visibility */}
                          <div className="relative w-full h-72 bg-gradient-to-br from-sky-100 via-slate-100 to-indigo-100 flex items-center justify-center text-sky-500 overflow-hidden group">
                            {product.image ? (
                              <>
                                <img
                                  src={product.image}
                                  alt={product.name}
                                  className={`w-full h-full object-cover`}
                                  onError={(e) => {
                                    const target = e.target as HTMLImageElement;
                                    target.style.display = "none";
                                    target.parentElement?.classList.add(
                                      "flex",
                                      "items-center",
                                      "justify-center",
                                    );
                                  }}
                                />
                              </>
                            ) : (
                              <ShoppingBag className="w-10 h-10" />
                            )}
                            {!product.inStock && (
                              <span className="absolute top-3 right-3 z-10 px-3 py-1.5 bg-red-600 text-white text-xs sm:text-sm font-bold rounded-full shadow">
                                Out of Stock
                              </span>
                            )}
                          </div>
                          <div className="p-4 sm:p-5 flex-1 flex flex-col">
                            <h2 className="text-base sm:text-lg font-bold text-gray-900 mb-1 line-clamp-2">
                              {product.name}
                            </h2>
                            <p className="text-xs sm:text-sm text-gray-600 mb-3 line-clamp-3 whitespace-pre-line">
                              {parseEmojis(product.description)}
                            </p>
                            <div className="mt-auto flex items-center justify-between gap-3 pt-3 border-t border-slate-100">
                              <div className="flex flex-col">
                                {(() => {
                                  // Backend: price = discounted price (USD), original_price = base price (USD)
                                  const discountedPrice = product.price || 0;
                                  const originalPrice =
                                    product.original_price != null
                                      ? product.original_price
                                      : discountedPrice;

                                  // Calculate discount percentage from original and discounted prices
                                  let discountPercent = 0;
                                  if (
                                    originalPrice > 0 &&
                                    discountedPrice < originalPrice
                                  ) {
                                    discountPercent =
                                      ((originalPrice - discountedPrice) /
                                        originalPrice) *
                                      100;
                                  }

                                  const hasDiscount =
                                    discountPercent > 0 &&
                                    discountedPrice < originalPrice;

                                  if (!hasDiscount) {
                                    return (
                                      <>
                                        <span className="text-xs text-gray-500">
                                          Price
                                        </span>
                                        <span className="text-base sm:text-lg font-extrabold text-sky-700">
                                          {formatCurrency(originalPrice)}
                                        </span>
                                      </>
                                    );
                                  }

                                  return (
                                    <>
                                      {/* Original price (struck-through) */}
                                      <span className="text-xs text-gray-500 line-through">
                                        {formatCurrency(originalPrice)}
                                      </span>

                                      {/* Discount badge */}
                                      <span className="inline-flex items-center px-2 py-0.5 rounded-full bg-green-50 text-green-700 text-[11px] font-semibold border border-green-200 mt-0.5 mb-0.5 w-fit">
                                        {discountPercent.toFixed(2)}% OFF
                                      </span>

                                      {/* Discounted price */}
                                      <span className="text-xs text-gray-500">
                                        Discounted Price
                                      </span>
                                      <span className="text-base sm:text-lg font-extrabold text-sky-700">
                                        {formatCurrency(discountedPrice)}
                                      </span>

                                      {/* Explicit discount percentage text */}
                                      <span className="mt-0.5 text-[11px] sm:text-xs text-gray-500">
                                        Discount: {discountPercent.toFixed(2)}%
                                      </span>
                                    </>
                                  );
                                })()}

                                {product.earningPerSale &&
                                  (() => {
                                    const profitPercent = parseFloat(
                                      product.user_profit_percentage || "0",
                                    );
                                    return (
                                      <>
                                        {/* User Profit Percentage Badge */}
                                        <span className="inline-flex items-center px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-700 text-[11px] font-semibold border border-emerald-200 mt-1 mb-1 w-fit">
                                          {profitPercent.toFixed(2)}% Profit
                                        </span>
                                        {product.earningPerSale && (
                                          <div className="mt-2 rounded-lg bg-emerald-50 border border-emerald-200 p-2">
                                            <p className="text-[11px] sm:text-xs font-semibold text-emerald-900">
                                              💰 Earning Opportunity
                                            </p>
                                            <p className="text-[11px] sm:text-xs text-emerald-700 mt-1">
                                              If you sell this product, you will
                                              earn{" "}
                                              <span className="font-bold">
                                                {formatCurrency(
                                                  product.earningPerSale,
                                                )}
                                              </span>
                                            </p>
                                          </div>
                                        )}
                                      </>
                                    );
                                  })()}
                              </div>
                              <div className="flex flex-col items-end">
                                <button
                                  type="button"
                                  className={`mt-2 inline-flex items-center justify-center px-3 py-1.5 rounded-lg text-xs sm:text-sm font-semibold shadow-sm disabled:opacity-60 disabled:cursor-not-allowed ${
                                    product.inStock
                                      ? "bg-sky-600 text-white hover:bg-sky-700"
                                      : "bg-gray-400 text-white cursor-not-allowed"
                                  }`}
                                  disabled={!product.inStock}
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    if (!product.inStock) return;
                                    setRequestingProduct(product);
                                    setNote("");
                                    setFullName("");
                                    setPhone("");
                                    setAddress("");
                                    setSecondPhoneNumber("");
                                    setFieldErrors({});
                                    setError(null);
                                  }}
                                >
                                  {!product.inStock ? "Out of Stock" : "Buy Now"}
                                </button>
                              </div>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>

                    {productsTotal > 0 && productsLastPage > 1 && (
                      <div className="mt-8 flex flex-col sm:flex-row items-center justify-between gap-3 p-4 border border-slate-200 rounded-xl bg-slate-50">
                        <div className="text-sm font-medium text-gray-700">
                          {(() => {
                            const start =
                              productsTotal === 0
                                ? 0
                                : (productsPage - 1) * PRODUCTS_PER_PAGE + 1;
                            const end = Math.min(
                              productsPage * PRODUCTS_PER_PAGE,
                              productsTotal,
                            );
                            return `Showing ${start}-${end} of ${productsTotal}`;
                          })()}
                        </div>
                        <div className="flex flex-wrap items-center justify-center gap-2">
                          <span className="text-xs text-gray-500 px-2">
                            10 / page
                          </span>
                          <button
                            type="button"
                            disabled={productsPage === 1}
                            onClick={() => setProductsPage(1)}
                            className="px-3 py-1.5 text-sm font-medium rounded-lg border border-gray-300 disabled:opacity-40 disabled:cursor-not-allowed hover:bg-white"
                          >
                            First
                          </button>
                          <button
                            type="button"
                            disabled={productsPage === 1}
                            onClick={() =>
                              setProductsPage((p) => Math.max(1, p - 1))
                            }
                            className="px-3 py-1.5 text-sm font-medium rounded-lg border border-gray-300 disabled:opacity-40 disabled:cursor-not-allowed hover:bg-white"
                          >
                            Prev
                          </button>
                          {Array.from({
                            length: Math.min(5, productsLastPage),
                          }).map((_, idx) => {
                            const windowStart = Math.max(
                              1,
                              Math.min(productsPage - 2, productsLastPage - 4),
                            );
                            const pageNum = windowStart + idx;
                            if (pageNum > productsLastPage) return null;
                            const isActive = pageNum === productsPage;
                            return (
                              <button
                                key={pageNum}
                                type="button"
                                onClick={() => setProductsPage(pageNum)}
                                className={`px-3 py-1.5 text-sm font-semibold rounded-lg border ${
                                  isActive
                                    ? "bg-sky-600 text-white border-sky-600"
                                    : "border-gray-300 hover:bg-white"
                                }`}
                              >
                                {pageNum}
                              </button>
                            );
                          })}
                          <button
                            type="button"
                            disabled={productsPage >= productsLastPage}
                            onClick={() =>
                              setProductsPage((p) =>
                                Math.min(productsLastPage, p + 1),
                              )
                            }
                            className="px-3 py-1.5 text-sm font-medium rounded-lg border border-gray-300 disabled:opacity-40 disabled:cursor-not-allowed hover:bg-white"
                          >
                            Next
                          </button>
                          <button
                            type="button"
                            disabled={productsPage >= productsLastPage}
                            onClick={() => setProductsPage(productsLastPage)}
                            className="px-3 py-1.5 text-sm font-medium rounded-lg border border-gray-300 disabled:opacity-40 disabled:cursor-not-allowed hover:bg-white"
                          >
                            Last
                          </button>
                        </div>
                      </div>
                    )}
                  </>
                )}
              </>
            ) : (
              <>
                {loadingRequests ? (
                  <div className="py-12 flex flex-col items-center text-center text-gray-500">
                    <PackageSearch className="w-10 h-10 mb-3 text-sky-400 animate-pulse" />
                    <p className="font-semibold">
                      Loading purchase requests...
                    </p>
                  </div>
                ) : requests.length === 0 ? (
                  <div className="py-12 flex flex-col items-center text-center text-gray-500">
                    <PackageSearch className="w-10 h-10 mb-3 text-sky-400" />
                    <p className="font-semibold">
                      You have no purchase requests yet.
                    </p>
                    <p className="text-sm text-gray-400 mt-1">
                      Start by requesting a product from the Products tab.
                    </p>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {requests.map((req) => (
                      <div
                        key={req.id}
                        className="flex flex-col gap-2 p-4 sm:p-5 bg-slate-50 border border-slate-200 rounded-2xl"
                      >
                        <div className="flex items-start justify-between gap-3">
                          <div className="flex items-start gap-3">
                            <div className="mt-0.5 w-9 h-9 rounded-full bg-sky-100 flex items-center justify-center text-sky-600">
                              <CheckCircle className="w-5 h-5" />
                            </div>
                            <div>
                              <p className="text-sm sm:text-base font-semibold text-gray-900">
                                {req.productName}
                              </p>
                              <p className="text-xs text-gray-500 mt-1">
                                Requested on{" "}
                                {req.createdAt
                                  ? new Date(req.createdAt).toLocaleDateString()
                                  : "Unknown date"}
                              </p>
                            </div>
                          </div>
                          <span
                            className={`px-2.5 py-1 rounded-full text-[11px] font-semibold border whitespace-nowrap ${getStatusStyles(
                              req.status,
                            )}`}
                          >
                            {req.status.charAt(0).toUpperCase() +
                              req.status.slice(1)}
                          </span>
                        </div>
                        {req.status === "rejected" && req.rejection_reason && (
                          <div className="ml-12 mt-1 px-3 py-2 bg-red-50 border border-red-200 rounded-lg">
                            <p className="text-xs font-semibold text-red-700">
                              Rejection Reason:
                            </p>
                            <p className="text-xs text-red-600 mt-0.5 leading-snug">
                              {req.rejection_reason}
                            </p>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </>
            )}
          </div>
        </div>
        {requestingProduct && (
          <div className="fixed inset-0 z-50 flex items-start justify-center bg-black/50 px-4 py-6 overflow-y-auto">
            <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full p-6 relative mt-auto mb-auto max-h-[90vh] overflow-y-auto">
              <button
                type="button"
                className="absolute top-3 right-3 p-1 rounded-full hover:bg-slate-100"
                onClick={() => {
                  if (!submitting) {
                    setRequestingProduct(null);
                    setFieldErrors({});
                    setError(null);
                  }
                }}
              >
                <X className="w-4 h-4 text-slate-500" />
              </button>
              <h2 className="text-xl font-bold text-gray-900 mb-1">
                Request Purchase
              </h2>
              <p className="text-sm text-gray-500 mb-4">
                {requestingProduct.name}
              </p>
              <div className="mb-4 rounded-xl border border-amber-200 bg-amber-50 px-3 py-2 text-xs text-amber-800">
                <p className="font-semibold">Important:</p>
                <p className="mt-1">
                  You must pay{" "}
                  <span className="font-bold text-amber-700">250 rupees</span>{" "}
                  as delivery charges before your order is processed. Send your
                  payment screenshot in the form below.
                </p>
                {productAccountsList.length > 0 ? (
                  <div className="mt-2 space-y-1.5">
                    {productAccountsList.map((acc, idx) => (
                      <div
                        key={acc.id ?? idx}
                        className="p-1.5 bg-white/60 rounded"
                      >
                        <span className="font-mono font-bold">
                          {acc.account_number}
                        </span>
                        <br />
                        <span className="font-semibold">
                          Payment Method:
                        </span>{" "}
                        {acc.bank}
                        <br />
                        <span className="font-semibold">
                          Account Name:
                        </span>{" "}
                        {acc.account_title}
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="mt-1 text-amber-600">
                    Loading payment details...
                  </p>
                )}
              </div>
              <form
                onSubmit={async (e) => {
                  e.preventDefault();
                  if (!requestingProduct) return;

                  try {
                    setSubmitting(true);
                    setError(null);
                    setFieldErrors({});

                    const response =
                      await purchaseRequestService.createPurchaseRequest({
                        productId: requestingProduct.id,
                        fullName,
                        phone,
                        address,
                        secondPhoneNumber: secondPhoneNumber || undefined,
                        note: note || undefined,
                        paymentScreenshot: paymentScreenshot || undefined,
                      });

                    if (response.success) {
                      // Reset form
                      setRequestingProduct(null);
                      setNote("");
                      setFullName("");
                      setPhone("");
                      setAddress("");
                      setSecondPhoneNumber("");
                      setPaymentScreenshot(null);
                      setFieldErrors({});
                      setActiveTab("requests");
                      // Refresh purchase requests and earnings
                      await fetchPurchaseRequests();
                      await fetchEarnings();
                    }
                  } catch (err: any) {
                    console.error("Error submitting purchase request:", err);

                    // Handle validation errors
                    if (err.data?.errors) {
                      const validationErrors = err.data.errors;
                      const mappedFieldErrors: Record<string, string> = {};

                      // Map backend field names to frontend field names
                      const fieldMapping: Record<string, string> = {
                        phone_number: "phone",
                        full_name: "fullName",
                        second_phone_number: "secondPhoneNumber",
                        product_id: "productId",
                        payment_screenshot: "paymentScreenshot",
                      };

                      // Extract first error message for each field
                      for (const [key, value] of Object.entries(
                        validationErrors,
                      )) {
                        const frontendKey = fieldMapping[key] || key;
                        const firstError = Array.isArray(value)
                          ? value[0]
                          : String(value);
                        mappedFieldErrors[frontendKey] = firstError;
                      }

                      setFieldErrors(mappedFieldErrors);

                      // Show first error as general message
                      const firstErrorValue =
                        Object.values(mappedFieldErrors)[0];
                      setError(
                        firstErrorValue ||
                          err.data?.message ||
                          "Validation failed. Please check the form.",
                      );
                    } else {
                      setError(
                        err.message ||
                          err.data?.message ||
                          "Failed to submit purchase request",
                      );
                    }
                  } finally {
                    setSubmitting(false);
                  }
                }}
                className="space-y-4"
              >
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Full Name
                  </label>
                  <input
                    type="text"
                    value={fullName}
                    onChange={(e) => {
                      setFullName(e.target.value);
                      if (fieldErrors.fullName) {
                        setFieldErrors((prev) => {
                          const updated = { ...prev };
                          delete updated.fullName;
                          return updated;
                        });
                      }
                    }}
                    className={`w-full rounded-lg border px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-sky-500 focus:border-sky-500 ${
                      fieldErrors.fullName
                        ? "border-red-300"
                        : "border-slate-300"
                    }`}
                    required
                  />
                  {fieldErrors.fullName && (
                    <p className="mt-1 text-xs text-red-600">
                      {fieldErrors.fullName}
                    </p>
                  )}
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Phone Number
                  </label>
                  <input
                    type="tel"
                    value={phone}
                    onChange={(e) => {
                      setPhone(e.target.value);
                      if (fieldErrors.phone) {
                        setFieldErrors((prev) => {
                          const updated = { ...prev };
                          delete updated.phone;
                          return updated;
                        });
                      }
                    }}
                    className={`w-full rounded-lg border px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-sky-500 focus:border-sky-500 ${
                      fieldErrors.phone ? "border-red-300" : "border-slate-300"
                    }`}
                    required
                  />
                  {fieldErrors.phone && (
                    <p className="mt-1 text-xs text-red-600">
                      {fieldErrors.phone}
                    </p>
                  )}
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Address
                  </label>
                  <textarea
                    rows={3}
                    value={address}
                    onChange={(e) => {
                      setAddress(e.target.value);
                      if (fieldErrors.address) {
                        setFieldErrors((prev) => {
                          const updated = { ...prev };
                          delete updated.address;
                          return updated;
                        });
                      }
                    }}
                    className={`w-full rounded-lg border px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-sky-500 focus:border-sky-500 resize-none ${
                      fieldErrors.address
                        ? "border-red-300"
                        : "border-slate-300"
                    }`}
                    placeholder="House / Street / City"
                    required
                  />
                  {fieldErrors.address && (
                    <p className="mt-1 text-xs text-red-600">
                      {fieldErrors.address}
                    </p>
                  )}
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    2nd Phone Number (Optional)
                  </label>
                  <input
                    type="text"
                    value={secondPhoneNumber}
                    onChange={(e) => {
                      setSecondPhoneNumber(e.target.value);
                      if (fieldErrors.secondPhoneNumber) {
                        setFieldErrors((prev) => {
                          const updated = { ...prev };
                          delete updated.secondPhoneNumber;
                          return updated;
                        });
                      }
                    }}
                    className={`w-full rounded-lg border px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-sky-500 focus:border-sky-500 ${
                      fieldErrors.secondPhoneNumber
                        ? "border-red-300"
                        : "border-slate-300"
                    }`}
                    placeholder="Optional"
                  />
                  {fieldErrors.secondPhoneNumber && (
                    <p className="mt-1 text-xs text-red-600">
                      {fieldErrors.secondPhoneNumber}
                    </p>
                  )}
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Note (optional)
                  </label>
                  <textarea
                    rows={3}
                    value={note}
                    onChange={(e) => setNote(e.target.value)}
                    className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-sky-500 focus:border-sky-500 resize-none"
                    placeholder="Add any details or delivery instructions"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Payment Screenshot (delivery charges)
                  </label>
                  <input
                    type="file"
                    accept="image/*"
                    onChange={(e) => {
                      const file = e.target.files?.[0];
                      if (file) {
                        setPaymentScreenshot(file);
                        if (fieldErrors.paymentScreenshot) {
                          setFieldErrors((prev) => {
                            const updated = { ...prev };
                            delete updated.paymentScreenshot;
                            return updated;
                          });
                        }
                      }
                    }}
                    className="block w-full text-xs text-gray-500 file:mr-3 file:py-1.5 file:px-3 file:rounded-lg file:border-0 file:text-xs file:font-semibold file:bg-sky-50 file:text-sky-700 hover:file:bg-sky-100"
                  />
                  {paymentScreenshot && (
                    <p className="mt-1 text-xs text-gray-600">
                      Selected: {paymentScreenshot.name}
                    </p>
                  )}
                  {fieldErrors.paymentScreenshot && (
                    <p className="mt-1 text-xs text-red-600">
                      {fieldErrors.paymentScreenshot}
                    </p>
                  )}
                </div>
                {error && (
                  <div className="rounded-lg bg-red-50 border border-red-200 px-3 py-2 text-xs text-red-800">
                    {error}
                  </div>
                )}
                <div className="flex items-center justify-end gap-3 pt-2">
                  <button
                    type="button"
                    className="px-4 py-2 rounded-lg text-sm font-semibold text-gray-600 hover:bg-slate-100"
                    onClick={() => {
                      if (!submitting) {
                        setRequestingProduct(null);
                        setFieldErrors({});
                        setError(null);
                      }
                    }}
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={submitting}
                    className="px-4 py-2 rounded-lg text-sm font-semibold bg-sky-600 text-white hover:bg-sky-700 disabled:opacity-60"
                  >
                    {submitting ? "Submitting..." : "Submit Request"}
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default ECommerceStore;
