import React from "react";
import { X, MessageCircle } from "lucide-react";
import ykPartnersLogo from "../assets/images/yk-partners-logo.svg";
import { YK_PARTNERS_WHATSAPP_URL } from "./YKPartnersButton";

interface YKPartnersModalProps {
  open: boolean;
  onClose: () => void;
}

const YKPartnersModal: React.FC<YKPartnersModalProps> = ({ open, onClose }) => {
  if (!open) return null;

  return (
    <div
      className="fixed inset-0 z-[60] flex items-center justify-center p-4"
      role="dialog"
      aria-modal="true"
      aria-labelledby="yk-partners-modal-title"
    >
      <button
        type="button"
        className="absolute inset-0 bg-black/50"
        onClick={onClose}
        aria-label="Close dialog"
      />

      <div className="relative z-10 w-full max-w-md rounded-2xl border border-sky-100 bg-white p-6 shadow-2xl sm:p-8">
        <button
          type="button"
          onClick={onClose}
          className="absolute right-4 top-4 rounded-full p-1 text-gray-400 transition-colors hover:bg-gray-100 hover:text-gray-600"
          aria-label="Close"
        >
          <X className="h-5 w-5" />
        </button>

        <div className="flex flex-col items-center text-center">
          <img
            src={ykPartnersLogo}
            alt="Y & K Partners"
            className="mb-4 h-16 w-16 rounded-full object-cover shadow-md"
          />

          <h2
            id="yk-partners-modal-title"
            className="mb-3 text-xl font-bold text-gray-900 sm:text-2xl"
          >
            Developed by Y &amp; K Partners
          </h2>

          <p className="mb-3 text-sm leading-relaxed text-gray-600 sm:text-base">
            I am the developer and I can build modern, responsive websites and
            mobile applications.
          </p>

          <p className="mb-6 text-sm leading-relaxed text-gray-600 sm:text-base">
            If you need a new system from scratch, I can design, develop, and
            deliver the right solution for your business.
          </p>

          <a
            href={YK_PARTNERS_WHATSAPP_URL}
            target="_blank"
            rel="noopener noreferrer"
            onClick={onClose}
            className="inline-flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-sky-500 to-blue-600 px-6 py-3 text-sm font-semibold text-white shadow-lg transition-all hover:from-sky-600 hover:to-blue-700 hover:shadow-xl active:scale-[0.98] sm:text-base"
          >
            <MessageCircle className="h-5 w-5" />
            Discuss Your Project on WhatsApp
          </a>
        </div>
      </div>
    </div>
  );
};

export default YKPartnersModal;
