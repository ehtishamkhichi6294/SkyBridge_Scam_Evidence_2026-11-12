import { apiClient, type ApiResponse } from './apiClient';
import { API_ENDPOINTS } from '../config/api';

// Withdrawal interfaces
export interface WithdrawalHistoryItem {
  id: string;
  date: string;
  time: string;
  amount: number;
  title: string;
  status: 'pending' | 'completed' | 'failed' | 'processing';
  account_number?: string;
  account_title?: string;
  account_type?: string;
  created_at: string;
  updated_at: string;
}

export interface WithdrawalHistoryResponse {
  current_page: number;
  data: WithdrawalHistoryItem[];
  first_page_url: string;
  from: number;
  last_page: number;
  last_page_url: string;
  links: Array<{
    url: string | null;
    label: string;
    active: boolean;
  }>;
  next_page_url: string | null;
  path: string;
  per_page: number;
  prev_page_url: string | null;
  to: number;
  total: number;
}

export interface WithdrawalRequest {
  amount: number;
  // Pakistani user fields
  account_number?: string;
  account_title?: string;
  account_type?: string;
  payment_method?: string;
  // International user fields (crypto)
  crypto_address?: string;
  crypto_network?: string;
  // Optional
  notes?: string;
}

export interface WithdrawalResponse {
  id: string;
  amount: number;
  status: string;
  message: string;
}

export interface WithdrawalStats {
  total_withdrawals: number;
  total_withdrawn: number;
  processing_count: number;
  average_processing_time: string;
}

export interface WithdrawalRulesResponse {
  // Backend shape can vary; keep it flexible.
  rules?: string[];
  data?: any;
  message?: string;
}

class WithdrawalService {
  // Get withdrawal history with pagination
  async getWithdrawalHistory(page: number = 1): Promise<ApiResponse<WithdrawalHistoryResponse>> {
    try {
      return await apiClient.get<WithdrawalHistoryResponse>(`${API_ENDPOINTS.WITHDRAWALS.HISTORY}?page=${page}`);
    } catch (error) {
      throw error;
    }
  }

  // Get overall withdrawal stats
  async getWithdrawalStats(): Promise<ApiResponse<WithdrawalStats>> {
    try {
      return await apiClient.get<WithdrawalStats>(API_ENDPOINTS.WITHDRAWALS.STATS);
    } catch (error) {
      throw error;
    }
  }

  // Get withdrawal rules shown to users before requesting
  async getWithdrawalRules(): Promise<ApiResponse<WithdrawalRulesResponse | any>> {
    try {
      return await apiClient.get<WithdrawalRulesResponse | any>(
        API_ENDPOINTS.WITHDRAWALS.RULES
      );
    } catch (error) {
      throw error;
    }
  }

  // Submit withdrawal request
  async submitWithdrawal(withdrawalData: WithdrawalRequest): Promise<ApiResponse<WithdrawalResponse>> {
    try {
      // Build request data - only include fields that are provided
      const requestData: Record<string, any> = {
        amount: withdrawalData.amount,
      };

      // Pakistani user fields
      if (withdrawalData.account_number) requestData.account_number = withdrawalData.account_number;
      if (withdrawalData.account_title) requestData.account_title = withdrawalData.account_title;
      if (withdrawalData.account_type) requestData.account_type = withdrawalData.account_type;
      if (withdrawalData.payment_method) requestData.payment_method = withdrawalData.payment_method;

      // International user fields (crypto)
      if (withdrawalData.crypto_address) requestData.crypto_address = withdrawalData.crypto_address;
      if (withdrawalData.crypto_network) requestData.crypto_network = withdrawalData.crypto_network;

      // Optional fields
      if (withdrawalData.notes) requestData.notes = withdrawalData.notes;

      return await apiClient.post<WithdrawalResponse>(API_ENDPOINTS.WITHDRAWALS.SUBMIT, requestData);
    } catch (error) {
      throw error;
    }
  }

  // Get specific withdrawal details
  async getWithdrawalDetails(withdrawalId: string): Promise<ApiResponse<WithdrawalHistoryItem>> {
    try {
      return await apiClient.get<WithdrawalHistoryItem>(API_ENDPOINTS.WITHDRAWALS.DETAILS.replace(':id', withdrawalId));
    } catch (error) {
      throw error;
    }
  }
}

// Export singleton instance
export const withdrawalService = new WithdrawalService();
export default WithdrawalService;