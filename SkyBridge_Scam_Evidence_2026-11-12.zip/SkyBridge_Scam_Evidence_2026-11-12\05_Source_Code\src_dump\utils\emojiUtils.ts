/**
 * Converts Unicode escape sequences in a string to actual emoji characters
 * Handles sequences like \ud83c\udf81 -> 🎁
 * 
 * @param text - The text containing Unicode escape sequences
 * @returns Text with Unicode sequences converted to actual emojis
 */
export function convertUnicodeToEmoji(text: string): string {
  if (!text) return text;
  
  // Replace escaped Unicode sequences with actual Unicode characters
  return text.replace(/\\u([0-9a-fA-F]{4})/g, (match, hex) => {
    try {
      return String.fromCharCode(parseInt(hex, 16));
    } catch (e) {
      return match; // Return original if conversion fails
    }
  });
}

/**
 * Converts Unicode surrogate pairs (emoji sequences) to actual emojis
 * Handles sequences like \ud83c\udf81 that form surrogate pairs
 * 
 * @param text - The text containing Unicode escape sequences
 * @returns Text with surrogate pairs converted to actual emojis
 */
export function convertSurrogatePairs(text: string): string {
  if (!text) return text;
  
  // First convert individual escape sequences
  let converted = convertUnicodeToEmoji(text);
  
  // Handle surrogate pairs by replacing the pattern
  converted = converted.replace(/[\uD800-\uDBFF][\uDC00-\uDFFF]/g, (pair) => {
    return pair; // The surrogate pair is already in correct Unicode format
  });
  
  return converted;
}

/**
 * Main function to convert all Unicode escape sequences to emojis
 * This is the function you should use for notification text
 * 
 * @param text - The text containing Unicode escape sequences
 * @returns Text with all Unicode sequences converted to actual emojis
 */
export function parseEmojis(text: string): string {
  if (!text) return text;
  
  // Convert the text first to handle escape sequences
  let result = convertUnicodeToEmoji(text);
  
  // Handle common HTML entities that might appear
  result = result.replace(/&amp;/g, '&')
                .replace(/&lt;/g, '<')
                .replace(/&gt;/g, '>')
                .replace(/&quot;/g, '"')
                .replace(/&#39;/g, "'");
  
  return result;
}
