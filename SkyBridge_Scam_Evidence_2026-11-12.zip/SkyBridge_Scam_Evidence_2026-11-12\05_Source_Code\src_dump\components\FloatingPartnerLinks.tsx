import React, { useState } from "react";
import YKPartnersButton from "./YKPartnersButton";
import YKPartnersModal from "./YKPartnersModal";
import { WHATSAPP_CHANNEL_URL } from "../constants/appLinks";

const iconButtonClass =
  "flex h-14 w-14 shrink-0 items-center justify-center rounded-full transition-all duration-300 hover:scale-105 active:scale-95";

interface FloatingPartnerLinksProps {
  variant?: "bar" | "floating";
}

const FloatingPartnerLinks: React.FC<FloatingPartnerLinksProps> = ({
  variant = "bar",
}) => {
  const [modalOpen, setModalOpen] = useState(false);

  const partnerButtons = (
    <>
      <YKPartnersButton compact onClick={() => setModalOpen(true)} />
      <a
        href={WHATSAPP_CHANNEL_URL}
        target="_blank"
        rel="noopener noreferrer"
        title="Chat with us on WhatsApp"
        className={`${iconButtonClass} bg-gradient-to-br from-green-400 to-green-600 shadow-[0_4px_20px_rgba(34,197,94,0.45)] hover:shadow-[0_6px_28px_rgba(34,197,94,0.6)]`}
      >
        <svg
          className="h-7 w-7 text-white"
          fill="currentColor"
          viewBox="0 0 24 24"
          aria-hidden="true"
        >
          <path d="M20.52 3.48A11.82 11.82 0 0012.04 0C5.47 0 .04 5.43.04 12a11.83 11.83 0 001.57 5.93L0 24l6.24-1.64A11.9 11.9 0 0012.05 24c6.57 0 11.99-5.43 11.99-12a11.82 11.82 0 00-3.52-8.52zM12.05 22.06a9.93 9.93 0 01-5.08-1.39l-.36-.21-3.7.97.99-3.6-.23-.37A9.96 9.96 0 012.1 12c0-5.48 4.46-9.94 9.94-9.94a9.9 9.9 0 016.99 2.9 9.9 9.9 0 012.9 7.04c-.01 5.48-4.47 9.94-9.88 9.94zm5.68-7.45c-.31-.16-1.84-.9-2.12-1.01-.28-.1-.49-.16-.7.16-.2.31-.8 1.01-.99 1.22-.18.2-.37.23-.68.08-.31-.16-1.32-.49-2.51-1.56-.93-.82-1.56-1.83-1.75-2.14-.18-.31-.02-.48.13-.63.13-.13.31-.34.46-.51.16-.17.2-.29.31-.49.1-.2.05-.37-.03-.52-.08-.16-.7-1.68-.96-2.3-.25-.6-.51-.52-.7-.53-.18 0-.39 0-.6 0-.2 0-.52.07-.79.37-.27.31-1.04 1.01-1.04 2.47s1.07 2.87 1.22 3.07c.16.2 2.11 3.2 5.1 4.49.71.31 1.27.49 1.7.63.71.23 1.36.2 1.87.13.57-.09 1.84-.75 2.1-1.47.26-.72.26-1.33.18-1.47-.09-.14-.28-.23-.59-.38z" />
        </svg>
        <span className="sr-only">WhatsApp Support</span>
      </a>
    </>
  );

  return (
    <>
      {variant === "floating" ? (
        <div className="fixed bottom-5 right-4 z-50 flex items-center gap-2 sm:bottom-6 sm:right-6 sm:gap-3">
          {partnerButtons}
        </div>
      ) : (
        <footer className="border-t border-sky-200/80 bg-white/95 shadow-[0_-4px_24px_rgba(0,0,0,0.08)] backdrop-blur-md">
          <div className="mx-auto max-w-7xl px-4 py-3 sm:px-6">
            <div className="grid grid-cols-1 items-center gap-3 sm:grid-cols-[1fr_auto_1fr] sm:gap-4">
              <div className="hidden sm:block" aria-hidden />

              <div className="text-center text-xs leading-relaxed text-gray-600 sm:text-sm">
                <p>&copy; 2024 SkyBridge International. All rights reserved.</p>
                <p className="mt-0.5 sm:mt-1">
                  Your trusted partner in digital earning opportunities.
                </p>
              </div>

              <div className="flex items-center justify-center gap-2 sm:justify-end sm:gap-3">
                {partnerButtons}
              </div>
            </div>
          </div>
        </footer>
      )}

      <YKPartnersModal open={modalOpen} onClose={() => setModalOpen(false)} />
    </>
  );
};

export default FloatingPartnerLinks;