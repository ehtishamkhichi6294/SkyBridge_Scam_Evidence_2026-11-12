/**
 * Single source of truth for all plan content.
 * Used by: Plans.tsx, UpgradePlan.tsx, Register.tsx
 *
 * Basic – $3.33 (Lifetime) 950 PKR
 * Standard – $7.00 (Lifetime) 2000 PKR
 * Prime – $14.00 (Lifetime) 4000 PKR
 * Premium – $21.00 (Lifetime) 6000 PKR
 *
 * SkyBridge logo colors: Basic #33a8e0, Standard #d82b2b, Prime #f7a933, Premium black
 */

export type PlanPriceKey = 950 | 2000 | 4000 | 6000;

export interface PlanContentItem {
  displayName: string;
  priceUsd: number;
  pricePkr: number;
  courses: string[];
  earningOpportunities: string[];
  bonusesRewards: string[];
  colorClass: string;
  colorGradient: string;
  isMostPopular?: boolean;
}

export const PLAN_CONTENT: Record<PlanPriceKey, PlanContentItem> = {
  950: {
    displayName: "Basic",
    priceUsd: 3.33,
    pricePkr: 950,
    courses: [
      "Leads Generation",
      "Digital Marketing Fundamentals",
      "English Speaking Skills",
    ],
    earningOpportunities: ["Ads Earnings", "E-Commerce", "Affiliate Marketing"],
    bonusesRewards: ["Daily Bonuses", "Level Rewards", "Monthly Prizes"],
    colorClass: "bg-[#33a8e0]",
    colorGradient: "from-[#33a8e0] to-[#2b8fc9]",
  },
  2000: {
    displayName: "Standard",
    priceUsd: 7.0,
    pricePkr: 2000,
    courses: ["TikTok Earning", "Video Editing", "Content Creation","All Basic Plan Courses"],
    earningOpportunities: [
      "High Ads Earnings",
      "E-Commerce",
      "Affiliate Marketing",
    ],
    bonusesRewards: ["Daily Bonuses", "Level Rewards", "Monthly Prizes"],
    colorClass: "bg-[#d82b2b]",
    colorGradient: "from-[#d82b2b] to-[#b82424]",
    isMostPopular: true,
  },
  4000: {
    displayName: "Prime",
    priceUsd: 14.0,
    pricePkr: 4000,
    courses: ["Affiliate Marketing", "LinkedIn Marketing", "E-Commerce", "All Basic & Standard Plan Courses", "Pinterest Course"],
    earningOpportunities: [
      "Higher Ads Earnings",
      "E-Commerce",
      "Affiliate Marketing",
    ],
    bonusesRewards: ["Daily Bonuses", "Level Rewards", "Monthly Prizes"],
    colorClass: "bg-[#f7a933]",
    colorGradient: "from-[#f7a933] to-[#e09820]",
  },
  6000: {
    displayName: "Premium",
    priceUsd: 21.0,
    pricePkr: 6000,
    courses: [
      "Forex Trading",
      "Instagram Growth Marketing",
      "Freelancing Course",
      "All Basic, Standard & Prime Plan Courses",
    ],
    earningOpportunities: [
      "Highest Ads Earnings",
      "E-Commerce",
      "Affiliate Marketing",
    ],
    bonusesRewards: ["Daily Bonuses", "Level Rewards", "Monthly Prizes"],
    colorClass: "bg-gray-900",
    colorGradient: "from-gray-900 to-black",
  },
};

/** Map API plan_name to display name (Basic, Standard, Prime, Premium) */
export function getDisplayNameForPlan(planName: string | undefined): string {
  if (!planName) return "";
  const n = planName.trim().toLowerCase().replace(/\s*plan\s*$/i, "").trim();
  if (!n || n === "plan") return "";
  if (n === "basic" || (n.includes("950") && n.includes("pkr"))) return "Basic";
  if (n === "standard" || (n.includes("2000") && n.includes("pkr")))
    return "Standard";
  if (n === "prime" || (n.includes("4000") && n.includes("pkr"))) return "Prime";
  if (n === "premium" || (n.includes("6000") && n.includes("pkr")))
    return "Premium";
  return planName.trim().replace(/\s*plan\s*$/i, "").trim() || planName.trim();
}

/** Get plan content by price_pkr; returns undefined if not found */
export function getPlanContentByPricePkr(
  pricePkr: number
): PlanContentItem | undefined {
  const key = pricePkr as PlanPriceKey;
  if (key in PLAN_CONTENT) return PLAN_CONTENT[key];
  return undefined;
}

/** Plan ids used on Plans page (for current plan matching) */
export const PLAN_IDS: Record<PlanPriceKey, string> = {
  950: "basic",
  2000: "standard",
  4000: "prime",
  6000: "premium",
};

/** Plan upgrade request statuses from `/user/plan-upgrade/history` */
export type PlanUpgradeStatus = "pending" | "approved" | "rejected";

export interface PlanUpgradeHistoryItem {
  id: number;
  plan_id?: number | string;
  plan_name?: string;
  planName?: string;
  requested_plan_id?: number | string;
  requested_plan_name?: string;
  to_plan_id?: number | string;
  new_plan_id?: number | string;
  plan?: {
    id?: number | string;
    name?: string;
    title?: string;
    price_pkr?: number | string;
    price_usd?: number | string;
  } | string | null;
  requested_plan?: {
    id?: number | string;
    name?: string;
    title?: string;
    price_pkr?: number | string;
  } | null;
  to_plan?: {
    id?: number | string;
    name?: string;
    title?: string;
    price_pkr?: number | string;
  } | null;
  status: PlanUpgradeStatus | string;
  transaction_id?: string;
  amount_pkr?: number | string | null;
  amount_usd?: number | string | null;
  rejection_reason?: string | null;
  admin_notes?: string | null;
  reason?: string | null;
  created_at?: string;
  updated_at?: string;
  reviewed_at?: string | null;
  [key: string]: unknown;
}

export type PlanCatalogItem = {
  id?: number | string;
  name?: string;
  price_pkr?: number | string;
  price_usd?: number | string;
};

/** Prefer rejection_reason, then admin_notes / reason */
export function getPlanUpgradeRejectionReason(
  item: PlanUpgradeHistoryItem,
): string | null {
  const reason =
    item.rejection_reason?.trim() ||
    item.admin_notes?.trim() ||
    item.reason?.trim() ||
    "";
  return reason || null;
}

const PLAN_ID_DISPLAY_NAMES: Record<number, string> = {
  1: "Basic",
  2: "Standard",
  3: "Prime",
  4: "Premium",
};

function formatPlanLabel(display: string): string {
  const cleaned = display.trim();
  if (!cleaned) return "Unknown Plan";
  return /plan$/i.test(cleaned) ? cleaned : `${cleaned} Plan`;
}

function readNestedPlan(
  value: unknown,
): { id?: number | string; name?: string; price_pkr?: number | string } | null {
  if (value == null) return null;
  if (typeof value === "number") {
    return Number.isFinite(value) && value > 0 ? { id: value } : null;
  }
  if (typeof value === "string") {
    const asId = Number(value);
    if (Number.isFinite(asId) && asId > 0 && String(asId) === value.trim()) {
      return { id: asId };
    }
    return value.trim() ? { name: value } : null;
  }
  if (typeof value !== "object") return null;
  const obj = value as {
    id?: number | string;
    name?: string;
    title?: string;
    price_pkr?: number | string;
  };
  return {
    id: obj.id,
    name: obj.name || obj.title,
    price_pkr: obj.price_pkr,
  };
}

/** Resolve upgrade history item to a full label like "Basic Plan" */
export function getPlanUpgradeDisplayName(
  item: PlanUpgradeHistoryItem,
  catalog?: PlanCatalogItem[],
): string {
  const nested =
    readNestedPlan(item.plan) ||
    readNestedPlan(item.requested_plan) ||
    readNestedPlan(item.to_plan);

  const nameCandidates = [
    nested?.name,
    item.plan_name,
    item.planName,
    item.requested_plan_name,
    typeof item.requested_plan === "object"
      ? item.requested_plan?.name || item.requested_plan?.title
      : undefined,
    typeof item.to_plan === "object"
      ? item.to_plan?.name || item.to_plan?.title
      : undefined,
  ];

  for (const candidate of nameCandidates) {
    if (typeof candidate !== "string" || !candidate.trim()) continue;
    const trimmed = candidate.trim();
    // Skip pure numeric strings — those are plan IDs, not names
    if (/^\d+$/.test(trimmed)) continue;
    const display = getDisplayNameForPlan(trimmed);
    if (display) return formatPlanLabel(display);
    return formatPlanLabel(trimmed);
  }

  const idCandidates = [
    item.plan_id,
    item.requested_plan_id,
    item.to_plan_id,
    item.new_plan_id,
    nested?.id,
    (item as { planId?: number | string }).planId,
    (item as { requestedPlanId?: number | string }).requestedPlanId,
  ];

  for (const rawId of idCandidates) {
    const planId = Number(rawId);
    if (!Number.isFinite(planId) || planId <= 0) continue;

    if (catalog?.length) {
      const match = catalog.find((p) => Number(p.id) === planId);
      if (match?.name) {
        const display =
          getDisplayNameForPlan(match.name) || match.name.trim();
        if (display) return formatPlanLabel(display);
      }
    }

    if (PLAN_ID_DISPLAY_NAMES[planId]) {
      return formatPlanLabel(PLAN_ID_DISPLAY_NAMES[planId]);
    }
  }

  const pricePkr = Number(nested?.price_pkr ?? 0);
  if (Number.isFinite(pricePkr) && pricePkr > 0) {
    const content = getPlanContentByPricePkr(pricePkr);
    if (content) return formatPlanLabel(content.displayName);

    if (catalog?.length) {
      const match = catalog.find((p) => Number(p.price_pkr) === pricePkr);
      if (match?.name) {
        const display =
          getDisplayNameForPlan(match.name) || match.name.trim();
        if (display) return formatPlanLabel(display);
      }
    }
  }

  return "Unknown Plan";
}
