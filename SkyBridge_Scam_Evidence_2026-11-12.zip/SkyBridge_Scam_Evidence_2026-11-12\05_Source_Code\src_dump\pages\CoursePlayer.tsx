import { useEffect, useMemo, useRef, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { courseService } from '../services/courseService';
import type { CourseVideo } from '../types/course';
import { ArrowLeft, Play, List, CheckCircle, PlayCircle, Clock, SkipForward, SkipBack, Maximize2, Minimize2 } from 'lucide-react';

const CoursePlayer: React.FC = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [videos, setVideos] = useState<CourseVideo[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [descExpanded, setDescExpanded] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const playerContainerRef = useRef<HTMLDivElement | null>(null);
  const videoPlayerAnchorRef = useRef<HTMLDivElement | null>(null);
  const skipScrollOnMountRef = useRef(true);

  useEffect(() => {
    if (!id) return;
    skipScrollOnMountRef.current = true;
    setLoading(true);
    setError(null);
    courseService
      .getCourseVideos(id)
      .then((res) => {
        setVideos(res.data || []);
        setCurrentIndex(0);
        setDescExpanded(false);
      })
      .catch((e) => setError(e?.message || 'Failed to load videos'))
      .finally(() => setLoading(false));
  }, [id]);

  const scrollToVideoPlayer = () => {
    requestAnimationFrame(() => {
      videoPlayerAnchorRef.current?.scrollIntoView({
        behavior: 'smooth',
        block: 'start',
      });
    });
  };

  const selectVideo = (index: number) => {
    setDescExpanded(false);
    if (index === currentIndex) {
      scrollToVideoPlayer();
      return;
    }
    setCurrentIndex(index);
  };

  useEffect(() => {
    if (loading || error) return;
    if (skipScrollOnMountRef.current) {
      skipScrollOnMountRef.current = false;
      return;
    }
    scrollToVideoPlayer();
  }, [currentIndex, loading, error]);

  useEffect(() => {
    const handleFullscreenChange = () => {
      setIsFullscreen(document.fullscreenElement === playerContainerRef.current);
    };

    document.addEventListener('fullscreenchange', handleFullscreenChange);
    return () => {
      document.removeEventListener('fullscreenchange', handleFullscreenChange);
    };
  }, []);

  const toggleFullscreen = async () => {
    const container = playerContainerRef.current;
    if (!container) return;

    try {
      if (document.fullscreenElement === container) {
        await document.exitFullscreen();
      } else {
        await container.requestFullscreen();
      }
    } catch {
      // Browser/user gesture restrictions can block fullscreen requests.
    }
  };

  const current = useMemo(() => videos[currentIndex], [videos, currentIndex]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-sky-50 to-indigo-50">
      <div className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-sky-600 via-indigo-600 to-purple-700">
          <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxnIGZpbGw9IiNmZmYiIGZpbGwtb3BhY2l0eT0iMC4wNSI+PHBhdGggZD0iTTM2IDE0YzMuMzE0IDAgNi0yLjY4NiA2LTZzLTIuNjg2LTYtNi02LTYgMi42ODYtNiA2IDIuNjg2IDYgNiA2ek0yNCA0OGMzLjMxNCAwIDYtMi42ODYgNi02cy0yLjY4Ni02LTYtNi02IDIuNjg2LTYgNiAyLjY4NiA2IDYgNnoiLz48L2c+PC9nPjwvc3ZnPg==')] opacity-30" />
        </div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
          <div className="flex items-center justify-between">
            <div className="text-white">
              <div className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full bg-white/10 backdrop-blur-md border border-white/20 mb-4 shadow-xl">
                <PlayCircle className="w-5 h-5" />
                <span className="font-bold">Course Player</span>
              </div>
              <h1 className="text-4xl sm:text-5xl font-black tracking-tight drop-shadow-2xl mb-2">
                Learn & Master
              </h1>
              <p className="text-xl text-white/90">Watch, practice, a your goals</p>
            </div>
            <button
              onClick={() => navigate(-1)}
              className="px-6 py-3 rounded-2xl bg-white text-sky-700 font-bold shadow-2xl hover:shadow-xl hover:scale-105 transform transition-all flex items-center gap-3"
            >
              <ArrowLeft className="w-5 h-5" />
              Back
            </button>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {loading && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2">
              <div className="aspect-video w-full rounded-3xl bg-gradient-to-br from-sky-200 via-indigo-200 to-purple-200 animate-pulse shadow-2xl" />
              <div className="mt-6 h-8 w-3/4 bg-gray-200 rounded-xl animate-pulse" />
              <div className="mt-3 h-6 w-1/2 bg-gray-100 rounded-lg animate-pulse" />
            </div>
            <div className="bg-white rounded-3xl shadow-2xl p-6 border border-gray-100">
              <div className="h-6 w-1/2 bg-gray-200 rounded-lg animate-pulse mb-6" />
              <div className="space-y-4">
                {Array.from({ length: 6 }).map((_, i) => (
                  <div key={i} className="h-20 bg-gray-100 rounded-2xl animate-pulse" />
                ))}
              </div>
            </div>
          </div>
        )}
        {error && (
          <div className="bg-white rounded-3xl shadow-2xl border-2 border-red-200 p-10 text-center max-w-2xl mx-auto">
            <div className="w-20 h-20 bg-gradient-to-br from-red-400 to-red-600 rounded-full flex items-center justify-center mx-auto mb-6">
              <span className="text-4xl">⚠️</span>
            </div>
            <h3 className="text-2xl font-bold text-gray-900 mb-3">Error Loading Videos</h3>
            <p className="text-gray-600 text-lg">{error}</p>
          </div>
        )}

        {!loading && !error && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Video Player */}
            <div className="lg:col-span-2 space-y-6">
              {/* Player Container */}
              <div ref={videoPlayerAnchorRef} className="scroll-mt-28">
              <div ref={playerContainerRef} className="relative rounded-3xl overflow-hidden bg-black shadow-2xl border-4 border-gray-200">
                <div className="relative aspect-video w-full">
                  {current?.url || current?.video ? (
                    <video
                      key={current?.id}
                      src={(current as any).url || (current as any).video}
                      poster={current?.thumbnail}
                      controls
                      controlsList="nodownload noremoteplayback"
                      disablePictureInPicture={true}
                      disableRemotePlayback={true}
                      onContextMenu={(e) => e.preventDefault()}
                      className="w-full h-full"
                      style={{ 
                        backgroundImage: 'none',
                      }}
                    />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-gray-900 to-black text-white">
                      <div className="text-center">
                        <PlayCircle className="w-24 h-24 mx-auto mb-6 opacity-30" />
                        <p className="text-xl font-semibold">No video source available</p>
                      </div>
                    </div>
                  )}
                  <button
                    type="button"
                    onClick={toggleFullscreen}
                    className="absolute top-3 right-3 z-10 px-3 py-2 rounded-lg bg-black/60 text-white text-xs font-semibold hover:bg-black/75 transition-all backdrop-blur-sm flex items-center gap-2"
                    aria-label={isFullscreen ? 'Exit fullscreen' : 'Enter fullscreen'}
                  >
                    {isFullscreen ? (
                      <>
                        <Minimize2 className="w-4 h-4" />
                        Small Screen
                      </>
                    ) : (
                      <>
                        <Maximize2 className="w-4 h-4" />
                        Full Screen
                      </>
                    )}
                  </button>
                </div>
              </div>
              </div>

              {/* Video Info Card */}
              <div className="bg-white rounded-3xl shadow-xl border border-gray-100 p-8">
                <div className="flex items-start gap-4 mb-6">
                  <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-sky-500 to-indigo-600 flex items-center justify-center shadow-lg flex-shrink-0">
                    <PlayCircle className="w-8 h-8 text-white" />
                  </div>
                  <div className="flex-1">
                    <h2 className="text-3xl font-black text-gray-900 mb-2">{current?.title || 'Untitled Video'}</h2>
                    {current?.description && (
                      <div>
                        <div
                          className="text-gray-600 text-lg leading-relaxed"
                          style={{
                            display: descExpanded ? 'block' : '-webkit-box',
                            WebkitLineClamp: descExpanded ? 'unset' : '2',
                            WebkitBoxOrient: 'vertical',
                            overflow: 'hidden',
                          }}
                        >
                          {current.description}
                        </div>
                        <button
                          type="button"
                          className="mt-2 text-sky-600 hover:text-sky-700 text-sm font-semibold"
                          onClick={() => setDescExpanded((v) => !v)}
                        >
                          {descExpanded ? 'Read less' : 'Read more'}
                        </button>
                      </div>
                    )}
                  </div>
                </div>

                {/* Navigation Controls */}
                <div className="flex gap-4 pt-6 border-t-2 border-gray-100">
                  <button
                    disabled={currentIndex === 0}
                    onClick={() => selectVideo(Math.max(0, currentIndex - 1))}
                    className="flex-1 px-6 py-4 rounded-2xl bg-gray-100 text-gray-700 font-bold hover:bg-gray-200 disabled:opacity-40 disabled:cursor-not-allowed transition-all flex items-center justify-center gap-3"
                  >
                    <SkipBack className="w-5 h-5" />
                    Previous
                  </button>
                  <button
                    disabled={currentIndex >= videos.length - 1}
                    onClick={() => selectVideo(Math.min(videos.length - 1, currentIndex + 1))}
                    className="flex-1 px-6 py-4 rounded-2xl bg-gradient-to-r from-sky-500 to-indigo-600 text-white font-bold shadow-xl hover:shadow-2xl hover:scale-105 transform transition-all disabled:opacity-40 disabled:cursor-not-allowed disabled:hover:scale-100 flex items-center justify-center gap-3"
                  >
                    Next
                    <SkipForward className="w-5 h-5" />
                  </button>
                </div>
              </div>
            </div>

            <div>
              <div className="bg-white rounded-3xl shadow-2xl border border-gray-100 overflow-hidden">
                {/* Playlist Header */}
                <div className="bg-gradient-to-r from-sky-500 via-indigo-600 to-purple-600 p-6 text-white">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-3">
                      <div className="w-12 h-12 rounded-xl bg-white/20 backdrop-blur-md flex items-center justify-center">
                        <List className="w-6 h-6" />
                      </div>
                      <div>
                        <h3 className="text-xl font-black">Course Playlist</h3>
                        <p className="text-sm text-white/80">{videos.length} videos</p>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Playlist Content */}
                {videos.length === 0 ? (
                  <div className="p-12 text-center text-gray-400">
                    <List className="w-16 h-16 mx-auto mb-4 opacity-20" />
                    <p className="text-lg font-semibold">No videos available</p>
                  </div>
                ) : (
                  <ul className="max-h-[65vh] overflow-auto">
                    {videos.map((v, idx) => (
                      <li key={v.id}>
                        <button
                          onClick={() => selectVideo(idx)}
                          className={`w-full flex items-center gap-4 px-6 py-4 text-left border-b border-gray-100 hover:bg-gradient-to-r hover:from-sky-50 hover:to-indigo-50 transition-all group ${idx === currentIndex ? 'bg-gradient-to-r from-sky-50 to-indigo-50' : ''
                            }`}
                        >
                          {/* Thumbnail */}
                          <div className="relative w-24 h-16 rounded-xl bg-gradient-to-br from-sky-100 to-indigo-100 overflow-hidden flex-shrink-0 shadow-lg border-2 border-gray-200">
                            {v.thumbnail ? (
                              <img src={v.thumbnail} alt={v.title} className="w-full h-full object-cover" />
                            ) : (
                              <div className="w-full h-full flex items-center justify-center text-sky-400">
                                <PlayCircle className="w-8 h-8" />
                              </div>
                            )}
                            {idx === currentIndex && (
                              <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
                                <div className="w-10 h-10 rounded-full bg-white flex items-center justify-center">
                                  <Play className="w-5 h-5 text-sky-600" />
                                </div>
                              </div>
                            )}
                          </div>

                          {/* Video Info */}
                          <div className="flex-1 min-w-0">
                            <p className={`text-sm font-bold truncate mb-1 ${idx === currentIndex ? 'text-sky-700' : 'text-gray-900'}`}>
                              {v.title}
                            </p>
                            {v.duration && (
                              <div className="flex items-center gap-1.5 text-xs text-gray-500">
                                <Clock className="w-3 h-3" />
                                <span>{v.duration}</span>
                              </div>
                            )}
                          </div>

                          {/* Status Badge */}
                          {idx === currentIndex && (
                            <div className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-gradient-to-r from-sky-500 to-indigo-600 text-white text-xs font-black shadow-lg">
                              <CheckCircle className="w-4 h-4" />
                              Now Playing
                            </div>
                          )}
                        </button>
                      </li>
                    ))}
                  </ul>
                )}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default CoursePlayer;
