import React, { useState, useEffect } from "react";
import {
  DollarSign,
  AlertCircle,
  Loader2,
  X,
  CheckCircle,
  Clock,
  XCircle,
  Wallet,
  TrendingUp,
  FileText,
  Camera,
} from "lucide-react";
import { useCurrency } from "../contexts/CurrencyContext";
import { withdrawalService } from "../services/withdrawalService";
import { userService } from "../services/userService";

/** Replace ISO-8601 timestamps in API error strings with 12-hour locale time (no seconds). */
function formatIsoDatesInMessage(message: string): string {
  if (!message) return message;
  return message.replace(
    /\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:Z|[+-]\d{2}:\d{2})?/g,
    (iso) => {
      const d = new Date(iso);
      if (Number.isNaN(d.getTime())) return iso;
      return d.toLocaleString("en-US", {
        month: "long",
        day: "numeric",
        year: "numeric",
        hour: "numeric",
        minute: "2-digit",
        hour12: true,
      });
    },
  );
}

const ORDINALS = ["First", "Second", "Third", "Fourth", "Fifth", "Sixth"];
const ordinalLabel = (n: number) => ORDINALS[n - 1] ?? `${n}th`;

const Withdraw = () => {
  const [amount, setAmount] = useState("");
  const [accountNumber, setAccountNumber] = useState("");
  const [accountTitle, setAccountTitle] = useState("");
  const [accountType, setAccountType] = useState("");
  // International user fields
  const [isInternationalUser, setIsInternationalUser] = useState(false);
  const [bep20Address, setBep20Address] = useState("");
  const [cryptoNetwork] = useState("BEP20 (BSC)");
  const [profileLoading, setProfileLoading] = useState(true);
  const [profileError, setProfileError] = useState(null);
  const [showReceipt, setShowReceipt] = useState(false);
  const [activeReceipt, setActiveReceipt] = useState<any | null>(null);

  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);
  const [historyPage, setHistoryPage] = useState(1);
  const [withdrawalHistory, setWithdrawalHistory] = useState<any[]>([]);
  const [historyTotalPages, setHistoryTotalPages] = useState(1);
  const [uploadingScreenshot, setUploadingScreenshot] = useState<number | null>(
    null,
  );
  const [screenshotPreview, setScreenshotPreview] = useState<{
    [key: number]: string;
  }>({});

  // Withdrawal rules shown to user before requesting
  const [rulesLoading, setRulesLoading] = useState(true);
  const [rulesError, setRulesError] = useState<string | null>(null);
  const [withdrawalRules, setWithdrawalRules] = useState<any>(null);

  const { exchangeRate } = useCurrency();

  // Dynamic minimum withdrawal amount based on API "next_attempt_number"
  // Backend example:
  // - next_attempt_number: 1
  // - min_withdrawal_amount: 0.25
  // - withdrawal_limits: [{ attempt: 1, min_amount: 0.25 }, ...]
  const nextAttemptNumber = Number(withdrawalRules?.next_attempt_number ?? 1);
  const minWithdrawalForAttempt = (() => {
    const limits = Array.isArray(withdrawalRules?.withdrawal_limits)
      ? withdrawalRules.withdrawal_limits
      : [];

    const matched = limits.find(
      (l: any) => Number(l?.attempt) === nextAttemptNumber,
    );
    const fromMatched = Number(matched?.min_amount ?? NaN);
    if (Number.isFinite(fromMatched) && fromMatched > 0) return fromMatched;

    const fromRules = Number(withdrawalRules?.min_withdrawal_amount ?? NaN);
    if (Number.isFinite(fromRules) && fromRules > 0) return fromRules;

    // Safe fallback before rules load
    return 0.25;
  })();

  // Limit tiers shown in the "Withdrawal Limits" card — driven by admin settings.
  // The highest attempt is the "and all next" tier (backend convention).
  const withdrawalLimitTiers: { attempt: number; min_amount: number }[] = (
    Array.isArray(withdrawalRules?.withdrawal_limits) &&
    withdrawalRules.withdrawal_limits.length
      ? withdrawalRules.withdrawal_limits
      : [
          { attempt: 1, min_amount: 0.25 },
          { attempt: 2, min_amount: 0.75 },
          { attempt: 3, min_amount: 1.0 },
        ]
  )
    .map((l: any) => ({
      attempt: Number(l?.attempt ?? 0),
      min_amount: Number(l?.min_amount ?? 0),
    }))
    .filter((l: { attempt: number; min_amount: number }) => l.attempt > 0 && Number.isFinite(l.min_amount))
    .sort(
      (
        a: { attempt: number },
        b: { attempt: number },
      ) => a.attempt - b.attempt,
    );

  const availableBalance = Number(withdrawalRules?.available_balance ?? 0);

  const maxRequestsPerWindow = Number(
    withdrawalRules?.time_limit?.max_requests ?? 1,
  );
  const periodHoursWindow = Number(
    withdrawalRules?.time_limit?.period_hours ?? 24,
  );

  // 5% processing fee calculations derived from entered amount
  const feeRate = 0.05;
  const amountNum = parseFloat(amount || "0");
  const processingFee = amountNum > 0 ? +(amountNum * feeRate).toFixed(2) : 0;
  const netAmount = +Math.max(amountNum - processingFee, 0).toFixed(2);
  // Sum of amounts for currently loaded transactions (current page)
  const pageAmountSum = withdrawalHistory.reduce(
    (sum, w) => sum + Number(w?.amount ?? 0),
    0,
  );

  // Load withdrawal history for a given page
  const loadHistory = async (page: number = historyPage) => {
    try {
      const res = await withdrawalService.getWithdrawalHistory(page);
      setWithdrawalHistory(res.data.data || []);
      setHistoryTotalPages(res.data.last_page || 1);
    } catch (err: any) {
      console.error("Failed to load withdrawal history", err?.message || err);
    }
  };

  // Load user profile data
  const loadUserProfile = async () => {
    setProfileLoading(true);
    setProfileError(null);
    try {
      const res = await userService.getUserProfile();
      console.log("Profile Response:", res);
      if (res) {
        // Check if user is international (non-Pakistan country with BEP20 address)
        const isIntl = res.country !== "Pakistan" && !!res.bep20_address;
        console.log("User Type Detection:", {
          country: res.country,
          bep20_address: res.bep20_address,
          isInternational: isIntl,
        });
        setIsInternationalUser(isIntl);

        if (isIntl) {
          // International user - use BEP20 address
          setBep20Address(res.bep20_address || "");
        } else {
          // Pakistani user - use account details
          setAccountNumber(res.account_number || "");
          setAccountTitle(res.account_title || "");
          setAccountType(res.payment_methods?.[0] || "");
        }
      }
    } catch (err: any) {
      console.error("Failed to load user profile", err?.message || err);
      setProfileError(err?.message || "Failed to load profile data");
    } finally {
      setProfileLoading(false);
    }
  };

  // Fetch history when page changes
  useEffect(() => {
    loadHistory();
  }, [historyPage]);

  // Load user profile + withdrawal rules in parallel on mount
  useEffect(() => {
    const loadRules = async () => {
      setRulesLoading(true);
      setRulesError(null);
      try {
        const res = await withdrawalService.getWithdrawalRules();
        setWithdrawalRules(res?.data ?? null);
      } catch (err: any) {
        setRulesError(err?.message || "Failed to load withdrawal rules");
      } finally {
        setRulesLoading(false);
      }
    };

    Promise.all([loadUserProfile(), loadRules()]);
  }, []);

  // Real-time polling to refresh history automatically
  useEffect(() => {
    const interval = setInterval(() => {
      loadHistory();
    }, 5000); // refresh every 5 seconds
    return () => clearInterval(interval);
  }, [historyPage]);

  // Real-time polling for active receipt while modal is open
  useEffect(() => {
    if (!showReceipt || !activeReceipt?.id) return;
    const id = setInterval(async () => {
      try {
        const res = await withdrawalService.getWithdrawalDetails(
          String(activeReceipt.id),
        );
        const data: any = res && (res as any).data ? (res as any).data : res;
        setActiveReceipt((prev: any) => (prev ? { ...prev, ...data } : data));
        // Also refresh list to reflect latest status
        loadHistory();
      } catch (e) {
        // ignore transient errors
      }
    }, 4000);
    return () => clearInterval(id);
  }, [showReceipt, activeReceipt?.id]);

  // Normalize payment method/account type to canonical values
  const normalizePaymentMethod = (value: string) => {
    const v = (value || "").trim().toLowerCase();
    if (!v) return "";
    if (
      ["jazzcash", "jazz caash", "jazz-cash", "jazz cash", "jazcash"].includes(
        v,
      )
    )
      return "JazzCash";
    if (["easypaisa", "easy paisa", "easy-paisa"].includes(v))
      return "EasyPaisa";
    if (["bank transfer", "banktransfer", "bank-transfer", "bank"].includes(v))
      return "Bank Transfer";
    return value.trim();
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSuccessMessage(null);

    if (amountNum < minWithdrawalForAttempt) {
      setError(
        `Minimum withdrawal amount is $${minWithdrawalForAttempt.toFixed(2)}`,
      );
      return;
    }

    // Validate based on user type
    if (isInternationalUser) {
      if (!bep20Address) {
        setError("BEP20 address is required");
        return;
      }
    } else {
      if (!accountNumber || !accountTitle || !accountType) {
        setError("Please fill in all required fields");
        return;
      }
    }

    const normalizedAccountType = normalizePaymentMethod(accountType);

    setIsLoading(true);
    setError(null);

    try {
      let payload: any;

      // Debug logging
      console.log("Withdrawal Debug:", {
        isInternationalUser,
        bep20Address,
        cryptoNetwork,
        accountNumber,
        accountTitle,
        accountType: normalizedAccountType,
      });

      if (isInternationalUser) {
        // International user payload
        payload = {
          amount: amountNum,
          crypto_address: bep20Address,
          crypto_network: cryptoNetwork,
        };
      } else {
        // Pakistani user payload
        payload = {
          amount: amountNum,
          account_number: accountNumber,
          account_title: accountTitle,
          account_type: normalizedAccountType,
          payment_method: normalizedAccountType,
        };
      }

      console.log("Withdrawal Payload:", payload);

      const res = await withdrawalService.submitWithdrawal(payload);
      const result: any = res && (res as any).data ? (res as any).data : res;

      const receiptData = isInternationalUser
        ? {
            id: result?.id,
            amount: payload.amount,
            net_amount: netAmount,
            crypto_address: bep20Address,
            crypto_network: cryptoNetwork,
            payment_method: "BEP20 (BSC)",
            status: result?.status || "pending",
            created_at: new Date().toISOString(),
            message: result?.message,
          }
        : {
            id: result?.id,
            amount: payload.amount,
            net_amount: netAmount,
            account_number: payload.account_number,
            account_title: payload.account_title,
            account_type: payload.account_type,
            payment_method: payload.payment_method,
            status: result?.status || "pending",
            created_at: new Date().toISOString(),
            message: result?.message,
          };

      setActiveReceipt(receiptData);
      setShowReceipt(true);
      setAmount("");
      setSuccessMessage(
        result?.message || "Withdrawal request submitted successfully.",
      );
      // Refresh history after successful request
      const historyRes = await withdrawalService.getWithdrawalHistory(1);
      setWithdrawalHistory(historyRes.data.data || []);
      setHistoryPage(1);
      setHistoryTotalPages(historyRes.data.last_page || 1);
    } catch (err: any) {
      setSuccessMessage(null);
      setError(err?.message || "Failed to submit withdrawal request");
    } finally {
      setIsLoading(false);
    }
  };

  const closeReceipt = () => {
    setShowReceipt(false);
    setActiveReceipt(null);
  };

  // Handle screenshot upload for status updates
  const handleScreenshotUpload = async (withdrawalId: number, file: File) => {
    try {
      setUploadingScreenshot(withdrawalId);

      // Create preview
      const preview = URL.createObjectURL(file);
      setScreenshotPreview((prev) => ({ ...prev, [withdrawalId]: preview }));

      // Here you would upload to your API
      // const formData = new FormData();
      // formData.append('screenshot', file);
      // formData.append('withdrawal_id', withdrawalId.toString());
      // await withdrawalService.uploadStatusScreenshot(formData);

      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 1000));

      // Refresh history after upload
      await loadHistory();
    } catch (err: any) {
      console.error("Failed to upload screenshot:", err);
      setError(err?.message || "Failed to upload screenshot");
    } finally {
      setUploadingScreenshot(null);
    }
  };

  // Get status icon and color
  const getStatusDisplay = (status: string) => {
    const normalizedStatus = (status || "").toLowerCase();
    switch (normalizedStatus) {
      case "completed":
      case "approved":
        return {
          icon: CheckCircle,
          bgColor: "bg-emerald-100",
          textColor: "text-emerald-700",
          borderColor: "border-emerald-300",
          iconColor: "text-emerald-600",
        };
      case "pending":
      case "processing":
        return {
          icon: Clock,
          bgColor: "bg-amber-100",
          textColor: "text-amber-700",
          borderColor: "border-amber-300",
          iconColor: "text-amber-600",
        };
      case "rejected":
      case "failed":
        return {
          icon: XCircle,
          bgColor: "bg-red-100",
          textColor: "text-red-700",
          borderColor: "border-red-300",
          iconColor: "text-red-600",
        };
      default:
        return {
          icon: Clock,
          bgColor: "bg-gray-100",
          textColor: "text-gray-700",
          borderColor: "border-gray-300",
          iconColor: "text-gray-600",
        };
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-sky-50 to-indigo-50">
      <div className="max-w-7xl mx-auto space-y-6 p-4 sm:p-6 lg:p-8">
        {/* Modern Header */}
        <div className="mb-8">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-sky-100 text-sky-700 border border-sky-200 text-xs sm:text-sm font-semibold mb-3">
            <Wallet className="w-4 h-4" />
            <span>Withdraw Earnings</span>
          </div>
          <h1 className="text-2xl sm:text-3xl lg:text-4xl font-extrabold bg-gradient-to-r from-sky-600 to-sky-700 bg-clip-text text-transparent tracking-tight">
            Withdraw Your Earnings
          </h1>
          <p className="text-gray-600 mt-2 text-sm sm:text-base max-w-2xl">
            Choose your preferred payment method and withdraw your earnings
            securely
          </p>
          <div className="mt-4 inline-flex items-center gap-2 px-4 py-3 rounded-lg bg-sky-100 border border-sky-200 text-sky-800 text-sm font-medium">
            <Clock className="w-5 h-5 text-sky-600 flex-shrink-0" />
            <span>
              Withdrawal processing time: <strong>24 hours</strong>. Your
              request will be processed within 24 hours.
            </span>
          </div>
        </div>

        <div className="bg-gradient-to-r from-amber-50 to-orange-50 border-l-4 border-amber-500 rounded-lg p-4 sm:p-5 flex items-start space-x-3 shadow-sm">
          <AlertCircle className="w-5 h-5 text-amber-600 mt-0.5 flex-shrink-0" />
          <div>
            <h3 className="text-sm font-semibold text-amber-900 mb-1">
              Withdrawal Information
            </h3>
            <p className="text-sm text-amber-800 mt-1 leading-relaxed">
              Minimum withdrawal amount is{" "}
              <strong className="text-amber-900">
                ${minWithdrawalForAttempt.toFixed(2)} / Rs.
                {Math.round(
                  minWithdrawalForAttempt * exchangeRate,
                ).toLocaleString()}
              </strong>
              . A processing fee of{" "}
              <strong className="text-amber-900">5%</strong> will be deducted
              from the requested amount. Processing time is typically{" "}
              <strong className="text-amber-900">24-48 hours</strong>.
            </p>
          </div>
        </div>

        {/* Withdrawal limits (policy copy + matches API withdrawal_limits tiers) */}
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-5">
          <h3 className="text-sm font-bold text-gray-900 mb-3 flex items-center gap-2">
            <Wallet className="w-4 h-4 text-sky-600" />
            Withdrawal Limits
          </h3>
          <ul className="space-y-2 text-sm text-gray-700">
            {withdrawalLimitTiers.map((tier, i) => (
              <li key={tier.attempt} className="flex gap-2">
                <span className="text-sky-600 font-semibold">{i + 1}.</span>
                <span>
                  {ordinalLabel(tier.attempt)} minimum withdrawal
                  {i === withdrawalLimitTiers.length - 1
                    ? " and all next"
                    : ""}
                  : <strong>${tier.min_amount.toFixed(2)}</strong>
                </span>
              </li>
            ))}
            <li className="flex gap-2 pt-1 border-t border-slate-100 mt-2">
              <span className="text-amber-600 font-semibold">•</span>
              <span>
                Only <strong>{maxRequestsPerWindow}</strong> withdrawal request
                can be submitted within{" "}
                <strong>{periodHoursWindow} hours</strong>.
              </span>
            </li>
          </ul>
          {rulesLoading && (
            <p className="text-xs text-gray-500 mt-3 flex items-center gap-2">
              <Loader2 className="w-3.5 h-3.5 animate-spin text-sky-600" />
              Loading live withdrawal rules…
            </p>
          )}
          {rulesError && (
            <p className="text-xs text-amber-800 mt-3">
              {formatIsoDatesInMessage(rulesError)}
            </p>
          )}
          {!rulesLoading &&
            withdrawalRules?.time_limit?.period_hours != null && (
              <p className="text-xs text-gray-500 mt-3">
                Server rule:{" "}
                {Number(withdrawalRules.time_limit.max_requests ?? 1)}{" "}
                request(s) per{" "}
                {Number(withdrawalRules.time_limit.period_hours ?? 24)} hour
                window.
              </p>
            )}
        </div>

        <div className="max-w-2xl mx-auto space-y-6">
          {/* Stats Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="bg-white rounded-xl shadow-sm border-2 border-sky-500 p-4 sm:p-5">
              <div className="flex items-center justify-between mb-2">
                <p className="text-xs sm:text-sm font-medium text-gray-600">
                  Available Balance
                </p>
                <Wallet className="w-5 h-5 text-sky-600" />
              </div>
              <p className="text-xl sm:text-2xl font-bold text-gray-900">
                ${availableBalance.toFixed(2)} / Rs.
                {Math.round(availableBalance * exchangeRate).toLocaleString()}
              </p>
              <p className="text-xs text-gray-500 mt-1">
                This is the maximum you can withdraw right now.
              </p>
            </div>
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-4 sm:p-5">
              <div className="flex items-center justify-between mb-2">
                <p className="text-xs sm:text-sm font-medium text-gray-600">
                  Total Withdrawn
                </p>
                <DollarSign className="w-5 h-5 text-sky-600" />
              </div>
              <p className="text-xl sm:text-2xl font-bold text-gray-900">
                ${pageAmountSum.toFixed(2)} / Rs.
                {Math.round(pageAmountSum * exchangeRate).toLocaleString()}
              </p>
            </div>
          </div>
          <div className="bg-white rounded-xl shadow-lg border border-gray-200 p-6 sm:p-8">
            <div className="flex items-center gap-3 mb-6">
              <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-sky-500 to-sky-600 flex items-center justify-center">
                <Wallet className="w-5 h-5 text-white" />
              </div>
              <h2 className="text-xl sm:text-2xl font-bold text-gray-900">
                Withdrawal Details
              </h2>
            </div>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  Withdrawal Amount
                </label>
                <div className="relative">
                  <DollarSign className="absolute left-4 top-1/2 transform -translate-y-1/2 w-5 h-5 text-sky-500" />
                  <input
                    type="number"
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                    placeholder={minWithdrawalForAttempt.toFixed(2)}
                    min={minWithdrawalForAttempt}
                    step="0.01"
                    className="w-full pl-12 pr-4 py-3.5 border-2 border-gray-200 rounded-xl focus:ring-2 focus:ring-sky-500 focus:border-sky-500 transition-all text-gray-900 font-medium"
                  />
                </div>
                <p className="text-xs text-gray-500 mt-2 flex items-center gap-1">
                  <AlertCircle className="w-3 h-3" />
                  Minimum withdrawal: ${minWithdrawalForAttempt.toFixed(2)} /
                  Rs.
                  {Math.round(
                    minWithdrawalForAttempt * exchangeRate,
                  ).toLocaleString()}
                </p>
                {amountNum > 0 && amountNum < minWithdrawalForAttempt && (
                  <p className="text-xs text-red-600 mt-1 flex items-center gap-1">
                    <AlertCircle className="w-3 h-3" />
                    Amount is below the minimum withdrawal of $
                    {minWithdrawalForAttempt.toFixed(2)}.
                  </p>
                )}
                {amountNum > availableBalance && (
                  <p className="text-xs text-red-600 mt-1 flex items-center gap-1">
                    <AlertCircle className="w-3 h-3" />
                    Amount exceeds your available balance of $
                    {availableBalance.toFixed(2)}.
                  </p>
                )}
              </div>

              {isInternationalUser ? (
                /* International User - BEP20 Address */
                <>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      BEP20 Wallet Address
                    </label>
                    <input
                      type="text"
                      value={bep20Address}
                      readOnly
                      className="w-full px-4 py-3.5 border-2 border-gray-200 rounded-xl bg-gray-50 text-gray-600 cursor-not-allowed font-mono text-sm"
                    />
                    <p className="text-sm text-gray-500 mt-1">
                      Your BEP20 wallet address from your profile
                    </p>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Network
                    </label>
                    <input
                      type="text"
                      value={cryptoNetwork}
                      readOnly
                      className="w-full px-4 py-3.5 border-2 border-gray-200 rounded-xl bg-gray-50 text-gray-600 cursor-not-allowed"
                    />
                    <p className="text-sm text-gray-500 mt-1">
                      Binance Smart Chain (BSC) network
                    </p>
                  </div>
                </>
              ) : (
                /* Pakistani User - Bank/Mobile Money Details */
                <>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Account Number
                    </label>
                    <input
                      type="text"
                      value={accountNumber}
                      readOnly
                      className="w-full px-4 py-3.5 border-2 border-gray-200 rounded-xl bg-gray-50 text-gray-600 cursor-not-allowed"
                    />
                    <p className="text-sm text-gray-500 mt-1">
                      This field is automatically filled from your profile
                    </p>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Account Title
                    </label>
                    <input
                      type="text"
                      value={accountTitle}
                      readOnly
                      className="w-full px-4 py-3.5 border-2 border-gray-200 rounded-xl bg-gray-50 text-gray-600 cursor-not-allowed"
                    />
                    <p className="text-sm text-gray-500 mt-1">
                      This field is automatically filled from your profile
                    </p>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Account Type
                    </label>
                    <input
                      type="text"
                      value={accountType}
                      readOnly
                      className="w-full px-4 py-3.5 border-2 border-gray-200 rounded-xl bg-gray-50 text-gray-600 cursor-not-allowed"
                    />
                    <p className="text-sm text-gray-500 mt-1">
                      This field is automatically filled from your profile
                    </p>
                  </div>
                </>
              )}

              {profileLoading && (
                <div className="flex items-center justify-center py-4">
                  <Loader2 className="w-6 h-6 text-sky-600 animate-spin mr-2" />
                  <span className="text-gray-600">Loading profile data...</span>
                </div>
              )}

              {profileError && (
                <div className="bg-red-50 border border-red-200 rounded-lg p-4 flex items-start space-x-3">
                  <AlertCircle className="w-5 h-5 text-red-600 mt-0.5 flex-shrink-0" />
                  <div>
                    <h3 className="text-sm font-semibold text-red-800">
                      Profile Error
                    </h3>
                    <p className="text-sm text-red-700 mt-1">
                      {formatIsoDatesInMessage(String(profileError))}
                    </p>
                  </div>
                </div>
              )}

              <div className="bg-gradient-to-br from-sky-50 to-blue-50 border-2 border-sky-200 rounded-xl p-5">
                <h3 className="text-sm font-bold text-gray-900 mb-4 flex items-center gap-2">
                  <TrendingUp className="w-4 h-4 text-sky-600" />
                  Withdrawal Summary
                </h3>
                <div className="space-y-3 text-sm">
                  <div className="flex justify-between items-center">
                    <span className="text-gray-700 font-medium">
                      Requested Amount:
                    </span>
                    <span className="font-semibold text-gray-900">
                      ${amountNum.toFixed(2)} / Rs.
                      {Math.round(amountNum * exchangeRate).toLocaleString()}
                    </span>
                  </div>
                  <div className="flex justify-between items-center text-xs text-gray-600">
                    <span>Processing Fee (5%):</span>
                    <span>
                      ${processingFee.toFixed(2)} / Rs.
                      {Math.round(
                        processingFee * exchangeRate,
                      ).toLocaleString()}
                    </span>
                  </div>
                  <div className="border-t-2 border-sky-200 pt-3 flex justify-between items-center">
                    <span className="font-bold text-gray-900 text-base">
                      You'll Receive:
                    </span>
                    <span className="font-extrabold text-emerald-600 text-lg">
                      ${netAmount.toFixed(2)} / Rs.
                      {Math.round(netAmount * exchangeRate).toLocaleString()}
                    </span>
                  </div>
                </div>
              </div>

              <button
                onClick={handleSubmit}
                disabled={
                  !amount || amountNum < minWithdrawalForAttempt || isLoading
                }
                className="w-full bg-gradient-to-r from-sky-600 to-sky-700 text-white py-4 px-6 rounded-xl font-semibold hover:from-sky-700 hover:to-sky-800 focus:ring-2 focus:ring-sky-500 focus:ring-offset-2 disabled:from-gray-300 disabled:to-gray-400 disabled:cursor-not-allowed transition-all transform hover:scale-[1.02] active:scale-[0.98] shadow-lg hover:shadow-xl flex items-center justify-center gap-2"
              >
                {isLoading ? (
                  <>
                    <Loader2 className="w-5 h-5 animate-spin" />
                    <span>Processing...</span>
                  </>
                ) : (
                  <>
                    <Wallet className="w-5 h-5" />
                    <span>Submit Withdrawal Request</span>
                  </>
                )}
              </button>

              {error && (
                <div className="bg-red-50 border-l-4 border-red-500 rounded-lg p-4 flex items-start space-x-3 shadow-sm">
                  <AlertCircle className="w-5 h-5 text-red-600 mt-0.5 flex-shrink-0" />
                  <div className="flex-1">
                    <h3 className="text-sm font-semibold text-red-800">Error</h3>
                    <p className="text-sm text-red-700 mt-1">
                      {formatIsoDatesInMessage(error)}
                    </p>
                  </div>
                  <button
                    onClick={() => setError(null)}
                    className="text-red-400 hover:text-red-600"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              )}

              {successMessage && (
                <div className="bg-emerald-50 border-l-4 border-emerald-500 rounded-lg p-4 flex items-start space-x-3 shadow-sm">
                  <CheckCircle className="w-5 h-5 text-emerald-600 mt-0.5 flex-shrink-0" />
                  <div className="flex-1">
                    <h3 className="text-sm font-semibold text-emerald-800">
                      Success
                    </h3>
                    <p className="text-sm text-emerald-700 mt-1">
                      {successMessage}
                    </p>
                  </div>
                  <button
                    onClick={() => setSuccessMessage(null)}
                    className="text-emerald-400 hover:text-emerald-600"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-lg border border-gray-200 overflow-hidden">
          <div className="p-6 sm:p-8 border-b border-gray-200 bg-gradient-to-r from-gray-50 to-white">
            <div className="flex items-center gap-3 mb-2">
              <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-purple-500 to-purple-600 flex items-center justify-center">
                <FileText className="w-5 h-5 text-white" />
              </div>
              <h2 className="text-xl sm:text-2xl font-bold text-gray-900">
                Withdrawal History
              </h2>
            </div>
            <p className="text-gray-600 text-sm sm:text-base ml-[52px]">
              Track all your withdrawal requests and their status
            </p>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full min-w-[600px]">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    #
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Date
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Time
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Amount
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Withdrawal Amount
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    {isInternationalUser ? "BEP20 Address" : "Account Number"}
                  </th>
                  {!isInternationalUser && (
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Account Title
                    </th>
                  )}
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    {isInternationalUser ? "Network" : "Account Type"}
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Status
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Reason
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {withdrawalHistory.map((withdrawal: any, index: number) => (
                  <tr key={withdrawal.id || index} className="hover:bg-gray-50">
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm font-medium text-gray-900">
                        {index + 1}
                      </div>
                    </td>

                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-gray-900">
                        {withdrawal.created_at
                          ? withdrawal.created_at.slice(0, 10)
                          : (withdrawal.date ?? "-")}
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-gray-500">
                        {withdrawal.created_at
                          ? new Date(withdrawal.created_at).toLocaleTimeString()
                          : (withdrawal.time ?? "-")}
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm font-semibold text-gray-900">
                        Rs.{" "}
                        {Math.round(
                          Number(withdrawal.amount ?? 0) * exchangeRate,
                        ).toLocaleString()}
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-gray-900">
                        Rs.{" "}
                        {Math.round(
                          (withdrawal.net_amount != null
                            ? Number(withdrawal.net_amount)
                            : Number(withdrawal.amount ?? 0) -
                              (withdrawal.fee != null
                                ? Number(withdrawal.fee)
                                : Number(withdrawal.amount ?? 0) * feeRate)) *
                            exchangeRate,
                        ).toLocaleString()}
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div
                        className={`text-sm text-gray-900 ${isInternationalUser ? "font-mono text-xs" : ""}`}
                      >
                        {isInternationalUser
                          ? withdrawal.crypto_address ||
                            withdrawal.account_number ||
                            "-"
                          : (withdrawal.account_number ?? "-")}
                      </div>
                    </td>
                    {!isInternationalUser && (
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-gray-900">
                          {accountTitle ?? "-"}
                        </div>
                      </td>
                    )}
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-gray-900">
                        {isInternationalUser
                          ? withdrawal.crypto_network || "BEP20 (BSC)"
                          : (withdrawal.account_type ?? "-")}
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      {(() => {
                        const statusDisplay = getStatusDisplay(
                          withdrawal.status,
                        );
                        const StatusIcon = statusDisplay.icon;
                        return (
                          <span
                            className={`px-3 py-1.5 inline-flex items-center gap-1.5 text-xs leading-5 font-semibold rounded-full border ${statusDisplay.bgColor} ${statusDisplay.textColor} ${statusDisplay.borderColor}`}
                          >
                            <StatusIcon
                              className={`w-3.5 h-3.5 ${statusDisplay.iconColor}`}
                            />
                            {(withdrawal.status || "pending")
                              .charAt(0)
                              .toUpperCase() +
                              (withdrawal.status || "pending").slice(1)}
                          </span>
                        );
                      })()}
                    </td>
                    <td className="px-6 py-4">
                      {withdrawal.status === "rejected" && withdrawal.rejection_reason ? (
                        <div className="max-w-[180px] text-xs text-red-600 leading-snug">
                          {withdrawal.rejection_reason}
                        </div>
                      ) : (
                        <span className="text-xs text-gray-400">—</span>
                      )}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center gap-2">
                        {/* Screenshot Upload Button */}
                        {(withdrawal.status === "pending" ||
                          withdrawal.status === "processing") && (
                          <label className="relative cursor-pointer">
                            <input
                              type="file"
                              accept="image/*"
                              className="hidden"
                              onChange={(e) => {
                                const file = e.target.files?.[0];
                                if (file && withdrawal.id) {
                                  handleScreenshotUpload(
                                    Number(withdrawal.id),
                                    file,
                                  );
                                }
                              }}
                              disabled={uploadingScreenshot === withdrawal.id}
                            />
                            <button
                              className={`px-3 py-1.5 text-xs font-medium rounded-lg border transition-all ${
                                uploadingScreenshot === withdrawal.id
                                  ? "bg-gray-100 text-gray-400 border-gray-300 cursor-not-allowed"
                                  : "bg-blue-50 text-blue-700 border-blue-200 hover:bg-blue-100"
                              } flex items-center gap-1.5`}
                              disabled={uploadingScreenshot === withdrawal.id}
                            >
                              {uploadingScreenshot === withdrawal.id ? (
                                <>
                                  <Loader2 className="w-3 h-3 animate-spin" />
                                  <span>Uploading...</span>
                                </>
                              ) : (
                                <>
                                  <Camera className="w-3.5 h-3.5" />
                                  <span>Upload SS</span>
                                </>
                              )}
                            </button>
                          </label>
                        )}

                        {/* Screenshot Preview */}
                        {screenshotPreview[withdrawal.id] && (
                          <div className="relative group">
                            <img
                              src={screenshotPreview[withdrawal.id]}
                              alt="Screenshot preview"
                              className="w-8 h-8 rounded object-cover border border-gray-300 cursor-pointer"
                              onClick={() => {
                                // Open in modal or full view
                                window.open(
                                  screenshotPreview[withdrawal.id],
                                  "_blank",
                                );
                              }}
                            />
                          </div>
                        )}

                        {/* View Receipt Button */}
                        <button
                          className="px-3 py-1.5 text-xs font-medium text-sky-600 hover:text-sky-800 hover:bg-sky-50 rounded-lg border border-sky-200 transition-all flex items-center gap-1.5"
                          onClick={() => {
                            setActiveReceipt(withdrawal);
                            setShowReceipt(true);
                          }}
                        >
                          <FileText className="w-3.5 h-3.5" />
                          <span>View</span>
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            {/* Pagination Controls */}
            <div className="flex items-center justify-between px-6 py-4 border-t border-gray-200 bg-gradient-to-r from-gray-50 to-white">
              <button
                className="px-4 py-2 text-sm font-medium rounded-lg bg-white border-2 border-gray-300 text-gray-700 hover:bg-gray-50 hover:border-gray-400 disabled:opacity-50 disabled:cursor-not-allowed transition-all flex items-center gap-2"
                onClick={() => setHistoryPage((p) => Math.max(1, p - 1))}
                disabled={historyPage <= 1}
              >
                <span>←</span>
                <span>Previous</span>
              </button>
              <div className="text-sm font-semibold text-gray-700 bg-white px-4 py-2 rounded-lg border border-gray-200">
                Page <span className="text-sky-600">{historyPage}</span> of{" "}
                <span className="text-sky-600">{historyTotalPages}</span>
              </div>
              <button
                className="px-4 py-2 text-sm font-medium rounded-lg bg-white border-2 border-gray-300 text-gray-700 hover:bg-gray-50 hover:border-gray-400 disabled:opacity-50 disabled:cursor-not-allowed transition-all flex items-center gap-2"
                onClick={() =>
                  setHistoryPage((p) => Math.min(historyTotalPages, p + 1))
                }
                disabled={historyPage >= historyTotalPages}
              >
                <span>Next</span>
                <span>→</span>
              </button>
            </div>
          </div>
        </div>

        {showReceipt && activeReceipt && (
          <div className="fixed inset-0 z-50 flex items-center justify-center">
            <div
              className="absolute inset-0 bg-black/50"
              onClick={closeReceipt}
            />
            <div className="relative z-10 w-[92%] max-w-sm sm:max-w-md">
              {/* White outer frame */}
              <div className="bg-white/95 rounded-3xl shadow-2xl p-2">
                {/* Gradient card */}
                <div className="relative rounded-2xl bg-gradient-to-b from-sky-600 via-blue-600 to-indigo-700 text-white p-5 overflow-auto h-[620px] sm:h-[660px] md:h-[700px]">
                  {/* Close */}
                  <button
                    onClick={closeReceipt}
                    className="absolute right-3 top-3 text-white/90 hover:text-white"
                    aria-label="Close"
                  >
                    <X className="w-5 h-5" />
                  </button>

                  {/* Title */}
                  <h3 className="text-xl font-bold text-center">
                    Withdrawal Receipt
                  </h3>

                  {/* Status chip with icon */}
                  <div className="mt-4 mb-2 flex items-center gap-2 justify-center">
                    {(() => {
                      const statusDisplay = getStatusDisplay(
                        activeReceipt.status,
                      );
                      const StatusIcon = statusDisplay.icon;
                      return (
                        <>
                          <div
                            className={`h-8 w-8 rounded-full ${statusDisplay.bgColor} border-2 ${statusDisplay.borderColor} flex items-center justify-center`}
                          >
                            <StatusIcon
                              className={`w-4 h-4 ${statusDisplay.iconColor}`}
                            />
                          </div>
                          <span
                            className={`uppercase tracking-widest font-bold ${statusDisplay.textColor} text-sm`}
                          >
                            {activeReceipt.status || "Pending"}
                          </span>
                        </>
                      );
                    })()}
                  </div>

                  {/* Divider */}
                  <div className="h-px w-full bg-white/30 my-3" />

                  {/* Info rows */}
                  <div className="space-y-3 text-sm">
                    <div className="flex items-center justify-between">
                      <span className="text-white/85">Transaction ID:</span>
                      <span className="font-semibold">#{activeReceipt.id}</span>
                    </div>

                    <div className="flex items-center justify-between">
                      <span className="text-white/85">Date:</span>
                      <span className="font-semibold">
                        {activeReceipt.created_at
                          ? new Date(
                              activeReceipt.created_at,
                            ).toLocaleDateString()
                          : new Date().toLocaleDateString()}
                      </span>
                    </div>

                    <div className="flex items-center justify-between">
                      <span className="text-white/85">Time:</span>
                      <span className="font-semibold">
                        {activeReceipt.created_at
                          ? new Date(
                              activeReceipt.created_at,
                            ).toLocaleTimeString()
                          : new Date().toLocaleTimeString()}
                      </span>
                    </div>

                    {activeReceipt.net_amount && (
                      <div className="flex items-center justify-between">
                        <span className="text-white/85">
                          Withdrawal Amount:
                        </span>
                        <span className="font-semibold">
                          ${Number(activeReceipt.net_amount).toFixed(2)} / Rs.{" "}
                          {Math.round(
                            activeReceipt.net_amount * exchangeRate,
                          ).toLocaleString()}
                        </span>
                      </div>
                    )}

                    <div className="flex items-center justify-between">
                      <span className="text-white/85">Payment Method:</span>
                      <span className="font-semibold">
                        {activeReceipt.payment_method ||
                          activeReceipt.account_type ||
                          "-"}
                      </span>
                    </div>

                    {activeReceipt.crypto_network ? (
                      <>
                        <div className="flex flex-col gap-1">
                          <span className="text-white/85">Crypto Network:</span>
                          <span className="font-semibold">
                            {activeReceipt.crypto_network}
                          </span>
                        </div>
                        <div className="flex flex-col gap-1">
                          <span className="text-white/85">Crypto Address:</span>
                          <span className="font-mono text-xs break-all bg-white/10 rounded px-2 py-1">
                            {activeReceipt.crypto_address || "-"}
                          </span>
                        </div>
                      </>
                    ) : (
                      <>
                        <div className="flex items-center justify-between">
                          <span className="text-white/85">Account Number:</span>
                          <span className="font-semibold">
                            {activeReceipt.account_number || "-"}
                          </span>
                        </div>
                        <div className="flex items-center justify-between">
                          <span className="text-white/85">Account Title:</span>
                          <span className="font-semibold">
                            {accountTitle || "-"}
                          </span>
                        </div>
                        <div className="flex items-center justify-between">
                          <span className="text-white/85">Account Type:</span>
                          <span className="font-semibold">
                            {activeReceipt.account_type || "-"}
                          </span>
                        </div>
                      </>
                    )}

                    {activeReceipt.transaction_hash && (
                      <div className="flex flex-col gap-1">
                        <span className="text-white/85">Transaction Hash:</span>
                        <span className="font-mono text-xs break-all bg-white/10 rounded px-2 py-1">
                          {activeReceipt.transaction_hash}
                        </span>
                      </div>
                    )}

                    <div className="flex items-center justify-between">
                      <span className="text-white/85">Status:</span>
                      <span
                        className={`font-extrabold ${activeReceipt.status === "rejected" ? "text-red-300" : activeReceipt.status === "completed" ? "text-emerald-300" : "text-amber-300"}`}
                      >
                        {(activeReceipt.status || "pending")
                          .charAt(0)
                          .toUpperCase() +
                          (activeReceipt.status || "pending").slice(1)}
                      </span>
                    </div>

                    {activeReceipt.status === "rejected" && activeReceipt.rejection_reason && (
                      <div className="flex flex-col gap-1 bg-red-900/30 border border-red-400/30 rounded-lg px-3 py-2">
                        <span className="text-white/85 text-xs font-semibold">Rejection Reason:</span>
                        <span className="text-red-200 text-xs leading-snug">{activeReceipt.rejection_reason}</span>
                      </div>
                    )}

                    {activeReceipt.updated_at &&
                      activeReceipt.updated_at !== activeReceipt.created_at && (
                        <div className="flex items-center justify-between">
                          <span className="text-white/85">Last Updated:</span>
                          <span className="font-semibold">
                            {new Date(
                              activeReceipt.updated_at,
                            ).toLocaleString()}
                          </span>
                        </div>
                      )}
                  </div>

                  {/* Bottom divider + thanks */}
                  <div className="h-px w-full bg-white/30 my-4" />
                  <p className="text-center text-[11px]">
                    Thanks For Using{" "}
                    <span className="font-bold text-sky-200">
                      SkyBridge International
                    </span>
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default Withdraw;
