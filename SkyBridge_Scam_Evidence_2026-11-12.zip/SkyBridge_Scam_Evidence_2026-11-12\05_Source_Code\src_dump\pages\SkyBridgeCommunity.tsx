import React, { useState, useEffect } from "react";
import {
  Users,
  MessageCircle,
  Heart,
  Share2,
  Calendar,
  Trophy,
} from "lucide-react";
import { apiClient } from "../services/apiClient";

const SkyBridgeCommunity: React.FC = () => {
  const communityStats = [
    {
      icon: Users,
      label: "Active Members",
      value: "12,450",
      color: "text-blue-600",
    },
    {
      icon: MessageCircle,
      label: "Daily Posts",
      value: "1,234",
      color: "text-green-600",
    },
    {
      icon: Heart,
      label: "Likes Today",
      value: "5,678",
      color: "text-red-600",
    },
    { icon: Share2, label: "Shares", value: "890", color: "text-purple-600" },
  ];

  // Static array of 50 comments with varying lengths
  const allComments = [
    {
      id: 1,
      author: "Sara Ahmed",
      time: "2 hours ago",
      content:
        "Just reached my first milestone! Thanks to the amazing SkyBridge community for all the support and guidance. The journey has been incredible so far, and I'm excited to see what comes next. Every day brings new opportunities and learning experiences! 🎉",
      likes: 45,
      comments: 12,
    },
    {
      id: 2,
      author: "Mikaeel Khan",
      time: "4 hours ago",
      content: "Amazing results! $1000 in first month! 💰",
      likes: 78,
      comments: 23,
    },
    {
      id: 3,
      author: "Emaan Ali",
      time: "6 hours ago",
      content:
        "New training session tomorrow at 3 PM EST. Don't miss out on learning the latest strategies and techniques that will help you grow your business!",
      likes: 34,
      comments: 8,
    },
    {
      id: 4,
      author: "Ahmed Ali",
      time: "1 hour ago",
      content:
        "SkyBridge changed my life completely! From struggling financially to earning $500 in just my second week. The platform provides everything you need to succeed - training, support, and real opportunities. Grateful for this amazing community! 🚀",
      likes: 67,
      comments: 15,
    },
    {
      id: 5,
      author: "Mahira Khan",
      time: "3 hours ago",
      content: "Love the training materials here!",
      likes: 42,
      comments: 9,
    },
    {
      id: 6,
      author: "Daniyal Hussain",
      time: "5 hours ago",
      content:
        "Just completed my first successful referral! The commission system is fantastic and the support team helped me through every step.",
      likes: 56,
      comments: 18,
    },
    {
      id: 7,
      author: "Fatima Khan",
      time: "30 minutes ago",
      content:
        "SkyBridge has given me financial freedom. From Pakistan to the world! The global reach of this platform is incredible and the earning opportunities are endless. So proud to be part of this community! 🇵🇰",
      likes: 89,
      comments: 25,
    },
    {
      id: 8,
      author: "Junaid Iqbal",
      time: "1 hour ago",
      content: "Best community ever! 👏",
      likes: 38,
      comments: 11,
    },
    {
      id: 9,
      author: "Areeba Sheikh",
      time: "2 hours ago",
      content:
        "Crossed $2000 this month! SkyBridge International is the real deal and I'm living proof of it! 🚀",
      likes: 95,
      comments: 32,
    },
    {
      id: 10,
      author: "Khalid Riaz",
      time: "4 hours ago",
      content: "The mobile app makes tracking so easy!",
      likes: 29,
      comments: 7,
    },
    {
      id: 11,
      author: "Ayesha Siddiqui",
      time: "6 hours ago",
      content:
        "Weekly webinars are incredibly informative and practical! Learning new strategies every week that I can immediately apply to my business. The trainers are experts and always available for questions. Highly recommend attending these sessions! 📚",
      likes: 51,
      comments: 14,
    },
    {
      id: 12,
      author: "Raza Shah",
      time: "8 hours ago",
      content: "Life changed! 💪",
      likes: 73,
      comments: 21,
    },
    {
      id: 13,
      author: "Zara Ahmed",
      time: "1 day ago",
      content:
        "The withdrawal process is so smooth and fast. Got my payment in 24 hours! No delays, no complications.",
      likes: 64,
      comments: 19,
    },
    {
      id: 14,
      author: "Mikaal Abbas",
      time: "1 day ago",
      content:
        "Building my team has been an incredible journey with SkyBridge! The leadership training is absolutely top-notch and covers everything from communication skills to advanced business strategies. The mentorship program has been a game-changer for my personal and professional growth!",
      likes: 47,
      comments: 13,
    },
    {
      id: 15,
      author: "Nadia Hassan",
      time: "1 day ago",
      content: "From housewife to entrepreneur! 👩‍💼",
      likes: 82,
      comments: 28,
    },
    {
      id: 16,
      author: "Jameel Tariq",
      time: "2 days ago",
      content:
        "The transparency in this platform is refreshing. Real earnings, real opportunities! Everything is clearly explained and documented.",
      likes: 55,
      comments: 16,
    },
    {
      id: 17,
      author: "Sana Malik",
      time: "2 days ago",
      content:
        "SkyBridge community feels like family. Supporting each other to success! The bonds we've formed here go beyond business - we genuinely care about each other's growth and wellbeing. This supportive environment makes all the difference! ❤️",
      likes: 71,
      comments: 22,
    },
    {
      id: 18,
      author: "Danish Zubair",
      time: "2 days ago",
      content: "Bonus system rocks! 🎯",
      likes: 43,
      comments: 10,
    },
    {
      id: 19,
      author: "Amina Yusuf",
      time: "3 days ago",
      content:
        "Grateful for this opportunity. SkyBridge is blessing for people like us! The platform has opened doors I never knew existed.",
      likes: 68,
      comments: 20,
    },
    {
      id: 20,
      author: "Salman Malik",
      time: "3 days ago",
      content:
        "Customer support is outstanding! They resolve issues within hours and always go the extra mile to ensure customer satisfaction. The team is professional, friendly, and incredibly knowledgeable about every aspect of the platform!",
      likes: 36,
      comments: 8,
    },
    {
      id: 21,
      author: "Khadija Omar",
      time: "3 days ago",
      content:
        "The earning potential here is unlimited. Sky is the limit! The opportunities keep growing and expanding every day. I've discovered income streams I never knew existed before joining this amazing platform! ✨",
      likes: 79,
      comments: 24,
    },
    {
      id: 22,
      author: "Rayyan Yusuf",
      time: "4 days ago",
      content: "Daily challenges are amazing! 🎯",
      likes: 41,
      comments: 12,
    },
    {
      id: 23,
      author: "Hina Rashid",
      time: "4 days ago",
      content:
        "SkyBridge gave me confidence to dream big. Now I'm achieving those dreams! The mindset shift has been incredible.",
      likes: 87,
      comments: 29,
    },
    {
      id: 24,
      author: "Kamran Ahmed",
      time: "4 days ago",
      content:
        "The analytics dashboard is incredibly detailed and user-friendly! I can track every aspect of my business performance, from daily earnings to long-term growth trends. The insights help me make better decisions and optimize my strategies for maximum results!",
      likes: 33,
      comments: 6,
    },
    {
      id: 25,
      author: "Laiba Iqbal",
      time: "5 days ago",
      content: "Zero to expert! 📈",
      likes: 62,
      comments: 17,
    },
    {
      id: 26,
      author: "Murtaza Ali",
      time: "5 days ago",
      content:
        "SkyBridge International is not just a platform, it's a movement! The vision and mission resonate with thousands of people worldwide. 🌟",
      likes: 76,
      comments: 23,
    },
    {
      id: 27,
      author: "Rabia Siddique",
      time: "5 days ago",
      content:
        "The monthly rewards program is absolutely fantastic! It provides extra motivation to perform well and gives recognition to consistent performers. The rewards are substantial and really make a difference in monthly earnings. Love this feature!",
      likes: 49,
      comments: 14,
    },
    {
      id: 28,
      author: "Kashif Hussain",
      time: "6 days ago",
      content: "Passive income made easy! 💰",
      likes: 58,
      comments: 18,
    },
    {
      id: 29,
      author: "Maryam Ali",
      time: "6 days ago",
      content:
        "The community events are so engaging! Love meeting fellow entrepreneurs and sharing experiences. Networking has never been this fun!",
      likes: 44,
      comments: 11,
    },
    {
      id: 30,
      author: "Bilal Khan",
      time: "6 days ago",
      content:
        "SkyBridge tools and resources are absolutely world-class! Everything you need to succeed is provided in one comprehensive platform. From training materials to analytics tools, from community support to expert guidance - it's all here! The quality is unmatched in the industry.",
      likes: 65,
      comments: 19,
    },
    {
      id: 31,
      author: "Samira Khan",
      time: "1 week ago",
      content:
        "The mentorship program changed my perspective completely. Grateful for the guidance and support from experienced leaders who genuinely care about our success! The one-on-one sessions have been invaluable for my personal and professional growth.",
      likes: 72,
      comments: 21,
    },
    {
      id: 32,
      author: "Anas Riaz",
      time: "1 week ago",
      content: "Consistency pays off! 💪",
      likes: 39,
      comments: 9,
    },
    {
      id: 33,
      author: "Farah Noor",
      time: "1 week ago",
      content:
        "SkyBridge made financial literacy accessible to everyone. Knowledge is power! The educational resources are comprehensive and easy to understand. 📚",
      likes: 81,
      comments: 26,
    },
    {
      id: 34,
      author: "Burhan Shah",
      time: "1 week ago",
      content:
        "The global reach of this platform is absolutely impressive! Connecting with people from different countries and cultures has been an amazing experience. SkyBridge truly brings the world together through shared opportunities and mutual success!",
      likes: 52,
      comments: 15,
    },
    {
      id: 35,
      author: "Ayesha Tariq",
      time: "1 week ago",
      content: "Student to earner! 🎓💰",
      likes: 69,
      comments: 20,
    },
    {
      id: 36,
      author: "Jason Hall",
      time: "1 week ago",
      content:
        "The innovation in this platform keeps surprising me. Always something new and exciting! The development team is constantly improving features.",
      likes: 37,
      comments: 8,
    },
    {
      id: 37,
      author: "Saima Iqbal",
      time: "1 week ago",
      content:
        "SkyBridge community celebrates everyone's success! No competition, just pure collaboration and mutual support. The positive energy here is contagious and motivates everyone to achieve their best. We lift each other up and celebrate together!",
      likes: 84,
      comments: 27,
    },
    {
      id: 38,
      author: "Ehtesham Khan",
      time: "1 week ago",
      content: "Top-notch security! 🔒",
      likes: 46,
      comments: 13,
    },
    {
      id: 39,
      author: "Noor Fatima",
      time: "1 week ago",
      content:
        "Breaking barriers and stereotypes! SkyBridge empowers women entrepreneurs and provides equal opportunities for everyone. Proud to be part of this inclusive community! 👑",
      likes: 93,
      comments: 31,
    },
    {
      id: 40,
      author: "Talha Khan",
      time: "2 weeks ago",
      content:
        "The scalability of earnings here is absolutely amazing! Growth has no limits and the potential keeps expanding. I've seen my income multiply month after month with consistent effort and the right strategies. The sky truly is the limit here!",
      likes: 61,
      comments: 18,
    },
    {
      id: 41,
      author: "Rubina Shah",
      time: "2 weeks ago",
      content: "Passion to profession! ✨",
      likes: 75,
      comments: 22,
    },
    {
      id: 42,
      author: "Ali Raza",
      time: "2 weeks ago",
      content:
        "The technology behind this platform is cutting-edge. Impressed by the innovation and user experience! Everything works seamlessly.",
      likes: 40,
      comments: 10,
    },
    {
      id: 43,
      author: "Shazia Malik",
      time: "2 weeks ago",
      content:
        "From traditional job to digital entrepreneur! SkyBridge made the transition incredibly smooth and provided all the support I needed. The learning curve was manageable thanks to excellent training and mentorship. Now I'm living my entrepreneurial dreams!",
      likes: 77,
      comments: 24,
    },
    {
      id: 44,
      author: "Noman Iqbal",
      time: "2 weeks ago",
      content: "Multiple income streams! 💼",
      likes: 54,
      comments: 16,
    },
    {
      id: 45,
      author: "Bushra Aziz",
      time: "2 weeks ago",
      content:
        "SkyBridge gave me wings to fly high! Soaring towards financial freedom every single day. The opportunities are endless and the support is incredible! 🦅",
      likes: 88,
      comments: 28,
    },
    {
      id: 46,
      author: "Luqman Ahmed",
      time: "2 weeks ago",
      content:
        "The training quality is exceptional and comprehensive! Professional development at its absolute best. The curriculum covers everything from basics to advanced strategies, and the instructors are industry experts with real-world experience!",
      likes: 48,
      comments: 14,
    },
    {
      id: 47,
      author: "Mariam Hussain",
      time: "2 weeks ago",
      content: "Building generational wealth! 🏛️",
      likes: 86,
      comments: 25,
    },
    {
      id: 48,
      author: "Tahir Hussain",
      time: "2 weeks ago",
      content:
        "The work-life balance here is perfect. Earning while enjoying life! Flexibility is amazing and allows me to spend quality time with family.",
      likes: 35,
      comments: 7,
    },
    {
      id: 49,
      author: "Sidra Baig",
      time: "2 weeks ago",
      content:
        "SkyBridge community is my second family! Love and support everywhere you look. The relationships I've built here go beyond business - we genuinely care about each other's success and wellbeing. This supportive environment makes all the difference! 🤗",
      likes: 91,
      comments: 30,
    },
    {
      id: 50,
      author: "Jibran Ali",
      time: "2 weeks ago",
      content: "Bright future ahead! 🌟",
      likes: 63,
      comments: 19,
    },
  ];

  // State for current displayed posts
  const [recentPosts, setRecentPosts] = useState<typeof allComments>([]);

  // Leaderboard state (Top 3)
  const [leaders, setLeaders] = useState<
    Array<{
      name: string;
      income: number;
      country: string;
      country_flag?: string;
      position: number;
    }>
  >([]);
  const [leadersLoading, setLeadersLoading] = useState<boolean>(true);
  const [leadersError, setLeadersError] = useState<string | null>(null);

  // Function to get 3 random comments
  const isPakistaniName = (name: string) => {
    const pkPatterns =
      /(ahmed|ali|khan|fatima|noor|amin|hassan|hussain|tariq|rabia|ayesha|saima|zara|maryam|sidra|khadija|sana|hina|iqbal|shah|yusuf|malik|baig|abbas|riaz|zubair)/i;
    return pkPatterns.test(name || "");
  };

  const getRandomComments = () => {
    const shuffled = [...allComments].sort(() => 0.5 - Math.random());
    let pick = shuffled.slice(0, 3);
    if (!pick.some((p) => isPakistaniName(p.author))) {
      const pk = shuffled.find((p) => isPakistaniName(p.author));
      if (pk) {
        pick[0] = pk;
      }
    }
    return pick;
  };

  // Initialize and set up auto-rotation
  useEffect(() => {
    // Set initial random comments
    setRecentPosts(getRandomComments());

    // Set up interval to change comments every 3 hours (3 * 60 * 60 * 1000 ms)
    const interval = setInterval(
      () => {
        setRecentPosts(getRandomComments());
      },
      3 * 60 * 60 * 1000,
    );

    // Cleanup interval on component unmount
    return () => clearInterval(interval);
  }, []);

  // Fetch Top 3 leaders with default filter all_time and fixed date range
  useEffect(() => {
    const fetchTopLeaders = async () => {
      try {
        setLeadersLoading(true);
        setLeadersError(null);
        apiClient.refreshAuthToken();
        const res = await apiClient.get(`/leaderboard?filter=all_time`);
        const responseData: any = res.data;
        const apiLeaders =
          responseData?.leaders || responseData?.data?.leaders || [];
        const mapped = apiLeaders
          .slice(0, 3)
          .map((item: any, index: number) => ({
            name: item.full_name || item.name,
            income: parseFloat(item.total_earned || item.income || 0),
            country: item.country,
            country_flag: item.country_flag,
            position: item.position ?? index + 1,
          }));
        setLeaders(mapped);
      } catch (err: any) {
        setLeadersError(err.message || "Failed to load leaders");
      } finally {
        setLeadersLoading(false);
      }
    };
    fetchTopLeaders();
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent mb-2">
            SkyBridge Community
          </h1>
          <p className="text-gray-600 text-lg">
            Connect, Share, and Grow Together
          </p>
        </div>

        {/* Main Content */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Community Feed */}
          <div className="lg:col-span-2">
            <div className="bg-white rounded-2xl shadow-lg p-6">
              {/* Recent Posts */}
              <div className="space-y-6">
                {recentPosts.map((post) => (
                  <div
                    key={post.id}
                    className="border border-gray-200 rounded-xl p-6 hover:shadow-md transition-all duration-200"
                  >
                    <div className="flex items-center mb-3">
                      <div className="w-10 h-10 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full flex items-center justify-center text-white font-bold">
                        {post.author.charAt(0)}
                      </div>
                      <div className="ml-3">
                        <p className="font-semibold text-gray-900">
                          {post.author}
                        </p>
                        <p className="text-gray-500 text-sm">{post.time}</p>
                      </div>
                    </div>
                    <p className="text-gray-700 mb-4">
                      {post.content
                        .replace(
                          /Daily ad earning from multiple cycles/gi,
                          "Ad Watching Earning",
                        )
                        .replace(/Sky Bridge/g, "SkyBridge")}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Upcoming Events */}

            {/* Top Contributors */}
            <div className="bg-white rounded-2xl shadow-lg p-6">
              <h3 className="text-xl font-bold text-gray-900 mb-4 flex items-center">
                <Trophy className="w-6 h-6 mr-2 text-yellow-600" />
                Top 3 Contributors
              </h3>
              <div className="space-y-3">
                {leadersLoading ? (
                  <div className="text-sm text-gray-500">
                    Loading top leaders...
                  </div>
                ) : leadersError ? (
                  <div className="text-sm text-red-600">
                    Error: {leadersError}
                  </div>
                ) : leaders.length === 0 ? (
                  <div className="text-sm text-gray-500">No leaders found.</div>
                ) : (
                  leaders.map((leader, index) => (
                    <div
                      key={index}
                      className="flex items-center justify-between"
                    >
                      <div className="flex items-center">
                        <div className="w-8 h-8 bg-gradient-to-r from-yellow-400 to-orange-500 rounded-full flex items-center justify-center text-white font-bold text-sm">
                          {leader.name?.charAt(0) || "?"}
                        </div>
                        <div className="ml-3">
                          <span className="font-medium text-gray-900">
                            {leader.name}
                          </span>
                          <div className="flex items-center text-xs text-gray-500">
                            <span className="mr-1">
                              {leader.country_flag || ""}
                            </span>
                            <span>
                              ${Number(leader.income || 0).toFixed(2)}
                            </span>
                          </div>
                        </div>
                      </div>
                      <span className="text-yellow-600 font-bold">
                        #{leader.position ?? index + 1}
                      </span>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SkyBridgeCommunity;
