import React from "react";
import { Link } from "react-router-dom";
import { useAuth } from "../contexts/AuthContext";
import {
  Copy,
  Check,
  Crown,
  Star,
  Sparkles,
  TrendingUp,
  Eye,
  EyeOff,
} from "lucide-react";
import { useCurrency } from "../contexts/CurrencyContext";
import {
  DollarSign,
  Users,
  Target,
  LayoutDashboard,
  ShoppingBag,
} from "lucide-react";
import handCoin from "../assets/images/hand-coin.png";
import bannerImage from "../assets/images/banner.jpeg";
import { apiClient } from "../services/apiClient";
import { userService, UserProfile } from "../services/userService";
import { getDisplayNameForPlan } from "../constants/plans";
import { API_ENDPOINTS } from "../config/api";
import VideoTutorialSection from "../components/VideoTutorialSection";

const Dashboard: React.FC = () => {
  const { user } = useAuth();
  const { formatCurrency } = useCurrency();
  const [showCopiedTooltip, setShowCopiedTooltip] = React.useState(false);
  const [showReferralCode, setShowReferralCode] = React.useState(false);

  // Dashboard metrics from /user/user-dashboard
  const [metrics, setMetrics] = React.useState({
    today: 0,
    rewards: 0,
    last30: 0,
    lifetime: 0,
  });
  const [metricsLoading, setMetricsLoading] = React.useState(true);
  const [metricsError, setMetricsError] = React.useState<string | null>(null);

  // User profile fetched from API /user/profile
  const [profileData, setProfileData] = React.useState<UserProfile | null>(
    null,
  );

  const getDisplayableImageUrl = (imageData: string | undefined): string => {
    if (!imageData) return "";
    return imageData;
  };

  const planLabel =
    getDisplayNameForPlan(profileData?.plan_name) ||
    profileData?.plan_name ||
    profileData?.plan ||
    user?.plan;
  const planTier =
    (planLabel && ["Basic", "Standard", "Prime", "Premium"].includes(planLabel)
      ? planLabel.toLowerCase()
      : null) ??
    profileData?.plan ??
    user?.plan;

  React.useEffect(() => {
    let isMounted = true;
    const loadDashboard = async () => {
      try {
        setMetricsLoading(true);
        setMetricsError(null);
        apiClient.refreshAuthToken();

        const [profileOutcome, dashboardOutcome] = await Promise.allSettled([
          userService.getUserProfile(),
          apiClient.get(API_ENDPOINTS.USER.USER_DASHBOARD),
        ]);

        if (!isMounted) return;

        if (profileOutcome.status === "fulfilled") {
          setProfileData(profileOutcome.value);
        } else if (user) {
          setProfileData({
            id: typeof (user as any).id === "number" ? (user as any).id : 0,
            name: user.name || "",
            email: user.email || "",
            phone: user.phone || "",
            country: user.country || "",
            referralCode: user.referralCode || "",
            profile_picture: (user as any).profileImage,
          } as UserProfile);
        }

        if (dashboardOutcome.status === "fulfilled") {
          const d: any = dashboardOutcome.value.data;
          const today =
            parseFloat(d?.today_earning ?? d?.todayEarning ?? 0) || 0;
          const rewards =
            parseFloat(
              d?.total_rewards_earning ?? d?.totalRewardsEarning ?? 0,
            ) || 0;
          const last30 =
            parseFloat(
              d?.last_30_days_total_earning ?? d?.last30DaysTotalEarning ?? 0,
            ) || 0;
          const lifetime =
            parseFloat(
              d?.lifetime_total_earning ?? d?.lifetimeTotalEarning ?? 0,
            ) || 0;
          setMetrics({ today, rewards, last30, lifetime });
        } else {
          const err = dashboardOutcome.reason as { message?: string };
          setMetricsError(err?.message || "Failed to load dashboard metrics");
        }
      } catch (err: any) {
        if (isMounted)
          setMetricsError(err?.message || "Failed to load dashboard data");
      } finally {
        if (isMounted) setMetricsLoading(false);
      }
    };
    loadDashboard();
    return () => {
      isMounted = false;
    };
  }, []);

  return (
    <>
      {/* Social Icons - Desktop Only */}
      <div className="hidden sm:flex sm:items-center sm:justify-end mb-4">
        <div className="flex items-center space-x-3">
          {/* Facebook */}
          <a
            href="/media"
            className="w-10 h-10 bg-gradient-to-br from-sky-600 to-sky-700 rounded-full flex items-center justify-center hover:from-sky-700 hover:to-sky-800 transition-all duration-300 shadow-lg hover:shadow-xl transform hover:scale-105"
            title="Facebook"
          >
            <svg
              className="w-5 h-5 text-white"
              fill="currentColor"
              viewBox="0 0 24 24"
            >
              <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z" />
            </svg>
          </a>

          {/* Instagram */}
          <a
            href="/media"
            className="w-10 h-10 bg-gradient-to-br from-pink-500 to-purple-600 rounded-full flex items-center justify-center hover:from-pink-600 hover:to-purple-700 transition-all duration-300 shadow-lg hover:shadow-xl transform hover:scale-105"
            title="Instagram"
          >
            <svg
              className="w-5 h-5 text-white"
              fill="currentColor"
              viewBox="0 0 24 24"
            >
              <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z" />
            </svg>
          </a>

          {/* YouTube */}
          <a
            href="/media"
            className="w-10 h-10 bg-gradient-to-br from-red-500 to-red-600 rounded-full flex items-center justify-center hover:from-red-600 hover:to-red-700 transition-all duration-300 shadow-lg hover:shadow-xl transform hover:scale-105"
            title="YouTube"
          >
            <svg
              className="w-5 h-5 text-white"
              fill="currentColor"
              viewBox="0 0 24 24"
            >
              <path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z" />
            </svg>
          </a>

          {/* WhatsApp */}
          <a
            href="https://whatsapp.com/channel/0029VbC8jz9It5rv89vDrx16"
            target="_blank"
            rel="noopener noreferrer"
            className="w-10 h-10 bg-gradient-to-br from-green-500 to-green-600 rounded-full flex items-center justify-center hover:from-green-600 hover:to-green-700 transition-all duration-300 shadow-lg hover:shadow-xl transform hover:scale-105 active:scale-95"
            title="Follow SkyBridge on WhatsApp"
          >
            <svg
              className="w-5 h-5 text-white"
              fill="currentColor"
              viewBox="0 0 24 24"
            >
              <path d="M20.52 3.48A11.82 11.82 0 0012.04 0C5.47 0 .04 5.43.04 12a11.83 11.83 0 001.57 5.93L0 24l6.24-1.64A11.9 11.9 0 0012.05 24c6.57 0 11.99-5.43 11.99-12a11.82 11.82 0 00-3.52-8.52zM12.05 22.06a9.93 9.93 0 01-5.08-1.39l-.36-.21-3.7.97.99-3.6-.23-.37A9.96 9.96 0 012.1 12c0-5.48 4.46-9.94 9.94-9.94a9.9 9.9 0 016.99 2.9 9.9 9.9 0 012.9 7.04c-.01 5.48-4.47 9.94-9.88 9.94zm5.68-7.45c-.31-.16-1.84-.9-2.12-1.01-.28-.1-.49-.16-.7.16-.2.31-.8 1.01-.99 1.22-.18.2-.37.23-.68.08-.31-.16-1.32-.49-2.51-1.56-.93-.82-1.56-1.83-1.75-2.14-.18-.31-.02-.48.13-.63.13-.13.31-.34.46-.51.16-.17.2-.29.31-.49.1-.2.05-.37-.03-.52-.08-.16-.7-1.68-.96-2.3-.25-.6-.51-.52-.7-.53-.18 0-.39 0-.6 0-.2 0-.52.07-.79.37-.27.31-1.04 1.01-1.04 2.47s1.07 2.87 1.22 3.07c.16.2 2.11 3.2 5.1 4.49.71.31 1.27.49 1.7.63.71.23 1.36.2 1.87.13.57-.09 1.84-.75 2.1-1.47.26-.72.26-1.33.18-1.47-.09-.14-.28-.23-.59-.38z" />
            </svg>
          </a>
        </div>
      </div>

      {/* Banner Content */}
      <div className="w-full overflow-hidden shadow-2xl border mt-2 sm:mt-0">
        <img
          src={bannerImage}
          alt="SkyBridge International Banner"
          className="block w-full h-auto sm:h-24 md:h-32 lg:h-40 object-contain sm:object-cover object-center"
        />
      </div>
      <div className="px-3 sm:px-6 lg:px-8 space-y-4">
        {/* Header Section */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 sm:gap-4"></div>

        {/* User Profile Section */}
        <div className="p-1 sm:p-6 mb-4 sm:mb-6">
          <div className="flex items-center justify-between gap-3 sm:gap-4">
            <div className="flex items-start space-x-3 sm:space-x-4 min-w-0 flex-1">
              {/* User Avatar */}
              <div className="w-20 h-20 sm:w-24 sm:h-24 bg-gradient-to-br from-sky-500 to-sky-600 rounded-lg sm:rounded-xl flex items-center justify-center shadow-lg border-1 border-white/30 p-1 overflow-hidden shrink-0">
                {profileData?.profile_picture ? (
                  <img
                    src={getDisplayableImageUrl(profileData.profile_picture)}
                    alt="User Avatar"
                    className="w-full h-full rounded-md sm:rounded-lg object-cover"
                    onError={(e) => {
                      e.currentTarget.src =
                        "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80";
                    }}
                  />
                ) : (
                  <img
                    src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80"
                    alt="User Avatar"
                    className="w-full h-full rounded-md sm:rounded-lg object-cover"
                  />
                )}
              </div>

              {/* User Info */}
              <div className="flex-1 min-w-0">
                <h2 className="text-lg sm:text-2xl font-bold text-gray-900 mb-1 truncate">
                  {profileData?.name || user?.name}
                </h2>
                <div className="flex items-center space-x-2 mb-2">
                  <span className="text-gray-600 font-medium text-xs sm:text-sm">
                    ID:
                  </span>
                  <span className="text-sky-600 font-bold text-sm sm:text-lg truncate">
                    {(() => {
                      const code =
                        profileData?.referralCode || user?.referralCode || "";
                      if (!code) return "";
                      return showReferralCode
                        ? code
                        : "•".repeat(Math.max(code.length, 6));
                    })()}
                  </span>
                  <button
                    onClick={() => setShowReferralCode((prev) => !prev)}
                    className="hover:text-sky-700 focus:outline-none"
                    title={showReferralCode ? "Hide ID" : "Show ID"}
                    aria-label={showReferralCode ? "Hide ID" : "Show ID"}
                  >
                    {showReferralCode ? (
                      <EyeOff className="h-4 w-4 sm:h-5 sm:w-5" />
                    ) : (
                      <Eye className="h-4 w-4 sm:h-5 sm:w-5" />
                    )}
                  </button>
                  <button
                    onClick={() => {
                      const code =
                        profileData?.referralCode || user?.referralCode;
                      if (code) {
                        const rawBase =
                          typeof window !== "undefined" && window.location?.origin && !window.location.origin.includes("localhost")
                            ? window.location.origin
                            : (API_CONFIG.APP_URL || "https://sky-bridge-international.com");
                        const cleanBase = rawBase
                          .replace("https://backend.sky-bridge-international.com", "https://sky-bridge-international.com")
                          .replace(/\/$/, "");
                        const url = `${cleanBase}/register?refCode=${encodeURIComponent(code)}`;
                        navigator.clipboard.writeText(url).then(() => {
                          setShowCopiedTooltip(true);
                          setTimeout(() => setShowCopiedTooltip(false), 2000);
                        });
                      }
                    }}
                    className="relative hover:text-sky-700 focus:outline-none"
                    title="Copy ID"
                  >
                    {showCopiedTooltip ? (
                      <Check className="h-4 w-4 sm:h-5 sm:w-5 text-green-500" />
                    ) : (
                      <Copy className="h-4 w-4 sm:h-5 sm:w-5" />
                    )}
                  </button>
                </div>
                {/* Plan Display */}
                <div className="flex items-center space-x-2">
                  {planTier || profileData?.plan_name ? (
                    <div className="flex items-center space-x-2">
                      <span className="text-gray-600 font-medium text-xs sm:text-sm">
                        Plan:
                      </span>
                      <span className="inline-flex items-center px-2 py-1 rounded-md text-xs sm:text-sm font-semibold bg-gradient-to-r from-blue-500 to-blue-600 text-white">
                        {planTier === "basic" && (
                          <Star className="w-3 h-3 mr-1" />
                        )}
                        {planTier === "standard" && (
                          <Sparkles className="w-3 h-3 mr-1" />
                        )}
                        {planTier === "prime" && (
                          <TrendingUp className="w-3 h-3 mr-1" />
                        )}
                        {planTier === "premium" && (
                          <Crown className="w-3 h-3 mr-1" />
                        )}
                        {planLabel} Plan
                      </span>
                    </div>
                  ) : (
                    <span className="text-xs sm:text-sm text-gray-500 italic"></span>
                  )}
                </div>
              </div>
            </div>

            <div className="flex flex-col gap-2 flex-shrink-0 self-center"></div>
          </div>
        </div>
        <div className="flex flex-wrap items-center gap-3 sm:gap-4">
          <h1 className="text-xl sm:text-3xl font-bold text-gray-900">
            Dashboard
          </h1>
          <VideoTutorialSection
            buttonOnly
            maxViews={2}
            buttonLabel="Watch Tutorial"
            buttonClassName="inline-flex items-center justify-center gap-2 px-4 sm:px-5 py-2 sm:py-2.5 rounded-full bg-white border border-sky-600 text-sky-600 font-medium text-xs sm:text-sm hover:bg-sky-50 transition-all active:scale-95 shrink-0"
          />
        </div>

        {/* Earnings Cards - Stacked on mobile, 2 cols on tablet, 4 cols on desktop */}
        <div className="space-y-3 sm:space-y-4 md:space-y-0 md:grid md:grid-cols-2 md:gap-4 lg:grid-cols-4 lg:gap-4">
          {/* 1st Card - Sky Blue Border - Today's Earning */}
          <div className="w-full bg-white rounded-lg sm:rounded-xl shadow-lg border-l-4 border-sky-500 p-4 sm:p-6 md:p-5 md:min-h-40 hover:shadow-xl transition-all duration-300">
            <div className="flex items-center justify-between md:flex-col md:items-start md:gap-3">
              <div className="flex-1 w-full md:order-2 md:space-y-1 md:text-left">
                <p className="text-2xl sm:text-3xl md:text-2xl lg:text-4xl font-extrabold text-gray-900 lg:truncate">
                  {formatCurrency(metrics.today)}
                </p>
                <p className="mt-1 text-sm sm:text-base md:text-sm font-bold uppercase tracking-wide text-sky-600 md:whitespace-normal md:leading-tight">
                  Today's Earning
                </p>
              </div>
              <div className="w-12 h-12 sm:w-16 sm:h-16 md:w-14 md:h-14 lg:w-20 lg:h-20 bg-gradient-to-br from-sky-500 to-sky-700 rounded-full flex items-center justify-center shadow-lg ml-4 md:ml-0 md:order-1">
                <img
                  src={handCoin}
                  alt="Coin"
                  className="w-10 h-8 sm:w-16 sm:h-13 lg:w-21 lg:h-18"
                />
              </div>
            </div>
          </div>

          {/* 2nd Card - Red Border - Rewards Earning */}
          <div className="w-full bg-white rounded-lg sm:rounded-xl shadow-lg border-l-4 border-red-500 p-4 sm:p-6 md:p-5 md:min-h-40 hover:shadow-xl transition-all duration-300">
            <div className="flex items-center justify-between md:flex-col md:items-start md:gap-3">
              <div className="flex-1 w-full md:order-2 md:space-y-1 md:text-left">
                <p className="text-2xl sm:text-3xl md:text-2xl lg:text-4xl font-extrabold text-gray-900 lg:truncate">
                  {formatCurrency(metrics.rewards)}
                </p>
                <p className="mt-1 text-sm sm:text-base md:text-sm font-bold uppercase tracking-wide text-red-600 md:whitespace-normal md:leading-tight">
                  Rewards Earning
                </p>
              </div>
              <div className="w-12 h-12 sm:w-16 sm:h-16 md:w-14 md:h-14 lg:w-20 lg:h-20 bg-gradient-to-br from-red-500 to-red-700 rounded-full flex items-center justify-center shadow-lg ml-4 md:ml-0 md:order-1">
                <img
                  src={handCoin}
                  alt="Coin"
                  className="w-10 h-8 sm:w-16 sm:h-13 lg:w-21 lg:h-18"
                />
              </div>
            </div>
          </div>

          {/* 3rd Card - Yellow Border - Last 30 Days Earning */}
          <div className="w-full bg-white rounded-lg sm:rounded-xl shadow-lg border-l-4 border-yellow-500 p-4 sm:p-6 md:p-5 md:min-h-40 hover:shadow-xl transition-all duration-300">
            <div className="flex items-center justify-between md:flex-col md:items-start md:gap-3">
              <div className="flex-1 w-full md:order-2 md:space-y-1 md:text-left">
                <p className="text-2xl sm:text-3xl md:text-2xl lg:text-4xl font-extrabold text-gray-900 lg:truncate">
                  {formatCurrency(metrics.last30)}
                </p>
                <p className="mt-1 text-sm sm:text-base md:text-sm font-bold uppercase tracking-wide text-yellow-600 md:whitespace-normal md:leading-tight">
                  Last 30 Days Earning
                </p>
              </div>
              <div className="w-12 h-12 sm:w-16 sm:h-16 md:w-14 md:h-14 lg:w-20 lg:h-20 bg-gradient-to-br from-yellow-500 to-yellow-700 rounded-full flex items-center justify-center shadow-lg ml-4 md:ml-0 md:order-1">
                <img
                  src={handCoin}
                  alt="Coin"
                  className="w-10 h-8 sm:w-16 sm:h-13 lg:w-21 lg:h-18"
                />
              </div>
            </div>
          </div>

          {/* 4th Card - Black Border - Total Earning */}
          <div className="w-full bg-white rounded-lg sm:rounded-xl shadow-lg border-l-4 border-gray-800 p-4 sm:p-6 md:p-5 md:min-h-40 hover:shadow-xl transition-all duration-300">
            <div className="flex items-center justify-between md:flex-col md:items-start md:gap-3">
              <div className="flex-1 w-full md:order-2 md:space-y-1 md:text-left">
                <p className="text-2xl sm:text-3xl md:text-2xl lg:text-4xl font-extrabold text-gray-900 lg:truncate">
                  {formatCurrency(metrics.lifetime)}
                </p>
                <p className="mt-1 text-sm sm:text-base md:text-sm font-bold uppercase tracking-wide text-gray-800 md:whitespace-normal md:leading-tight">
                  Total Earning
                </p>
              </div>
              <div className="w-12 h-12 sm:w-16 sm:h-16 md:w-14 md:h-14 lg:w-20 lg:h-20 bg-gradient-to-br from-gray-600 to-gray-800 rounded-full flex items-center justify-center shadow-lg ml-4 md:ml-0 md:order-1">
                <img
                  src={handCoin}
                  alt="Coin"
                  className="w-10 h-8 sm:w-16 sm:h-13 lg:w-21 lg:h-18"
                />
              </div>
            </div>
          </div>
        </div>

        {/* Quick Access Section */}
        <div className="bg-white rounded-xl sm:rounded-2xl shadow-lg border border-gray-100 p-3 sm:p-6">
          <h2 className="text-lg sm:text-2xl font-bold text-gray-900 mb-3 sm:mb-6">
            Quick Access
          </h2>
          <div className="space-y-2 sm:space-y-3">
            {/* Card 1 - Sky Blue */}
            <Link
              to="/affiliate-course"
              className="group flex items-center p-3 sm:p-4 rounded-lg sm:rounded-xl bg-transparent shadow-lg border-l-4 border-sky-500 hover:shadow-xl transition-all duration-300"
            >
              <div className="w-8 h-8 sm:w-12 sm:h-12 bg-gradient-to-br from-sky-500 to-sky-700 rounded-full flex items-center justify-center mr-3 sm:mr-4 shadow-lg transition-all duration-300">
                <LayoutDashboard className="w-4 h-4 sm:w-6 sm:h-6 text-white" />
              </div>
              <span className="text-sm sm:text-lg font-bold uppercase tracking-wide text-sky-600 transition-colors duration-300">
                Courses
              </span>
            </Link>

            {/* Card 2 - Red */}
            <Link
              to="/ecommerce-store"
              className="group flex items-center p-3 sm:p-4 rounded-lg sm:rounded-xl bg-transparent shadow-lg border-l-4 border-red-500 hover:shadow-xl transition-all duration-300"
            >
              <div className="w-8 h-8 sm:w-12 sm:h-12 bg-gradient-to-br from-red-500 to-red-700 rounded-full flex items-center justify-center mr-3 sm:mr-4 shadow-lg transition-all duration-300">
                <Users className="w-4 h-4 sm:w-6 sm:h-6 text-white" />
              </div>
              <div className="flex items-center gap-2">
                <span className="text-sm sm:text-lg font-bold uppercase tracking-wide text-red-600 transition-colors duration-300">
                  E-Commerce Store
                </span>
              </div>
            </Link>

            {/* Card 3 - Yellow */}
            <Link
              to="/ads"
              className="group flex items-center p-3 sm:p-4 rounded-lg sm:rounded-xl bg-transparent shadow-lg border-l-4 border-yellow-500 hover:shadow-xl transition-all duration-300"
            >
              <div className="w-8 h-8 sm:w-12 sm:h-12 bg-gradient-to-br from-yellow-500 to-yellow-700 rounded-full flex items-center justify-center mr-3 sm:mr-4 shadow-lg transition-all duration-300">
                <Target className="w-4 h-4 sm:w-6 sm:h-6 text-white" />
              </div>
              <span className="text-sm sm:text-lg font-bold uppercase tracking-wide text-yellow-600 transition-colors duration-300">
                Ads
              </span>
            </Link>

            {/* Card 4 - Black */}
            <Link
              to="/withdraw"
              className="group flex items-center p-3 sm:p-4 rounded-lg sm:rounded-xl bg-transparent shadow-lg border-l-4 border-gray-800 hover:shadow-xl transition-all duration-300"
            >
              <div className="w-8 h-8 sm:w-12 sm:h-12 bg-gradient-to-br from-gray-600 to-gray-800 rounded-full flex items-center justify-center mr-3 sm:mr-4 shadow-lg transition-all duration-300">
                <DollarSign className="w-4 h-4 sm:w-6 sm:h-6 text-white" />
              </div>
              <span className="text-sm sm:text-lg font-bold uppercase tracking-wide text-gray-800 transition-colors duration-300">
                Withdraw
              </span>
            </Link>
          </div>
        </div>

        {/* Mobile Social Media Icons - Right Side */}
        <div className="sm:hidden fixed right-2 top-1/3 z-50 -translate-y-1/2">
          <div className="flex flex-col space-y-3">
            <a
              href="/media"
              className="w-8 h-8 bg-gradient-to-br from-sky-600 to-sky-700 rounded-lg flex items-center justify-center active:from-sky-700 active:to-sky-800 transition-all duration-300 shadow-lg active:scale-95"
              title="Facebook"
            >
              <svg
                className="w-5 h-5 text-white"
                fill="currentColor"
                viewBox="0 0 24 24"
              >
                <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z" />
              </svg>
            </a>

            <a
              href="/media"
              className="w-8 h-8 bg-gradient-to-br from-pink-500 to-purple-600 rounded-lg flex items-center justify-center active:from-pink-600 active:to-purple-700 transition-all duration-300 shadow-lg active:scale-95"
              title="Instagram"
            >
              <svg
                className="w-5 h-5 text-white"
                fill="currentColor"
                viewBox="0 0 24 24"
              >
                <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z" />
              </svg>
            </a>

            <a
              href="https://youtube.com/@sky.bridgeinternational?si=mCCBQ30PYdFSxGyx"
              target="_blank"
              rel="noopener noreferrer"
              className="w-8 h-8 bg-gradient-to-br from-red-500 to-red-600 rounded-lg flex items-center justify-center active:from-red-600 active:to-red-700 transition-all duration-300 shadow-lg active:scale-95"
              title="YouTube - Sky Bridge International"
            >
              <svg
                className="w-5 h-5 text-white"
                fill="currentColor"
                viewBox="0 0 24 24"
              >
                <path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z" />
              </svg>
            </a>

            <a
              href="https://whatsapp.com/channel/0029VbC8jz9It5rv89vDrx16"
              target="_blank"
              rel="noopener noreferrer"
              className="w-8 h-8 bg-gradient-to-br from-green-500 to-green-600 rounded-lg flex items-center justify-center active:from-green-600 active:to-green-700 transition-all duration-300 shadow-lg active:scale-95"
              title="Follow Skybridge Withdrawal Proof on WhatsApp"
            >
              <svg
                className="w-5 h-5 text-white"
                fill="currentColor"
                viewBox="0 0 24 24"
              >
                <path d="M20.52 3.48A11.82 11.82 0 0012.04 0C5.47 0 .04 5.43.04 12a11.83 11.83 0 001.57 5.93L0 24l6.24-1.64A11.9 11.9 0 0012.05 24c6.57 0 11.99-5.43 11.99-12a11.82 11.82 0 00-3.52-8.52zM12.05 22.06a9.93 9.93 0 01-5.08-1.39l-.36-.21-3.7.97.99-3.6-.23-.37A9.96 9.96 0 012.1 12c0-5.48 4.46-9.94 9.94-9.94a9.9 9.9 0 016.99 2.9 9.9 9.9 0 012.9 7.04c-.01 5.48-4.47 9.94-9.88 9.94zm5.68-7.45c-.31-.16-1.84-.9-2.12-1.01-.28-.1-.49-.16-.7.16-.2.31-.8 1.01-.99 1.22-.18.2-.37.23-.68.08-.31-.16-1.32-.49-2.51-1.56-.93-.82-1.56-1.83-1.75-2.14-.18-.31-.02-.48.13-.63.13-.13.31-.34.46-.51.16-.17.2-.29.31-.49.1-.2.05-.37-.03-.52-.08-.16-.7-1.68-.96-2.3-.25-.6-.51-.52-.7-.53-.18 0-.39 0-.6 0-.2 0-.52.07-.79.37-.27.31-1.04 1.01-1.04 2.47s1.07 2.87 1.22 3.07c.16.2 2.11 3.2 5.1 4.49.71.31 1.27.49 1.7.63.71.23 1.36.2 1.87.13.57-.09 1.84-.75 2.1-1.47.26-.72.26-1.33.18-1.47-.09-.14-.28-.23-.59-.38z" />
              </svg>
            </a>
          </div>
        </div>
      </div>
    </>
  );
};

export default Dashboard;
