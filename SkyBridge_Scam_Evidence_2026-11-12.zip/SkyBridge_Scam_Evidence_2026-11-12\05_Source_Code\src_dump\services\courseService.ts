import { apiClient } from './apiClient';
import { API_ENDPOINTS } from '../config/api';
import type { Course, CourseVideo, CourseType } from '../types/course';

export interface ListCoursesParams {
  name?: string;
  type?: CourseType | '';
}

export const courseService = {
  async listCourses(params: ListCoursesParams = {}) {
    const query = new URLSearchParams();
    if (params.name) query.set('name', params.name);
    if (params.type) query.set('type', params.type);
    const endpoint = `${API_ENDPOINTS.COURSES}${query.toString() ? `?${query.toString()}` : ''}`;
    return apiClient.get<Course[]>(endpoint);
  },

  async getCourseVideos(courseId: number | string) {
    return apiClient.get<CourseVideo[]>(`${API_ENDPOINTS.COURSES}/${courseId}/videos`);
  },

  async purchaseCourse(courseId: number | string) {
    return apiClient.post<{ unlocked: boolean }>(`${API_ENDPOINTS.COURSES}/${courseId}/purchase`);
  },

  async myPurchasedCourses() {
    return apiClient.get<Course[]>(`/user/courses/purchased`);
  },
};
