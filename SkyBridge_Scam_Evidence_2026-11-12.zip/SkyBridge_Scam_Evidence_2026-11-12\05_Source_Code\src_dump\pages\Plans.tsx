import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../contexts/AuthContext";
import { useCurrency } from "../contexts/CurrencyContext";
import {
  Check,
  Star,
  Sparkles,
  TrendingUp,
  Crown,
  Zap,
  Clock,
  CheckCircle,
  XCircle,
  ClipboardList,
  Loader2,
} from "lucide-react";
import { apiClient } from "../services/apiClient";
import { planUpgradeService } from "../services/planUpgradeService";
import {
  PLAN_CONTENT,
  PLAN_IDS,
  getDisplayNameForPlan,
  getPlanUpgradeDisplayName,
  getPlanUpgradeRejectionReason,
  type PlanPriceKey,
  type PlanUpgradeHistoryItem,
} from "../constants/plans";

interface Plan {
  id: string;
  name: string;
  price: number;
  pricePKR: number;
  courses: string[];
  earningOpportunities: string[];
  bonuses: string[];
  icon: React.ReactNode;
  color: string;
  popular?: boolean;
}

const PRICE_KEYS: PlanPriceKey[] = [950, 2000, 4000, 6000];
const PLAN_ICONS = [Star, Sparkles, TrendingUp, Crown] as const;

const Plans: React.FC = () => {
  const { isAuthenticated } = useAuth();
  const { currency, setCurrency } = useCurrency();
  const navigate = useNavigate();
  const [userPlan, setUserPlan] = useState<string | null>(null);
  const [upgradeHistory, setUpgradeHistory] = useState<
    PlanUpgradeHistoryItem[]
  >([]);
  const [historyLoading, setHistoryLoading] = useState(false);
  const [planCatalog, setPlanCatalog] = useState<
    Array<{ id: number; name: string; price_pkr: number }>
  >([]);

  const plans: Plan[] = PRICE_KEYS.map((key, index) => {
    const c = PLAN_CONTENT[key];
    const Icon = PLAN_ICONS[index];
    return {
      id: PLAN_IDS[key],
      name: `${c.displayName} Plan`,
      price: c.priceUsd,
      pricePKR: c.pricePkr,
      courses: c.courses,
      earningOpportunities: c.earningOpportunities,
      bonuses: c.bonusesRewards,
      icon: <Icon className="w-8 h-8" />,
      color: c.colorGradient,
      popular: c.isMostPopular,
    };
  });

  useEffect(() => {
    if (!isAuthenticated) {
      navigate("/login");
      return;
    }
    fetchUserPlan();
    fetchUpgradeHistory();
    fetchPlanCatalog();
  }, [isAuthenticated, navigate]);

  interface UserProfileResponse {
    data: {
      plan?: string;
      plan_id?: number;
      plan_name?: string;
    };
    success?: boolean;
    message?: string;
  }

  const fetchPlanCatalog = async () => {
    try {
      const response = await apiClient.get<any>("/plans");
      const data = response.data;
      const list = Array.isArray(data) ? data : data?.data;
      if (Array.isArray(list)) {
        setPlanCatalog(
          list.map((p: any) => ({
            id: Number(p.id),
            name: String(p.name || ""),
            price_pkr: Number(p.price_pkr || 0),
          })),
        );
      }
    } catch (error) {
      console.error("Error fetching plans catalog:", error);
    }
  };

  const fetchUpgradeHistory = async () => {
    setHistoryLoading(true);
    try {
      const items = await planUpgradeService.getHistory();
      setUpgradeHistory(items);
    } catch (error) {
      console.error("Error fetching plan upgrade history:", error);
    } finally {
      setHistoryLoading(false);
    }
  };

  const fetchUserPlan = async () => {
    try {
      const response = await apiClient.get("/user/profile") as UserProfileResponse;
      const d = response?.data;
      if (!d) return;
      if (d.plan && ["basic", "standard", "prime", "premium"].includes(d.plan)) {
        setUserPlan(d.plan);
        return;
      }
      if (typeof d.plan_id === "number") {
        const idMap: Record<number, string> = { 1: "basic", 2: "standard", 3: "prime", 4: "premium" };
        if (idMap[d.plan_id]) setUserPlan(idMap[d.plan_id]);
        return;
      }
      const displayName = getDisplayNameForPlan(d.plan_name);
      setUserPlan(displayName ? displayName.toLowerCase() : null);
    } catch (error) {
      console.error("Error fetching user plan:", error);
    }
  };

  const formatPrice = (amount: number, showCurrency = true) => {
    const options = { 
      minimumFractionDigits: 0, 
      maximumFractionDigits: 2 
    };
    const formatted = new Intl.NumberFormat('en-US', options).format(amount);
    return showCurrency ? `${currency === 'USD' ? '$' : '₨'}${formatted}` : formatted;
  };

  const formatHistoryDate = (d?: string) => {
    if (!d) return "—";
    return new Date(d).toLocaleDateString("en-US", {
      year: "numeric",
      month: "short",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  const statusBadge = (status: string) => {
    const normalized = status.toLowerCase();
    const cfg =
      normalized === "approved"
        ? {
            label: "Approved",
            className: "bg-green-100 text-green-800 border-green-200",
            icon: CheckCircle,
          }
        : normalized === "rejected"
          ? {
              label: "Rejected",
              className: "bg-red-100 text-red-800 border-red-200",
              icon: XCircle,
            }
          : {
              label: "Pending",
              className: "bg-yellow-100 text-yellow-800 border-yellow-200",
              icon: Clock,
            };
    const Icon = cfg.icon;
    return (
      <span
        className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold border ${cfg.className}`}
      >
        <Icon className="w-3.5 h-3.5" />
        {cfg.label}
      </span>
    );
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-4xl sm:text-5xl font-bold text-gray-900 mb-4">
            Available Plans
          </h1>
          <p className="text-lg sm:text-xl text-gray-600 max-w-2xl mx-auto mb-6">
            Explore our plans designed to maximize your earning potential with
            SkyBridge International
          </p>
          
          {/* Currency Selector */}
          <div className="flex justify-center mb-6">
            <div className="relative inline-block w-32">
              <select
                value={currency}
                onChange={(e) => setCurrency(e.target.value as 'USD' | 'PKR')}
                className="block appearance-none w-full bg-white border border-gray-300 text-gray-700 py-2 px-4 pr-8 rounded-lg leading-tight focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                <option value="USD">USD ($)</option>
                <option value="PKR">PKR (₨)</option>
              </select>
              <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-gray-700">
                <svg className="fill-current h-4 w-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20">
                  <path d="M9.293 12.95l.707.707L15.657 8l-1.414-1.414L10 10.828 5.757 6.586 4.343 8z"/>
                </svg>
              </div>
            </div>
          </div>
        </div>

        {/* Plans Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 lg:gap-8">
          {plans.map((plan) => {
            const isCurrentPlan = userPlan === plan.id;

            return (
              <div
                key={plan.id}
                className={`relative bg-white rounded-2xl shadow-xl overflow-hidden transition-all duration-300 transform hover:scale-105 ${
                  plan.popular
                    ? "ring-4 ring-green-500 ring-opacity-50 scale-105"
                    : ""
                } ${isCurrentPlan ? "ring-4 ring-green-500 ring-opacity-50" : ""}`}
              >
              

                {/* Current Plan Badge */}
                {isCurrentPlan && (
                  <div className="absolute top-0 left-0 bg-gradient-to-r from-green-500 to-green-600 text-white px-4 py-1 text-sm font-bold rounded-br-lg">
                    Current Plan
                  </div>
                )}

                {/* Plan Header */}
                <div
                  className={`bg-gradient-to-r ${plan.color} text-white p-6 text-center`}
                >
                  <div className="flex justify-center mb-4">{plan.icon}</div>
                  <h3 className="text-2xl font-bold mb-2">{plan.name}</h3>
                  <div className="text-center">
                  <div className="text-4xl font-extrabold mb-1">
                    {formatPrice(currency === 'USD' ? plan.price : plan.pricePKR)}
                  </div>
                  <div className="text-sm text-white/80">
                    {currency === 'USD' 
                      ? `₨${plan.pricePKR.toLocaleString()}` 
                      : `$${plan.price.toFixed(2)}`}
                  </div>
                  <div className="text-sm mt-1 text-white/80">Lifetime</div>
                </div>
                </div>

                {/* Plan Features */}
                <div className="p-6">
                  <div className="space-y-6 mb-6">
                    {/* Courses Included */}
                    <div>
                      <h4 className="font-bold text-gray-900 mb-3 text-sm uppercase tracking-wide">
                        Courses Included
                      </h4>
                      <ul className="space-y-2">
                        {plan.courses.map((course, index) => (
                          <li key={index} className="flex items-start">
                            <Check className="w-4 h-4 text-green-500 mr-2 flex-shrink-0 mt-1" />
                            <span className="text-sm text-gray-700">{course}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    {/* Earning Opportunities */}
                    <div>
                      <h4 className="font-bold text-gray-900 mb-3 text-sm uppercase tracking-wide">
                        Earning Opportunities
                      </h4>
                      <ul className="space-y-2">
                        {plan.earningOpportunities.map((opportunity, index) => (
                          <li key={index} className="flex items-start">
                            <Check className="w-4 h-4 text-blue-500 mr-2 flex-shrink-0 mt-1" />
                            <span className="text-sm text-gray-700">{opportunity}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    {/* Bonuses & Rewards */}
                    <div>
                      <h4 className="font-bold text-gray-900 mb-3 text-sm uppercase tracking-wide">
                        Bonuses & Rewards
                      </h4>
                      <ul className="space-y-2">
                        {plan.bonuses.map((bonus, index) => (
                          <li key={index} className="flex items-start">
                            <Check className="w-4 h-4 text-yellow-500 mr-2 flex-shrink-0 mt-1" />
                            <span className="text-sm text-gray-700">{bonus}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Upgrade Request History */}
        <div className="mt-10 bg-white rounded-2xl shadow-lg p-6 sm:p-8">
          <h2 className="text-xl font-bold text-gray-900 mb-4 flex items-center gap-2">
            <ClipboardList className="w-5 h-5 text-blue-600" />
            Upgrade Request History
          </h2>
          {historyLoading ? (
            <div className="flex justify-center py-8">
              <Loader2 className="w-6 h-6 animate-spin text-blue-600" />
            </div>
          ) : upgradeHistory.length === 0 ? (
            <p className="text-sm text-gray-500 text-center py-4">
              No upgrade requests yet.
            </p>
          ) : (
            <div className="space-y-3">
              {upgradeHistory.map((item) => {
                const rejectionReason = getPlanUpgradeRejectionReason(item);
                const status = String(item.status || "pending").toLowerCase();
                return (
                  <div
                    key={item.id}
                    className="rounded-xl border border-gray-200 p-4 bg-gray-50/60"
                  >
                    <div className="flex flex-wrap items-start justify-between gap-2 mb-2">
                      <div>
                        <p className="font-semibold text-gray-900">
                          {getPlanUpgradeDisplayName(item, planCatalog)}
                        </p>
                        {item.transaction_id && (
                          <p className="text-sm text-gray-600 font-mono mt-0.5">
                            TX: {item.transaction_id}
                          </p>
                        )}
                        <p className="text-xs text-gray-400 mt-1">
                          {formatHistoryDate(item.created_at)}
                        </p>
                      </div>
                      {statusBadge(status)}
                    </div>
                    {status === "rejected" && rejectionReason && (
                      <div className="mt-2 px-3 py-2 bg-red-50 border border-red-200 rounded-lg">
                        <p className="text-xs font-semibold text-red-700">
                          Rejection Reason:
                        </p>
                        <p className="text-xs text-red-600 mt-0.5 leading-snug">
                          {rejectionReason}
                        </p>
                      </div>
                    )}
                    {status === "approved" && (
                      <p className="mt-2 text-sm text-green-700">
                        Your plan upgrade has been approved.
                      </p>
                    )}
                    {status === "pending" && (
                      <p className="mt-2 text-sm text-yellow-700">
                        Your request is under review by admin.
                      </p>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Info Section */}
        <div className="mt-12 bg-white rounded-2xl shadow-lg p-6 sm:p-8">
          <div className="flex items-start">
            <Zap className="w-6 h-6 text-yellow-500 mr-4 flex-shrink-0 mt-1" />
            <div>
              <h3 className="text-xl font-bold text-gray-900 mb-2">
                About Our Plans
              </h3>
              <p className="text-gray-600">
                All plans are lifetime plans - pay once and enjoy forever! Each plan unlocks 
                exclusive courses, earning opportunities, bonuses, and higher earning potential.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Plans;
