import React, { useState, useEffect, useRef } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../contexts/AuthContext";
import { apiClient } from "../services/apiClient";
import { API_ENDPOINTS } from "../config/api";
import { userService } from "../services/userService";
import {
  ArrowUp,
  Upload,
  CheckCircle,
  AlertCircle,
  Loader2,
  ArrowLeft,
  Star,
  Sparkles,
  TrendingUp,
  Crown,
  Check,
  Clock,
  XCircle,
  ClipboardList,
} from "lucide-react";
import {
  getDisplayNameForPlan,
  getPlanContentByPricePkr,
  getPlanUpgradeDisplayName,
  getPlanUpgradeRejectionReason,
  type PlanUpgradeHistoryItem,
} from "../constants/plans";
import { planUpgradeService } from "../services/planUpgradeService";

interface PlanOption {
  id: number;
  name: string;
  price_pkr: number;
  price_usd: number;
}

interface UserProfile {
  plan_id: number;
  plan_name: string;
  plan_price_pkr: number;
  country: string;
}

const UpgradePlan: React.FC = () => {
  const { isAuthenticated } = useAuth();
  const navigate = useNavigate();

  const [plans, setPlans] = useState<PlanOption[]>([]);
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [selectedPlanId, setSelectedPlanId] = useState<number | null>(null);
  const [transactionId, setTransactionId] = useState("");
  const [senderAccountNumber, setSenderAccountNumber] = useState("");
  const [senderAccountTitle, setSenderAccountTitle] = useState("");
  const [screenshot, setScreenshot] = useState<File | null>(null);
  const [screenshotPreview, setScreenshotPreview] = useState<string | null>(
    null,
  );
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState(false);
  const [upgradeHistory, setUpgradeHistory] = useState<
    PlanUpgradeHistoryItem[]
  >([]);
  const [historyLoading, setHistoryLoading] = useState(true);
  const paymentFormRef = useRef<HTMLDivElement>(null);
  const shouldScrollToForm = useRef(false);

  // Account details for payment (array - multiple accounts)
  const [accountDetailsList, setAccountDetailsList] = useState<any[]>([]);

  useEffect(() => {
    if (!isAuthenticated) {
      navigate("/login");
      return;
    }
    fetchData();
    fetchUpgradeHistory();
  }, [isAuthenticated, navigate]);

  useEffect(() => {
    if (!selectedPlanId || !shouldScrollToForm.current) return;
    shouldScrollToForm.current = false;
    // Wait for payment form to mount, then scroll
    requestAnimationFrame(() => {
      paymentFormRef.current?.scrollIntoView({
        behavior: "smooth",
        block: "start",
      });
    });
  }, [selectedPlanId]);

  const selectPlan = (planId: number) => {
    if (selectedPlanId === planId) {
      paymentFormRef.current?.scrollIntoView({
        behavior: "smooth",
        block: "start",
      });
      return;
    }
    shouldScrollToForm.current = true;
    setSelectedPlanId(planId);
  };

  const fetchUpgradeHistory = async () => {
    setHistoryLoading(true);
    try {
      const items = await planUpgradeService.getHistory();
      setUpgradeHistory(items);
    } catch (err) {
      console.error("Error fetching plan upgrade history:", err);
    } finally {
      setHistoryLoading(false);
    }
  };

  const fetchData = async () => {
    setLoading(true);
    try {
      const [plansResult, profileRes, accountResult] = await Promise.all([
        apiClient.get<any>(API_ENDPOINTS.PLANS),
        userService.getUserProfile(),
        apiClient
          .get<any>(`${API_ENDPOINTS.ACCOUNT}?type=plan_upgrade`)
          .catch(() => null),
      ]);

      const plansData = plansResult.data;
      if (Array.isArray(plansData)) {
        setPlans(plansData);
      } else if (plansData?.data) {
        setPlans(plansData.data);
      }

      if (profileRes) {
        setUserProfile({
          plan_id: profileRes.plan_id ?? 0,
          plan_name: profileRes.plan_name ?? "",
          plan_price_pkr: profileRes.plan_price_pkr ?? 0,
          country: profileRes.country ?? "",
        });
      }

      if (accountResult?.data) {
        const d = accountResult.data;
        setAccountDetailsList(Array.isArray(d) ? d : [d]);
      }
    } catch (err) {
      console.error("Error fetching data:", err);
      setError("Failed to load data. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const higherPlans = plans.filter(
    (p) => userProfile && p.price_pkr > userProfile.plan_price_pkr,
  );

  const handleScreenshotChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const allowedTypes = ["image/jpeg", "image/png", "image/jpg", "image/webp"];
    if (!allowedTypes.includes(file.type)) {
      setError("Please upload a valid image (JPG, PNG, WEBP)");
      return;
    }
    if (file.size > 5 * 1024 * 1024) {
      setError("Image must be less than 5MB");
      return;
    }

    setScreenshot(file);
    setError("");
    const reader = new FileReader();
    reader.onload = (ev) => setScreenshotPreview(ev.target?.result as string);
    reader.readAsDataURL(file);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");

    if (!selectedPlanId) {
      setError("Please select a plan to upgrade to");
      return;
    }
    if (!transactionId.trim()) {
      setError("Please enter the transaction ID");
      return;
    }
    if (!senderAccountNumber.trim()) {
      setError("Please enter the sender account number");
      return;
    }
    if (!senderAccountTitle.trim()) {
      setError("Please enter the sender account title");
      return;
    }
    if (!screenshot) {
      setError("Please upload a payment screenshot");
      return;
    }

    setSubmitting(true);
    try {
      const formData = new FormData();
      formData.append("plan_id", String(selectedPlanId));
      formData.append("transaction_id", transactionId.trim());
      formData.append("transaction_screenshot", screenshot);
      formData.append("sender_account_number", senderAccountNumber.trim());
      formData.append("sender_account_title", senderAccountTitle.trim());

      const response = await apiClient.post<any>(
        API_ENDPOINTS.PLAN_UPGRADE,
        formData,
      );

      if (response.success) {
        setSuccess(true);
        void fetchUpgradeHistory();
      } else {
        setError(response.message || "Failed to submit upgrade request");
      }
    } catch (err: any) {
      setError(
        err.data?.message ||
          err.message ||
          "Failed to submit upgrade request. Please try again.",
      );
    } finally {
      setSubmitting(false);
    }
  };

  const formatHistoryDate = (d?: string) => {
    if (!d) return "—";
    return new Date(d).toLocaleDateString("en-US", {
      year: "numeric",
      month: "short",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  const statusBadge = (status: string) => {
    const normalized = status.toLowerCase();
    const cfg =
      normalized === "approved"
        ? {
            label: "Approved",
            className: "bg-green-100 text-green-800 border-green-200",
            icon: CheckCircle,
          }
        : normalized === "rejected"
          ? {
              label: "Rejected",
              className: "bg-red-100 text-red-800 border-red-200",
              icon: XCircle,
            }
          : {
              label: "Pending",
              className: "bg-yellow-100 text-yellow-800 border-yellow-200",
              icon: Clock,
            };
    const Icon = cfg.icon;
    return (
      <span
        className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold border ${cfg.className}`}
      >
        <Icon className="w-3.5 h-3.5" />
        {cfg.label}
      </span>
    );
  };

  const renderUpgradeHistory = () => (
    <div className="bg-white rounded-2xl shadow-lg p-6">
      <h2 className="text-xl font-bold text-gray-800 mb-4 flex items-center gap-2">
        <ClipboardList className="w-5 h-5 text-blue-600" />
        Upgrade Request History
      </h2>
      {historyLoading ? (
        <div className="flex justify-center py-8">
          <Loader2 className="w-6 h-6 animate-spin text-blue-600" />
        </div>
      ) : upgradeHistory.length === 0 ? (
        <p className="text-sm text-gray-500 text-center py-6">
          No upgrade requests yet.
        </p>
      ) : (
        <div className="space-y-3">
          {upgradeHistory.map((item) => {
            const rejectionReason = getPlanUpgradeRejectionReason(item);
            const status = String(item.status || "pending").toLowerCase();
            return (
              <div
                key={item.id}
                className="rounded-xl border border-gray-200 p-4 bg-gray-50/60"
              >
                <div className="flex flex-wrap items-start justify-between gap-2 mb-2">
                  <div>
                    <p className="font-semibold text-gray-900">
                      {getPlanUpgradeDisplayName(item, plans)}
                    </p>
                    {item.transaction_id && (
                      <p className="text-sm text-gray-600 font-mono mt-0.5">
                        TX: {item.transaction_id}
                      </p>
                    )}
                    <p className="text-xs text-gray-400 mt-1">
                      {formatHistoryDate(item.created_at)}
                    </p>
                  </div>
                  {statusBadge(status)}
                </div>
                {status === "rejected" && rejectionReason && (
                  <div className="mt-2 px-3 py-2 bg-red-50 border border-red-200 rounded-lg">
                    <p className="text-xs font-semibold text-red-700">
                      Rejection Reason:
                    </p>
                    <p className="text-xs text-red-600 mt-0.5 leading-snug">
                      {rejectionReason}
                    </p>
                  </div>
                )}
                {status === "approved" && (
                  <p className="mt-2 text-sm text-green-700">
                    Your plan upgrade has been approved.
                  </p>
                )}
                {status === "pending" && (
                  <p className="mt-2 text-sm text-yellow-700">
                    Your request is under review by admin.
                  </p>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-blue-600" />
      </div>
    );
  }

  if (success) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 py-8 px-4">
        <div className="max-w-lg mx-auto space-y-6">
          <div className="bg-white rounded-2xl shadow-xl p-8 text-center">
            <CheckCircle className="w-16 h-16 text-green-500 mx-auto mb-4" />
            <h2 className="text-2xl font-bold text-gray-900 mb-2">
              Upgrade Request Submitted!
            </h2>
            <p className="text-gray-600 mb-6">
              Your plan upgrade request has been submitted successfully. Admin
              will review and approve it shortly. You can track status below.
            </p>
            <button
              onClick={() => navigate("/dashboard")}
              className="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition"
            >
              Back to Dashboard
            </button>
          </div>
          {renderUpgradeHistory()}
        </div>
      </div>
    );
  }

  if (higherPlans.length === 0 && userProfile) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 py-8 px-4">
        <div className="max-w-lg mx-auto">
          <div className="bg-white rounded-2xl shadow-xl p-8 text-center">
            <CheckCircle className="w-16 h-16 text-green-500 mx-auto mb-4" />
            <h2 className="text-2xl font-bold text-gray-900 mb-2">
              You're on the Highest Plan!
            </h2>
            <p className="text-gray-600 mb-2">
              Current Plan:{" "}
              <span className="font-semibold">
                {getDisplayNameForPlan(userProfile.plan_name)}
              </span>
            </p>
            <p className="text-gray-500 mb-6">
              You already have the highest plan available. No upgrades needed!
            </p>
            <button
              onClick={() => navigate("/dashboard")}
              className="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition"
            >
              Back to Dashboard
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 py-8 px-4">
      <div className="max-w-6xl mx-auto">
        <div className="mb-6">
          <button
            onClick={() => navigate(-1)}
            className="flex items-center text-gray-600 hover:text-gray-900 mb-4"
          >
            <ArrowLeft className="w-4 h-4 mr-1" />
            Back
          </button>
          <h1 className="text-3xl font-bold text-gray-900">Upgrade Plan</h1>
          {userProfile && (
            <p className="text-gray-600 mt-1">
              Current Plan:{" "}
              <span className="font-semibold text-blue-600">
                {getDisplayNameForPlan(userProfile.plan_name)}
              </span>{" "}
              ({userProfile.plan_price_pkr} PKR)
            </p>
          )}
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          {renderUpgradeHistory()}

          {/* Plan Selection */}
          <div className="bg-white rounded-2xl shadow-lg p-6">
            <h2 className="text-xl font-bold text-gray-800 mb-4">
              Select New Plan
            </h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {higherPlans.map((plan) => {
                const displayName = getDisplayNameForPlan(plan.name);
                const ui = getPlanContentByPricePkr(plan.price_pkr) ?? {
                  colorClass: "bg-gray-600",
                  courses: [],
                  earningOpportunities: [],
                  bonusesRewards: [],
                };
                const PlanIcon =
                  displayName === "Basic"
                    ? Star
                    : displayName === "Standard"
                      ? Sparkles
                      : displayName === "Prime"
                        ? TrendingUp
                        : Crown;
                const isSelected = selectedPlanId === plan.id;
                return (
                  <div
                    key={plan.id}
                    className={`relative rounded-2xl border-2 transition-all overflow-hidden bg-white ${
                      isSelected
                        ? "border-blue-500 shadow-xl"
                        : "border-gray-200 hover:border-blue-300 hover:shadow-lg"
                    }`}
                  >
                    {isSelected && (
                      <div className="absolute top-4 right-4 z-10">
                        <CheckCircle className="w-6 h-6 text-blue-600" />
                      </div>
                    )}
                    <div
                      className={`text-white p-6 ${ui.colorClass}`}
                      onClick={() => selectPlan(plan.id)}
                      role="button"
                      tabIndex={0}
                      onKeyDown={(e) => {
                        if (e.key === "Enter" || e.key === " ") {
                          e.preventDefault();
                          selectPlan(plan.id);
                        }
                      }}
                    >
                      <div className="flex items-center gap-2 mb-2">
                        <PlanIcon className="w-6 h-6 text-white" />
                        <h3 className="text-xl font-bold">
                          {displayName} Plan
                        </h3>
                      </div>
                      <p className="text-3xl font-extrabold mb-1">
                        ${plan.price_usd}{" "}
                        <span className="text-base font-normal opacity-90">
                          Lifetime
                        </span>
                      </p>
                      <p className="text-sm opacity-90">
                        {plan.price_pkr.toLocaleString()} PKR
                      </p>
                    </div>
                    <div className="p-6 space-y-5">
                      <div>
                        <h4 className="font-bold text-gray-800 text-xs uppercase tracking-wide mb-2">
                          Courses Included
                        </h4>
                        <ul className="space-y-1">
                          {ui.courses.map((item, idx) => (
                            <li
                              key={idx}
                              className="flex items-start text-gray-700 text-sm"
                            >
                              <Check className="w-4 h-4 text-green-500 mr-2 flex-shrink-0 mt-0.5" />
                              {item}
                            </li>
                          ))}
                        </ul>
                      </div>
                      <div>
                        <h4 className="font-bold text-gray-800 text-xs uppercase tracking-wide mb-2">
                          Earning Opportunities
                        </h4>
                        <ul className="space-y-1">
                          {ui.earningOpportunities.map((item, idx) => (
                            <li
                              key={idx}
                              className="flex items-start text-gray-700 text-sm"
                            >
                              <Check className="w-4 h-4 text-blue-500 mr-2 flex-shrink-0 mt-0.5" />
                              {item}
                            </li>
                          ))}
                        </ul>
                      </div>
                      <div>
                        <h4 className="font-bold text-gray-800 text-xs uppercase tracking-wide mb-2">
                          Bonuses & Rewards
                        </h4>
                        <ul className="space-y-1">
                          {ui.bonusesRewards.map((item, idx) => (
                            <li
                              key={idx}
                              className="flex items-start text-gray-700 text-sm"
                            >
                              <Check className="w-4 h-4 text-amber-500 mr-2 flex-shrink-0 mt-0.5" />
                              {item}
                            </li>
                          ))}
                        </ul>
                      </div>
                    </div>
                    <div className="p-6 pt-0">
                      <button
                        type="button"
                        onClick={() => selectPlan(plan.id)}
                        className={`w-full py-3 text-white font-semibold rounded-lg transition-opacity hover:opacity-90 ${ui.colorClass}`}
                      >
                        Select Plan
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Payment Info */}
          {selectedPlanId && (
            <div
              ref={paymentFormRef}
              className="bg-white rounded-2xl shadow-lg p-6 scroll-mt-6"
            >
              <h2 className="text-xl font-bold text-gray-800 mb-4">
                Payment Details
              </h2>

              {/* Account details */}
              {accountDetailsList.length > 0 && (
                <div className="mb-6 p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                  <h3 className="text-lg font-semibold text-yellow-800 mb-3">
                    Send Payment To:
                  </h3>
                  <div className="space-y-3">
                    {accountDetailsList.map((acc, idx) => (
                      <div
                        key={acc.id ?? idx}
                        className="grid grid-cols-1 md:grid-cols-3 gap-3 p-3 bg-white/60 rounded"
                      >
                        <div>
                          <p className="text-sm font-medium text-yellow-800 mb-1">
                            Account Title:
                          </p>
                          <p className="font-semibold text-yellow-900">
                            {acc.account_title}
                          </p>
                        </div>
                        <div>
                          <p className="text-sm font-medium text-yellow-800 mb-1">
                            Account Number:
                          </p>
                          <p className="font-mono font-semibold text-yellow-900">
                            {acc.account_number}
                          </p>
                        </div>
                        {acc.bank && (
                          <div>
                            <p className="text-sm font-medium text-yellow-800 mb-1">
                              Bank:
                            </p>
                            <p className="font-semibold text-yellow-900">
                              {acc.bank}
                            </p>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                  <div className="mt-3 p-3 bg-green-50 border border-green-200 rounded text-sm text-green-700">
                    <p className="font-medium text-green-800 mb-1">
                      Instructions:
                    </p>
                    1. Send the full plan amount to any account above
                    <br />
                    2. Take a screenshot of the transaction
                    <br />
                    3. Upload the screenshot below and enter the transaction ID
                  </div>
                </div>
              )}

              {/* Selected plan amount */}
              {(() => {
                const selectedPlan = higherPlans.find(
                  (p) => p.id === selectedPlanId,
                );
                return selectedPlan ? (
                  <div className="mb-4 p-3 bg-blue-50 border border-blue-200 rounded-lg">
                    <p className="text-sm text-blue-700">
                      Amount to pay ({getDisplayNameForPlan(selectedPlan.name)}
                      ):{" "}
                      <span className="font-bold text-blue-900 text-lg">
                        {selectedPlan.price_pkr.toLocaleString()} PKR ($
                        {selectedPlan.price_usd})
                      </span>
                    </p>
                  </div>
                ) : null;
              })()}

              {/* Transaction ID */}
              <div className="mb-4">
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Transaction ID <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  value={transactionId}
                  onChange={(e) => setTransactionId(e.target.value)}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="Enter your transaction ID"
                />
              </div>

              {/* Sender Account Number */}
              <div className="mb-4">
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Sender Account Number <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  value={senderAccountNumber}
                  onChange={(e) => setSenderAccountNumber(e.target.value)}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="Enter sender account number"
                />
              </div>

              {/* Sender Account Title */}
              <div className="mb-4">
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Sender Account Title <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  value={senderAccountTitle}
                  onChange={(e) => setSenderAccountTitle(e.target.value)}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="Enter sender account title"
                />
              </div>

              {/* Screenshot Upload */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Payment Screenshot <span className="text-red-500">*</span>
                </label>
                <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center hover:border-blue-400 transition cursor-pointer">
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleScreenshotChange}
                    className="hidden"
                    id="screenshot-upload"
                  />
                  <label htmlFor="screenshot-upload" className="cursor-pointer">
                    {screenshotPreview ? (
                      <img
                        src={screenshotPreview}
                        alt="Screenshot preview"
                        className="max-h-48 mx-auto rounded-lg"
                      />
                    ) : (
                      <div>
                        <Upload className="w-10 h-10 text-gray-400 mx-auto mb-2" />
                        <p className="text-gray-600">
                          Click to upload screenshot
                        </p>
                        <p className="text-sm text-gray-400">
                          JPG, PNG, WEBP (Max 5MB)
                        </p>
                      </div>
                    )}
                  </label>
                </div>
              </div>
            </div>
          )}

          {/* Error */}
          {error && (
            <div className="flex items-center gap-2 p-4 bg-red-50 border border-red-200 rounded-lg">
              <AlertCircle className="w-5 h-5 text-red-500 flex-shrink-0" />
              <p className="text-red-700">{error}</p>
            </div>
          )}

          {/* Submit */}
          {selectedPlanId && (
            <button
              type="submit"
              disabled={submitting}
              className="w-full py-4 bg-gradient-to-r from-blue-600 to-blue-700 text-white font-bold rounded-xl hover:from-blue-700 hover:to-blue-800 transition disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
            >
              {submitting ? (
                <>
                  <Loader2 className="w-5 h-5 animate-spin" />
                  Submitting...
                </>
              ) : (
                <>
                  <ArrowUp className="w-5 h-5" />
                  Submit Upgrade Request
                </>
              )}
            </button>
          )}
        </form>
      </div>
    </div>
  );
};

export default UpgradePlan;
