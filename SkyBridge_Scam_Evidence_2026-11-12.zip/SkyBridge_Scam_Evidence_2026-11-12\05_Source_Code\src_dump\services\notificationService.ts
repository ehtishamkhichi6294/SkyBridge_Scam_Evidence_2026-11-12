import { apiClient, ApiResponse } from './apiClient';
import { API_ENDPOINTS } from '../config/api';

export interface Notification {
  id: string;
  type: 'success' | 'warning' | 'info' | 'reward' | 'payment' | 'referral';
  title: string;
  message: string;
  timestamp: string;
  amount?: number;
}

export interface NotificationsResponse {
  success: boolean;
  message: string;
  data: {
    current_page: number;
    data: Notification[];
    first_page_url: string;
    from: number | null;
    last_page: number;
    last_page_url: string;
  };
}

export class NotificationService {
  /**
   * Get notifications with pagination
   */
  static async getNotifications(page: number = 1): Promise<ApiResponse<NotificationsResponse['data']>> {
    try {
      const response = await apiClient.get<NotificationsResponse['data']>(
        `${API_ENDPOINTS.NOTIFICATIONS.LIST}?page=${page}`
      );
      return response;
    } catch (error) {
      console.error('Error fetching notifications:', error);
      throw error;
    }
  }

  /**
   * Get the number of notifications the current user has not read yet.
   * Returns 0 on any failure so the bell never gets stuck showing a count.
   */
  static async getUnreadCount(): Promise<number> {
    try {
      const response = await apiClient.get<{ unread_count: number }>(
        API_ENDPOINTS.NOTIFICATIONS.UNREAD_COUNT
      );
      const count = response.data?.unread_count;
      return typeof count === 'number' ? count : 0;
    } catch (error) {
      console.error('Error fetching unread notification count:', error);
      return 0;
    }
  }

  /**
   * Mark all notifications as read for the current user (advances the
   * server-side read watermark). Called when the user opens the notifications page.
   */
  static async markAllAsRead(): Promise<ApiResponse<{ unread_count: number }>> {
    try {
      const response = await apiClient.post<{ unread_count: number }>(
        API_ENDPOINTS.NOTIFICATIONS.MARK_READ
      );
      return response;
    } catch (error) {
      console.error('Error marking notifications as read:', error);
      throw error;
    }
  }

  /**
   * Delete notification (if needed in future)
   */
  static async deleteNotification(notificationId: string): Promise<ApiResponse<any>> {
    try {
      const response = await apiClient.delete<any>(
        `${API_ENDPOINTS.NOTIFICATIONS.LIST}/${notificationId}`
      );
      return response;
    } catch (error) {
      console.error('Error deleting notification:', error);
      throw error;
    }
  }
}

export default NotificationService;