import { useEffect, useMemo, useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { courseService } from '../services/courseService';
import type { Course, CourseType } from '../types/course';
import { toast } from 'react-toastify';
import { Search, BookOpen, Award, Sparkles, Zap, Users, CheckCircle2, Filter } from 'lucide-react';
import CourseCard from '../components/CourseCard';

const AffiliateCourse: React.FC = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const [search, setSearch] = useState('');
  const [type, setType] = useState<CourseType | ''>('');
  const [loading, setLoading] = useState(false);
  const [courses, setCourses] = useState<Course[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [purchaseTarget, setPurchaseTarget] = useState<Course | null>(null);
  const [purchasing, setPurchasing] = useState(false);
  const [showPurchased, setShowPurchased] = useState(false);
  const [purchasedCourses, setPurchasedCourses] = useState<Course[]>([]);



  
  const loadCourses = async (filterType?: CourseType | '', searchQuery?: string) => {
    setLoading(true);
    setError(null);
    try {
      const typeToUse = filterType !== undefined ? filterType : type;
      const searchToUse = searchQuery !== undefined ? searchQuery : search;
      const res = await courseService.listCourses({ 
        name: searchToUse || undefined, 
        type: typeToUse || undefined 
      });
      setCourses(res.data || []);
    } catch (e: any) {
      setError(e?.message || 'Failed to load courses');
    } finally {
      setLoading(false);
    }
  };

  const loadPurchasedCourses = async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await courseService.myPurchasedCourses();
      setPurchasedCourses(res.data || []);
    } catch (e: any) {
      setError(e?.message || 'Failed to load purchased courses');
    } finally {
      setLoading(false);
    }
  };

  const handleOpenCourse = (course: Course) => {
    if (course.is_plan_locked) {
      toast.info(
        `Please upgrade to ${course.required_plan_name || 'a higher plan'} to view this course.`,
      );
      navigate('/upgrade-plan');
      return;
    }
    if (showPurchased || course.type === 'free' || course.unlocked) {
      if (course.content_type === 'link' && course.course_link) {
        window.open(course.course_link, '_blank', 'noopener,noreferrer');
        return;
      }
      navigate(`/affiliate-course/${course.id}`);
      return;
    }
    setPurchaseTarget(course);
  };

  useEffect(() => {
    loadCourses();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    const purchaseCourseId = (location.state as { purchaseCourseId?: number } | null)
      ?.purchaseCourseId;
    if (!purchaseCourseId || courses.length === 0) return;

    const course = courses.find((c) => c.id === purchaseCourseId);
    if (course) {
      handleOpenCourse(course);
    }
    navigate(location.pathname, { replace: true, state: null });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [courses, location.state, location.pathname]);

  const filtered = useMemo(() => {
    if (showPurchased) {
      const q = (search || '').toLowerCase();
      return purchasedCourses.filter((c) => !q || c.name.toLowerCase().includes(q));
    }
    return courses;
  }, [showPurchased, purchasedCourses, courses, search]);

  const handlePurchase = async () => {
    if (!purchaseTarget) return;
    setPurchasing(true);
    try {
      const res = await courseService.purchaseCourse(purchaseTarget.id);
      if (res?.data?.unlocked) {
        toast.success('Course unlocked successfully');
        setPurchaseTarget(null);
        await loadCourses();
        if (showPurchased) await loadPurchasedCourses();
      } else {
        toast.info('Purchase processed');
        setPurchaseTarget(null);
        await loadCourses();
        if (showPurchased) await loadPurchasedCourses();
      }
    } catch (e: any) {
      toast.error(e?.message || 'Failed to purchase course');
    } finally {
      setPurchasing(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-sky-50 to-indigo-50">
      {/* Ultra Modern Hero with Glassmorphism */}
      <div className="relative overflow-hidden">
        {/* Animated Background */}
        <div className="absolute inset-0 bg-gradient-to-br from-sky-600 via-indigo-600 to-purple-700">
          <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxnIGZpbGw9IiNmZmYiIGZpbGwtb3BhY2l0eT0iMC4wNSI+PHBhdGggZD0iTTM2IDE0YzMuMzE0IDAgNi0yLjY4NiA2LTZzLTIuNjg2LTYtNi02LTYgMi42ODYtNiA2IDIuNjg2IDYgNiA2ek0yNCA0OGMzLjMxNCAwIDYtMi42ODYgNi02cy0yLjY4Ni02LTYtNi02IDIuNjg2LTYgNiAyLjY4NiA2IDYgNnoiLz48L2c+PC9nPjwvc3ZnPg==')] opacity-30" />
          <div className="absolute top-0 left-1/4 w-96 h-96 bg-sky-400 rounded-full mix-blend-multiply filter blur-3xl opacity-20 animate-blob" />
          <div className="absolute top-0 right-1/4 w-96 h-96 bg-purple-400 rounded-full mix-blend-multiply filter blur-3xl opacity-20 animate-blob animation-delay-2000" />
          <div className="absolute bottom-0 left-1/3 w-96 h-96 bg-indigo-400 rounded-full mix-blend-multiply filter blur-3xl opacity-20 animate-blob animation-delay-4000" />
        </div>

        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 sm:py-24">
          {/* Hero Content */}
          <div className="text-center mb-12">
            <div className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full bg-white/10 backdrop-blur-md border border-white/20 text-white text-sm font-semibold mb-6 shadow-2xl hover:bg-white/20 transition-all">
              <Sparkles className="w-4 h-4 animate-pulse" />
              <span>Premium Learning Experience</span>
              <Sparkles className="w-4 h-4 animate-pulse" />
            </div>
            
            <h1 className="text-5xl sm:text-6xl lg:text-7xl font-black text-white tracking-tight mb-6 drop-shadow-2xl">
              Discover Your
              <span className="block bg-gradient-to-r from-amber-200 via-yellow-300 to-amber-200 bg-clip-text text-transparent animate-gradient">
                Next Course
              </span>
            </h1>
            
            <p className="text-xl sm:text-2xl text-white/90 max-w-3xl mx-auto mb-10 leading-relaxed">
              Transform your skills with world-class courses. Learn at your own pace from industry experts.
            </p>

            {/* Animated Stats */}
            <div className="flex flex-wrap justify-center gap-6 sm:gap-10">
              <div className="group">
                <div className="bg-white/10 backdrop-blur-md border border-white/20 rounded-2xl p-6 hover:bg-white/20 transition-all shadow-2xl hover:scale-105 transform duration-300">
                  <div className="flex items-center gap-4">
                    <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-amber-400 to-orange-500 flex items-center justify-center shadow-lg">
                      <BookOpen className="w-7 h-7 text-white" />
                    </div>
                    <div className="text-left">
                      <div className="text-3xl font-black text-white">{courses.length}+</div>
                      <div className="text-sm text-white/80 font-medium">Premium Courses</div>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="group">
                <div className="bg-white/10 backdrop-blur-md border border-white/20 rounded-2xl p-6 hover:bg-white/20 transition-all shadow-2xl hover:scale-105 transform duration-300">
                  <div className="flex items-center gap-4">
                    <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-emerald-400 to-teal-500 flex items-center justify-center shadow-lg">
                      <Users className="w-7 h-7 text-white" />
                    </div>
                    <div className="text-left">
                      <div className="text-3xl font-black text-white">50K+</div>
                      <div className="text-sm text-white/80 font-medium">Active Learners</div>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="group">
                <div className="bg-white/10 backdrop-blur-md border border-white/20 rounded-2xl p-6 hover:bg-white/20 transition-all shadow-2xl hover:scale-105 transform duration-300">
                  <div className="flex items-center gap-4">
                    <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-purple-400 to-pink-500 flex items-center justify-center shadow-lg">
                      <Zap className="w-7 h-7 text-white" />
                    </div>
                    <div className="text-left">
                      <div className="text-3xl font-black text-white">Expert</div>
                      <div className="text-sm text-white/80 font-medium">Instructors</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Modern Search Bar with Glassmorphism */}
          <div className="max-w-5xl mx-auto">
            <div className="bg-white/95 backdrop-blur-xl rounded-3xl shadow-2xl border border-white/50 p-8">
              <div className="flex flex-col md:flex-row gap-4">
                <div className="flex-1 relative group">
                  <Search className="absolute left-5 top-1/2 -translate-y-1/2 w-6 h-6 text-sky-500 group-hover:text-sky-600 transition-colors" />
                  <input
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                    onKeyPress={(e) => {
                      if (e.key === 'Enter') {
                        if (showPurchased) {
                          // client-side filter; ensure purchased loaded at least once
                          if (purchasedCourses.length === 0) loadPurchasedCourses();
                        } else {
                          loadCourses(type, search);
                        }
                      }
                    }}
                    placeholder="Search for courses..."
                    className="w-full pl-14 pr-6 py-4 text-lg rounded-2xl border-2 border-gray-200 bg-white focus:border-sky-500 focus:outline-none focus:ring-4 focus:ring-sky-100 transition-all font-medium"
                  />
                </div>
                <button
                  onClick={() => {
                    if (showPurchased) {
                      if (purchasedCourses.length === 0) loadPurchasedCourses();
                    } else {
                      loadCourses(type, search);
                    }
                  }}
                  className="px-8 py-4 rounded-2xl bg-gradient-to-r from-sky-500 to-indigo-600 text-white font-bold text-lg shadow-xl hover:shadow-2xl hover:scale-105 transform transition-all flex items-center justify-center gap-3"
                >
                  <Search className="w-5 h-5" />
                  Search
                </button>
              </div>
              
              {/* Filter Pills */}
              <div className="flex flex-wrap gap-3 mt-6 items-center">
                <div className="flex items-center gap-2 text-gray-600 font-semibold">
                  <Filter className="w-4 h-4" />
                  <span>Filter:</span>
                </div>
                <button
                  onClick={() => { 
                    setShowPurchased(false);
                    setType(''); 
                    loadCourses('', search); 
                  }}
                  className={`px-6 py-3 rounded-xl font-bold transition-all transform hover:scale-105 ${
                    !showPurchased && type === '' 
                      ? 'bg-gradient-to-r from-sky-500 to-indigo-600 text-white shadow-lg' 
                      : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                  }`}
                >
                  All Courses
                </button>
                <button
                  onClick={() => { 
                    setShowPurchased(false);
                    setType('free'); 
                    loadCourses('free', search); 
                  }}
                  className={`px-6 py-3 rounded-xl font-bold transition-all transform hover:scale-105 ${
                    !showPurchased && type === 'free' 
                      ? 'bg-gradient-to-r from-emerald-500 to-teal-600 text-white shadow-lg' 
                      : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                  }`}
                >
                  🎓 Free
                </button>
                <button
                  onClick={() => { 
                    setShowPurchased(false);
                    setType('premium'); 
                    loadCourses('premium', search); 
                  }}
                  className={`px-6 py-3 rounded-xl font-bold transition-all transform hover:scale-105 ${
                    !showPurchased && type === 'premium' 
                      ? 'bg-gradient-to-r from-amber-500 to-orange-600 text-white shadow-lg' 
                      : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                  }`}
                >
                  ⭐ Premium
                </button>
                <button
                  onClick={() => {
                    setShowPurchased(true);
                    setType('');
                    if (purchasedCourses.length === 0) loadPurchasedCourses();
                  }}
                  className={`px-6 py-3 rounded-xl font-bold transition-all transform hover:scale-105 ${
                    showPurchased
                      ? 'bg-gradient-to-r from-purple-500 to-fuchsia-600 text-white shadow-lg'
                      : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                  }`}
                >
                  🛒 Purchased
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Premium Course Cards */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        {loading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
            {Array.from({ length: 6 }).map((_, i) => (
              <div key={i} className="bg-white rounded-3xl shadow-xl overflow-hidden border border-gray-100">
                <div className="aspect-video bg-gradient-to-br from-sky-200 via-indigo-200 to-purple-200 animate-pulse" />
                <div className="p-6">
                  <div className="h-6 bg-gray-200 rounded-lg animate-pulse mb-3" />
                  <div className="h-4 bg-gray-100 rounded animate-pulse w-3/4 mb-2" />
                  <div className="h-4 bg-gray-100 rounded animate-pulse w-1/2" />
                </div>
              </div>
            ))}
          </div>
        ) : error ? (
          <div className="bg-white rounded-3xl shadow-2xl border-2 border-red-200 p-10 text-center max-w-2xl mx-auto">
            <div className="w-20 h-20 bg-gradient-to-br from-red-400 to-red-600 rounded-full flex items-center justify-center mx-auto mb-6">
              <span className="text-4xl">⚠️</span>
            </div>
            <h3 className="text-2xl font-bold text-gray-900 mb-3">Oops! Something went wrong</h3>
            <p className="text-gray-600 mb-6 text-lg">{error}</p>
            <button 
              onClick={() => loadCourses(type, search)} 
              className="px-8 py-4 rounded-2xl bg-gradient-to-r from-sky-500 to-indigo-600 text-white font-bold shadow-xl hover:shadow-2xl hover:scale-105 transform transition-all"
            >
              Try Again
            </button>
          </div>
        ) : filtered.length === 0 ? (
          <div className="text-center py-20">
            <div className="w-32 h-32 bg-gradient-to-br from-sky-100 to-indigo-100 rounded-full flex items-center justify-center mx-auto mb-8 shadow-xl">
              <BookOpen className="w-16 h-16 text-sky-600" />
            </div>
            <h3 className="text-3xl font-bold text-gray-900 mb-4">No Courses Found</h3>
            <p className="text-gray-600 mb-8 text-lg">Try adjusting your search or filter criteria.</p>
            <button
              onClick={() => { 
                setSearch(''); 
                setType(''); 
                loadCourses('', ''); 
              }}
              className="px-8 py-4 rounded-2xl bg-gradient-to-r from-sky-500 to-indigo-600 text-white font-bold shadow-xl hover:shadow-2xl hover:scale-105 transform transition-all"
            >
              Clear All Filters
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
            {filtered.map((course) => (
              <CourseCard
                key={course.id}
                course={course}
                onOpen={handleOpenCourse}
              />
            ))}
          </div>
        )}
      </div>

      {/* Ultra Premium Purchase Modal */}
      {purchaseTarget && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 animate-fadeIn">
          <div className="absolute inset-0 bg-black/70 backdrop-blur-md" onClick={() => !purchasing && setPurchaseTarget(null)} />
          <div className="relative w-full max-w-md sm:max-w-2xl animate-scaleIn">
            {/* Animated Glow */}
            <div className="absolute -inset-2 bg-gradient-to-r from-amber-400 via-orange-500 to-amber-400 rounded-3xl blur-2xl opacity-60 animate-pulse" />
            
            {/* Modal Content */}
            <div className="relative bg-white rounded-3xl shadow-2xl overflow-hidden">
              {/* Header with Gradient */}
              <div className="bg-gradient-to-r from-amber-500 via-orange-500 to-amber-600 p-6 sm:p-8 text-white">
                <div className="flex items-start gap-6">
                  <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl bg-white/20 backdrop-blur-md flex items-center justify-center shadow-2xl">
                    <Award className="w-10 h-10 sm:w-12 sm:h-12 text-white" />
                  </div>
                  <div className="flex-1">
                    <h3 className="text-2xl sm:text-3xl font-black mb-2">Unlock Premium Access</h3>
                    <p className="text-amber-50 text-base sm:text-lg">Get lifetime access to exclusive content</p>
                  </div>
                </div>
              </div>
              
              {/* Course Info */}
              <div className="p-6 sm:p-8">
                <div className="bg-gradient-to-br from-sky-50 to-indigo-50 rounded-2xl p-4 sm:p-6 mb-6 border-2 border-sky-200">
                  <div className="flex items-center gap-3 mb-4">
                    <BookOpen className="w-6 h-6 text-sky-600" />
                    <h4 className="font-bold text-gray-900 text-lg">Course Details</h4>
                  </div>
                  <p className="text-gray-700 font-semibold text-xl mb-4">{purchaseTarget.name}</p>
                  
                  <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pt-4 border-t-2 border-sky-200">
                    <div>
                      <div className="text-sm text-gray-600 font-medium mb-1">Investment</div>
                      <div className="text-3xl sm:text-4xl font-black bg-gradient-to-r from-amber-600 to-orange-600 bg-clip-text text-transparent">
                        {purchaseTarget.price ? `$${purchaseTarget.price}` : 'Premium'}
                      </div>
                    </div>
                    <div className="px-4 sm:px-5 py-2.5 sm:py-3 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 text-white font-black text-xs sm:text-sm shadow-lg">
                      ⭐ PREMIUM ACCESS
                    </div>
                  </div>
                </div>
                
                {/* Benefits */}
                <div className="space-y-3 mb-6">
                  <div className="flex items-center gap-3 text-gray-700">
                    <div className="w-6 h-6 rounded-full bg-emerald-100 flex items-center justify-center">
                      <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    </div>
                    <span className="font-semibold">Lifetime access to all course materials</span>
                  </div>
                  <div className="flex items-center gap-3 text-gray-700">
                    <div className="w-6 h-6 rounded-full bg-emerald-100 flex items-center justify-center">
                      <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    </div>
                    <span className="font-semibold">Watch anytime, anywhere</span>
                  </div>
                  <div className="flex items-center gap-3 text-gray-700">
                    <div className="w-6 h-6 rounded-full bg-emerald-100 flex items-center justify-center">
                      <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    </div>
                    <span className="font-semibold">Expert instructor support</span>
                  </div>
                </div>
                
                {/* Action Buttons */}
                <div className="flex flex-col sm:flex-row gap-3 sm:gap-4">
                  <button
                    onClick={() => setPurchaseTarget(null)}
                    disabled={purchasing}
                    className="flex-1 px-5 py-3 sm:px-6 sm:py-4 rounded-2xl bg-gray-100 text-gray-700 font-bold hover:bg-gray-200 disabled:opacity-50 transition-all"
                  >
                    Maybe Later
                  </button>
                  <button
                    disabled={purchasing}
                    onClick={handlePurchase}
                    className="flex-1 px-5 py-3 sm:px-6 sm:py-4 rounded-2xl bg-gradient-to-r from-amber-500 to-orange-600 text-white font-black shadow-xl hover:shadow-2xl hover:scale-105 transform transition-all disabled:opacity-50 flex items-center justify-center gap-3"
                  >
                    {purchasing ? (
                      <>
                        <div className="w-5 h-5 border-3 border-white border-t-transparent rounded-full animate-spin" />
                        Processing...
                      </>
                    ) : (
                      <>
                        <Sparkles className="w-5 h-5" />
                        Unlock Now
                      </>
                    )}
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>      
      )}
    </div>
  );
};

export default AffiliateCourse;
