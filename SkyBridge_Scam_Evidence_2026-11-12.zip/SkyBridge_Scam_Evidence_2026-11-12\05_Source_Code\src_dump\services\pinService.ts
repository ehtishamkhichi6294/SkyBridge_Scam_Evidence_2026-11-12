import { apiClient, ApiError } from "./apiClient";
import { API_ENDPOINTS } from "../config/api";

export interface PlanSummary {
  id: number;
  name: string;
  price_pkr: string | number;
  price_usd: string | number;
}

export interface PinPurchaseRequestItem {
  id: number;
  pin_purchase_request_id: number;
  plan_id: number;
  quantity: number;
  amount_pkr: string;
  amount_usd: string;
  plan: PlanSummary;
}

export interface PinPurchaseRequest {
  id: number;
  user_id?: number;
  plan_id?: number;
  transaction_id: string;
  transaction_account_number: string;
  transaction_account_title: string;
  transaction_screenshot?: string;
  amount_pkr?: string | number;
  amount_usd?: string | number;
  total_pins_requested?: number;
  status: "pending" | "approved" | "rejected";
  admin_notes?: string | null;
  approved_at?: string | null;
  rejected_at?: string | null;
  plan?: PlanSummary;
  items?: PinPurchaseRequestItem[];
  created_at: string;
  updated_at?: string;
}

export interface AccountPin {
  id: number;
  pin_code: string;
  plan_id: number;
  purchase_request_id?: number;
  purchased_by_user_id?: number;
  used_by_user_id?: number | null;
  used_at?: string | null;
  status: "unused" | "used";
  plan?: PlanSummary;
  used_by?: { id: number; name: string; email: string } | null;
  created_at: string;
}

export interface PaginatorMeta<T> {
  data: T[];
  current_page: number;
  last_page: number;
  total?: number;
}

export interface PinFieldErrors {
  [key: string]: string;
}

export class PinServiceError extends Error {
  fieldErrors: PinFieldErrors;

  constructor(message: string, fieldErrors: PinFieldErrors = {}) {
    super(message);
    this.name = "PinServiceError";
    this.fieldErrors = fieldErrors;
  }
}

function parseFieldErrors(err: ApiError): PinFieldErrors {
  const raw = err.data?.errors;
  if (!raw || typeof raw !== "object") return {};
  const out: PinFieldErrors = {};
  for (const [key, val] of Object.entries(raw)) {
    if (Array.isArray(val) && val[0]) out[key] = String(val[0]);
    else if (typeof val === "string") out[key] = val;
  }
  return out;
}

function unwrapPaginator<T>(payload: unknown): PaginatorMeta<T> {
  if (Array.isArray(payload)) {
    return { data: payload as T[], current_page: 1, last_page: 1 };
  }
  if (payload && typeof payload === "object" && "data" in payload) {
    const p = payload as PaginatorMeta<T>;
    return {
      data: Array.isArray(p.data) ? p.data : [],
      current_page: p.current_page ?? 1,
      last_page: p.last_page ?? 1,
      total: p.total,
    };
  }
  return { data: [], current_page: 1, last_page: 1 };
}

function handlePinError(err: unknown): never {
  if (err && typeof err === "object" && "status" in err) {
    const apiErr = err as ApiError;
    const fieldErrors = parseFieldErrors(apiErr);
    throw new PinServiceError(
      apiErr.message || "Request failed",
      fieldErrors,
    );
  }
  throw err;
}

export interface SubmitPinRequestInput {
  items: Array<{ planId: number; quantity: number }>;
  transactionId: string;
  transactionAccountNumber: string;
  transactionAccountTitle: string;
  transactionScreenshot: File;
}

export interface CreateAccountWithPinInput {
  fullName: string;
  email: string;
  password: string;
  passwordConfirmation: string;
  country: string;
  referralCode: string;
  pinCode: string;
  accountNumber?: string;
  accountTitle?: string;
  paymentMethods?: string;
  bep20Address?: string;
}

export interface TodayPinOffer {
  id: number;
  title: string;
  description?: string | null;
  discount_percentage: string | number;
  day_of_week: number;
  day_name: string;
  plan_id: number;
  plan?: PlanSummary;
}

export const pinService = {
  async submitPinRequest(input: SubmitPinRequestInput) {
    const form = new FormData();
    form.append("transaction_id", input.transactionId.trim());
    form.append(
      "transaction_account_number",
      input.transactionAccountNumber.trim(),
    );
    form.append(
      "transaction_account_title",
      input.transactionAccountTitle.trim(),
    );
    form.append("transaction_screenshot", input.transactionScreenshot);

    input.items.forEach((item, index) => {
      form.append(`items[${index}][plan_id]`, String(item.planId));
      form.append(`items[${index}][quantity]`, String(item.quantity));
    });

    try {
      return await apiClient.post<PinPurchaseRequest>(
        API_ENDPOINTS.PIN.REQUESTS,
        form,
      );
    } catch (err) {
      handlePinError(err);
    }
  },

  async getPinRequests(params?: { status?: string; page?: number }) {
    const q = new URLSearchParams();
    if (params?.status && params.status !== "all") {
      q.set("status", params.status);
    }
    if (params?.page) q.set("page", String(params.page));
    const qs = q.toString();
    const endpoint = `${API_ENDPOINTS.PIN.REQUESTS}${qs ? `?${qs}` : ""}`;
    try {
      const res = await apiClient.get<PaginatorMeta<PinPurchaseRequest>>(
        endpoint,
      );
      return { ...res, data: unwrapPaginator<PinPurchaseRequest>(res.data) };
    } catch (err) {
      handlePinError(err);
    }
  },

  async getPins(params?: { status?: string; page?: number }) {
    const q = new URLSearchParams();
    if (params?.status && params.status !== "all") {
      q.set("status", params.status);
    }
    if (params?.page) q.set("page", String(params.page));
    const qs = q.toString();
    const endpoint = `${API_ENDPOINTS.PIN.PINS}${qs ? `?${qs}` : ""}`;
    try {
      const res = await apiClient.get<PaginatorMeta<AccountPin>>(endpoint);
      return { ...res, data: unwrapPaginator<AccountPin>(res.data) };
    } catch (err) {
      handlePinError(err);
    }
  },

  async createAccountWithPin(input: CreateAccountWithPinInput) {
    try {
      const payload: Record<string, any> = {
        full_name: input.fullName.trim(),
        email: input.email.trim(),
        password: input.password,
        password_confirmation: input.passwordConfirmation,
        country: input.country.trim(),
        referral_code: input.referralCode.trim(),
        pin_code: input.pinCode.trim(),
      };

      if (input.country.trim().toLowerCase() === "pakistan") {
        if (input.accountNumber) payload.account_number = input.accountNumber.trim();
        if (input.accountTitle) payload.account_title = input.accountTitle.trim();
        if (input.paymentMethods) payload.payment_methods = input.paymentMethods.trim();
      } else {
        if (input.bep20Address) payload.bep20_address = input.bep20Address.trim();
      }

      return await apiClient.post(API_ENDPOINTS.PIN.CREATE_ACCOUNT, payload);
    } catch (err) {
      handlePinError(err);
    }
  },

  async getTodaySignupOffers() {
    try {
      const res = await apiClient.get<TodayPinOffer[]>(
        API_ENDPOINTS.PIN.SIGNUP_OFFER_TODAY,
      );
      const list = Array.isArray(res.data) ? res.data : [];
      return { ...res, data: list };
    } catch (err) {
      handlePinError(err);
    }
  },
};

export default pinService;
