import React, { useState, useEffect } from "react";
import {
  Award,
  Star,
  DollarSign,
  CheckCircle,
  ArrowRight,
  Crown,
  Zap,
  Users,
} from "lucide-react";
import { userService } from "../services/userService";

interface Rewardlevel {
  amount: number;
  cost: number;
  popular?: boolean;
  featured?: boolean;
}

const Rewards: React.FC = () => {
  // State for total referrals
  const [totalReferrals, setTotalReferrals] = useState<number>(0);
  const [isLoadingReferrals, setIsLoadingReferrals] = useState<boolean>(true);
  const [referralError, setReferralError] = useState<string | null>(null);

  // State for claim functionality
  const [claimingLevels, setClaimingLevels] = useState<Set<number>>(new Set());
  const [claimedLevels, setClaimedLevels] = useState<Set<number>>(new Set());
  const [claimMessage, setClaimMessage] = useState<string | null>(null);
  const [rewardModalOpen, setRewardModalOpen] = useState(false);
  const [rewardModalAnimateIn, setRewardModalAnimateIn] = useState(false);
  const [rewardModalLevel, setRewardModalLevel] = useState<Rewardlevel | null>(null);
  const rewardlevels: Rewardlevel[] = [
    { amount: 25, cost: 10, featured: true },
    { amount: 50, cost: 10, featured: true },
    { amount: 100, cost: 15, featured: true },
    { amount: 200, cost: 30, featured: true },
    { amount: 500, cost: 100, featured: true },
    { amount: 750, cost: 50, featured: true },
    { amount: 1000, cost: 100, featured: true },
    { amount: 1250, cost: 50, featured: true },
    { amount: 1500, cost: 50, featured: true },
    { amount: 1750, cost: 50, featured: true },
    { amount: 2000, cost: 300, featured: true },
    { amount: 3000, cost: 300, featured: true },
    { amount: 4000, cost: 300, featured: true },
    { amount: 5000, cost: 500, featured: true },
    { amount: 10000, cost: 3000, featured: true },
  ];

  const getRowStyle = (level: Rewardlevel) => {
    if (level.featured) {
      return "bg-gradient-to-r from-sky-50 to-sky-100 border-l-4 border-sky-500 shadow-lg";
    }
    if (level.popular) {
      return "bg-gradient-to-r from-sky-50 to-cyan-50 border-l-4 border-sky-500 shadow-md";
    }
    return "bg-white border-l-4 border-gray-200 hover:border-gray-300 hover:shadow-md";
  };

  const closeRewardModal = () => {
    setRewardModalAnimateIn(false);
    setTimeout(() => {
      setRewardModalOpen(false);
      setRewardModalLevel(null);
    }, 200);
  };

  const getBadge = (level: Rewardlevel) => {
    if (level.featured) {
      return (
        <div className="flex items-center space-x-1 bg-gradient-to-r from-sky-500 to-sky-600 text-white px-3 py-1 rounded-full text-xs font-bold">
          <Crown className="w-3 h-3" />
          <span>FEATURED</span>
        </div>
      );
    }
    if (level.popular) {
      return (
        <div className="flex items-center space-x-1 bg-gradient-to-r from-sky-500 to-cyan-500 text-white px-3 py-1 rounded-full text-xs font-bold">
          <Star className="w-3 h-3" />
          <span>POPULAR</span>
        </div>
      );
    }
    return null;
  };

  const getROI = (level: Rewardlevel) => {
    return ((level.amount / level.cost) * 100).toFixed(0);
  };

  const isClaimable = (level: Rewardlevel) => {
    // Claim becomes available when your approved referrals are equal or above the threshold
    return totalReferrals >= level.amount;
  };

  // Handle claim reward
  const handleClaim = async (level: Rewardlevel) => {
    if (!isClaimable(level) || claimingLevels.has(level.amount) || claimedLevels.has(level.amount)) {
      return;
    }

    try {
      // Add level to claiming set
      setClaimingLevels((prev) => new Set(prev).add(level.amount));
      setClaimMessage(null);

      // Call the API (pass level as required)
      const result = await userService.claimReward(level.amount);

      const alreadyClaimed = (result.message || '').toLowerCase().includes('already been claimed');

      if (result.success) {
        setClaimMessage(`✅ ${result.message}`);
        setClaimedLevels((prev) => new Set(prev).add(level.amount));
        setRewardModalLevel(level);
        setRewardModalOpen(true);
        setTimeout(() => setRewardModalAnimateIn(true), 20);
        // Optionally refresh referral count after successful claim
        const summary = await userService.getReferralSummary();
        setTotalReferrals(summary.approved_referrals);
        // Ensure previously claimed levels are marked from server response
        setClaimedLevels(new Set(summary.claimed_rewards || []));
      } else if (alreadyClaimed) {
        setClaimMessage(`ℹ️ ${result.message}`);
        // Mark level as claimed to disable button and change text
        setClaimedLevels((prev) => new Set(prev).add(level.amount));
      } else {
        setClaimMessage(`❌ ${result.message}`);
      }
    } catch (error: any) {
      console.error("Error claiming reward:", error);
      setClaimMessage(`❌ ${error.message || "Failed to claim reward"}`);
    } finally {
      // Remove level from claiming set
      setClaimingLevels((prev) => {
        const newSet = new Set(prev);
        newSet.delete(level.amount);
        return newSet;
      });

      // Clear message after 3 seconds
      setTimeout(() => setClaimMessage(null), 3000);
    }
  };

  // Fetch total referrals on component mount
  useEffect(() => {
    const fetchReferralCount = async () => {
      try {
        setIsLoadingReferrals(true);
        setReferralError(null);
        const summary = await userService.getReferralSummary();
        // Show approved_referrals under "My Referrals"
        setTotalReferrals(Number(summary?.approved_referrals ?? 0));
        // Initialize claimed levels from server so buttons show "Claimed" from start
        setClaimedLevels(new Set(summary?.claimed_rewards || []));
      } catch (error: any) {
        console.error("Failed to fetch referral count:", error);
        setReferralError(error.message || "Failed to load referral count");
      } finally {
        setIsLoadingReferrals(false);
      }
    };

    fetchReferralCount();
  }, []);

  const renderReferralCount = () => {
    if (isLoadingReferrals) {
      return (
        <div className="flex items-center space-x-2">
          <Users className="w-4 h-4 text-gray-400" />
          <span className="text-gray-500">Loading...</span>
        </div>
      );
    }

    if (referralError) {
      return (
        <div className="flex items-center space-x-2">
          <Users className="w-4 h-4 text-red-400" />
          <span className="text-red-500">Error</span>
        </div>
      );
    }

    return (
      <div className="flex items-center space-x-2">
        <Users className="w-4 h-4 text-sky-600" />
        <span className="text-gray-900 font-semibold">{totalReferrals}</span>
      </div>
    );
  };

  return (
    <div className="space-y-4 md:space-y-8 px-4 md:px-0">
      {/* Header Section */}
      <div className="bg-gradient-to-r from-sky-600 to-sky-700 rounded-xl md:rounded-2xl p-4 md:p-8 text-white mt-2 md:mt-0">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between space-y-4 md:space-y-0">
          <div className="flex items-center space-x-3 md:space-x-4">
            <div className="w-12 h-12 md:w-16 md:h-16 bg-white/20 rounded-xl md:rounded-2xl flex items-center justify-center backdrop-blur-sm">
              <Award className="w-6 h-6 md:w-8 md:h-8" />
            </div>
            <div>
              <h1 className="text-2xl md:text-4xl font-bold text-white mb-1 md:mb-2">
                Rewards List
              </h1>
              <p className="text-sky-100 text-sm md:text-lg">
                Professional reward levels with instant payouts
              </p>
            </div>
          </div>
          <div className="flex md:hidden items-center justify-center space-x-6">
            <div className="text-center">
              <div className="text-xl font-bold">
                {rewardlevels.length}
              </div>
              <div className="text-xs text-sky-100">Total levels</div>
            </div>
            <div className="text-center">
              <div className="text-xl font-bold">
                {isLoadingReferrals
                  ? "..."
                  : referralError
                  ? "Error"
                  : totalReferrals}
              </div>
              <div className="text-xs text-sky-100">My Referrals</div>
            </div>
            <div className="text-center">
              <div className="text-xl font-bold">100%</div>
              <div className="text-xs text-sky-100">Success Rate</div>
            </div>
          </div>
          <div className="hidden md:flex items-center space-x-6">
            <div className="text-center">
              <div className="text-2xl font-bold">{rewardlevels.length}</div>
              <div className="text-sm text-sky-100">Total levels</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold">
                {isLoadingReferrals
                  ? "..."
                  : referralError
                  ? "Error"
                  : totalReferrals}
              </div>
              <div className="text-sm text-sky-100">My Referrals</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold">100%</div>
              <div className="text-sm text-sky-100">Success Rate</div>
            </div>
          </div>
        </div>
      </div>

      {/* Claim Message */}
      {claimMessage && (
        <div
          className={`
          p-4 rounded-xl border-l-4 ${
            claimMessage.includes("✅")
              ? "bg-green-50 border-green-500 text-green-700"
              : "bg-red-50 border-red-500 text-red-700"
          }
        `}
        >
          <div className="font-medium">{claimMessage}</div>
        </div>
      )}

      {/* Rewards List */}
      <div className="bg-white rounded-xl md:rounded-2xl shadow-xl border border-gray-100 overflow-hidden">
        {/* Desktop List Header */}
        <div className="hidden md:block bg-gray-50 px-8 py-4 border-b border-gray-200">
          <div className="grid grid-cols-12 gap-4 items-center">
            <div className="col-span-1 text-sm font-semibold text-gray-600 uppercase tracking-wide">
              #
            </div>
            <div className="col-span-3 text-sm font-semibold text-gray-600 uppercase tracking-wide">
              Reward Details
            </div>
            <div className="col-span-2 text-sm font-semibold text-gray-600 uppercase tracking-wide">
              Reward Amount
            </div>
            <div className="col-span-2 text-sm font-semibold text-gray-600 uppercase tracking-wide">
              MEMBERS
            </div>
            <div className="col-span-2 text-sm font-semibold text-gray-600 uppercase tracking-wide">
              Action
            </div>
          </div>
        </div>

        {/* List Items */}
        <div className="divide-y divide-gray-100">
          {rewardlevels.map((level, index) => (
            <div
              key={index}
              className={`
                transition-all duration-300 cursor-pointer
                ${getRowStyle(level)}
              `}
            >
              {/* Desktop Layout */}
              <div className="hidden md:block px-8 py-6 hover:transform hover:scale-[1.02]">
                <div className="grid grid-cols-12 gap-4 items-center">
                  {/* Index */}
                  <div className="col-span-1">
                    <div className="w-8 h-8 bg-gray-100 rounded-full flex items-center justify-center">
                      <span className="text-sm font-bold text-gray-700">
                        {index + 1}
                      </span>
                    </div>
                  </div>

                  {/* Reward Details */}
                  <div className="col-span-3">
                    <div className="flex items-center space-x-3">
                      <div
                        className={`
                      w-12 h-12 rounded-xl flex items-center justify-center
                      ${
                        level.featured
                          ? "bg-sky-100"
                          : level.popular
                          ? "bg-sky-100"
                          : "bg-gray-100"
                      }
                    `}
                      >
                        {level.featured ? (
                          <Crown className={`w-6 h-6 text-sky-600`} />
                        ) : level.popular ? (
                          <Star className={`w-6 h-6 text-sky-600`} />
                        ) : (
                          <DollarSign className={`w-6 h-6 text-gray-600`} />
                        )}
                      </div>
                      <div>
                        <div className="font-bold text-gray-900">
                          level {index + 1}
                        </div>
                        <div className="flex items-center space-x-2">
                          {getBadge(level)}
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Entry Cost */}
                  <div className="col-span-2">
                    <div className="text-2xl font-bold text-gray-900">
                      ${level.cost}
                    </div>
                    <div className="text-sm text-gray-500">Reward</div>
                  </div>

                  {/* Reward Amount */}
                  <div className="col-span-2">
                    <div className="text-2xl font-bold text-green-600">
                      {/* {level.amount} */}
                    </div>
                  </div>

                  {/* Action Button */}
                  <div className="col-span-2">
                    <button
                      disabled={
                        !isClaimable(level) || claimingLevels.has(level.amount) || claimedLevels.has(level.amount)
                      }
                      onClick={() => handleClaim(level)}
                      className={`
                        w-full py-3 px-4 rounded-xl font-semibold transition-all duration-200 transform hover:scale-105 flex items-center justify-center space-x-2
                        ${
                          ((isClaimable(level) && !claimingLevels.has(level.amount)) || claimedLevels.has(level.amount))
                            ? level.featured
                              ? "bg-gradient-to-r from-sky-600 to-sky-700 text-white hover:from-sky-700 hover:to-sky-800 shadow-lg"
                              : level.popular
                              ? "bg-gradient-to-r from-sky-600 to-cyan-600 text-white hover:from-sky-700 hover:to-cyan-700 shadow-md"
                              : "bg-gradient-to-r from-gray-600 to-gray-700 text-white hover:from-gray-700 hover:to-gray-800"
                            : "bg-gray-300 text-gray-500 cursor-not-allowed"
                        }
                      `}
                    >
                      <span>
                        {claimingLevels.has(level.amount)
                          ? "Claiming..."
                          : claimedLevels.has(level.amount)
                          ? "Claimed"
                          : isClaimable(level)
                          ? "Claim"
                          : "Locked"}
                      </span>
                      <ArrowRight className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>

              {/* Mobile Card Layout */}
              <div className="md:hidden p-4">
                <div className="flex items-start space-x-3">
                  {/* Level Number & Icon */}
                  <div className="flex-shrink-0">
                    <div className="w-6 h-6 bg-gray-100 rounded-full flex items-center justify-center mb-2">
                      <span className="text-xs font-bold text-gray-700">
                        {index + 1}
                      </span>
                    </div>
                    <div
                      className={`
                      w-10 h-10 rounded-lg flex items-center justify-center
                      ${
                        level.featured
                          ? "bg-sky-100"
                          : level.popular
                          ? "bg-sky-100"
                          : "bg-gray-100"
                      }
                    `}
                    >
                      {level.featured ? (
                        <Crown className={`w-5 h-5 text-sky-600`} />
                      ) : level.popular ? (
                        <Star className={`w-5 h-5 text-sky-600`} />
                      ) : (
                        <DollarSign className={`w-5 h-5 text-gray-600`} />
                      )}
                    </div>
                  </div>

                  {/* Content */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between mb-2">
                      <div className="font-bold text-gray-900">
                        Level {index + 1}
                      </div>
                      {getBadge(level)}
                    </div>

                    <div className="grid grid-cols-2 gap-3 mb-3">
                      <div>
                        <div className="text-xs text-gray-500 uppercase tracking-wide">
                          Reward
                        </div>
                        <div className="text-lg font-bold text-gray-900">
                          ${level.cost}
                        </div>
                      </div>
                      <div>
                        <div className="text-xs text-gray-500 uppercase tracking-wide">
                          Members
                        </div>
                        <div className="text-lg font-bold text-green-600">
                          {level.amount}
                        </div>
                      </div>
                    </div>

                    <button
                      disabled={
                        !isClaimable(level) || claimingLevels.has(level.amount) || claimedLevels.has(level.amount)
                      }
                      onClick={() => handleClaim(level)}
                      className={`
                        w-full py-2.5 px-4 rounded-lg font-semibold transition-all duration-200 flex items-center justify-center space-x-2 text-sm
                        ${
                          ((isClaimable(level) && !claimingLevels.has(level.amount)) || claimedLevels.has(level.amount))
                            ? level.featured
                              ? "bg-gradient-to-r from-sky-600 to-sky-700 text-white hover:from-sky-700 hover:to-sky-800 shadow-lg"
                              : level.popular
                              ? "bg-gradient-to-r from-sky-600 to-cyan-600 text-white hover:from-sky-700 hover:to-cyan-700 shadow-md"
                              : "bg-gradient-to-r from-gray-600 to-gray-700 text-white hover:from-gray-700 hover:to-gray-800"
                            : "bg-gray-300 text-gray-500 cursor-not-allowed"
                        }
                      `}
                    >
                      <span>
                        {claimingLevels.has(level.amount)
                          ? "Claiming..."
                          : claimedLevels.has(level.amount)
                          ? "Claimed"
                          : isClaimable(level)
                          ? "Claim"
                          : "Locked"}
                      </span>
                      <ArrowRight className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Stats Section */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 md:gap-6">
        <div className="bg-white rounded-xl md:rounded-2xl shadow-lg border border-gray-100 p-4 md:p-6">
          <div className="flex items-center space-x-3 md:space-x-4">
            <div className="w-10 h-10 md:w-12 md:h-12 bg-sky-100 rounded-lg md:rounded-xl flex items-center justify-center">
              <Zap className="w-5 h-5 md:w-6 md:h-6 text-sky-600" />
            </div>
            <div>
              <div className="text-xl md:text-2xl font-bold text-gray-900">
                Instant
              </div>
              <div className="text-xs md:text-sm text-gray-600">
                Processing Time
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl md:rounded-2xl shadow-lg border border-gray-100 p-4 md:p-6">
          <div className="flex items-center space-x-3 md:space-x-4">
            <div className="w-10 h-10 md:w-12 md:h-12 bg-green-100 rounded-lg md:rounded-xl flex items-center justify-center">
              <CheckCircle className="w-5 h-5 md:w-6 md:h-6 text-green-600" />
            </div>
            <div>
              <div className="text-xl md:text-2xl font-bold text-gray-900">
                100%
              </div>
              <div className="text-xs md:text-sm text-gray-600">
                Success Rate
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl md:rounded-2xl shadow-lg border border-gray-100 p-4 md:p-6">
          <div className="flex items-center space-x-3 md:space-x-4">
            <div className="w-10 h-10 md:w-12 md:h-12 bg-sky-100 rounded-lg md:rounded-xl flex items-center justify-center">
              <Award className="w-5 h-5 md:w-6 md:h-6 text-sky-600" />
            </div>
            <div>
              <div className="text-xl md:text-2xl font-bold text-gray-900">
                {rewardlevels.length}
              </div>
              <div className="text-xs md:text-sm text-gray-600">
                Available levels
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Success Modal (Reward Claimed) */}
      {rewardModalOpen && rewardModalLevel && (
        <div className="fixed inset-0 z-50 flex items-center justify-center">
          {/* Backdrop */}
          <div
            className={`absolute inset-0 bg-black/60 backdrop-blur-sm transition-opacity duration-300 ${
              rewardModalAnimateIn ? "opacity-100" : "opacity-0"
            }`}
            onClick={closeRewardModal}
          />

          {/* Modal Content */}
          <div className="relative z-10 w-full max-w-md">
            <div
              className={`p-1 rounded-2xl bg-gradient-to-br from-blue-600 via-purple-600 to-pink-500 shadow-2xl transition-all duration-300 ease-out ${
                rewardModalAnimateIn
                  ? "opacity-100 scale-100 translate-y-0"
                  : "opacity-0 scale-95 translate-y-2"
              }`}
            >
              <div className="rounded-2xl bg-white">
                <div className="p-8 text-center">
                  <div className="flex justify-center items-center mb-4">
                    <div className="w-20 h-20 rounded-full bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center shadow-lg animate-pulse">
                      <CheckCircle className="w-12 h-12 text-white" />
                    </div>
                  </div>
                  <h3 className="text-2xl font-extrabold text-gray-900 mb-2">
                    Reward Claimed!
                  </h3>
                  <p className="text-gray-600 mb-6">
                    You successfully claimed the reward for
                    <span className="font-semibold text-gray-900"> Level </span>
                    <span className="font-semibold text-gray-900">
                      {/* Find index by amount for display */}
                      {Math.max(
                        1,
                        (rewardlevels.findIndex((l) => l.amount === rewardModalLevel.amount) + 1) || 1
                      )}
                    </span>
                    . Keep going!
                  </p>
                  <button
                    onClick={closeRewardModal}
                    className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-blue-600 text-white font-semibold shadow hover:bg-blue-700 active:scale-[0.98] transition-all"
                  >
                    Continue
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Rewards;
