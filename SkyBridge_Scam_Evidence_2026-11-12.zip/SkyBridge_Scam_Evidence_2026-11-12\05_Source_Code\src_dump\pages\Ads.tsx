import React, { useState, useRef, useEffect, useCallback } from "react";
import {
  Play,
  Pause,
  Volume2,
  VolumeX,
  CheckCircle,
  Eye,
  Clock,
  Star,
  Gift,
} from "lucide-react";
import { useAuth as useAuthContext } from "../contexts/AuthContext";
import { apiClient } from "../services/apiClient";
import { API_CONFIG, API_ENDPOINTS } from "../config/api";

interface YouTubePlayer {
  playVideo: () => void;
  pauseVideo: () => void;
  mute: () => void;
  unMute: () => void;
  getCurrentTime: () => number;
  getDuration: () => number;
  getPlayerState: () => number;
  destroy: () => void;
}

declare global {
  interface Window {
    YT?: {
      Player: new (
        elementId: string,
        options: {
          videoId: string;
          width?: string | number;
          height?: string | number;
          playerVars?: Record<string, string | number>;
          events?: {
            onReady?: (event: { target: YouTubePlayer }) => void;
            onStateChange?: (event: { data: number; target: YouTubePlayer }) => void;
          };
        }
      ) => YouTubePlayer;
      PlayerState: {
        ENDED: 0;
        PLAYING: 1;
        PAUSED: 2;
      };
    };
    onYouTubeIframeAPIReady?: () => void;
  }
}

const YT_PLAYER_STATE = { ENDED: 0, PLAYING: 1, PAUSED: 2 } as const;

interface VideoAd {
  id?: number;
  title: string;
  description: string;
  thumbnail?: string;
  videoUrl: string;
  duration: number;
  views?: number;
  reward?: number;
  category?: string;
  isWatched?: boolean;
}

// What screen the page shows. Driven entirely by the server's availability
// response — never by localStorage or the device clock.
type ViewState = "loading" | "video" | "watched" | "no-ad";

const WATCHED_MESSAGE =
  "You've already watched today's ad. Come back after midnight for the next one.";

const Ads: React.FC = () => {
  const { token } = useAuthContext();
  const [currentVideo, setCurrentVideo] = useState<VideoAd | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [watchProgress, setWatchProgress] = useState(0);
  const [isVideoCompleted, setIsVideoCompleted] = useState(false);
  const [totalEarnings, setTotalEarnings] = useState(0);
  const [todayEarnings, setTodayEarnings] = useState(0);
  const [viewState, setViewState] = useState<ViewState>("loading");
  const [statusMessage, setStatusMessage] = useState<string>("");
  const videoRef = useRef<HTMLVideoElement>(null);
  const youtubePlayerRef = useRef<YouTubePlayer | null>(null);
  const [isYouTube, setIsYouTube] = useState(false);
  const [watchPosted, setWatchPosted] = useState(false);
  const [lastEarning, setLastEarning] = useState<number | null>(null);

  // Server-driven countdown: store the absolute reset instant (epoch ms, parsed
  // from the server's ISO timestamp which carries the app-timezone offset) and
  // the difference between the server clock and this device's clock. Remaining
  // time = reset - (deviceNow + skew), so a wrong device clock can never produce
  // a stuck or wrong timer.
  const [msRemaining, setMsRemaining] = useState<number>(0);
  const nextResetMsRef = useRef<number | null>(null);
  const serverSkewRef = useRef<number>(0); // serverNow - deviceNow

  // Guards against duplicate actions.
  const watchReportedRef = useRef(false);
  const fetchingAdRef = useRef(false);
  const hasFetchedOnceRef = useRef(false); // avoids StrictMode double fetch
  const resetFiredRef = useRef(false); // refetch only once per reset boundary
  const ytProgressIntervalRef = useRef<number | null>(null);
  const ytElapsedRef = useRef(0);
  const ytDurationRef = useRef(0);

  const isYouTubeUrl = (url: string) => /youtube\.com|youtu\.be/.test(url);

  const extractYouTubeId = (url: string) => {
    try {
      const ytShort = url.match(/youtu\.be\/([^?&#]+)/);
      if (ytShort && ytShort[1]) return ytShort[1];
      const urlObj = new URL(url);
      if (urlObj.hostname.includes("youtube.com")) {
        const v = urlObj.searchParams.get("v");
        if (v) return v;
        const parts = urlObj.pathname.split("/").filter(Boolean);
        const embedIndex = parts.indexOf("embed");
        if (embedIndex >= 0 && parts[embedIndex + 1])
          return parts[embedIndex + 1];
      }
    } catch {
      return "";
    }
    return "";
  };

  const parseDurationToSeconds = (value: unknown): number => {
    if (typeof value === "number" && !isNaN(value)) return value;
    if (typeof value === "string") {
      const parts = value.split(":").map((p) => Number(p));
      if (parts.some((n) => isNaN(n))) return 0;
      if (parts.length === 3) {
        const [h, m, s] = parts;
        return h * 3600 + m * 60 + s;
      }
      if (parts.length === 2) {
        const [m, s] = parts;
        return m * 60 + s;
      }
      if (parts.length === 1) return parts[0];
    }
    return 0;
  };

  // Anchor the countdown to the server's view of time.
  const applyResetWindow = useCallback(
    (nextAvailableAt?: string | null, serverTime?: string | null) => {
      if (serverTime) {
        const serverMs = new Date(serverTime).getTime();
        if (!Number.isNaN(serverMs)) {
          serverSkewRef.current = serverMs - Date.now();
        }
      }
      if (nextAvailableAt) {
        const resetMs = new Date(nextAvailableAt).getTime();
        if (!Number.isNaN(resetMs)) {
          nextResetMsRef.current = resetMs;
          resetFiredRef.current = false; // a fresh boundary to count down to
          setMsRemaining(
            Math.max(0, resetMs - (Date.now() + serverSkewRef.current))
          );
        }
      }
    },
    []
  );

  // Keep apiClient auth in sync with the context token.
  useEffect(() => {
    if (token) {
      apiClient.setAuthToken(token);
    }
  }, [token]);

  // Refresh the header counters from the authoritative summary endpoint.
  const fetchEarningsSummary = useCallback(async () => {
    if (!token) return;
    try {
      apiClient.refreshAuthToken();
      const res = await apiClient.get<any>(
        API_ENDPOINTS.USER.AD_EARNINGS_SUMMARY
      );
      const d = (res?.data as any) || {};
      const total = parseFloat(d.total_ad_earning ?? d.total_earnings ?? "0");
      const today = parseFloat(d.today_ad_earning ?? d.today_earnings ?? "0");
      if (!Number.isNaN(total)) setTotalEarnings(total);
      if (!Number.isNaN(today)) setTodayEarnings(today);
    } catch (err) {
      console.error("Failed to fetch earnings summary:", err);
    }
  }, [token]);

  // Fetch today's authoritative ad state from the API.
  const fetchTodayAd = useCallback(async () => {
    if (fetchingAdRef.current) return;
    fetchingAdRef.current = true;
    try {
      watchReportedRef.current = false;
      if (ytProgressIntervalRef.current) {
        window.clearInterval(ytProgressIntervalRef.current);
        ytProgressIntervalRef.current = null;
      }
      ytElapsedRef.current = 0;
      ytDurationRef.current = 0;

      setViewState("loading");
      setCurrentVideo(null);
      setIsVideoCompleted(false);
      setWatchPosted(false);

      if (!token) {
        setStatusMessage("Please log in to watch ads.");
        setViewState("no-ad");
        return;
      }

      apiClient.refreshAuthToken();
      const res = await apiClient.get<any>(API_ENDPOINTS.AD.TODAY);
      const data = (res?.data as any) || {};

      // Sync the countdown to the server clock + next reset boundary.
      applyResetWindow(data.next_available_at, data.server_time);

      const ad = data.ad;

      if (data.already_watched_today) {
        setStatusMessage(WATCHED_MESSAGE);
        setViewState("watched");
        return;
      }

      if (!data.can_watch_today || !ad || typeof ad !== "object") {
        setStatusMessage("No ad available right now. Check back later!");
        setViewState("no-ad");
        return;
      }

      const videoUrlFromApi = ad.video_url || ad.youtube_link || "";
      const durationFromApi = parseDurationToSeconds(
        ad.duration ?? ad.video_duration ?? 0
      );

      if (!videoUrlFromApi) {
        setStatusMessage("No ad available right now. Check back later!");
        setViewState("no-ad");
        return;
      }

      setCurrentVideo({
        id: ad.id,
        title: ad.title,
        description: ad.description,
        thumbnail: ad.thumbnail,
        videoUrl: videoUrlFromApi,
        duration: durationFromApi,
        views: Number(ad.views ?? 0),
        reward: Number(ad.reward ?? 0),
        category: ad.category ?? "Ad",
        isWatched: false,
      });
      setIsYouTube(isYouTubeUrl(videoUrlFromApi));
      setWatchProgress(0);
      setIsPlaying(false);
      setViewState("video");
    } catch (err: any) {
      console.error("Error fetching ad:", err);
      const msg =
        (typeof err?.data?.message === "string" ? err.data.message : null) ||
        err?.message ||
        "Failed to load today's ad";
      setStatusMessage(typeof msg === "string" ? msg : "Failed to load today's ad");
      setViewState("no-ad");
    } finally {
      fetchingAdRef.current = false;
    }
  }, [token, applyResetWindow]);

  // Report watch completion to the API and switch to the countdown view.
  const reportWatchCompletion = useCallback(
    async (adId?: number) => {
      if (watchReportedRef.current || watchPosted || !adId || !token) return;
      watchReportedRef.current = true;
      setWatchPosted(true);

      try {
        apiClient.refreshAuthToken();
        const res = await apiClient.post<any>(API_ENDPOINTS.AD.WATCH, {
          ad_id: adId,
        });
        const data = (res?.data as any) || {};

        const earned = parseFloat(data.earning ?? "0");
        if (!Number.isNaN(earned) && earned > 0) setLastEarning(earned);

        applyResetWindow(data.next_available_at, null);
        setStatusMessage(WATCHED_MESSAGE);
        setViewState("watched");
        fetchEarningsSummary();
      } catch (err: any) {
        // A 400 here means the watch already counted (e.g. a concurrent device).
        // Re-sync to the server's reset window; otherwise reload authoritative state.
        const meta = err?.data?.errors;
        if (meta?.next_available_at) {
          applyResetWindow(meta.next_available_at, null);
          setStatusMessage(WATCHED_MESSAGE);
          setViewState("watched");
          fetchEarningsSummary();
        } else {
          console.error("Failed to report watch completion:", err);
          fetchTodayAd();
        }
      }
    },
    [watchPosted, token, applyResetWindow, fetchEarningsSummary, fetchTodayAd]
  );

  // Initial load — wait for the token, then fetch once.
  useEffect(() => {
    if (!token || hasFetchedOnceRef.current) return;
    hasFetchedOnceRef.current = true;
    fetchTodayAd();
    fetchEarningsSummary();
  }, [token, fetchTodayAd, fetchEarningsSummary]);

  // HTML5 video event handlers.
  useEffect(() => {
    const video = videoRef.current;
    if (!video || !currentVideo || isYouTube) return;

    const updateTime = () => {
      const progress =
        (video.currentTime / (video.duration || currentVideo.duration || 1)) *
        100;
      setWatchProgress(progress);
    };

    const handleEnded = () => {
      setWatchProgress(100);
      if (!isVideoCompleted) {
        setIsVideoCompleted(true);
        reportWatchCompletion(currentVideo.id);
      }
    };

    video.addEventListener("timeupdate", updateTime);
    video.addEventListener("ended", handleEnded);

    return () => {
      video.removeEventListener("timeupdate", updateTime);
      video.removeEventListener("ended", handleEnded);
    };
  }, [currentVideo, isVideoCompleted, isYouTube, reportWatchCompletion]);

  // YouTube IFrame Player API: detect native play button + track real progress.
  useEffect(() => {
    if (!currentVideo || !isYouTube || viewState !== "video") return;

    const videoId = extractYouTubeId(currentVideo.videoUrl);
    if (!videoId) return;

    let player: YouTubePlayer | null = null;
    let destroyed = false;

    const stopProgressTick = () => {
      if (ytProgressIntervalRef.current) {
        window.clearInterval(ytProgressIntervalRef.current);
        ytProgressIntervalRef.current = null;
      }
    };

    const handleVideoEnded = () => {
      stopProgressTick();
      setIsPlaying(false);
      setWatchProgress(100);
      if (!watchReportedRef.current) {
        setIsVideoCompleted(true);
        reportWatchCompletion(currentVideo.id);
      }
    };

    const startProgressTick = () => {
      stopProgressTick();
      ytProgressIntervalRef.current = window.setInterval(() => {
        if (!player) return;
        try {
          const current = player.getCurrentTime();
          const duration =
            player.getDuration() ||
            ytDurationRef.current ||
            currentVideo.duration ||
            0;
          if (duration > 0) {
            ytDurationRef.current = duration;
            ytElapsedRef.current = current;
            const progress = Math.min((current / duration) * 100, 100);
            setWatchProgress(progress);
            if (progress >= 100) handleVideoEnded();
          }
        } catch {
          // player may be torn down mid-tick
        }
      }, 500);
    };

    const onStateChange = (event: { data: number }) => {
      if (event.data === YT_PLAYER_STATE.PLAYING) {
        setIsPlaying(true);
        startProgressTick();
      } else if (event.data === YT_PLAYER_STATE.PAUSED) {
        setIsPlaying(false);
        stopProgressTick();
      } else if (event.data === YT_PLAYER_STATE.ENDED) {
        handleVideoEnded();
      }
    };

    const createPlayer = () => {
      if (destroyed || !window.YT?.Player) return;
      player = new window.YT.Player("yt-ad-player", {
        videoId,
        width: "100%",
        height: "400",
        playerVars: {
          modestbranding: 1,
          rel: 0,
          origin: window.location.origin,
        },
        events: {
          onStateChange,
        },
      });
      youtubePlayerRef.current = player;
    };

    const loadApiAndCreate = () => {
      if (window.YT?.Player) {
        createPlayer();
        return;
      }

      const prevReady = window.onYouTubeIframeAPIReady;
      window.onYouTubeIframeAPIReady = () => {
        prevReady?.();
        createPlayer();
      };

      if (!document.getElementById("youtube-iframe-api")) {
        const script = document.createElement("script");
        script.id = "youtube-iframe-api";
        script.src = "https://www.youtube.com/iframe_api";
        document.head.appendChild(script);
      }
    };

    loadApiAndCreate();

    return () => {
      destroyed = true;
      stopProgressTick();
      try {
        player?.destroy();
      } catch {
        // ignore teardown errors
      }
      youtubePlayerRef.current = null;
    };
  }, [currentVideo, isYouTube, viewState, reportWatchCompletion]);

  // Server-driven countdown to the next reset. Refetches exactly once when the
  // boundary is crossed so the next day's ad loads without a manual reload.
  useEffect(() => {
    const tick = () => {
      const resetMs = nextResetMsRef.current;
      if (resetMs == null) return;
      const remaining = Math.max(
        0,
        resetMs - (Date.now() + serverSkewRef.current)
      );
      setMsRemaining(remaining);

      if (remaining <= 0 && !resetFiredRef.current) {
        resetFiredRef.current = true;
        fetchTodayAd();
        fetchEarningsSummary();
      }
    };
    const id = window.setInterval(tick, 1000);
    tick();
    return () => window.clearInterval(id);
  }, [fetchTodayAd, fetchEarningsSummary]);

  // Pause on tab hide.
  useEffect(() => {
    const handleVisibility = () => {
      if (document.hidden) {
        if (isYouTube) {
          youtubePlayerRef.current?.pauseVideo();
        } else {
          videoRef.current?.pause();
        }
        setIsPlaying(false);
      }
    };

    document.addEventListener("visibilitychange", handleVisibility);
    return () =>
      document.removeEventListener("visibilitychange", handleVisibility);
  }, [isYouTube]);

  // Best-effort report on page unload if the video finished but the call didn't land.
  useEffect(() => {
    const handlePageHide = () => {
      if (isVideoCompleted && currentVideo?.id && !watchPosted && token) {
        fetch(`${API_CONFIG.BASE_URL}${API_ENDPOINTS.AD.WATCH}`, {
          method: "POST",
          headers: {
            Authorization: `Bearer ${token}`,
            "Content-Type": "application/json",
          },
          body: JSON.stringify({ ad_id: currentVideo.id }),
          keepalive: true,
        }).catch((err) => console.error("Unload report failed:", err));
      }
    };

    window.addEventListener("pagehide", handlePageHide);
    window.addEventListener("beforeunload", handlePageHide);

    return () => {
      window.removeEventListener("pagehide", handlePageHide);
      window.removeEventListener("beforeunload", handlePageHide);
    };
  }, [isVideoCompleted, currentVideo?.id, watchPosted, token]);

  const handlePlayPause = () => {
    if (isYouTube) {
      const player = youtubePlayerRef.current;
      if (!player) return;
      if (player.getPlayerState() === YT_PLAYER_STATE.PLAYING) {
        player.pauseVideo();
      } else {
        player.playVideo();
      }
    } else if (videoRef.current) {
      if (isPlaying) videoRef.current.pause();
      else videoRef.current.play();
      setIsPlaying((p) => !p);
    }
  };

  const handleMuteToggle = () => {
    if (isYouTube) {
      const player = youtubePlayerRef.current;
      if (!player) return;
      if (isMuted) player.unMute();
      else player.mute();
      setIsMuted((m) => !m);
    } else if (videoRef.current) {
      videoRef.current.muted = !isMuted;
      setIsMuted((m) => !m);
    }
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, "0")}`;
  };

  const formatMs = (ms: number) => {
    const totalSec = Math.floor(ms / 1000);
    const h = Math.floor(totalSec / 3600)
      .toString()
      .padStart(2, "0");
    const m = Math.floor((totalSec % 3600) / 60)
      .toString()
      .padStart(2, "0");
    const s = Math.floor(totalSec % 60)
      .toString()
      .padStart(2, "0");
    return `${h}:${m}:${s}`;
  };

  const Header = () => (
    <div className="bg-white shadow-sm border-b">
      <div className="max-w-6xl mx-auto px-6 py-6">
        <div className="flex items-center justify-between flex-col md:flex-row gap-4">
          <div>
            <h1 className="text-3xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
              Ads Earning Center
            </h1>
            <p className="text-gray-600 mt-1">
              Watch one ad a day and earn instant rewards
            </p>
          </div>
          <div className="flex items-center space-x-6">
            <div className="text-center">
              <div className="text-2xl font-bold text-green-600">
                ${totalEarnings.toFixed(2)}
              </div>
              <div className="text-sm text-gray-500">Total Earned</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-blue-600">
                ${todayEarnings.toFixed(2)}
              </div>
              <div className="text-sm text-gray-500">Today's Earnings</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  if (viewState === "loading") {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-gradient-to-br from-blue-50 via-white to-purple-50 px-4">
        <div
          className="h-10 w-10 border-2 border-sky-500 border-t-transparent rounded-full animate-spin mb-3"
          aria-hidden
        />
        <p className="text-sm text-gray-600">Loading ad…</p>
      </div>
    );
  }

  // Already watched today → show the server-driven countdown to the next ad.
  if (viewState === "watched") {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50">
        <Header />
        <div className="max-w-6xl mx-auto px-6 py-8">
          <div className="bg-white rounded-2xl shadow-lg border border-gray-100 p-8 text-center">
            <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <CheckCircle className="w-10 h-10 text-green-600" />
            </div>
            <h2 className="text-2xl font-bold text-gray-900 mb-2">
              Today's ad is done!
            </h2>
            <p className="text-gray-600 mb-6 max-w-md mx-auto">{statusMessage}</p>
            {lastEarning != null && lastEarning > 0 && (
              <p className="text-green-600 font-semibold mb-6">
                You earned ${lastEarning.toFixed(3)} from this ad.
              </p>
            )}
            <div className="inline-flex items-center gap-3 bg-blue-50 border border-blue-100 rounded-xl px-6 py-4">
              <Clock className="w-6 h-6 text-blue-600" />
              <div className="text-left">
                <p className="text-sm text-gray-600">Next ad unlocks in</p>
                <p className="text-2xl font-bold text-blue-700 tabular-nums">
                  {formatMs(msRemaining)}
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // No ad available right now.
  if (viewState === "no-ad" || !currentVideo) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50">
        <Header />
        <div className="max-w-6xl mx-auto px-6 py-8">
          <div className="bg-amber-50 border-l-4 border-amber-500 p-6 rounded-lg">
            <h2 className="text-xl font-bold text-amber-800 mb-2">
              No ad available right now
            </h2>
            <p className="text-amber-700">
              {statusMessage || "Check back later!"}
            </p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50">
      <Header />

      <div className="max-w-6xl mx-auto px-6 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            <div className="bg-white rounded-2xl shadow-xl border border-gray-100 overflow-hidden">
              <div className="relative">
                {isYouTube ? (
                  <div
                    id="yt-ad-player"
                    className="w-full h-[400px] bg-black"
                  />
                ) : (
                  <video
                    ref={videoRef}
                    className="w-full h-[400px] bg-black object-cover"
                    poster={currentVideo.thumbnail}
                    onPlay={() => setIsPlaying(true)}
                    onPause={() => setIsPlaying(false)}
                  >
                    <source src={currentVideo.videoUrl} type="video/mp4" />
                    Your browser does not support the video tag.
                  </video>
                )}

                <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent pointer-events-none">
                  <div className="absolute bottom-0 left-0 right-0 p-6 pointer-events-auto">
                    <div className="mb-4">
                      <div className="w-full bg-white/20 rounded-full h-2">
                        <div
                          className="bg-gradient-to-r from-blue-500 to-purple-500 h-2 rounded-full transition-all duration-300"
                          style={{ width: `${watchProgress}%` }}
                        />
                      </div>
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-4">
                        <button
                          onClick={handlePlayPause}
                          className="bg-white/20 hover:bg-white/30 backdrop-blur-sm rounded-full p-3 text-white transition-all"
                        >
                          {isPlaying ? (
                            <Pause className="w-6 h-6" />
                          ) : (
                            <Play className="w-6 h-6" />
                          )}
                        </button>
                        <button
                          onClick={handleMuteToggle}
                          className="bg-white/20 hover:bg-white/30 backdrop-blur-sm rounded-full p-2 text-white transition-all"
                        >
                          {isMuted ? (
                            <VolumeX className="w-5 h-5" />
                          ) : (
                            <Volume2 className="w-5 h-5" />
                          )}
                        </button>
                      </div>
                      <div className="flex items-center space-x-2 text-white">
                        <Star className="w-4 h-4" />
                        <span className="text-sm">
                          {(currentVideo.views ?? 0).toLocaleString()} views
                        </span>
                      </div>
                    </div>
                  </div>
                </div>

                {isVideoCompleted && (
                  <div className="absolute inset-0 bg-black/80 flex items-center justify-center">
                    <div className="text-center text-white p-8">
                      <div className="w-20 h-20 bg-green-500 rounded-full flex items-center justify-center mx-auto mb-4 animate-pulse">
                        <CheckCircle className="w-10 h-10" />
                      </div>
                      <h3 className="text-2xl font-bold mb-2">
                        Ad completed successfully!
                      </h3>
                    </div>
                  </div>
                )}
              </div>

              <div className="p-6">
                <div className="flex items-start justify-between mb-4 flex-col md:flex-row gap-4">
                  <div className="flex-1">
                    <h2 className="text-xl font-bold text-gray-900 mb-2">
                      {currentVideo.title}
                    </h2>
                    <p className="text-gray-600 text-sm leading-relaxed">
                      {currentVideo.description}
                    </p>
                  </div>
                </div>
                <div className="flex items-center justify-between text-sm text-gray-500 flex-wrap gap-4">
                  <div className="flex items-center space-x-4">
                    <span className="flex items-center">
                      <Eye className="w-4 h-4 mr-1" />
                      {(currentVideo.views ?? 0).toLocaleString()}
                    </span>
                    <span className="flex items-center">
                      <Clock className="w-4 h-4 mr-1" />
                      {formatTime(currentVideo.duration || 0)}
                    </span>
                    <span className="bg-blue-100 text-blue-800 px-2 py-1 rounded-full">
                      {currentVideo.category ?? "Ad"}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="lg:col-span-1">
            <div className="space-y-6">
              <div className="bg-white rounded-2xl shadow-lg border border-gray-100 p-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
                  <Gift className="w-5 h-5 mr-2 text-purple-600" /> Earning
                  Progress
                </h3>
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-gray-600">Watch Progress</span>
                    <span className="font-semibold text-blue-600">
                      {Math.round(watchProgress)}%
                    </span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-3">
                    <div
                      className="bg-gradient-to-r from-blue-500 to-purple-500 h-3 rounded-full transition-all duration-300"
                      style={{ width: `${watchProgress}%` }}
                    />
                  </div>
                  <div className="text-center">
                    {watchProgress >= 100 ? (
                      <div className="text-green-600 font-semibold flex items-center justify-center">
                        <CheckCircle className="w-4 h-4 mr-1" /> Completed!
                      </div>
                    ) : (
                      <div className="text-gray-500 text-sm">
                        Watch {Math.max(0, 100 - Math.round(watchProgress))}%
                        more to earn
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Ads;
