import React from "react";
import {
  BrowserRouter as Router,
  Routes,
  Route,
  Navigate,
  Outlet,
  useLocation,
} from "react-router-dom";
import { AuthProvider, useAuth } from "./contexts/AuthContext";
import { CurrencyProvider } from "./contexts/CurrencyContext";
import Layout from "./components/Layout";
import Header from "./components/Header";
import Login from "./pages/Login";
import Register from "./pages/Register";
import AccountPending from "./pages/AccountPending";
import Dashboard from "./pages/Dashboard";
import Leaderboard from "./pages/Leaderboard";
import ReferralLeaderboard from "./pages/ReferralLeaderboard";
import Withdraw from "./pages/Withdraw";
import Rewards from "./pages/Rewards";
import Bonus from "./pages/Bonus";
import Ads from "./pages/Ads";
import About from "./pages/About";
import Home from "./pages/Home";
import AboutUs from "./pages/AboutUs";
import SkyBridgeCommunity from "./pages/SkyBridgeCommunity";
import AffiliateCourse from "./pages/AffiliateCourse";
import CoursePlayer from "./pages/CoursePlayer";
import MyTeam from "./pages/MyTeam";
import ProfileInfo from "./pages/ProfileInfo";
import ChangeAccountDetails from "./pages/ChangeAccountDetails";
import Notifications from "./pages/Notifications";
import Transaction from "./pages/Transaction";
import { SidebarProvider } from "./contexts/SideBarContect";
import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import ECommerceStore from "./pages/ECommerceStore";
import ProductDetails from "./pages/ProductDetails";
import Plans from "./pages/Plans";
import UpgradePlan from "./pages/UpgradePlan";
import BuyPin from "./pages/BuyPin";
import MyPins from "./pages/MyPins";
import PinRequests from "./pages/PinRequests";
import CreateAccountWithPin from "./pages/CreateAccountWithPin";
import ForgotPassword from "./pages/ForgotPassword";
import Competition from "./pages/Competition";

const GlobalLayout: React.FC = () => {
  const location = useLocation();

  // Routes where header should be hidden
  // (keep it visible on home `/` so the logo + Get Started button show)
  const hideHeaderRoutes = ["/login", "/register", "/account-pending"];

  // Check if current route should hide header or not
  const shouldHideHeader = hideHeaderRoutes.some(
    (route) =>
      location.pathname === route || location.pathname.startsWith(route + "/")
  );

  return (
    <div className="min-h-screen bg-gray-50">
      {!shouldHideHeader && <Header />}
      <div className={shouldHideHeader ? "" : "pt-24 sm:pt-28"}>
        <Outlet />
      </div>
    </div>
  );
};

const ProtectedRoute: React.FC<{ children: React.ReactNode }> = ({
  children,
}) => {
  const { isAuthenticated } = useAuth();
  return isAuthenticated ? <>{children}</> : <Navigate to="/login" />;
};

const PublicRoute: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { isAuthenticated } = useAuth();
  return !isAuthenticated ? <>{children}</> : <Navigate to="/dashboard" />;
};

function App() {
  return (
    <CurrencyProvider>
      <AuthProvider>
        <SidebarProvider>
          <Router>
            <Routes>
              <Route path="/" element={<GlobalLayout />}>
                {/* Public routes */}
                <Route index element={<Home />} />
                <Route path="about" element={<About />} />
                <Route
                  path="login"
                  element={
                    <PublicRoute>
                      <Login />
                    </PublicRoute>
                  }
                />
                <Route
                  path="register"
                  element={
                    <PublicRoute>
                      <Register />
                    </PublicRoute>
                  }
                />
                <Route path="account-pending" element={<AccountPending />} />
                <Route
                  path="forgot-password"
                  element={
                    <PublicRoute>
                      <ForgotPassword />
                    </PublicRoute>
                  }
                />

                {/* Protected routes with sidebar layout */}
                <Route
                  path="about-us"
                  element={
                    <ProtectedRoute>
                      <Layout />
                    </ProtectedRoute>
                  }
                >
                  <Route index element={<AboutUs />} />
                </Route>
                <Route
                  path="dashboard"
                  element={
                    <ProtectedRoute>
                      <Layout />
                    </ProtectedRoute>
                  }
                >
                  <Route index element={<Dashboard />} />
                </Route>
                <Route
                  path="leaderboard"
                  element={
                    <ProtectedRoute>
                      <Layout />
                    </ProtectedRoute>
                  }
                >
                  <Route index element={<Leaderboard />} />
                </Route>
                <Route
                  path="referral-leaderboard"
                  element={
                    <ProtectedRoute>
                      <Layout />
                    </ProtectedRoute>
                  }
                >
                  <Route index element={<ReferralLeaderboard />} />
                </Route>
                <Route
                  path="affiliate-leaderboard"
                  element={
                    <ProtectedRoute>
                      <Layout />
                    </ProtectedRoute>
                  }
                >
                  <Route index element={<ReferralLeaderboard />} />
                </Route>
                <Route
                  path="withdraw"
                  element={
                    <ProtectedRoute>
                      <Layout />
                    </ProtectedRoute>
                  }
                >
                  <Route index element={<Withdraw />} />
                </Route>
                <Route
                  path="ecommerce-store"
                  element={
                    <ProtectedRoute>
                      <Layout />
                    </ProtectedRoute>
                  }
                >
                  <Route index element={<ECommerceStore />} />
                  <Route path=":id" element={<ProductDetails />} />
                </Route>
                <Route
                  path="ads-earning"
                  element={
                    <ProtectedRoute>
                      <Layout />
                    </ProtectedRoute>
                  }
                >
                  <Route index element={<Ads />} />
                </Route>
                <Route
                  path="rewards"
                  element={
                    <ProtectedRoute>
                      <Layout />
                    </ProtectedRoute>
                  }
                >
                  <Route index element={<Rewards />} />
                </Route>
                <Route
                  path="competition"
                  element={
                    <ProtectedRoute>
                      <Layout />
                    </ProtectedRoute>
                  }
                >
                  <Route index element={<Competition />} />
                </Route>
                <Route
                  path="bonus"
                  element={
                    <ProtectedRoute>
                      <Layout />
                    </ProtectedRoute>
                  }
                >
                  <Route index element={<Bonus />} />
                </Route>
                <Route
                  path="sky-bridge-community"
                  element={
                    <ProtectedRoute>
                      <Layout />
                    </ProtectedRoute>
                  }
                >
                  <Route index element={<SkyBridgeCommunity />} />
                </Route>
                <Route
                  path="affiliate-course"
                  element={
                    <ProtectedRoute>
                      <Layout />
                    </ProtectedRoute>
                  }
                >
                  <Route index element={<AffiliateCourse />} />
                  <Route path=":id" element={<CoursePlayer />} />
                </Route>
                <Route
                  path="my-team"
                  element={
                    <ProtectedRoute>
                      <Layout />
                    </ProtectedRoute>
                  }
                >
                  <Route index element={<MyTeam />} />
                </Route>
                <Route
                  path="profile-info"
                  element={
                    <ProtectedRoute>
                      <Layout />
                    </ProtectedRoute>
                  }
                >
                  <Route index element={<ProfileInfo />} />
                </Route>
                <Route
                  path="change-account-details"
                  element={
                    <ProtectedRoute>
                      <Layout />
                    </ProtectedRoute>
                  }
                >
                  <Route index element={<ChangeAccountDetails />} />
                </Route>
                <Route
                  path="notifications"
                  element={
                    <ProtectedRoute>
                      <Layout />
                    </ProtectedRoute>
                  }
                >
                  <Route index element={<Notifications />} />
                </Route>
                <Route
                  path="transactions"
                  element={
                    <ProtectedRoute>
                      <Layout />
                    </ProtectedRoute>
                  }
                >
                  <Route index element={<Transaction />} />
                </Route>
                <Route
                  path="plans"
                  element={
                    <ProtectedRoute>
                      <Layout />
                    </ProtectedRoute>
                  }
                >
                  <Route index element={<Plans />} />
                </Route>
                <Route
                  path="upgrade-plan"
                  element={
                    <ProtectedRoute>
                      <Layout />
                    </ProtectedRoute>
                  }
                >
                  <Route index element={<UpgradePlan />} />
                </Route>
                <Route
                  path="buy-pin"
                  element={
                    <ProtectedRoute>
                      <Layout />
                    </ProtectedRoute>
                  }
                >
                  <Route index element={<BuyPin />} />
                </Route>
                <Route
                  path="my-pins"
                  element={
                    <ProtectedRoute>
                      <Layout />
                    </ProtectedRoute>
                  }
                >
                  <Route index element={<MyPins />} />
                </Route>
                <Route
                  path="pin-requests"
                  element={
                    <ProtectedRoute>
                      <Layout />
                    </ProtectedRoute>
                  }
                >
                  <Route index element={<PinRequests />} />
                </Route>
                <Route
                  path="pin/create-account"
                  element={
                    <ProtectedRoute>
                      <Layout />
                    </ProtectedRoute>
                  }
                >
                  <Route index element={<CreateAccountWithPin />} />
                </Route>
                {/* Legacy routes for backward compatibility */}
                <Route
                  path="products"
                  element={
                    <ProtectedRoute>
                      <Layout />
                    </ProtectedRoute>
                  }
                >
                  <Route index element={<ECommerceStore />} />
                </Route>
                <Route
                  path="ads"
                  element={
                    <ProtectedRoute>
                      <Layout />
                    </ProtectedRoute>
                  }
                >
                  <Route index element={<Ads />} />
                </Route>
              </Route>
            </Routes>
          </Router>
        </SidebarProvider>
      </AuthProvider>
      <ToastContainer
        position="top-right"
        autoClose={5000}
        hideProgressBar={false}
        newestOnTop={false}
        closeOnClick
        rtl={false}
        pauseOnFocusLoss
        draggable
        pauseOnHover
        theme="light"
      />
    </CurrencyProvider>
  );
}

export default App;
