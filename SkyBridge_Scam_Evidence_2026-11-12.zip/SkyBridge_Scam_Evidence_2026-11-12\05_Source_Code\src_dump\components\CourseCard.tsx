import React, { useState } from "react";
import {
  BookOpen,
  Clock,
  ArrowRight,
} from "lucide-react";
import type { Course } from "../types/course";

interface CourseCardProps {
  course: Course;
  onOpen: (course: Course) => void;
}

const CourseCard: React.FC<CourseCardProps> = ({ course, onOpen }) => {
  const [expanded, setExpanded] = useState(false);
  const planLocked = !!course.is_plan_locked;
  const locked =
    planLocked || (course.type === "premium" && !course.unlocked);
  const needsToggle =
    (course.description ? course.description.length > 120 : false) ||
    (course.name ? course.name.length > 40 : false);

  const ctaLabel = planLocked
    ? "Upgrade Plan"
    : locked
      ? "Unlock Now"
      : course.content_type === "link"
        ? "Open Link"
        : "Start Now";

  return (
    <div className="group bg-white rounded-2xl shadow-md hover:shadow-xl border border-sky-100 hover:border-sky-300 transition-all duration-300 overflow-hidden flex flex-col">
      <button
        type="button"
        onClick={() => onOpen(course)}
        className="block w-full text-left flex-1 flex flex-col"
      >
        {/* Thumbnail */}
        <div className="relative aspect-[16/10] w-full bg-gradient-to-br from-sky-100 via-indigo-100 to-purple-100 overflow-hidden">
          {course.thumbnail ? (
            <img
              src={course.thumbnail}
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
              alt={course.name}
            />
          ) : (
            <div className="w-full h-full flex items-center justify-center">
              <BookOpen className="w-16 h-16 text-sky-400 opacity-50" />
            </div>
          )}

          {locked && (
            <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-transparent pointer-events-none" />
          )}

          {/* Premium / unlocked badge — top left (hide FREE) */}
          {course.type !== "free" && (
            <div className="absolute top-3 left-3 flex flex-col gap-2">
              <span
                className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-bold shadow-lg ${
                  course.unlocked && !planLocked
                    ? "bg-sky-500 text-white"
                    : "bg-gradient-to-r from-amber-400 to-orange-500 text-white"
                }`}
              >
                {course.unlocked && !planLocked ? "UNLOCKED" : "PREMIUM"}
              </span>
              {planLocked && course.required_plan_name && (
                <span className="px-2.5 py-1 rounded-full text-[10px] font-bold bg-indigo-600 text-white shadow-lg">
                  {course.required_plan_name}
                </span>
              )}
            </div>
          )}

        </div>

        {/* Body */}
        <div className="p-4 sm:p-5 flex-1 flex flex-col">
          <h3
            className={`text-lg sm:text-xl font-bold text-sky-700 ${
              expanded ? "" : "line-clamp-1"
            } mb-2 group-hover:text-sky-800 transition-colors`}
          >
            {course.name}
          </h3>
          {course.description && (
            <>
              <p
                className={`text-sm text-gray-600 ${
                  expanded ? "" : "line-clamp-2"
                } leading-relaxed`}
              >
                {course.description}
              </p>
              {needsToggle && (
                <span
                  role="button"
                  tabIndex={0}
                  className="mt-1 text-xs font-semibold text-sky-600 hover:text-sky-700 cursor-pointer self-start"
                  onClick={(e) => {
                    e.stopPropagation();
                    setExpanded((v) => !v);
                  }}
                  onKeyDown={(e) => {
                    if (e.key === "Enter" || e.key === " ") {
                      e.stopPropagation();
                      e.preventDefault();
                      setExpanded((v) => !v);
                    }
                  }}
                >
                  {expanded ? "Show less" : "Show more"}
                </span>
              )}
            </>
          )}

          <div className="mt-auto flex items-center justify-between pt-4 mt-4 border-t border-gray-100">
            <div className="flex items-center gap-2 text-sm text-gray-500">
              <Clock className="w-4 h-4 text-sky-500" />
              <span className="font-medium">{course.duration || "N/A"}</span>
            </div>
            <span className="text-sm font-bold text-sky-600 inline-flex items-center gap-1.5 group-hover:gap-2 transition-all">
              {ctaLabel}
              <ArrowRight className="w-4 h-4" />
            </span>
          </div>
        </div>
      </button>
    </div>
  );
};

export default CourseCard;
