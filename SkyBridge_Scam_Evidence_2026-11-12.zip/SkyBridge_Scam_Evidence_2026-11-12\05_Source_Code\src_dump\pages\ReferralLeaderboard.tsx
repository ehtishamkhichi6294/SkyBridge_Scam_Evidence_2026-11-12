import { useState, useEffect, useMemo } from "react";
import { LeaderboardPodium } from "../components/LeaderboardPodium";
import { apiClient } from "../services";
import {
  getAvatarFallbackUrl,
  resolveProfilePictureUrl,
} from "../utils/imageUtils";

interface Leader {
  position: number;
  displayName: string;
  username: string;
  totalReferralSalesPkr: number;
  image: string;
  countryFlag: string;
  country: string;
}

function pickLeaderUsername(item: Record<string, unknown>): string {
  const raw =
    item.username ??
    item.user_name ??
    item.userName ??
    item.referral_username ??
    "";
  return typeof raw === "string" ? raw.trim() : String(raw ?? "").trim();
}

function pickLeaderDisplayName(
  item: Record<string, unknown>,
  index: number,
): string {
  const username = pickLeaderUsername(item);
  const raw =
    item.full_name ??
    item.name ??
    item.display_name ??
    username ??
    `User ${index + 1}`;
  return typeof raw === "string" ? raw.trim() : String(raw);
}

function pickProfileImage(item: Record<string, unknown>): string {
  const user = item.user as Record<string, unknown> | undefined;
  const candidates = [
    item.profile_picture,
    item.profile_picture_url,
    item.profile_photo,
    item.image,
    item.avatar,
    item.avatar_url,
    user?.profile_picture,
    user?.profile_picture_url,
  ];
  for (const c of candidates) {
    if (typeof c === "string" && c.trim()) {
      const resolved = resolveProfilePictureUrl(c);
      if (resolved) return resolved;
    }
  }
  return "";
}

const formatPkr = (amount: number) =>
  `Rs. ${Math.round(amount).toLocaleString("en-PK")}`;

const getFlagUrl = (country: string) => {
  const map: Record<string, string> = {
    Pakistan: "https://flagcdn.com/w40/pk.png",
    India: "https://flagcdn.com/w40/in.png",
    Bangladesh: "https://flagcdn.com/w40/bd.png",
  };
  return map[country] ?? "https://flagcdn.com/w40/un.png";
};

function LeaderAvatar({
  src,
  alt,
  sizeClass,
  ringClass = "ring-2 ring-white",
}: {
  src: string;
  alt: string;
  /** Square dimensions — width and height must match (e.g. w-36 h-36) */
  sizeClass: string;
  ringClass?: string;
}) {
  const fallback = getAvatarFallbackUrl(alt);
  return (
    <div
      className={`relative shrink-0 flex-none overflow-hidden rounded-full bg-sky-100 shadow-md ${sizeClass} ${ringClass}`}
    >
      <img
        src={src || fallback}
        alt={alt}
        className="h-full w-full object-cover object-center"
        loading="lazy"
        referrerPolicy="no-referrer"
        onError={(e) => {
          const target = e.currentTarget;
          target.onerror = null;
          target.src = fallback;
        }}
      />
    </div>
  );
}

function LeaderListRow({ leader, rank }: { leader: Leader; rank: number }) {
  const label = leader.displayName || leader.username;
  const rankStyles =
    rank === 4
      ? "bg-gradient-to-br from-slate-500 to-slate-700 text-white"
      : "bg-gray-200 text-gray-700";

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-200 px-3 py-2.5 hover:shadow-md transition-shadow">
      <div className="flex items-center justify-between gap-2">
        <div className="flex items-center gap-2 min-w-0 flex-1">
          <div
            className={`w-8 h-8 shrink-0 rounded-md flex items-center justify-center text-sm font-bold ${rankStyles}`}
          >
            {rank}
          </div>
          <div className="w-5 h-5 rounded overflow-hidden ring-1 ring-gray-200 shrink-0">
            <img
              src={leader.countryFlag || getFlagUrl(leader.country)}
              alt=""
              className="w-full h-full object-cover"
            />
          </div>
          <LeaderAvatar
            src={leader.image}
            alt={label}
            sizeClass="w-10 h-10"
          />
          <div className="min-w-0 flex-1">
            <p className="text-sm font-semibold text-gray-900 break-words">
              {label}
            </p>
            {leader.username && leader.username !== label && (
              <p className="text-xs text-gray-500 break-words">
                @{leader.username}
              </p>
            )}
          </div>
        </div>
        <div className="text-right shrink-0">
          <p className="text-[10px] uppercase tracking-wide text-gray-500">Direct Sales</p>
          <p className="text-base font-bold text-gray-900 whitespace-nowrap">
            {formatPkr(leader.totalReferralSalesPkr)}
          </p>
        </div>
      </div>
    </div>
  );
}

const ReferralLeaderboard = () => {
  const [leaders, setLeaders] = useState<Leader[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const sortedLeaders = useMemo(() => {
    return [...leaders].sort(
      (a, b) => b.totalReferralSalesPkr - a.totalReferralSalesPkr,
    );
  }, [leaders]);

  const topThree = sortedLeaders.slice(0, 3);
  const rest = sortedLeaders.slice(3);

  useEffect(() => {
    const fetchLeaders = async () => {
      try {
        setLoading(true);
        setError(null);
        apiClient.refreshAuthToken();

        const res = await apiClient.get<Record<string, unknown>>(
          "/leaderboard/referrals",
        );
        const responseData = res.data as Record<string, unknown>;
        const apiLeaders = (responseData?.leaders ||
          (responseData?.data as Record<string, unknown>)?.leaders ||
          []) as Record<string, unknown>[];

        const mapped: Leader[] = apiLeaders.map((item, index) => {
          const username = pickLeaderUsername(item);
          const displayName = pickLeaderDisplayName(item, index);
          const avatarLabel = displayName || username || `User ${index + 1}`;
          const resolved = pickProfileImage(item);
          const image = resolved || getAvatarFallbackUrl(avatarLabel);

          const salesRaw =
            item.total_referral_sales_pkr ??
            item.total_referral_sales ??
            item.referral_sales_pkr ??
            item.sales_pkr ??
            item.this_month_joined ??
            0;
          const totalReferralSalesPkr =
            typeof salesRaw === "string"
              ? parseFloat(salesRaw)
              : Number(salesRaw);

          return {
            position: Number(item.position) || index + 1,
            displayName,
            username: username || displayName,
            totalReferralSalesPkr: Number.isFinite(totalReferralSalesPkr)
              ? totalReferralSalesPkr
              : 0,
            image,
            countryFlag:
              (item.country_flag as string) ??
              getFlagUrl((item.country as string) ?? ""),
            country: (item.country as string) ?? "",
          };
        });

        setLeaders(mapped);
      } catch (err: unknown) {
        setError(
          err instanceof Error
            ? err.message
            : "Failed to load affiliate leaderboard",
        );
      } finally {
        setLoading(false);
      }
    };

    void fetchLeaders();
  }, []);

  const pageHeader = (
    <div className="flex items-center justify-between mb-4">
      <h1 className="text-2xl sm:text-4xl font-bold bg-gradient-to-r from-sky-600 to-sky-700 bg-clip-text text-transparent">
        Affiliate Leaderboard
      </h1>
      <span
        className={`w-2 h-2 rounded-full ${error ? "bg-red-500" : loading ? "bg-emerald-500 animate-pulse" : "bg-emerald-500"}`}
      />
    </div>
  );

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <div className="space-y-6 p-4 max-w-4xl mx-auto w-full">
          {pageHeader}
          <div className="bg-white rounded-xl border border-gray-200 p-6 animate-pulse h-48" />
          <div className="space-y-4">
            {[1, 2, 3].map((i) => (
              <div
                key={i}
                className="bg-white rounded-xl shadow-sm border border-gray-200 p-4"
              >
                <div className="flex items-center gap-3">
                  <div className="w-11 h-11 bg-gray-200 rounded-lg animate-pulse" />
                  <div className="w-7 h-7 bg-gray-200 rounded-md animate-pulse" />
                  <div className="w-14 h-14 bg-gray-200 rounded-full animate-pulse" />
                  <div className="h-4 bg-gray-200 rounded w-32 animate-pulse" />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-gray-50">
        <div className="space-y-6 p-4 max-w-4xl mx-auto w-full">
          {pageHeader}
          <div className="bg-red-50 border-l-4 border-red-500 p-4">
            <h2 className="text-xl font-bold text-red-800">
              Error Loading Leaderboard
            </h2>
            <p className="text-red-700 mt-2">{error}</p>
            <button
              type="button"
              onClick={() => window.location.reload()}
              className="mt-3 px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700"
            >
              Retry
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="space-y-4 p-4 max-w-4xl mx-auto w-full">
        {pageHeader}

        {sortedLeaders.length > 0 ? (
          <>
            {topThree.length > 0 && (
              <LeaderboardPodium
                title="Top Sales This Month (PKR)"
                badgeLabel="Top"
                badgeClassName="bg-purple-100 text-purple-700"
                leaders={topThree.map((leader) => {
                  const label = leader.displayName || leader.username;
                  return {
                    id: leader.username,
                    name: label,
                    subtitle:
                      leader.username &&
                      leader.displayName &&
                      leader.displayName !== leader.username
                        ? `@${leader.username}`
                        : undefined,
                    amount: formatPkr(leader.totalReferralSalesPkr),
                    image: leader.image,
                  };
                })}
                totalCount={sortedLeaders.length}
              />
            )}

            {rest.length > 0 && (
              <div className="space-y-3">
                <h3 className="text-sm font-semibold text-gray-600 px-1">
                  Rank 4 onwards
                </h3>
                {rest.map((leader, index) => (
                  <LeaderListRow
                    key={`${leader.username}-${index + 4}`}
                    leader={leader}
                    rank={index + 4}
                  />
                ))}
              </div>
            )}
          </>
        ) : (
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-8 text-center">
            <h3 className="text-lg font-medium text-gray-900 mb-1">
              No Leaders Found
            </h3>
            <p className="text-gray-500 text-sm">
              No affiliate sales recorded yet.
            </p>
          </div>
        )}
      </div>
    </div>
  );
};

export default ReferralLeaderboard;
