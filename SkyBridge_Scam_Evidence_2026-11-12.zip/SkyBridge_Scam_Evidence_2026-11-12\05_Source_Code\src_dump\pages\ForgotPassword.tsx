import React, { useState, useRef, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import {
  Mail,
  KeyRound,
  Lock,
  AlertCircle,
  CheckCircle,
  Loader2,
  ArrowLeft,
  ShieldCheck,
  UserX,
  Upload,
  FileText,
} from "lucide-react";
import { apiClient } from "../services/apiClient";
import { API_ENDPOINTS, API_CONFIG } from "../config/api";
import { toast } from "react-toastify";

type Method = null | "otp" | "admin";
type OtpStep = 1 | 2 | 3;

interface AccountInfo {
  id?: number;
  account_number: string;
  account_title: string;
  bank: string;
}

// ─── OTP Flow ────────────────────────────────────────────────────────────────

function OtpFlow({ onBack }: { onBack: () => void }) {
  const navigate = useNavigate();
  const [step, setStep] = useState<OtpStep>(1);

  const [email, setEmail] = useState("");
  const [step1Loading, setStep1Loading] = useState(false);
  const [step1Error, setStep1Error] = useState("");

  const [otp, setOtp] = useState("");
  const [step2Loading, setStep2Loading] = useState(false);
  const [step2Error, setStep2Error] = useState("");
  const [resetToken, setResetToken] = useState("");
  const otpRef = useRef<HTMLInputElement>(null);

  const [password, setPassword] = useState("");
  const [passwordConfirmation, setPasswordConfirmation] = useState("");
  const [step3Loading, setStep3Loading] = useState(false);
  const [step3Error, setStep3Error] = useState("");

  // Resend cooldown (seconds remaining). Persisted so a page refresh keeps the timer.
  const COOLDOWN_KEY = "pwd_otp_cooldown_until";
  const [cooldown, setCooldown] = useState(0);

  const startCooldown = (seconds: number) => {
    const secs = Math.max(0, Math.ceil(seconds));
    sessionStorage.setItem(COOLDOWN_KEY, String(Date.now() + secs * 1000));
    setCooldown(secs);
  };

  // Resume any in-flight cooldown on mount (survives refresh / step changes).
  useEffect(() => {
    const until = Number(sessionStorage.getItem(COOLDOWN_KEY) || 0);
    const remaining = Math.ceil((until - Date.now()) / 1000);
    if (remaining > 0) setCooldown(remaining);
  }, []);

  // Tick the countdown down to zero.
  useEffect(() => {
    if (cooldown <= 0) return;
    const id = setInterval(() => setCooldown((c) => Math.max(0, c - 1)), 1000);
    return () => clearInterval(id);
  }, [cooldown]);

  // Extract retry_after_seconds from a 429 error body, if present.
  const retryAfterFrom = (err: unknown): number | undefined => {
    const data = (err as Record<string, unknown>)?.data as Record<string, unknown> | undefined;
    const errors = data?.errors as Record<string, unknown> | undefined;
    const v = errors?.retry_after_seconds;
    return typeof v === "number" ? v : undefined;
  };

  const handleStep1 = async (e: React.FormEvent) => {
    e.preventDefault();
    setStep1Error("");
    if (!email.trim()) { setStep1Error("Please enter your email address"); return; }
    if (cooldown > 0) { setStep1Error(`Please wait ${cooldown}s before requesting another code.`); return; }
    setStep1Loading(true);
    try {
      const res = await apiClient.post<{ resend_cooldown_seconds?: number }>(
        API_ENDPOINTS.AUTH.PASSWORD_RESET_REQUEST_OTP, { email: email.trim() });
      startCooldown((res.data as Record<string, unknown>)?.resend_cooldown_seconds as number ?? 60);
      setStep(2);
      setTimeout(() => otpRef.current?.focus(), 100);
    } catch (err: unknown) {
      const status = (err as Record<string, unknown>)?.status;
      const retryAfter = retryAfterFrom(err);
      if (status === 429) {
        if (retryAfter) startCooldown(retryAfter);
        setStep1Error(retryAfter
          ? `Too many requests. Please try again in ${retryAfter}s.`
          : "Too many attempts. Please try again later.");
      } else if (status === 422) {
        // Invalid / undeliverable email — show it, don't advance.
        const data = (err as Record<string, unknown>)?.data as Record<string, unknown> | undefined;
        const fieldErr = (data?.errors as Record<string, string[]> | undefined)?.email?.[0];
        setStep1Error(fieldErr || String(data?.message || "Please enter a valid email address."));
      } else {
        // Unknown / network hiccup — advance without revealing account existence.
        startCooldown(60);
        setStep(2);
        setTimeout(() => otpRef.current?.focus(), 100);
      }
    } finally {
      setStep1Loading(false);
    }
  };

  const handleResend = async () => {
    if (cooldown > 0 || step1Loading) return;
    setStep2Error("");
    setStep1Loading(true);
    try {
      const res = await apiClient.post<{ resend_cooldown_seconds?: number }>(
        API_ENDPOINTS.AUTH.PASSWORD_RESET_REQUEST_OTP, { email: email.trim() });
      startCooldown((res.data as Record<string, unknown>)?.resend_cooldown_seconds as number ?? 60);
      setOtp("");
      toast.success("A new code has been sent (if the email is registered).");
      setTimeout(() => otpRef.current?.focus(), 100);
    } catch (err: unknown) {
      const retryAfter = retryAfterFrom(err);
      if (retryAfter) startCooldown(retryAfter);
      const data = (err as Record<string, unknown>)?.data as Record<string, unknown> | undefined;
      setStep2Error(retryAfter
        ? `Please wait ${retryAfter}s before requesting another code.`
        : String(data?.message || "Could not resend the code. Please try again."));
    } finally {
      setStep1Loading(false);
    }
  };

  const handleStep2 = async (e: React.FormEvent) => {
    e.preventDefault();
    setStep2Error("");
    if (otp.trim().length !== 6) { setStep2Error("Please enter the 6-digit code"); return; }
    setStep2Loading(true);
    try {
      const res = await apiClient.post<{ reset_token: string }>(
        API_ENDPOINTS.AUTH.PASSWORD_RESET_VERIFY_OTP,
        { email: email.trim(), otp_code: otp.trim() },
      );
      const token = (res.data as Record<string, unknown>)?.reset_token as string | undefined;
      if (!token) throw new Error("Invalid response from server");
      sessionStorage.setItem("pwd_reset_token", token);
      sessionStorage.setItem("pwd_reset_email", email.trim());
      setResetToken(token);
      setStep(3);
    } catch (err: unknown) {
      const e = err as Record<string, unknown>;
      const msg: string = String((e?.data as Record<string,unknown>)?.message || e?.message || "Verification failed");
      if (msg.includes("Too many failed")) {
        setStep2Error(msg);
        toast.error("Too many failed attempts — please request a new code.");
        setTimeout(() => { setStep(1); setOtp(""); setResetToken(""); setStep2Error(""); }, 2500);
      } else {
        setStep2Error(msg);
      }
    } finally {
      setStep2Loading(false);
    }
  };

  const handleStep3 = async (e: React.FormEvent) => {
    e.preventDefault();
    setStep3Error("");
    if (password.length < 8) { setStep3Error("Password must be at least 8 characters"); return; }
    if (password !== passwordConfirmation) { setStep3Error("Passwords do not match"); return; }
    setStep3Loading(true);
    const token = resetToken || sessionStorage.getItem("pwd_reset_token") || "";
    const storedEmail = email.trim() || sessionStorage.getItem("pwd_reset_email") || "";
    try {
      await apiClient.post(API_ENDPOINTS.AUTH.PASSWORD_RESET_RESET, {
        email: storedEmail,
        reset_token: token,
        password,
        password_confirmation: passwordConfirmation,
      });
      sessionStorage.removeItem("pwd_reset_token");
      sessionStorage.removeItem("pwd_reset_email");
      toast.success("Password reset successfully. You can now log in.");
      navigate("/login");
    } catch (err: unknown) {
      const e = err as Record<string, unknown>;
      const msg: string = String((e?.data as Record<string,unknown>)?.message || e?.message || "Reset failed");
      if (msg.includes("Invalid or expired")) {
        setStep3Error(msg);
        toast.error("Reset token expired — please start over.");
        setTimeout(() => { setStep(1); setOtp(""); setPassword(""); setPasswordConfirmation(""); setResetToken(""); setStep3Error(""); }, 2500);
      } else {
        setStep3Error(msg);
      }
    } finally {
      setStep3Loading(false);
    }
  };

  const goBackToStep1 = () => { setStep(1); setOtp(""); setStep2Error(""); setStep3Error(""); };

  return (
    <>
      {/* Progress bar */}
      <div className="flex border-b border-gray-100">
        {([1, 2, 3] as OtpStep[]).map((s) => (
          <div key={s} className={`flex-1 h-1 transition-colors duration-300 ${step >= s ? "bg-sky-500" : "bg-gray-200"}`} />
        ))}
      </div>

      <div className="p-6 sm:p-8">
        <button
          type="button"
          onClick={step === 1 ? onBack : goBackToStep1}
          className="inline-flex items-center text-sky-600 hover:text-sky-700 text-sm font-medium mb-6"
        >
          <ArrowLeft className="w-4 h-4 mr-1" />
          {step === 1 ? "Back" : "Back to email"}
        </button>

        {/* Step 1 */}
        {step === 1 && (
          <form onSubmit={handleStep1} className="space-y-5">
            <div className="text-center mb-6">
              <div className="inline-flex items-center justify-center w-14 h-14 rounded-full bg-sky-100 mb-3">
                <Mail className="w-7 h-7 text-sky-600" />
              </div>
              <h1 className="text-2xl font-bold text-gray-800">Forgot Password?</h1>
              <p className="text-sm text-gray-500 mt-1">Enter your email and we'll send a 6-digit code.</p>
            </div>
            {step1Error && (
              <div className="flex items-start gap-2 p-3 bg-red-50 border border-red-200 rounded-lg text-red-700 text-sm">
                <AlertCircle className="w-4 h-4 mt-0.5 shrink-0" />{step1Error}
              </div>
            )}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Email Address</label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 w-5 h-5" />
                <input
                  type="email"
                  value={email}
                  onChange={(e) => { setEmail(e.target.value); if (step1Error) setStep1Error(""); }}
                  className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-sky-500 focus:border-transparent text-sm"
                  placeholder="user@example.com"
                  required
                  autoFocus
                />
              </div>
            </div>
            <button
              type="submit"
              disabled={step1Loading || cooldown > 0}
              className="w-full bg-sky-600 text-white py-3 rounded-xl font-semibold hover:bg-sky-700 transition disabled:opacity-50 flex items-center justify-center gap-2"
            >
              {step1Loading ? <><Loader2 className="w-5 h-5 animate-spin" />Sending…</> : cooldown > 0 ? `Resend in ${cooldown}s` : "Send Code"}
            </button>
          </form>
        )}

        {/* Step 2 */}
        {step === 2 && (
          <form onSubmit={handleStep2} className="space-y-5">
            <div className="text-center mb-6">
              <div className="inline-flex items-center justify-center w-14 h-14 rounded-full bg-sky-100 mb-3">
                <KeyRound className="w-7 h-7 text-sky-600" />
              </div>
              <h1 className="text-2xl font-bold text-gray-800">Enter Code</h1>
              <p className="text-sm text-gray-500 mt-1">
                If <span className="font-medium">{email}</span> is registered, a 6-digit code was sent.
              </p>
            </div>
            {step2Error && (
              <div className="flex items-start gap-2 p-3 bg-red-50 border border-red-200 rounded-lg text-red-700 text-sm">
                <AlertCircle className="w-4 h-4 mt-0.5 shrink-0" />{step2Error}
              </div>
            )}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">6-Digit Code</label>
              <input
                ref={otpRef}
                type="text"
                inputMode="numeric"
                maxLength={6}
                value={otp}
                onChange={(e) => { setOtp(e.target.value.replace(/\D/g, "").slice(0, 6)); if (step2Error) setStep2Error(""); }}
                className="w-full px-4 py-4 border border-gray-300 rounded-xl focus:ring-2 focus:ring-sky-500 text-center text-2xl font-mono tracking-widest"
                placeholder="000000"
                autoFocus
              />
              <p className="text-xs text-gray-400 mt-1">Code is valid for 10 minutes.</p>
            </div>
            <button
              type="submit"
              disabled={step2Loading || otp.length !== 6}
              className="w-full bg-sky-600 text-white py-3 rounded-xl font-semibold hover:bg-sky-700 transition disabled:opacity-50 flex items-center justify-center gap-2"
            >
              {step2Loading ? <><Loader2 className="w-5 h-5 animate-spin" />Verifying…</> : "Verify Code"}
            </button>
            <div className="text-center text-sm text-gray-500">
              Didn't receive a code?{" "}
              {cooldown > 0 ? (
                <span className="text-gray-400 font-medium">Resend in {cooldown}s</span>
              ) : (
                <button
                  type="button"
                  onClick={handleResend}
                  disabled={step1Loading}
                  className="text-sky-600 hover:text-sky-700 font-medium disabled:opacity-50"
                >
                  {step1Loading ? "Sending…" : "Resend code"}
                </button>
              )}
              <button
                type="button"
                onClick={goBackToStep1}
                className="block mx-auto mt-1 text-xs text-gray-400 hover:text-gray-600"
              >
                Use a different email
              </button>
            </div>
          </form>
        )}

        {/* Step 3 */}
        {step === 3 && (
          <form onSubmit={handleStep3} className="space-y-5">
            <div className="text-center mb-6">
              <div className="inline-flex items-center justify-center w-14 h-14 rounded-full bg-green-100 mb-3">
                <Lock className="w-7 h-7 text-green-600" />
              </div>
              <h1 className="text-2xl font-bold text-gray-800">New Password</h1>
              <p className="text-sm text-gray-500 mt-1">Set a strong password (min. 8 characters).</p>
            </div>
            {step3Error && (
              <div className="flex items-start gap-2 p-3 bg-red-50 border border-red-200 rounded-lg text-red-700 text-sm">
                <AlertCircle className="w-4 h-4 mt-0.5 shrink-0" />{step3Error}
              </div>
            )}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">New Password</label>
              <input
                type="password"
                value={password}
                onChange={(e) => { setPassword(e.target.value); if (step3Error) setStep3Error(""); }}
                className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-sky-500 text-sm"
                placeholder="Min. 8 characters"
                required
                autoFocus
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Confirm Password</label>
              <input
                type="password"
                value={passwordConfirmation}
                onChange={(e) => { setPasswordConfirmation(e.target.value); if (step3Error) setStep3Error(""); }}
                onPaste={(e) => e.preventDefault()}
                onCopy={(e) => e.preventDefault()}
                onCut={(e) => e.preventDefault()}
                className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-sky-500 text-sm"
                placeholder="Re-enter password"
                required
              />
              {password && passwordConfirmation && password !== passwordConfirmation && (
                <p className="text-xs text-red-600 mt-1">Passwords do not match</p>
              )}
              {password && passwordConfirmation && password === passwordConfirmation && (
                <p className="text-xs text-green-600 mt-1 flex items-center gap-1">
                  <CheckCircle className="w-3.5 h-3.5" /> Passwords match
                </p>
              )}
            </div>
            <button
              type="submit"
              disabled={step3Loading}
              className="w-full bg-green-600 text-white py-3 rounded-xl font-semibold hover:bg-green-700 transition disabled:opacity-50 flex items-center justify-center gap-2"
            >
              {step3Loading ? <><Loader2 className="w-5 h-5 animate-spin" />Resetting…</> : "Reset Password"}
            </button>
            <p className="text-xs text-center text-gray-400">
              Reset link expires in 15 minutes.
            </p>
          </form>
        )}
      </div>
    </>
  );
}

// ─── Admin Request Flow ───────────────────────────────────────────────────────

function AdminRequestFlow({ onBack }: { onBack: () => void }) {
  const [email, setEmail] = useState("");
  const [senderAccountNumber, setSenderAccountNumber] = useState("");
  const [screenshot, setScreenshot] = useState<File | null>(null);
  const [screenshotPreview, setScreenshotPreview] = useState<string | null>(null);
  const [accountList, setAccountList] = useState<AccountInfo[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");

  useEffect(() => {
    (async () => {
      try {
        const res = await fetch(`${API_CONFIG.BASE_URL}${API_ENDPOINTS.ACCOUNT}?type=reset_password`);
        const data = await res.json();
        if (data.success && data.data) {
          setAccountList(Array.isArray(data.data) ? data.data : [data.data]);
        }
      } catch {
        // silently ignore — accounts may not be configured
      }
    })();
  }, []);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (!file.type.startsWith("image/")) {
      setError("Please upload an image file (JPG, PNG, etc.)");
      return;
    }
    if (file.size > 5 * 1024 * 1024) {
      setError("Image must be less than 5MB");
      return;
    }
    setScreenshot(file);
    setError("");
    const reader = new FileReader();
    reader.onloadend = () => setScreenshotPreview(reader.result as string);
    reader.readAsDataURL(file);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    if (!email.trim()) { setError("Please enter your email address."); return; }
    if (!senderAccountNumber.trim()) { setError("Please enter your sender account number."); return; }
    if (!screenshot) { setError("Please upload your payment screenshot."); return; }

    setLoading(true);
    try {
      const formData = new FormData();
      formData.append("email", email.trim());
      formData.append("sender_account_number", senderAccountNumber.trim());
      formData.append("payment_screenshot", screenshot);

      const res = await apiClient.post(API_ENDPOINTS.AUTH.PASSWORD_RESET_REQUEST, formData);
      const data = res?.data as Record<string, unknown>;
      setSuccess(String(data?.message || "Request submitted! Admin will reset your password within 24 hours."));
      setEmail("");
      setSenderAccountNumber("");
      setScreenshot(null);
      setScreenshotPreview(null);
    } catch (err: unknown) {
      const e = err as Record<string, unknown>;
      const errData = e?.data as Record<string, unknown> | undefined;
      const fieldErrors = errData?.errors as Record<string, string[]> | undefined;
      if (fieldErrors) {
        const firstField = Object.values(fieldErrors)[0];
        setError(Array.isArray(firstField) ? firstField[0] : String(firstField));
      } else {
        setError(String(errData?.message || e?.message || "Failed to submit request. Please try again."));
      }
    } finally {
      setLoading(false);
    }
  };

  if (success) {
    return (
      <div className="p-6 sm:p-8">
        <div className="text-center py-6">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-green-100 mb-4">
            <CheckCircle className="w-8 h-8 text-green-600" />
          </div>
          <h2 className="text-xl font-bold text-gray-800 mb-2">Request Submitted!</h2>
          <p className="text-gray-600 text-sm mb-6">{success}</p>
          <Link
            to="/login"
            className="inline-flex items-center gap-2 px-6 py-3 bg-sky-600 text-white rounded-xl font-semibold hover:bg-sky-700 transition text-sm"
          >
            Back to Login
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 sm:p-8">
      <button
        type="button"
        onClick={onBack}
        className="inline-flex items-center text-sky-600 hover:text-sky-700 text-sm font-medium mb-6"
      >
        <ArrowLeft className="w-4 h-4 mr-1" />
        Back
      </button>

      <div className="text-center mb-6">
        <div className="inline-flex items-center justify-center w-14 h-14 rounded-full bg-orange-100 mb-3">
          <FileText className="w-7 h-7 text-orange-600" />
        </div>
        <h1 className="text-2xl font-bold text-gray-800">Admin Reset Request</h1>
        <p className="text-sm text-gray-500 mt-1">
          Send payment and submit a request — admin will reset your password within 24 hours.
        </p>
      </div>

      {/* Payment Instructions */}
      <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-xl mb-5">
        <p className="text-sm font-semibold text-yellow-900 mb-2">Payment Details</p>
        {accountList.length > 0 ? (
          <div className="space-y-2 mb-3">
            {accountList.map((acc, idx) => (
              <div key={acc.id ?? idx} className="p-2 bg-white/70 rounded-lg text-sm text-yellow-900">
                <p className="font-mono font-bold">{acc.account_number}</p>
                <p className="text-yellow-700">{acc.bank} — {acc.account_title}</p>
              </div>
            ))}
          </div>
        ) : (
          <p className="text-sm text-yellow-700 mb-3">Loading payment details…</p>
        )}
        <div className="text-sm text-yellow-900 space-y-1 border-t border-yellow-200 pt-2">
          <p>Send <strong>50 Rupees</strong> from your registered SkyBridge account number.</p>
          <p className="text-yellow-800">After payment, your password will be reset to <span className="font-mono font-bold">123456789</span> within 24 hours.</p>
        </div>
      </div>

      {error && (
        <div className="flex items-start gap-2 p-3 bg-red-50 border border-red-200 rounded-lg text-red-700 text-sm mb-4">
          <AlertCircle className="w-4 h-4 mt-0.5 shrink-0" />{error}
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Email Address</label>
          <div className="relative">
            <Mail className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 w-5 h-5" />
            <input
              type="email"
              value={email}
              onChange={(e) => { setEmail(e.target.value); if (error) setError(""); }}
              className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-sky-500 text-sm"
              placeholder="user@example.com"
              required
            />
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Sender Account Number <span className="text-gray-400 font-normal">(number you sent payment from)</span>
          </label>
          <input
            type="text"
            value={senderAccountNumber}
            onChange={(e) => { setSenderAccountNumber(e.target.value); if (error) setError(""); }}
            className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-sky-500 text-sm"
            placeholder="e.g. 03001234567"
            required
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Payment Screenshot</label>
          <div className="border-2 border-dashed border-gray-300 rounded-xl p-4 text-center hover:border-sky-400 transition cursor-pointer">
            <input
              type="file"
              accept="image/*"
              onChange={handleFileChange}
              className="hidden"
              id="admin-reset-screenshot"
            />
            <label htmlFor="admin-reset-screenshot" className="cursor-pointer">
              {screenshotPreview ? (
                <div>
                  <img src={screenshotPreview} alt="Preview" className="max-h-40 mx-auto rounded-lg object-contain" />
                  {screenshot && (
                    <p className="text-xs text-gray-500 mt-2">{screenshot.name} ({(screenshot.size / 1024).toFixed(0)} KB)</p>
                  )}
                </div>
              ) : (
                <div>
                  <Upload className="w-8 h-8 text-gray-400 mx-auto mb-2" />
                  <p className="text-sm text-gray-600">Click to upload screenshot</p>
                  <p className="text-xs text-gray-400">JPG, PNG (Max 5MB)</p>
                </div>
              )}
            </label>
          </div>
        </div>

        <button
          type="submit"
          disabled={loading}
          className="w-full bg-orange-500 text-white py-3 rounded-xl font-semibold hover:bg-orange-600 transition disabled:opacity-50 flex items-center justify-center gap-2"
        >
          {loading ? <><Loader2 className="w-5 h-5 animate-spin" />Submitting…</> : "Submit Reset Request"}
        </button>
      </form>
    </div>
  );
}

// ─── Method Selector ─────────────────────────────────────────────────────────

function MethodSelector({ onSelect }: { onSelect: (m: "otp" | "admin") => void }) {
  return (
    <div className="p-6 sm:p-8">
      <Link
        to="/login"
        className="inline-flex items-center text-sky-600 hover:text-sky-700 text-sm font-medium mb-6"
      >
        <ArrowLeft className="w-4 h-4 mr-1" />
        Back to Login
      </Link>

      <div className="text-center mb-8">
        <div className="inline-flex items-center justify-center w-14 h-14 rounded-full bg-sky-100 mb-3">
          <KeyRound className="w-7 h-7 text-sky-600" />
        </div>
        <h1 className="text-2xl font-bold text-gray-800">Forgot Password?</h1>
        <p className="text-sm text-gray-500 mt-1">Choose how you want to reset your password.</p>
      </div>

      <div className="space-y-3">
        {/* OTP Option */}
        <button
          type="button"
          onClick={() => onSelect("otp")}
          className="w-full text-left p-4 rounded-xl border-2 border-sky-200 hover:border-sky-500 hover:bg-sky-50 transition-all duration-200 group"
        >
          <div className="flex items-center gap-4">
            <div className="w-11 h-11 rounded-full bg-sky-100 group-hover:bg-sky-200 flex items-center justify-center shrink-0 transition">
              <ShieldCheck className="w-5 h-5 text-sky-600" />
            </div>
            <div className="min-w-0">
              <p className="font-semibold text-gray-800 text-sm">I have access to my email</p>
              <p className="text-xs text-gray-500 mt-0.5">
                We'll send a 6-digit code to your email — verify and set a new password instantly.
              </p>
            </div>
          </div>
        </button>

        {/* Admin Option */}
        <button
          type="button"
          onClick={() => onSelect("admin")}
          className="w-full text-left p-4 rounded-xl border-2 border-orange-200 hover:border-orange-400 hover:bg-orange-50 transition-all duration-200 group"
        >
          <div className="flex items-center gap-4">
            <div className="w-11 h-11 rounded-full bg-orange-100 group-hover:bg-orange-200 flex items-center justify-center shrink-0 transition">
              <UserX className="w-5 h-5 text-orange-600" />
            </div>
            <div className="min-w-0">
              <p className="font-semibold text-gray-800 text-sm">I don't have email access</p>
              <p className="text-xs text-gray-500 mt-0.5">
                Send 50 Rs payment and submit a request — admin will reset your password within 24 hours.
              </p>
            </div>
          </div>
        </button>
      </div>
    </div>
  );
}

// ─── Main Page ────────────────────────────────────────────────────────────────

const ForgotPassword: React.FC = () => {
  const [method, setMethod] = useState<Method>(null);

  return (
    <div className="min-h-screen bg-gradient-to-br from-sky-500 via-sky-600 to-sky-700 flex items-center justify-center p-4">
      <div className="w-full max-w-md bg-white rounded-2xl shadow-2xl overflow-hidden">
        {method === null && <MethodSelector onSelect={setMethod} />}
        {method === "otp" && <OtpFlow onBack={() => setMethod(null)} />}
        {method === "admin" && <AdminRequestFlow onBack={() => setMethod(null)} />}
      </div>
    </div>
  );
};

export default ForgotPassword;
