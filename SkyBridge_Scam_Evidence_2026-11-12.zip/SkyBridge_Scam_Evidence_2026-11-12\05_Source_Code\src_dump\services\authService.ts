import { apiClient } from "./apiClient";
import { API_ENDPOINTS } from "../config/api";

// Ensure apiClient is updated with current token
const updateApiClientToken = (token: string | null) => {
  if (token) {
    apiClient.setAuthToken(token);
  } else {
    apiClient.removeAuthToken();
  }
};

export interface LoginRequest {
  email: string;
  password: string;
}

export interface RegisterRequest {
  name: string;
  email: string;
  password: string;
  confirmPassword: string;
  referralCode?: string;
  country: string;
  planId: number;
  phoneNumber: string;
  confirmPhoneNumber: string;
  paymentMethods: string[];
  accountTitle: string;
  bep20Address?: string;
  trc20Address?: string;
  screenshot: File | null;
  transactionId: string;
  transactionAccountNumber: string;
  transactionAccountTitle: string;
}

export interface LoginResponse {
  success: boolean;
  message: string;
  data?: {
    user: {
      id: number;
      name: string;
      email: string;
      country: string;
      referral_code: string;
      account_number: string;
      account_title: string;
    };
    token?: string;
    access_token?: string;
  };
  error?: string;
}

export interface RegisterResponse {
  success: boolean;
  message: string;
  data?: {
    user: {
      id: number;
      name: string;
      email: string;
      country: string;
      referral_code: string;
      account_number: string;
      account_title: string;
    };
    token?: string;
    access_token?: string;
  };
  error?: string;
}

export interface User {
  id: number;
  name: string;
  email: string;
  country: string;
  referral_code: string;
  account_number: string;
  account_title: string;
}

class AuthService {
  private static instance: AuthService;
  private currentUser: User | null = null;
  private token: string | null = null;

  private constructor() {
    // Load user data from localStorage on initialization
    this.loadUserFromStorage();
  }

  public static getInstance(): AuthService {
    if (!AuthService.instance) {
      AuthService.instance = new AuthService();
    }
    return AuthService.instance;
  }

  private loadUserFromStorage(): void {
    try {
      const userData = localStorage.getItem("user");
      const token =
        localStorage.getItem("token") || localStorage.getItem("access_token");

      if (userData && token) {
        this.currentUser = JSON.parse(userData);
        this.token = token;
        // Update apiClient with loaded token
        updateApiClientToken(token);
      }
    } catch (error) {
      console.error("Error loading user from storage:", error);
      this.clearStorage();
    }
  }

  private saveUserToStorage(user: User, token: string): void {
    try {
      localStorage.setItem("user", JSON.stringify(user));
      localStorage.setItem("token", token);
      localStorage.setItem("access_token", token); // For backward compatibility
      this.currentUser = user;
      this.token = token;
      // Update apiClient with new token
      updateApiClientToken(token);
    } catch (error) {
      console.error("Error saving user to storage:", error);
    }
  }

  private clearStorage(): void {
    localStorage.removeItem("user");
    localStorage.removeItem("token");
    localStorage.removeItem("access_token");
    this.currentUser = null;
    this.token = null;
    // Remove token from apiClient
    updateApiClientToken(null);
  }

  public async login(
    email: string,
    password: string,
  ): Promise<{
    success: boolean;
    error?: string;
    message?: string;
    user?: User;
  }> {
    try {
      const loginData: LoginRequest = { email, password };
      // Use a longer timeout for login so slow servers don't trigger "Request timeout"
      const response = await apiClient.post<LoginResponse>(
        API_ENDPOINTS.AUTH.LOGIN,
        loginData,
        { timeout: 60000 },
      );

      if (response.success && response.data?.user) {
        const { user } = response.data;
        const token = response.data.token || response.data.access_token;

        if (token) {
          this.saveUserToStorage(user, token);
          return {
            success: true,
            user,
            message: response.message || "Login successful",
          };
        } else {
          return {
            success: false,
            error: "No authentication token received",
            message: response.message,
          };
        }
      } else {
        return {
          success: false,
          error: response.message || response.error || "Login failed",
          message: response.message || response.error,
        };
      }
    } catch (error: any) {
      console.error("Login error:", error);

      // Handle different types of errors
      if (error.response?.data?.message) {
        return {
          success: false,
          error: error.response.data.message,
          message: error.response.data.message,
        };
      } else if (error.response?.data?.error) {
        return {
          success: false,
          error: error.response.data.error,
          message: error.response.data.error,
        };
      } else if (error.message) {
        // Make "Failed to fetch" error more user-friendly
        if (
          error.message === "Failed to fetch" ||
          error.message.toLowerCase().includes("network")
        ) {
          const networkMessage =
            "Unable to connect to server. Please check your internet connection or try again later.";
          return {
            success: false,
            error: networkMessage,
            message: networkMessage,
          };
        }
        return { success: false, error: error.message, message: error.message };
      } else {
        return {
          success: false,
          error: "Network error. Please check your connection.",
          message: "Network error. Please check your connection.",
        };
      }
    }
  }

  public logout(): void {
    // Revoke the token server-side; local logout must not wait on or fail with the network.
    // apiClient captures the Authorization header synchronously, before it is removed.
    apiClient.post(API_ENDPOINTS.AUTH.LOGOUT).catch(() => {});
    this.clearStorage();
  }

  public getCurrentUser(): User | null {
    return this.currentUser;
  }

  public patchStoredUser(patch: Record<string, unknown>): User | null {
    if (!this.currentUser) return null;
    const updated = { ...this.currentUser, ...patch } as User;
    try {
      localStorage.setItem("user", JSON.stringify(updated));
      this.currentUser = updated;
    } catch {
      // ignore storage errors
    }
    return updated;
  }

  public getToken(): string | null {
    return this.token;
  }

  public isAuthenticated(): boolean {
    return !!(this.currentUser && this.token);
  }

  public async register(
    formData: RegisterRequest,
  ): Promise<{
    success: boolean;
    error?: string;
    user?: User;
    fieldErrors?: Record<string, string>;
  }> {
    const friendlyScreenshotError =
      "Screenshot is too large. Please upload a smaller image (e.g. lower resolution or size) and try again.";
    const isScreenshotTooLong = (msg: string) =>
      typeof msg === "string" &&
      (msg.includes("Data too long") ||
        msg.includes("right truncated") ||
        msg.includes("transaction_screenshot") ||
        msg.includes("22001"));

    try {
      // Determine if user is international (crypto) or Pakistani
      const isPakistani = formData.country === "Pakistan";

      // Build FormData for multipart/form-data upload
      const registrationPayload = new FormData();
      registrationPayload.append("full_name", formData.name);
      registrationPayload.append("email", formData.email);
      registrationPayload.append("country", formData.country);
      registrationPayload.append("referral_code", formData.referralCode || "");
      registrationPayload.append("password", formData.password);
      registrationPayload.append(
        "password_confirmation",
        formData.confirmPassword,
      );
      registrationPayload.append("plan_id", String(formData.planId));
      registrationPayload.append("transaction_id", formData.transactionId);

      if (formData.screenshot) {
        registrationPayload.append(
          "transaction_screenshot",
          formData.screenshot,
        );
      }

      // Add country-specific fields
      if (isPakistani) {
        registrationPayload.append("account_number", formData.phoneNumber);
        registrationPayload.append("account_title", formData.accountTitle);
        registrationPayload.append(
          "payment_methods",
          formData.paymentMethods.join(", "),
        );
        registrationPayload.append(
          "transaction_account_number",
          formData.transactionAccountNumber,
        );
        registrationPayload.append(
          "transaction_account_title",
          formData.transactionAccountTitle,
        );
      } else {
        // International user - crypto payment
        registrationPayload.append("bep20_address", formData.bep20Address);
      }

      // Registration with screenshot can be slow (image + server-side checks),
      // so we explicitly allow a longer timeout for this request.
      const response = await apiClient.post<RegisterResponse>(
        API_ENDPOINTS.AUTH.REGISTER,
        registrationPayload,
        { timeout: 90000 },
      );

      if (response.success && response.data?.user) {
        const { user } = response.data;
        const token = response.data.token || response.data.access_token;

        if (token) {
          this.saveUserToStorage(user, token);
          return { success: true, user };
        } else {
          // Some registration endpoints do not return a token. Treat as successful registration
          // without creating an authenticated session. Caller should navigate to Login.
          return { success: true, user };
        }
      } else {
        // Handle non-throwing validation responses defensively
        const raw = (response as any).data || {};
        const validationErrors = raw.errors || (response as any).errors;
        if (validationErrors) {
          const fieldErrors: Record<string, string> = {};
          const mapKey: (key: string) => string = (key) => {
            const mapping: Record<string, string> = {
              email: "email",
              referral_code: "referralCode",
              password: "password",
              password_confirmation: "confirmPassword",
              full_name: "name",
              country: "country",
              account_number: "phoneNumber",
              account_title: "accountTitle",
              payment_methods: "paymentMethods",
              transaction_id: "transactionId",
              transaction_account_number: "transactionAccountNumber",
              transaction_account_title: "transactionAccountTitle",
              transaction_screenshot: "screenshot",
              bep20_address: "bep20Address",
              plan_id: "planId",
            };
            return mapping[key] || key;
          };
          for (const [key, value] of Object.entries(validationErrors)) {
            const firstError = Array.isArray(value) ? value[0] : String(value);
            fieldErrors[mapKey(key)] = firstError;
          }
          const firstErrorValue = Object.values(fieldErrors)[0];
          const errorMsg = isScreenshotTooLong(firstErrorValue)
            ? friendlyScreenshotError
            : firstErrorValue || response.message || "Registration failed";
          return { success: false, error: errorMsg, fieldErrors };
        }
        const rawError = response.message || raw.error || "Registration failed";
        return {
          success: false,
          error: isScreenshotTooLong(String(rawError))
            ? friendlyScreenshotError
            : rawError,
        };
      }
    } catch (error: any) {
      console.error("Registration error:", error);

      // Prefer specific validation errors over generic message
      if (error.data?.errors) {
        // Map validation errors to frontend field names and surface first error message
        const validationErrors = error.data.errors;
        const fieldErrors: Record<string, string> = {};
        const mapKey = (key: string) => {
          const mapping: Record<string, string> = {
            email: "email",
            referral_code: "referralCode",
            password: "password",
            password_confirmation: "confirmPassword",
            full_name: "name",
            country: "country",
            account_number: "phoneNumber",
            account_title: "accountTitle",
            payment_methods: "paymentMethods",
            transaction_id: "transactionId",
            transaction_account_number: "transactionAccountNumber",
            transaction_account_title: "transactionAccountTitle",
            transaction_screenshot: "screenshot",
            bep20_address: "bep20Address",
          };
          return mapping[key] || key;
        };
        for (const [key, value] of Object.entries(validationErrors)) {
          const firstError = Array.isArray(value) ? value[0] : String(value);
          fieldErrors[mapKey(key)] = firstError;
        }
        const firstErrorValue = Object.values(fieldErrors)[0];
        const errorMsg = isScreenshotTooLong(firstErrorValue)
          ? friendlyScreenshotError
          : firstErrorValue || "Validation failed";
        return { success: false, error: errorMsg, fieldErrors };
      }
      const msg =
        error.data?.message ||
        error.data?.error ||
        error.message ||
        "Network error. Please check your connection.";
      return {
        success: false,
        error: isScreenshotTooLong(String(msg)) ? friendlyScreenshotError : msg,
      };
    }
  }

  public async refreshToken(): Promise<boolean> {
    // Implement token refresh logic if your API supports it
    // For now, return false to indicate refresh is not available
    return false;
  }
}

export const authService = AuthService.getInstance();
export default authService;
