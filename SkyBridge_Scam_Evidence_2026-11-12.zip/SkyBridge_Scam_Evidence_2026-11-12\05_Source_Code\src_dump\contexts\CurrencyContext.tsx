import React, { createContext, useContext, useState, ReactNode } from 'react';

export type Currency = 'USD' | 'PKR';

interface CurrencyContextType {
  currency: Currency;
  setCurrency: (currency: Currency) => void;
  exchangeRate: number;
  formatCurrency: (amount: number) => string;
  convertAmount: (amount: number, fromCurrency?: Currency) => number;
}

export const CurrencyContext = createContext<CurrencyContextType | undefined>(undefined);

interface CurrencyProviderProps {
  children: ReactNode;
}

export const CurrencyProvider: React.FC<CurrencyProviderProps> = ({ children }) => {
  const [currency, setCurrency] = useState<Currency>('USD');
  const exchangeRate = 285; // 1 USD = 285 PKR

  const formatCurrency = (amount: number): string => {
    const convertedAmount = convertAmount(amount, 'USD');
    if (currency === 'USD') {
      // Format USD with commas: $1.18
      return `$${convertedAmount.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
    } else {
      // Format PKR with commas: ₨1.18
      return `₨${convertedAmount.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
    }
  };

  const convertAmount = (amount: number, fromCurrency: Currency = 'USD'): number => {
    if (fromCurrency === currency) {
      return amount;
    }
    
    if (fromCurrency === 'USD' && currency === 'PKR') {
      return amount * exchangeRate;
    } else if (fromCurrency === 'PKR' && currency === 'USD') {
      return amount / exchangeRate;
    }
    
    return amount;
  };

  const value: CurrencyContextType = {
    currency,
    setCurrency,
    exchangeRate,
    formatCurrency,
    convertAmount,
  };

  return (
    <CurrencyContext.Provider value={value}>
      {children}
    </CurrencyContext.Provider>
  );
};

export const useCurrency = (): CurrencyContextType => {
  const context = useContext(CurrencyContext);
  if (context === undefined) {
    throw new Error('useCurrency must be used within a CurrencyProvider');
  }
  return context;
};