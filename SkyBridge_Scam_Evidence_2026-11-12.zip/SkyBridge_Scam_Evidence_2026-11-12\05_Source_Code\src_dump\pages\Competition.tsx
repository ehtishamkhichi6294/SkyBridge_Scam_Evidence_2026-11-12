import React, { useMemo, useState, useEffect } from "react";
import {
  Trophy,
  Calendar,
  Clock,
  Gift,
  Crown,
  Medal,
  Info,
  X,
  Mountain,
  Loader2,
  Users,
} from "lucide-react";
import bannerImage from "../assets/images/comp_banner.jpeg";
import { apiClient } from "../services/apiClient";
import { API_ENDPOINTS } from "../config/api";
import {
  getAvatarFallbackUrl,
  resolveProfilePictureUrl,
} from "../utils/imageUtils";

interface CompetitionInfo {
  id: number;
  title: string;
  description?: string | null;
  starts_at: string;
  ends_at: string;
  status: string;
  is_running: boolean;
  has_ended: boolean;
  days_remaining: number;
  primary_target_pkr: number;
}

interface CompetitionTier {
  id: number;
  place: number;
  title: string;
  target_pkr: number;
  prize_label: string;
  bonus_amount_pkr: number;
  achieved: boolean;
}

interface MyProgress {
  total_sales_pkr: number;
  primary_target_pkr: number;
  remaining_pkr: number;
  progress_percent: number;
  rank: number | null;
  achieved_tier: CompetitionTier | null;
}

interface LeaderboardRow {
  rank: number;
  user_id: number;
  name: string;
  total_sales_pkr: number;
  is_me: boolean;
  profile_picture?: string | null;
}

interface CompetitionPayload {
  competition: CompetitionInfo;
  tiers: CompetitionTier[];
  my_progress: MyProgress;
}

const TIER_PRESENTATION: Record<
  number,
  { icon: React.ReactNode; accent: string }
> = {
  1: {
    icon: <Crown className="w-5 h-5" />,
    accent: "from-amber-400 to-yellow-500",
  },
  2: {
    icon: <Medal className="w-5 h-5" />,
    accent: "from-slate-300 to-slate-400",
  },
  3: {
    icon: <Gift className="w-5 h-5" />,
    accent: "from-orange-400 to-amber-600",
  },
};

function formatDateLabel(iso: string) {
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return iso;
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

function formatShortDate(iso: string) {
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return iso;
  return d.toLocaleDateString("en-GB", {
    day: "numeric",
    month: "short",
  });
}

function formatPkr(amount: number) {
  return `Rs ${Math.round(amount).toLocaleString("en-US")}`;
}

function toNumber(value: unknown): number {
  if (value == null || value === "") return 0;
  const n =
    typeof value === "string"
      ? parseFloat(value.replace(/,/g, ""))
      : Number(value);
  return Number.isFinite(n) ? n : 0;
}

function calcProgress(earned: number, target: number) {
  const safeTarget = Math.max(0, target);
  const safeEarned = Math.max(0, earned);
  const percent =
    safeTarget > 0 ? Math.min(100, (safeEarned / safeTarget) * 100) : 0;
  return {
    earned: safeEarned,
    target: safeTarget,
    remaining: Math.max(0, safeTarget - safeEarned),
    percent,
  };
}

function normalizeTier(raw: Record<string, unknown>): CompetitionTier {
  return {
    id: toNumber(raw.id),
    place: toNumber(raw.place),
    title: String(raw.title ?? ""),
    target_pkr: toNumber(raw.target_pkr ?? raw.targetPkr),
    prize_label: String(raw.prize_label ?? raw.prizeLabel ?? ""),
    bonus_amount_pkr: toNumber(raw.bonus_amount_pkr ?? raw.bonusAmountPkr),
    achieved: Boolean(raw.achieved),
  };
}

function normalizeProgress(
  raw: Record<string, unknown> | null | undefined,
  competition: CompetitionInfo,
  tiers: CompetitionTier[],
): MyProgress {
  const primaryTarget = toNumber(
    raw?.primary_target_pkr ??
      raw?.primaryTargetPkr ??
      competition.primary_target_pkr ??
      tiers[0]?.target_pkr,
  );
  const totalSales = toNumber(
    raw?.total_sales_pkr ?? raw?.totalSalesPkr ?? raw?.sales_pkr ?? raw?.earned_pkr,
  );
  const remaining = toNumber(
    raw?.remaining_pkr ??
      raw?.remainingPkr ??
      Math.max(0, primaryTarget - totalSales),
  );
  const progressPercent = toNumber(
    raw?.progress_percent ??
      raw?.progressPercent ??
      (primaryTarget > 0 ? (totalSales / primaryTarget) * 100 : 0),
  );

  return {
    total_sales_pkr: totalSales,
    primary_target_pkr: primaryTarget,
    remaining_pkr: remaining,
    progress_percent: Math.min(100, Math.max(0, progressPercent)),
    rank:
      raw?.rank == null && raw?.Rank == null
        ? null
        : toNumber(raw.rank ?? raw.Rank) || null,
    achieved_tier: raw?.achieved_tier
      ? normalizeTier(raw.achieved_tier as Record<string, unknown>)
      : raw?.achievedTier
        ? normalizeTier(raw.achievedTier as Record<string, unknown>)
        : null,
  };
}

function normalizePayload(raw: unknown): CompetitionPayload | null {
  if (!raw || typeof raw !== "object") return null;

  const data = raw as Record<string, unknown>;
  const competitionRaw = (data.competition ?? data) as Record<string, unknown>;
  if (!competitionRaw?.title && !competitionRaw?.id) return null;

  const competition: CompetitionInfo = {
    id: toNumber(competitionRaw.id),
    title: String(competitionRaw.title ?? "Incentive Competition"),
    description:
      (competitionRaw.description as string | null | undefined) ?? null,
    starts_at: String(competitionRaw.starts_at ?? competitionRaw.startsAt ?? ""),
    ends_at: String(competitionRaw.ends_at ?? competitionRaw.endsAt ?? ""),
    status: String(competitionRaw.status ?? "running"),
    is_running: Boolean(
      competitionRaw.is_running ?? competitionRaw.isRunning ?? true,
    ),
    has_ended: Boolean(
      competitionRaw.has_ended ?? competitionRaw.hasEnded ?? false,
    ),
    days_remaining: toNumber(
      competitionRaw.days_remaining ?? competitionRaw.daysRemaining,
    ),
    primary_target_pkr: toNumber(
      competitionRaw.primary_target_pkr ?? competitionRaw.primaryTargetPkr,
    ),
  };

  const tiersRaw = Array.isArray(data.tiers) ? data.tiers : [];
  const tiers = tiersRaw.map((tier) =>
    normalizeTier(tier as Record<string, unknown>),
  );

  if (!competition.primary_target_pkr && tiers[0]?.target_pkr) {
    competition.primary_target_pkr = tiers[0].target_pkr;
  }

  const progressRaw =
    (data.my_progress ?? data.myProgress ?? data.progress) as
      | Record<string, unknown>
      | undefined;

  return {
    competition,
    tiers,
    my_progress: normalizeProgress(progressRaw, competition, tiers),
  };
}

function normalizeLeaderboardRow(raw: Record<string, unknown>): LeaderboardRow {
  return {
    rank: toNumber(raw.rank),
    user_id: toNumber(raw.user_id ?? raw.userId),
    name: String(raw.name ?? "User"),
    total_sales_pkr: toNumber(raw.total_sales_pkr ?? raw.totalSalesPkr),
    is_me: Boolean(raw.is_me ?? raw.isMe),
    profile_picture:
      (raw.profile_picture ?? raw.profilePicture ?? raw.profile_photo ?? null) as
        | string
        | null
        | undefined,
  };
}

interface ProgressBarProps {
  earned: number;
  target: number;
  compact?: boolean;
}

const ProgressBar: React.FC<ProgressBarProps> = ({
  earned,
  target,
  compact = false,
}) => {
  const { percent, remaining } = calcProgress(earned, target);
  const barWidth = percent > 0 ? Math.max(percent, 3) : 0;

  return (
    <div className={compact ? "mt-3" : ""}>
      <div className="flex items-center justify-between text-sm mb-1.5">
        <span className="font-medium">
          <span className="text-emerald-600 font-bold">
            {Math.round(earned).toLocaleString()}
          </span>
          <span className="text-gray-500">
            /{Math.round(target).toLocaleString()}
          </span>
        </span>
        <span className="text-xs text-gray-400">Sales (PKR)</span>
      </div>
      <div
        className={`w-full bg-gray-200 rounded-full overflow-hidden ${
          compact ? "h-2" : "h-2.5"
        }`}
      >
        <div
          className={`h-full rounded-full transition-all duration-500 ${
            percent >= 100
              ? "bg-emerald-500"
              : "bg-gradient-to-r from-emerald-400 to-emerald-600"
          }`}
          style={{ width: `${barWidth}%` }}
        />
      </div>
      <p className={`text-gray-500 ${compact ? "mt-1 text-xs" : "mt-1.5 text-sm"}`}>
        <span className="font-bold text-gray-900">{formatPkr(remaining)}</span>{" "}
        remaining to reach target
      </p>
    </div>
  );
};

function periodLabelFrom(startsAt: string, endsAt: string) {
  return `From ${formatShortDate(startsAt)} To ${formatShortDate(endsAt)}`;
}

const Competition: React.FC = () => {
  const [payload, setPayload] = useState<CompetitionPayload | null>(null);
  const [leaderboard, setLeaderboard] = useState<LeaderboardRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [infoOpen, setInfoOpen] = useState(false);

  useEffect(() => {
    let mounted = true;
    const load = async () => {
      try {
        setLoading(true);
        apiClient.refreshAuthToken();
        const [currentRes, boardRes] = await Promise.all([
          apiClient.get(API_ENDPOINTS.COMPETITION.CURRENT),
          apiClient.get(`${API_ENDPOINTS.COMPETITION.LEADERBOARD}?limit=50`),
        ]);

        if (!mounted) return;

        const boardData = (boardRes as any)?.data;
        const leaderboardRows = Array.isArray(boardData)
          ? boardData.map((row: Record<string, unknown>) =>
              normalizeLeaderboardRow(row),
            )
          : [];

        const normalizedPayload = normalizePayload((currentRes as any)?.data);
        if (normalizedPayload) {
          const meRow = leaderboardRows.find((row) => row.is_me);
          if (
            meRow &&
            meRow.total_sales_pkr > normalizedPayload.my_progress.total_sales_pkr
          ) {
            normalizedPayload.my_progress = normalizeProgress(
              {
                ...normalizedPayload.my_progress,
                total_sales_pkr: meRow.total_sales_pkr,
              },
              normalizedPayload.competition,
              normalizedPayload.tiers,
            );
          }
        }

        setPayload(normalizedPayload);
        setLeaderboard(leaderboardRows);
      } catch {
        if (mounted) {
          setPayload(null);
          setLeaderboard([]);
        }
      } finally {
        if (mounted) setLoading(false);
      }
    };
    load();
    return () => {
      mounted = false;
    };
  }, []);

  const competition = payload?.competition ?? null;
  const tiers = payload?.tiers ?? [];
  const progress = payload?.my_progress ?? null;

  const periodLabel = useMemo(() => {
    if (!competition) return "";
    return periodLabelFrom(competition.starts_at, competition.ends_at);
  }, [competition]);

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <Loader2 className="w-8 h-8 text-sky-600 animate-spin" />
      </div>
    );
  }

  if (!competition) {
    return (
      <div className="min-h-screen bg-gray-50 pb-10">
        <div className="max-w-2xl mx-auto px-3 sm:px-4 pt-8">
          <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-8 text-center">
            <Trophy className="w-12 h-12 text-gray-300 mx-auto mb-3" />
            <h1 className="text-xl font-bold text-gray-900 mb-1">
              Incentive Competitions
            </h1>
            <p className="text-sm text-gray-500">
              No competition running right now
            </p>
          </div>
        </div>
      </div>
    );
  }

  const salesPkr = progress?.total_sales_pkr ?? 0;
  const targetPkr =
    progress?.primary_target_pkr ||
    competition.primary_target_pkr ||
    tiers[0]?.target_pkr ||
    0;
  const remainingAmount =
    progress?.remaining_pkr ?? Math.max(0, targetPkr - salesPkr);
  const progressPct = calcProgress(salesPkr, targetPkr).percent;
  const daysLeft = competition.has_ended ? 0 : competition.days_remaining ?? 0;
  const isFinalized = competition.status === "finalized";
  const hasEnded = competition.has_ended || isFinalized;

  const meOnBoard = leaderboard.some((r) => r.is_me);

  return (
    <div className="min-h-screen bg-gray-50 pb-10">
      <div className="max-w-2xl mx-auto px-3 sm:px-4 pt-2 sm:pt-4 space-y-4">
        <div className="overflow-hidden rounded-3xl shadow-lg border border-gray-200">
          <img
            src={bannerImage}
            alt="SkyBridge Competition Banner"
            className="w-full h-auto object-cover"
          />
        </div>

        <div className="flex items-center gap-3 mb-2">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-sky-500 to-sky-700 flex items-center justify-center shadow-md">
            <Trophy className="w-5 h-5 text-white" />
          </div>
          <div>
            <h1 className="text-xl sm:text-2xl font-bold text-gray-900">
              Incentive Competitions
            </h1>
            <p className="text-sm text-gray-500">{periodLabel}</p>
          </div>
        </div>

        {(hasEnded || isFinalized) && (
          <div
            className={`rounded-xl px-4 py-3 text-sm font-medium ${
              isFinalized
                ? "bg-violet-50 text-violet-800 border border-violet-100"
                : "bg-amber-50 text-amber-800 border border-amber-100"
            }`}
          >
            {isFinalized
              ? "Results are locked in — winners have been decided."
              : "This competition has ended. Final standings are shown below."}
          </div>
        )}

        <div className="bg-white rounded-2xl shadow-md border border-gray-100 overflow-hidden">
          <div className="p-4 sm:p-5">
            <div className="flex items-start justify-between gap-3 mb-4">
              <h2 className="text-lg sm:text-xl font-bold text-gray-900 leading-snug">
                {competition.title}
              </h2>
              <button
                type="button"
                onClick={() => setInfoOpen(true)}
                className="shrink-0 text-sm font-semibold text-sky-600 hover:text-sky-800 flex items-center gap-1"
              >
                <Info className="w-4 h-4" />
                More Info
              </button>
            </div>

            <div className="grid grid-cols-3 gap-3 mb-5">
              <div>
                <p className="text-xs text-gray-500 mb-1">Start Date</p>
                <p className="text-sm font-semibold text-gray-900">
                  {formatDateLabel(competition.starts_at)}
                </p>
              </div>
              <div>
                <p className="text-xs text-gray-500 mb-1">End Date</p>
                <p className="text-sm font-semibold text-gray-900">
                  {formatDateLabel(competition.ends_at)}
                </p>
              </div>
              <div className="text-right">
                <p className="text-xs text-gray-500 mb-1 flex items-center justify-end gap-1">
                  <Clock className="w-3 h-3" />
                  Remaining
                </p>
                <p className="text-sm font-bold text-sky-700">
                  {hasEnded
                    ? "Ended"
                    : `${daysLeft} ${daysLeft === 1 ? "Day" : "Days"}`}
                </p>
              </div>
            </div>

            <div className="mb-4">
              <ProgressBar earned={salesPkr} target={targetPkr} />
              {progress?.rank != null && (
                <p className="mt-1.5 text-xs text-gray-500">
                  Your rank:{" "}
                  <span className="font-semibold text-gray-800">
                    #{progress.rank}
                  </span>
                </p>
              )}
            </div>

            <div className="mb-5">
              <p className="text-2xl sm:text-3xl font-extrabold text-gray-900">
                {formatPkr(remainingAmount)}
              </p>
              <p className="text-sm text-gray-500">
                Remaining Amount ({Math.round(progressPct)}% earned)
              </p>
            </div>

            <div className="relative w-full aspect-[4/3] rounded-xl overflow-hidden bg-gradient-to-br from-emerald-700 via-teal-600 to-sky-700">
              <div className="absolute inset-0 opacity-30 bg-[radial-gradient(circle_at_30%_20%,white,transparent_50%)]" />
              <div className="absolute inset-0 flex flex-col items-center justify-center text-white p-6 text-center">
                <Mountain className="w-14 h-14 mb-3 opacity-90" />
                <p className="text-2xl sm:text-3xl font-black tracking-wide uppercase line-clamp-2">
                  {competition.title}
                </p>
                <div className="mt-4 inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/20 text-xs font-semibold backdrop-blur-sm">
                  <Calendar className="w-3.5 h-3.5" />
                  {formatShortDate(competition.starts_at)} –{" "}
                  {formatShortDate(competition.ends_at)}
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="space-y-3">
          <h3 className="text-sm font-bold uppercase tracking-wide text-gray-500 px-1">
            Winner Prizes
          </h3>
          {tiers.map((t) => {
            const presentation = TIER_PRESENTATION[t.place] || {
              icon: <Trophy className="w-5 h-5" />,
              accent: "from-sky-400 to-sky-600",
            };
            const tierProgress = calcProgress(salesPkr, t.target_pkr);
            const met = t.achieved || tierProgress.percent >= 100;
            return (
              <div
                key={t.id}
                className={`bg-white rounded-xl border shadow-sm p-4 ${
                  met
                    ? "border-emerald-300 ring-1 ring-emerald-100"
                    : "border-gray-100"
                }`}
              >
                <div className="flex items-start gap-3">
                  <div
                    className={`w-10 h-10 rounded-full bg-gradient-to-br ${presentation.accent} flex items-center justify-center text-white shadow shrink-0`}
                  >
                    {presentation.icon}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-2">
                      <p className="font-bold text-gray-900">{t.title}</p>
                      {met ? (
                        <span className="text-[10px] font-bold uppercase bg-emerald-100 text-emerald-700 px-2 py-0.5 rounded-full">
                          Target Met
                        </span>
                      ) : (
                        <span className="text-[10px] font-bold uppercase bg-sky-100 text-sky-700 px-2 py-0.5 rounded-full">
                          {Math.round(tierProgress.percent)}%
                        </span>
                      )}
                    </div>
                    <p className="text-sm text-sky-700 font-semibold mt-0.5">
                      Target: {formatPkr(t.target_pkr)} Sales
                    </p>
                    <p className="text-sm text-gray-600 mt-1">{t.prize_label}</p>
                    <ProgressBar
                      earned={salesPkr}
                      target={t.target_pkr}
                      compact
                    />
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Leaderboard */}
        <div className="space-y-3">
          <h3 className="text-sm font-bold uppercase tracking-wide text-gray-500 px-1 flex items-center gap-2">
            <Users className="w-4 h-4" />
            Leaderboard
          </h3>
          <div className="bg-white rounded-xl border border-gray-100 shadow-sm overflow-hidden">
            {leaderboard.length === 0 ? (
              <p className="p-5 text-sm text-gray-500 text-center">
                No sales recorded yet. Be the first on the board!
              </p>
            ) : (
              <ul className="divide-y divide-gray-50">
                {leaderboard.map((row) => {
                  const imageUrl = row.profile_picture
                    ? resolveProfilePictureUrl(row.profile_picture)
                    : "";
                  const fallback = getAvatarFallbackUrl(row.name);
                  return (
                    <li
                      key={row.user_id}
                      className={`flex items-center justify-between gap-3 px-4 py-3 ${
                        row.is_me ? "bg-sky-50" : ""
                      }`}
                    >
                      <div className="flex items-center gap-3 min-w-0">
                        <span
                          className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold shrink-0 ${
                            row.rank <= 3
                              ? "bg-amber-100 text-amber-800"
                              : "bg-gray-100 text-gray-600"
                          }`}
                        >
                          {row.rank}
                        </span>
                        <div className="w-8 h-8 rounded-full overflow-hidden bg-sky-100 shrink-0">
                          <img
                            src={imageUrl || fallback}
                            alt={row.name}
                            className="w-full h-full object-cover"
                            loading="lazy"
                            onError={(e) => {
                              const target = e.currentTarget;
                              if (target.src !== fallback) {
                                target.onerror = null;
                                target.src = fallback;
                              }
                            }}
                          />
                        </div>
                        <div className="min-w-0">
                          <p className="font-semibold text-gray-900 truncate">
                            {row.name}
                            {row.is_me && (
                              <span className="ml-2 text-[10px] font-bold uppercase text-sky-700 bg-sky-100 px-1.5 py-0.5 rounded">
                                You
                              </span>
                            )}
                          </p>
                        </div>
                      </div>
                      <p className="text-sm font-bold text-gray-800 shrink-0">
                        {formatPkr(row.total_sales_pkr)}
                      </p>
                    </li>
                  );
                })}
              </ul>
            )}
            {!meOnBoard && progress?.rank != null && (
              <div className="border-t border-sky-100 bg-sky-50 px-4 py-3 flex items-center justify-between">
                <p className="text-sm text-sky-800">
                  Your standing:{" "}
                  <span className="font-bold">#{progress.rank}</span>
                </p>
                <p className="text-sm font-bold text-sky-900">
                  {formatPkr(salesPkr)}
                </p>
              </div>
            )}
          </div>
        </div>
      </div>

      {infoOpen && (
        <div
          className="fixed inset-0 z-50 bg-black/50 flex items-end sm:items-center justify-center p-0 sm:p-4"
          onClick={() => setInfoOpen(false)}
        >
          <div
            className="bg-white w-full sm:max-w-md sm:rounded-2xl rounded-t-2xl max-h-[85vh] overflow-y-auto shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="sticky top-0 bg-white border-b border-gray-100 px-5 py-4 flex items-center justify-between">
              <h3 className="text-lg font-bold text-gray-900">
                Competition Details
              </h3>
              <button
                type="button"
                onClick={() => setInfoOpen(false)}
                className="p-2 rounded-full hover:bg-gray-100"
                aria-label="Close"
              >
                <X className="w-5 h-5 text-gray-500" />
              </button>
            </div>
            <div className="p-5 space-y-4 text-sm text-gray-700">
              <p>
                <span className="font-semibold text-gray-900">Time Period:</span>{" "}
                {periodLabel}
              </p>
              <p>
                {competition.description ||
                  "Hit the sales targets below during the competition window to qualify for prizes. Top performers win based on ranking and target achievement."}
              </p>
              <ul className="space-y-3">
                {tiers.map((t) => (
                  <li
                    key={t.id}
                    className="rounded-xl bg-sky-50 border border-sky-100 p-3"
                  >
                    <p className="font-bold text-gray-900">{t.title}</p>
                    <p className="text-sky-700 font-medium">
                      Target: {formatPkr(t.target_pkr)} Sales
                    </p>
                    <p className="mt-1">{t.prize_label}</p>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Competition;