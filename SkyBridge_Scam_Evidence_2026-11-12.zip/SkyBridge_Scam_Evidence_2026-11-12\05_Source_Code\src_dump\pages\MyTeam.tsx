import React, { useState, useEffect, useMemo } from "react";
import {
  Users,
  TrendingUp,
  DollarSign,
  Award,
  UserPlus,
  Search,
  Filter,
  MoreVertical,
  ArrowLeft,
} from "lucide-react";
import { apiClient } from "../services/apiClient";
import { API_ENDPOINTS } from "../config/api";

interface TeamMember {
  id: number;
  name: string;
  email: string;
  joinDate: string;
  status: string;
  level: string;
  earnings: string;
  referrals: number;
  avatar: string;
}

interface ReferredMemberPlan {
  id: number;
  name: string;
  price_pkr: number;
  price_usd: string;
  is_active: boolean;
}

interface ReferredMembersAPIResponse {
  success: boolean;
  message: string;
  data: {
    referrer_email: string;
    referrer_name: string;
    total_referred_members: number;
    referred_members: Array<{
      member_name: string;
      member_email: string;
      joining_date: string;
      current_plan?: ReferredMemberPlan | null;
    }>;
  };
}

interface TeamStatsAPIResponse {
  success: boolean;
  message: string;
  data: {
    this_month_joined: number;
    total_all_time_joined: number;
    total_team_earnings: number;
    total_hierarchy_count: number;
  };
}

const MyTeam: React.FC = () => {
  const [currentPage, setCurrentPage] = useState(1);
  const [searchTerm, setSearchTerm] = useState("");
  const [levelFilter, setLevelFilter] = useState("All");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [teamMembers, setTeamMembers] = useState<TeamMember[]>([]);
  const [viewingTeamOf, setViewingTeamOf] = useState<string | null>(null); // Track which user's team we're viewing
  const itemsPerPage = 10;
  const [teamStatsData, setTeamStatsData] = useState({
    this_month_joined: 0,
    total_all_time_joined: 0,
    total_team_earnings: 0,
    total_hierarchy_count: 0,
  });

  // Get current user's email from localStorage
  const userData = localStorage.getItem("user");
  let currentUserEmail = "";
  if (userData) {
    try {
      const parsedUser = JSON.parse(userData);
      currentUserEmail = parsedUser.email || "";
    } catch (e) {
      console.warn("Failed to parse user data from localStorage");
    }
  }

  // Fetch team members and team stats on mount
  useEffect(() => {
    const fetchAll = async () => {
      try {
        setLoading(true);
        setError(null);

        const token = localStorage.getItem("access_token");
        if (!token) {
          throw new Error("Authentication required. Please log in.");
        }

        const membersReq = apiClient.post<{ referred_members: ReferredMembersAPIResponse["data"]["referred_members"] }>(
          API_ENDPOINTS.REFERRED_MEMBERS,
          { email: currentUserEmail }
        );

        const statsReq = apiClient.get<TeamStatsAPIResponse["data"]>(
          API_ENDPOINTS.USER.TEAM_STATS
        );

        const [membersRes, statsRes] = await Promise.all([
          membersReq,
          statsReq,
        ]);

        const membersData = membersRes.data as ReferredMembersAPIResponse["data"];
        const statsData = statsRes.data as TeamStatsAPIResponse["data"];

        const mappedMembers = (membersData.referred_members || []).map(
          (member, index) => ({
            id: index + 1,
            name: member.member_name,
            email: member.member_email,
            joinDate: member.joining_date.split(" ")[0], // YYYY-MM-DD
            status: "Active", // default — you can enhance this later
            level: member.current_plan?.name ?? "—",
            earnings: "$0.00", // placeholder — replace with real data if available
            referrals: 0, // placeholder
            avatar: member.member_name
              .split(" ")
              .map((n) => n[0])
              .join("")
              .toUpperCase()
              .slice(0, 2),
          })
        );

        setTeamMembers(mappedMembers);
        setTeamStatsData(statsData);
      } catch (err: any) {
        setError(err.message || "Failed to load team data");
      } finally {
        setLoading(false);
      }
    };

    fetchAll();
  }, []);

  // Handle viewing a specific member's team
  const handleViewTeam = async (memberEmail: string) => {
    try {
      setLoading(true);
      setError(null);

      const response = await apiClient.post<ReferredMembersAPIResponse["data"]>(
        API_ENDPOINTS.REFERRED_MEMBERS,
        { email: memberEmail }
      );

      const data = response.data;

      // Map API data to our TeamMember type
      const mappedMembers = (data.referred_members || []).map((member, index) => ({
        id: index + 1,
        name: member.member_name,
        email: member.member_email,
        joinDate: member.joining_date.split(" ")[0],
        status: "Active",
        level: member.current_plan?.name ?? "—",
        earnings: "$0.00",
        referrals: 0,
        avatar: member.member_name
          .split(" ")
          .map((n) => n[0])
          .join("")
          .toUpperCase()
          .slice(0, 2),
      }));

      setTeamMembers(mappedMembers);
      setViewingTeamOf(memberEmail);
      setCurrentPage(1); // Reset pagination
    } catch (err: any) {
      setError(err.message || "Failed to load team members");
    } finally {
      setLoading(false);
    }
  };

  // Go back to main team view
  const handleBackToMainTeam = () => {
    setViewingTeamOf(null);
    setCurrentPage(1);
    // Re-fetch main team (optional — you could cache it)
    // For now, just reset to initial state
  };

  // Filter and search logic
  const filteredMembers = useMemo(() => {
    return teamMembers.filter((member) => {
      const matchesSearch =
        member.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        member.email.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesLevel =
        levelFilter === "All" || member.level === levelFilter;
      return matchesSearch && matchesLevel;
    });
  }, [teamMembers, searchTerm, levelFilter]);

  // Pagination logic
  const totalPages = Math.ceil(filteredMembers.length / itemsPerPage);
  const startIndex = (currentPage - 1) * itemsPerPage;
  const endIndex = startIndex + itemsPerPage;
  const currentMembers = filteredMembers.slice(startIndex, endIndex);

  // Reset to first page when filters change
  React.useEffect(() => {
    setCurrentPage(1);
  }, [searchTerm, levelFilter]);

  const getLevelColor = (level: string) => {
    const l = level.toLowerCase();
    if (l.includes("premium"))
      return "bg-purple-100 text-purple-800 border-purple-200";
    if (l.includes("basic"))
      return "bg-orange-100 text-orange-800 border-orange-200";
    if (level === "—")
      return "bg-gray-100 text-gray-600 border-gray-200";
    return "bg-sky-100 text-sky-800 border-sky-200";
  };

  const planDistribution = useMemo(() => {
    const counts = new Map<string, number>();
    for (const m of teamMembers) {
      const key = m.level;
      counts.set(key, (counts.get(key) || 0) + 1);
    }
    const entries = [...counts.entries()].sort((a, b) => b[1] - a[1]);
    const max = Math.max(...entries.map(([, n]) => n), 1);
    return entries.map(([planName, count]) => ({
      planName,
      count,
      barPct: Math.round((count / max) * 100),
    }));
  }, [teamMembers]);

  // Team Stats — adjust based on actual data if available
  const teamStats = [
    {
      icon: Users,
      label: "Total Team Members",
      value: `${teamStatsData.total_hierarchy_count}`,
      color: "text-sky-600",
    },
    {
      icon: TrendingUp,
      label: "Active This Month",
      value: `${teamStatsData.this_month_joined}`,
      color: "text-green-600",
    },
    {
      icon: DollarSign,
      label: "Team Earnings",
      value: `$${Number(teamStatsData.total_team_earnings || 0).toFixed(2)}`,
      color: "text-purple-600",
    },
    {
      icon: Award,
      label: "Direct Members",
      value: `${teamStatsData.total_all_time_joined}`,
      color: "text-yellow-600",
    },
  ];

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-sky-50 via-white to-blue-50 p-3 sm:p-6">
        <div className="max-w-7xl mx-auto">
          {/* Header Skeleton */}
          <div className="mb-4 sm:mb-8">
            <div className="h-8 bg-gray-200 rounded w-48 mb-2"></div>
            <div className="h-4 bg-gray-200 rounded w-64"></div>
          </div>

          {/* Team Stats Skeleton */}
          <div className="grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-6 mb-4 sm:mb-8">
            {[...Array(4)].map((_, i) => (
              <div
                key={i}
                className="bg-white rounded-xl sm:rounded-2xl p-3 sm:p-6 shadow-lg"
              >
                <div className="flex items-center justify-between">
                  <div>
                    <div className="h-3 bg-gray-200 rounded w-20 mb-1"></div>
                    <div className="h-6 bg-gray-200 rounded w-24"></div>
                  </div>
                  <div className="w-8 h-8 bg-gray-200 rounded-full"></div>
                </div>
              </div>
            ))}
          </div>

          {/* Team Management Skeleton */}
          <div className="bg-white rounded-xl sm:rounded-2xl shadow-lg p-3 sm:p-6">
            <div className="flex flex-col space-y-3 sm:space-y-0 sm:flex-row justify-between items-start sm:items-center mb-4 sm:mb-6">
              <div className="h-6 bg-gray-200 rounded w-32"></div>
              <div className="flex flex-col sm:flex-row space-y-2 sm:space-y-0 sm:space-x-2 w-full sm:w-auto">
                <div className="h-10 bg-gray-200 rounded w-full sm:w-64"></div>
              </div>
            </div>

            {/* Table Skeleton */}
            <div className="hidden sm:block">
              <div className="bg-gray-50 h-10"></div>
              <div className="bg-white divide-y divide-gray-200">
                {[...Array(5)].map((_, i) => (
                  <div key={i} className="h-16 bg-gray-50"></div>
                ))}
              </div>
            </div>

            {/* Mobile Cards Skeleton */}
            <div className="sm:hidden">
              <div className="space-y-3">
                {[...Array(3)].map((_, i) => (
                  <div
                    key={i}
                    className="bg-gray-50 rounded-lg p-3 border border-gray-200"
                  >
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center">
                        <div className="w-8 h-8 bg-gray-200 rounded-full mr-2"></div>
                        <div>
                          <div className="h-4 bg-gray-200 rounded w-24 mb-1"></div>
                          <div className="h-3 bg-gray-200 rounded w-16"></div>
                        </div>
                      </div>
                      <div className="h-4 bg-gray-200 rounded w-16"></div>
                    </div>
                    <div className="grid grid-cols-2 gap-2 text-xs">
                      <div>
                        <div className="h-3 bg-gray-200 rounded w-12 mb-1"></div>
                        <div className="h-3 bg-gray-200 rounded w-24"></div>
                      </div>
                      <div>
                        <div className="h-3 bg-gray-200 rounded w-12 mb-1"></div>
                        <div className="h-3 bg-gray-200 rounded w-24"></div>
                      </div>
                      <div>
                        <div className="h-3 bg-gray-200 rounded w-12 mb-1"></div>
                        <div className="h-3 bg-gray-200 rounded w-24"></div>
                      </div>
                      <div>
                        <div className="h-3 bg-gray-200 rounded w-12 mb-1"></div>
                        <div className="h-3 bg-gray-200 rounded w-24"></div>
                      </div>
                    </div>
                    <div className="flex justify-between items-center mt-2">
                      <div className="h-5 bg-gray-200 rounded w-16"></div>
                      <div className="h-4 bg-gray-200 rounded w-4"></div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Pagination Skeleton */}
            <div className="flex flex-col sm:flex-row items-center justify-between mt-4 sm:mt-6 space-y-3 sm:space-y-0">
              <div className="h-4 bg-gray-200 rounded w-32"></div>
              <div className="flex space-x-1 sm:space-x-2">
                <div className="h-8 bg-gray-200 rounded w-16"></div>
                <div className="h-8 bg-gray-200 rounded w-8"></div>
                <div className="h-8 bg-gray-200 rounded w-8"></div>
                <div className="h-8 bg-gray-200 rounded w-16"></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-sky-50 via-white to-blue-50 p-3 sm:p-6">
        <div className="max-w-7xl mx-auto">
          {/* Header */}
          <div className="mb-4 sm:mb-8">
            <h1 className="text-2xl sm:text-4xl font-bold bg-gradient-to-r from-sky-600 to-sky-700 bg-clip-text text-transparent mb-1 sm:mb-2">
              My Team
            </h1>
            <p className="text-gray-600 text-sm sm:text-lg">
              Manage and Track Your Team Performance
            </p>
          </div>

          {/* Error Message */}
          <div className="bg-red-50 border-l-4 border-red-500 p-4 mb-6">
            <h2 className="text-xl font-bold text-red-800">
              Error Loading Team
            </h2>
            <p className="text-red-700 mt-2">{error}</p>
            <button
              onClick={() => window.location.reload()}
              className="mt-3 px-4 py-2 bg-red-600 text-white rounded hover:bg-red-700"
            >
              Retry
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-sky-50 via-white to-blue-50 p-3 sm:p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-4 sm:mb-8">
          {/* Back Button if viewing someone else's team */}
          {viewingTeamOf && (
            <button
              onClick={handleBackToMainTeam}
              className="flex items-center space-x-2 mb-2 text-sky-600 hover:text-sky-900 text-sm font-medium"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>Back to My Team</span>
            </button>
          )}
          <h1 className="text-2xl sm:text-4xl font-bold bg-gradient-to-r from-sky-600 to-sky-700 bg-clip-text text-transparent mb-1 sm:mb-2">
            {viewingTeamOf ? `Team of ${viewingTeamOf}` : "My Team"}
          </h1>
          <p className="text-gray-600 text-sm sm:text-lg">
            {viewingTeamOf
              ? `Manage and track the performance of ${viewingTeamOf}'s team`
              : "Manage and Track Your Team Performance"}
          </p>
        </div>

        {/* Team Stats */}
        <div className="grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-6 mb-4 sm:mb-8">
          {teamStats.map((stat, index) => (
            <div
              key={index}
              className="bg-white rounded-xl sm:rounded-2xl p-3 sm:p-6 shadow-lg"
            >
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-600 text-xs sm:text-sm font-medium">
                    {stat.label}
                  </p>
                  <p className="text-lg sm:text-3xl font-bold text-gray-900 mt-1">
                    {stat.value}
                  </p>
                </div>
                <div
                  className={`p-2 sm:p-3 rounded-lg sm:rounded-xl bg-gray-50`}
                >
                  <stat.icon
                    className={`w-5 h-5 sm:w-8 sm:h-8 ${stat.color}`}
                  />
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Team Management */}
        <div className="bg-white rounded-xl sm:rounded-2xl shadow-lg p-3 sm:p-6">
          {/* Header with Actions */}
          <div className="flex flex-col space-y-3 sm:space-y-0 sm:flex-row justify-between items-start sm:items-center mb-4 sm:mb-6">
            <h2 className="text-xl sm:text-2xl font-bold text-gray-900">
              Team Members
            </h2>
            <div className="flex flex-col sm:flex-row space-y-2 sm:space-y-0 sm:space-x-2 w-full sm:w-auto">
              <div className="relative">
                <Search className="w-4 h-4 sm:w-5 sm:h-5 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                <input
                  type="text"
                  placeholder="Search by name or email..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-9 sm:pl-10 pr-4 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-sky-500 focus:border-transparent w-full sm:w-64 text-sm sm:text-base"
                />
              </div>
            </div>
          </div>

          {/* Team Members - Mobile Cards */}
          <div className="sm:hidden">
            <div className="space-y-3">
              {currentMembers.map((member) => (
                <div
                  key={member.id}
                  className="bg-gray-50 rounded-lg p-3 border border-gray-200"
                >
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center">
                      <div className="w-8 h-8 bg-gradient-to-r from-sky-600 to-sky-700 rounded-full flex items-center justify-center text-white font-bold text-sm mr-2">
                        {member.avatar}
                      </div>
                      <div>
                        <p className="font-semibold text-gray-900 text-sm">
                          {member.name}
                        </p>
                        <p className="text-gray-600 text-xs">#{member.id}</p>
                      </div>
                    </div>
                    <span
                      className={`px-2 py-1 rounded-full text-xs font-semibold border ${getLevelColor(
                        member.level
                      )}`}
                    >
                      {member.level}
                    </span>
                  </div>

                  <div className="grid grid-cols-2 gap-2 text-xs">
                    <div>
                      <span className="text-gray-500">Email:</span>
                      <p className="text-gray-700 truncate">{member.email}</p>
                    </div>
                    <div>
                      <span className="text-gray-500">Join Date:</span>
                      <p className="text-gray-700">
                        {new Date(member.joinDate).toLocaleDateString()}
                      </p>
                    </div>
                    <div>
                      <span className="text-gray-500">Earnings:</span>
                      <p className="font-semibold text-gray-900">
                        {member.earnings}
                      </p>
                    </div>
                    <div>
                      <span className="text-gray-500">Referrals:</span>
                      <p className="text-gray-700">{member.referrals}</p>
                    </div>
                  </div>

                  <div className="flex justify-between items-center mt-2">
                    <span
                      className={`text-xs px-2 py-1 rounded-full ${
                        member.status === "Active"
                          ? "bg-green-100 text-green-800"
                          : "bg-red-100 text-red-800"
                      }`}
                    >
                      {member.status}
                    </span>
                    <button
                      onClick={() => handleViewTeam(member.email)}
                      className="p-1 hover:bg-gray-200 rounded transition-colors"
                    >
                      <MoreVertical className="w-4 h-4 text-gray-600" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Team Members Table - Desktop */}
          <div className="hidden sm:block overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-gray-200">
                  <th className="text-left py-3 px-3 font-semibold text-gray-900 text-sm">
                    ID
                  </th>
                  <th className="text-left py-3 px-3 font-semibold text-gray-900 text-sm">
                    Member
                  </th>
                  <th className="text-left py-3 px-3 font-semibold text-gray-900 text-sm">
                    Join Date
                  </th>
                  <th className="text-left py-3 px-3 font-semibold text-gray-900 text-sm">
                    Plan
                  </th>
                  <th className="text-left py-3 px-3 font-semibold text-gray-900 text-sm">
                    Earnings
                  </th>
                  <th className="text-left py-3 px-3 font-semibold text-gray-900 text-sm">
                    Referrals
                  </th>
                </tr>
              </thead>
              <tbody>
                {currentMembers.map((member) => (
                  <tr
                    key={member.id}
                    className="border-b border-gray-100 hover:bg-gray-50 transition-colors"
                  >
                    <td className="py-3 px-3">
                      <span className="font-bold text-sky-600 text-sm">
                        #{member.id}
                      </span>
                    </td>
                    <td className="py-3 px-3">
                      <div className="flex items-center">
                        <div className="w-8 h-8 bg-gradient-to-r from-sky-600 to-sky-700 rounded-full flex items-center justify-center text-white font-bold text-sm mr-3">
                          {member.avatar}
                        </div>
                        <div>
                          <p className="font-semibold text-gray-900 text-sm">
                            {member.name}
                          </p>
                          <p
                            onClick={() => handleViewTeam(member.email)}
                            className="text-gray-600 text-xs cursor-pointer hover:text-sky-600 underline"
                            title="View this member's team"
                          >
                            {member.email}
                          </p>
                        </div>
                      </div>
                    </td>
                    <td className="py-3 px-3 text-gray-600 text-sm">
                      {new Date(member.joinDate).toLocaleDateString()}
                    </td>
                    <td className="py-3 px-3 text-sm">
                      <span
                        className={`inline-flex px-2 py-0.5 rounded-full text-xs font-semibold border ${getLevelColor(
                          member.level
                        )}`}
                      >
                        {member.level}
                      </span>
                    </td>
                    <td className="py-3 px-3 font-semibold text-gray-900 text-sm">
                      {member.earnings}
                    </td>
                    <td className="py-3 px-3 text-gray-600 text-sm">
                      {member.referrals}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Pagination */}
          <div className="flex flex-col sm:flex-row items-center justify-between mt-4 sm:mt-6 space-y-3 sm:space-y-0">
            <p className="text-gray-600 text-xs sm:text-sm">
              Showing {startIndex + 1}-
              {Math.min(endIndex, filteredMembers.length)} of{" "}
              {filteredMembers.length} members
            </p>
            <div className="flex space-x-1 sm:space-x-2">
              <button
                onClick={() => setCurrentPage((prev) => Math.max(prev - 1, 1))}
                disabled={currentPage === 1}
                className="px-2 sm:px-3 py-1 sm:py-2 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors disabled:opacity-50 disabled:cursor-not-allowed text-xs sm:text-sm"
              >
                Previous
              </button>

              {/* Page Numbers */}
              {Array.from({ length: totalPages }, (_, i) => i + 1).map(
                (pageNum) => {
                  if (
                    pageNum === 1 ||
                    pageNum === totalPages ||
                    (pageNum >= currentPage - 1 && pageNum <= currentPage + 1)
                  ) {
                    return (
                      <button
                        key={pageNum}
                        onClick={() => setCurrentPage(pageNum)}
                        className={`px-2 sm:px-3 py-1 sm:py-2 rounded-lg transition-colors text-xs sm:text-sm ${
                          currentPage === pageNum
                            ? "bg-sky-600 text-white"
                            : "border border-gray-200 hover:bg-gray-50"
                        }`}
                      >
                        {pageNum}
                      </button>
                    );
                  } else if (
                    pageNum === currentPage - 2 ||
                    pageNum === currentPage + 2
                  ) {
                    return (
                      <span
                        key={pageNum}
                        className="px-1 sm:px-2 text-gray-400 text-xs"
                      >
                        ...
                      </span>
                    );
                  }
                  return null;
                }
              )}

              <button
                onClick={() =>
                  setCurrentPage((prev) => Math.min(prev + 1, totalPages))
                }
                disabled={currentPage === totalPages}
                className="px-2 sm:px-3 py-1 sm:py-2 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors disabled:opacity-50 disabled:cursor-not-allowed text-xs sm:text-sm"
              >
                Next
              </button>
            </div>
          </div>
        </div>

        {/* Team Performance Chart */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 sm:gap-8 mt-4 sm:mt-8">
          <div className="bg-white rounded-xl sm:rounded-2xl shadow-lg p-4 sm:p-6">
            <h3 className="text-lg sm:text-xl font-bold text-gray-900 mb-3 sm:mb-4">
              Plans in this view
            </h3>
            <div className="space-y-3 sm:space-y-4">
              {planDistribution.length === 0 ? (
                <p className="text-sm text-gray-500">No members to show.</p>
              ) : (
                planDistribution.map(({ planName, count, barPct }) => (
                  <div
                    key={planName}
                    className="flex items-center justify-between gap-2"
                  >
                    <span className="text-gray-600 text-sm sm:text-base truncate max-w-[40%]">
                      {planName}
                    </span>
                    <div className="flex items-center space-x-2 min-w-0 flex-1 justify-end">
                      <div className="w-20 sm:w-32 bg-gray-200 rounded-full h-2 shrink-0">
                        <div
                          className="bg-sky-500 h-2 rounded-full transition-all"
                          style={{ width: `${barPct}%` }}
                        />
                      </div>
                      <span className="text-xs sm:text-sm font-semibold text-gray-900 whitespace-nowrap">
                        {count} {count === 1 ? "member" : "members"}
                      </span>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MyTeam;
