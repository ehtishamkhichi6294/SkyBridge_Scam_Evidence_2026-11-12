import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import {
  KeyRound,
  Copy,
  Check,
  Loader2,
  ChevronLeft,
  ChevronRight,
} from "lucide-react";
import { toast } from "react-toastify";
import { pinService, AccountPin } from "../services/pinService";
import { copyToClipboard } from "../utils/clipboard";
import { getDisplayNameForPlan } from "../constants/plans";

type StatusFilter = "all" | "unused" | "used";

const MyPins: React.FC = () => {
  const [pins, setPins] = useState<AccountPin[]>([]);
  const [statusFilter, setStatusFilter] = useState<StatusFilter>("all");
  const [loading, setLoading] = useState(true);
  const [currentPage, setCurrentPage] = useState(1);
  const [lastPage, setLastPage] = useState(1);
  const [copiedId, setCopiedId] = useState<number | null>(null);

  useEffect(() => {
    void fetchPins();
  }, [statusFilter, currentPage]);

  const fetchPins = async () => {
    setLoading(true);
    try {
      const res = await pinService.getPins({
        status: statusFilter === "all" ? undefined : statusFilter,
        page: currentPage,
      });
      setPins(res?.data?.data ?? []);
      setLastPage(res?.data?.last_page ?? 1);
    } catch {
      toast.error("Failed to load PINs");
    } finally {
      setLoading(false);
    }
  };

  const handleCopy = async (pin: AccountPin) => {
    const ok = await copyToClipboard(pin.pin_code);
    if (ok) {
      setCopiedId(pin.id);
      toast.success("PIN copied");
      setTimeout(() => setCopiedId(null), 2000);
    }
  };

  const formatDate = (d: string) =>
    new Date(d).toLocaleDateString("en-US", {
      year: "numeric",
      month: "short",
      day: "numeric",
    });

  return (
    <div className="p-4 sm:p-6 max-w-5xl mx-auto">
      <h1 className="text-2xl font-bold text-gray-900 flex items-center gap-2 mb-1">
        <KeyRound className="w-7 h-7 text-blue-600" />
        My PINs
      </h1>
      <p className="text-gray-600 mb-6">
        PINs you purchased. Use them from{" "}
        <Link to="/pin/create-account" className="text-blue-600 hover:underline">
          Create Account with PIN
        </Link>
        .
      </p>

      <div className="flex flex-wrap gap-2 mb-6">
        {(["all", "unused", "used"] as StatusFilter[]).map((s) => (
          <button
            key={s}
            type="button"
            onClick={() => {
              setStatusFilter(s);
              setCurrentPage(1);
            }}
            className={`px-4 py-2 rounded-lg text-sm font-medium ${
              statusFilter === s
                ? "bg-blue-600 text-white"
                : "bg-gray-100 text-gray-700 hover:bg-gray-200"
            }`}
          >
            {s === "all" ? "All" : s.charAt(0).toUpperCase() + s.slice(1)}
          </button>
        ))}
      </div>

      {loading ? (
        <div className="flex justify-center py-12">
          <Loader2 className="w-8 h-8 animate-spin text-blue-600" />
        </div>
      ) : pins.length === 0 ? (
        <div className="text-center py-12 bg-white rounded-xl border border-gray-200">
          <p className="text-gray-600 mb-4">
            You don&apos;t have any PINs yet. Visit Buy PIN to request one.
          </p>
          <Link
            to="/buy-pin"
            className="inline-block px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
          >
            Buy PIN
          </Link>
        </div>
      ) : (
        <>
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="bg-gray-50 border-b border-gray-200">
                    <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase">
                      PIN Code
                    </th>
                    <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase">
                      Plan
                    </th>
                    <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase">
                      Status
                    </th>
                    <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase">
                      Created
                    </th>
                    <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase">
                      Used By
                    </th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100">
                  {pins.map((pin) => (
                    <tr key={pin.id} className="hover:bg-gray-50">
                      <td className="px-4 py-3">
                        <PinCodeCell pin={pin} copiedId={copiedId} onCopy={handleCopy} />
                      </td>
                      <td className="px-4 py-3 text-sm">
                        {getDisplayNameForPlan(pin.plan?.name ?? "")}
                      </td>
                      <td className="px-4 py-3">
                        <span
                          className={`inline-flex px-2.5 py-1 rounded-full text-xs font-medium ${
                            pin.status === "unused"
                              ? "bg-green-100 text-green-800"
                              : "bg-gray-100 text-gray-600"
                          }`}
                        >
                          {pin.status}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-sm text-gray-500">
                        {formatDate(pin.created_at)}
                      </td>
                      <td className="px-4 py-3 text-sm text-gray-700">
                        {pin.used_by ? (
                          <>
                            <div>{pin.used_by.name}</div>
                            <div className="text-gray-500 text-xs">
                              {pin.used_by.email}
                            </div>
                          </>
                        ) : (
                          "—"
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {lastPage > 1 && (
            <div className="flex items-center justify-center gap-2 mt-4">
              <button
                type="button"
                onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
                disabled={currentPage === 1}
                className="p-2 rounded-lg bg-gray-100 hover:bg-gray-200 disabled:opacity-50"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>
              <span className="text-sm text-gray-600">
                Page {currentPage} of {lastPage}
              </span>
              <button
                type="button"
                onClick={() =>
                  setCurrentPage((p) => Math.min(lastPage, p + 1))
                }
                disabled={currentPage === lastPage}
                className="p-2 rounded-lg bg-gray-100 hover:bg-gray-200 disabled:opacity-50"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          )}
        </>
      )}
    </div>
  );
};

function PinCodeCell({
  pin,
  copiedId,
  onCopy,
}: {
  pin: AccountPin;
  copiedId: number | null;
  onCopy: (pin: AccountPin) => void;
}) {
  return (
    <div className="flex items-center gap-2">
      <code className="font-mono text-sm">{pin.pin_code}</code>
      <button
        type="button"
        onClick={() => onCopy(pin)}
        className="p-1.5 rounded hover:bg-gray-100 text-gray-600"
        title="Copy PIN"
      >
        {copiedId === pin.id ? (
          <Check className="w-4 h-4 text-green-600" />
        ) : (
          <Copy className="w-4 h-4" />
        )}
      </button>
    </div>
  );
}

export default MyPins;
