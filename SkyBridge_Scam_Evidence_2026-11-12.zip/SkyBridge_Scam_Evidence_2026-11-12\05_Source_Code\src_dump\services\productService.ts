import { apiClient } from './apiClient';
import { API_ENDPOINTS } from '../config/api';

export interface Product {
  id: number;
  admin_id: number;
  name: string;
  price: string;
  original_price?: string;
  user_profit_percentage: string;
  category: string;
  description: string;
  images: string[];
  video?: string;
  is_out_of_stock?: boolean;
  created_at: string;
  updated_at: string;
  // Computed/helper properties
  inStock?: boolean;
  image?: string;
  earningPerSale?: number;
}

export interface PaginationLink {
  url: string | null;
  label: string;
  page: number | null;
  active: boolean;
}

export interface PaginatedProductsResponse {
  current_page: number;
  data: Product[];
  first_page_url: string;
  from: number;
  last_page: number;
  last_page_url: string;
  links: PaginationLink[];
  next_page_url: string | null;
  path: string;
  per_page: number;
  prev_page_url: string | null;
  to: number;
  total: number;
}

export interface ListProductsParams {
  category?: string;
  search?: string;
  page?: number;
  per_page?: number;
}

export const productService = {
  async listProducts(params: ListProductsParams = {}) {
    const query = new URLSearchParams();
    if (params.category) query.set('category', params.category);
    if (params.search) query.set('search', params.search);
    if (params.page) query.set('page', params.page.toString());
    if (params.per_page) query.set('per_page', params.per_page.toString());
    const endpoint = `${API_ENDPOINTS.PRODUCTS}${query.toString() ? `?${query.toString()}` : ''}`;
    return apiClient.get<PaginatedProductsResponse>(endpoint);
  },

  async getProductById(productId: number | string) {
    return apiClient.get<Product>(`${API_ENDPOINTS.PRODUCTS}/${productId}`);
  },
};

