// Base URL from environment (Vite exposes only VITE_* vars)
const envBaseUrl = import.meta.env.VITE_API_BASE_URL;
const envAppUrl = import.meta.env.VITE_APP_URL;

// API Configuration
export const API_CONFIG = {
  BASE_URL: typeof envBaseUrl === "string" && envBaseUrl
    ? envBaseUrl.replace(/\/$/, "")
    : "https://backend.sky-bridge-international.com/api",
  APP_URL: (typeof envAppUrl === "string" && envAppUrl
    ? envAppUrl.replace(/\/$/, "")
    : "https://sky-bridge-international.com").replace("https://backend.sky-bridge-international.com", "https://sky-bridge-international.com"),
  TIMEOUT: 30000,
  HEADERS: {
    "Content-Type": "application/json",
    Accept: "application/json",
  },
} as const;

// API Endpoints - paths only (no base URL)
export const API_ENDPOINTS = {
  AUTH: {
    LOGIN: "/auth/login",
    LOGOUT: "/auth/logout",
    REGISTER: "/auth/signup",
    PASSWORD_RESET_REQUEST_OTP: "/password-reset/request-otp",
    PASSWORD_RESET_VERIFY_OTP: "/password-reset/verify-otp",
    PASSWORD_RESET_RESET: "/password-reset/reset",
    PASSWORD_RESET_REQUEST: "/password-reset-request",
  },
  USER: {
    PROFILE: "/user/profile",
    USER_DASHBOARD: "/user/user-dashboard",
    CHANGE_PASSWORD: "/user/change-password",
    CHANGE_ACCOUNT_DETAILS: "/user/change-account-details",
    REFERRAL_COUNT: "/user/referral-count",
    TODAY_REFERRAL_COUNT: "/user/today-referral-count",
    CLAIM_REWARD: "/user/claim-reward",
    TEAM_STATS: "/user/team-stats",
    AD_EARNINGS_SUMMARY: "/user/ad/earnings-summary",
  },
  AD: {
    TODAY: "/ad/today",
    WATCH: "/ad/watch",
  },
  REFERRED_MEMBERS: "/referred-members",
  WITHDRAWALS: {
    HISTORY: "/user/withdrawal/history",
    SUBMIT: "/user/withdrawal/request",
    STATS: "/user/withdrawal/stats",
    DETAILS: "/user/withdrawal/:id",
    RULES: "/user/withdrawal/rules",
  },
  NOTIFICATIONS: {
    LIST: "/notifications",
    UNREAD_COUNT: "/notifications/unread-count",
    MARK_READ: "/notifications/mark-read",
  },
  // Plans endpoint
  PLANS: "/plans",
  // Health check endpoint
  HEALTH: "/health",
  COURSES: "/courses",
  ACCOUNT: "/account",
  CRYPTO_NETWORKS: "/crypto-networks",
  PRODUCTS: "/products",
  PURCHASE_REQUESTS: "/user/purchase-requests",
  PURCHASE_REQUESTS_EARNINGS: "/user/purchase-requests/earnings",
  // Plan upgrade endpoints
  PLAN_UPGRADE: "/user/plan-upgrade",
  PLAN_UPGRADE_HISTORY: "/user/plan-upgrade/history",
  // PIN purchase & management
  PIN: {
    REQUESTS: "/user/pin-requests",
    PINS: "/user/pins",
    CREATE_ACCOUNT: "/user/pins/create-account",
    SIGNUP_OFFER_TODAY: "/pin-signup-offer/today",
  },
  COMPETITION: {
    CURRENT: "/competition/current",
    LEADERBOARD: "/competition/leaderboard",
  },
} as const;

// Environment-based configuration
export const getApiConfig = () => {
  const isDevelopment = import.meta.env.DEV;
  return {
    ...API_CONFIG,
    DEBUG: isDevelopment,
  };
};
