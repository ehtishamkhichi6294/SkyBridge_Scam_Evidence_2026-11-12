import React, { useState, useEffect, useCallback } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../contexts/AuthContext";
import { useCurrency } from "../contexts/CurrencyContext";
import { API_ENDPOINTS } from "../config/api";
import { apiClient } from "../services/apiClient";
import { pinService, PinServiceError } from "../services/pinService";
import {
  Upload,
  CheckCircle,
  AlertCircle,
  Loader2,
  ArrowLeft,
  KeyRound,
  Plus,
  Trash2,
} from "lucide-react";
import { toast } from "react-toastify";
import { getDisplayNameForPlan } from "../constants/plans";

interface PlanOption {
  id: number;
  name: string;
  price_pkr: number;
  price_usd: number | string;
}

interface CartRow {
  id: number;
  planId: number | null;
  quantity: number | null;
}

let rowCounter = 0;
const newRow = (): CartRow => ({
  id: ++rowCounter,
  planId: null,
  quantity: null,
});

const BuyPin: React.FC = () => {
  const { isAuthenticated } = useAuth();
  const navigate = useNavigate();
  const { formatCurrency, currency } = useCurrency();

  const [plans, setPlans] = useState<PlanOption[]>([]);
  const [accountDetailsList, setAccountDetailsList] = useState<
    {
      id?: number;
      account_title: string;
      account_number: string;
      bank?: string;
    }[]
  >([
    {
      account_title: "Sky Bridge International",
      account_number: "1234567890",
      bank: "HBL",
    },
    {
      account_title: "Sky Bridge International",
      account_number: "0312-3456789",
      bank: "EasyPaisa",
    },
    {
      account_title: "Sky Bridge International",
      account_number: "0332-9876543",
      bank: "JazzCash",
    },
  ]);
  const [cart, setCart] = useState<CartRow[]>([newRow()]);
  const [transactionId, setTransactionId] = useState("");
  const [transactionAccountNumber, setTransactionAccountNumber] = useState("");
  const [transactionAccountTitle, setTransactionAccountTitle] = useState("");
  const [screenshot, setScreenshot] = useState<File | null>(null);
  const [screenshotPreview, setScreenshotPreview] = useState<string | null>(
    null,
  );
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState("");
  const [fieldErrors, setFieldErrors] = useState<Record<string, string>>({});
  const [successData, setSuccessData] = useState<{
    totalPkr: string;
    totalUsd: string;
    totalPins: number;
  } | null>(null);

  useEffect(() => {
    if (!isAuthenticated) {
      navigate("/login");
      return;
    }
    void fetchData();
  }, [isAuthenticated, navigate]);

  const fetchData = async () => {
    setLoading(true);
    setError("");
    try {
      const [plansResult, accountResult] = await Promise.allSettled([
        apiClient.get<PlanOption[]>(API_ENDPOINTS.PLANS),
        apiClient.get<
          | { account_title: string; account_number: string; bank?: string }[]
          | { account_title: string; account_number: string; bank?: string }
        >(`${API_ENDPOINTS.ACCOUNT}?type=pin_purchase`),
      ]);

      if (plansResult.status === "fulfilled") {
        const data = plansResult.value.data;
        setPlans(Array.isArray(data) ? data : []);
      } else {
        setError("Failed to load plans. Please try again.");
      }

      if (accountResult.status === "fulfilled") {
        const data = accountResult.value.data;
        const list = Array.isArray(data) ? data : data ? [data] : [];
        if (list.length > 0) setAccountDetailsList(list);
      }
    } finally {
      setLoading(false);
    }
  };

  const planPrice = useCallback(
    (plan: PlanOption) => {
      if (currency === "PKR") {
        const pkr = Number(plan.price_pkr);
        return `₨${pkr.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
      }
      return formatCurrency(Number(plan.price_usd));
    },
    [currency, formatCurrency],
  );

  const rowSubtotal = (row: CartRow): { pkr: number; usd: number } => {
    const plan = plans.find((p) => p.id === row.planId);
    if (!plan) return { pkr: 0, usd: 0 };
    const qty = row.quantity ?? 0;
    return {
      pkr: Number(plan.price_pkr) * qty,
      usd: Number(plan.price_usd) * qty,
    };
  };

  const totals = cart.reduce(
    (acc, row) => {
      const sub = rowSubtotal(row);
      return { pkr: acc.pkr + sub.pkr, usd: acc.usd + sub.usd };
    },
    { pkr: 0, usd: 0 },
  );

  const totalPins = cart.reduce(
    (acc, row) => acc + (row.planId ? (row.quantity ?? 0) : 0),
    0,
  );

  const addRow = () => {
    setCart((prev) => [...prev, newRow()]);
  };

  const removeRow = (id: number) => {
    setCart((prev) =>
      prev.length === 1 ? prev : prev.filter((r) => r.id !== id),
    );
  };

  const updatePlan = (id: number, planId: number | null) => {
    setCart((prev) => prev.map((r) => (r.id === id ? { ...r, planId } : r)));
  };

  const updateQty = (id: number, qty: number) => {
    const clamped = Math.max(1, Math.min(100, qty));
    setCart((prev) =>
      prev.map((r) => (r.id === id ? { ...r, quantity: clamped } : r)),
    );
  };

  const usedPlanIds = (excludeRowId: number) =>
    cart
      .filter((r) => r.id !== excludeRowId && r.planId !== null)
      .map((r) => r.planId);

  const handleScreenshotChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const allowed = ["image/jpeg", "image/png", "image/jpg", "image/webp"];
    if (!allowed.includes(file.type)) {
      setError("Please upload a valid image (JPG, PNG, WEBP)");
      return;
    }
    if (file.size > 5 * 1024 * 1024) {
      setError("Image must be less than 5MB");
      return;
    }
    setScreenshot(file);
    setError("");
    const reader = new FileReader();
    reader.onload = (ev) => setScreenshotPreview(ev.target?.result as string);
    reader.readAsDataURL(file);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setFieldErrors({});

    const validRows = cart.filter((r) => r.planId !== null);
    if (validRows.length === 0) {
      setError("Please add at least one plan to your cart");
      return;
    }
    if (!transactionId.trim()) {
      setError("Please enter the transaction ID");
      return;
    }
    if (!transactionAccountNumber.trim()) {
      setError("Please enter your account number");
      return;
    }
    if (!transactionAccountTitle.trim()) {
      setError("Please enter your account title");
      return;
    }
    if (!screenshot) {
      setError("Please upload a payment screenshot");
      return;
    }

    setSubmitting(true);
    try {
      const res = await pinService.submitPinRequest({
        items: validRows.map((r) => ({
          planId: r.planId!,
          quantity: r.quantity ?? 1,
        })),
        transactionId: transactionId.trim(),
        transactionAccountNumber: transactionAccountNumber.trim(),
        transactionAccountTitle: transactionAccountTitle.trim(),
        transactionScreenshot: screenshot,
      });

      const data = res?.data as any;
      setSuccessData({
        totalPkr: data?.amount_pkr ?? String(totals.pkr.toFixed(2)),
        totalUsd: data?.amount_usd ?? String(totals.usd.toFixed(2)),
        totalPins: data?.total_pins_requested ?? totalPins,
      });
      toast.success("PIN purchase request submitted successfully");
    } catch (err) {
      if (err instanceof PinServiceError) {
        setFieldErrors(err.fieldErrors);
        const firstErr =
          err.fieldErrors.transaction_id ||
          err.fieldErrors.items ||
          err.message ||
          "Failed to submit request";
        setError(firstErr);
      } else {
        setError(
          err instanceof Error ? err.message : "Failed to submit request",
        );
      }
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-blue-600" />
      </div>
    );
  }

  if (successData) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 py-8 px-4">
        <div className="bg-white rounded-2xl shadow-xl p-8 text-center max-w-lg mx-auto w-full">
          <CheckCircle className="w-16 h-16 text-green-500 mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-gray-900 mb-2">
            Request Submitted!
          </h2>
          <p className="text-gray-600 mb-4">
            Your PIN purchase request is pending admin review.
          </p>
          <div className="bg-gray-50 rounded-xl p-4 text-sm text-left mb-6 space-y-1">
            <p>
              <span className="text-gray-500">Total PINs:</span>{" "}
              <span className="font-bold">{successData.totalPins}</span>
            </p>
            <p>
              <span className="text-gray-500">Total (PKR):</span>{" "}
              <span className="font-bold">
                ₨
                {Number(successData.totalPkr).toLocaleString("en-US", {
                  minimumFractionDigits: 2,
                })}
              </span>
            </p>
            <p>
              <span className="text-gray-500">Total (USD):</span>{" "}
              <span className="font-bold">
                {formatCurrency(Number(successData.totalUsd))}
              </span>
            </p>
          </div>
          <div className="flex flex-col sm:flex-row gap-3 justify-center">
            <Link
              to="/pin-requests"
              className="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition"
            >
              View My Requests
            </Link>
            <button
              type="button"
              onClick={() => navigate("/dashboard")}
              className="px-6 py-3 border border-gray-300 rounded-lg hover:bg-gray-50"
            >
              Dashboard
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 py-8 px-4">
      <div className="max-w-2xl mx-auto">
        <button
          type="button"
          onClick={() => navigate(-1)}
          className="flex items-center text-gray-600 hover:text-gray-900 mb-4"
        >
          <ArrowLeft className="w-4 h-4 mr-1" />
          Back
        </button>
        <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-2">
          <KeyRound className="w-8 h-8 text-blue-600" />
          Buy PIN
        </h1>
        <p className="text-gray-600 mt-1 mb-6">
          Purchase PINs in bulk to create activated accounts for your team.
        </p>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Cart */}
          <div className="bg-white rounded-2xl shadow-lg p-6">
            <h2 className="text-xl font-bold text-gray-800 mb-4">PIN Cart</h2>

            <div className="space-y-3">
              {cart.map((row) => {
                const plan = plans.find((p) => p.id === row.planId);
                const sub = rowSubtotal(row);
                const taken = usedPlanIds(row.id);
                const itemErr =
                  fieldErrors[`items.${cart.indexOf(row)}.quantity`] ||
                  fieldErrors[`items.${cart.indexOf(row)}.plan_id`] ||
                  fieldErrors[`items`];

                return (
                  <div
                    key={row.id}
                    className="flex flex-col sm:flex-row gap-3 items-start sm:items-center p-3 bg-gray-50 rounded-xl border border-gray-200"
                  >
                    <div className="flex-1 min-w-0">
                      <select
                        value={row.planId ?? ""}
                        onChange={(e) =>
                          updatePlan(
                            row.id,
                            e.target.value ? Number(e.target.value) : null,
                          )
                        }
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500"
                      >
                        <option value="">Choose a plan…</option>
                        {plans.map((p) => (
                          <option
                            key={p.id}
                            value={p.id}
                            disabled={taken.includes(p.id)}
                          >
                            {getDisplayNameForPlan(p.name)} — ₨{Number(p.price_pkr).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} / ${Number(p.price_usd).toFixed(2)}
                            {taken.includes(p.id) ? " (already added)" : ""}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      <label className="text-sm text-gray-600 whitespace-nowrap">
                        Qty:
                      </label>
                      <input
                        type="text"
                        inputMode="numeric"
                        min={1}
                        max={100}
                        value={row.quantity ?? ""}
                        placeholder="qty"
                        onChange={(e) => {
                          const raw = e.target.value.replace(/\D/g, "");
                          setCart((prev) =>
                            prev.map((r) =>
                              r.id === row.id
                                ? {
                                    ...r,
                                    quantity:
                                      raw === ""
                                        ? null
                                        : Math.max(
                                            1,
                                            Math.min(100, Number(raw)),
                                          ),
                                  }
                                : r,
                            ),
                          );
                        }}
                        onKeyDown={(e) => {
                          if (
                            !/^\d$/.test(e.key) &&
                            ![
                              "Backspace",
                              "Delete",
                              "ArrowLeft",
                              "ArrowRight",
                              "Tab",
                            ].includes(e.key)
                          ) {
                            e.preventDefault();
                          }
                        }}
                        onPaste={(e) => {
                          e.preventDefault();
                          const pasted = e.clipboardData
                            .getData("text")
                            .replace(/\D/g, "");
                          if (pasted) updateQty(row.id, Number(pasted));
                        }}
                        className="w-20 px-2 py-2 border border-gray-300 rounded-lg text-sm text-center focus:ring-2 focus:ring-blue-500"
                      />
                    </div>

                    {plan && (
                      <div className="text-sm font-semibold whitespace-nowrap shrink-0 text-right">
                        <span className="text-blue-700">
                          ₨{sub.pkr.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                        </span>
                        <span className="text-gray-400 mx-1">/</span>
                        <span className="text-emerald-700">
                          ${sub.usd.toFixed(2)}
                        </span>
                      </div>
                    )}

                    <button
                      type="button"
                      onClick={() => removeRow(row.id)}
                      disabled={cart.length === 1}
                      className="p-2 text-red-500 hover:bg-red-50 rounded-lg disabled:opacity-30 shrink-0"
                      title="Remove row"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>

                    {itemErr && (
                      <p className="text-xs text-red-600 w-full">{itemErr}</p>
                    )}
                  </div>
                );
              })}
            </div>

            <button
              type="button"
              onClick={addRow}
              className="mt-3 flex items-center gap-2 text-sm text-blue-600 hover:text-blue-800 font-medium"
            >
              <Plus className="w-4 h-4" />
              Add another plan
            </button>

            {/* Live totals */}
            {totalPins > 0 && (
              <div className="mt-4 p-3 bg-blue-50 border border-blue-200 rounded-xl text-sm">
                <div className="flex justify-between font-semibold text-blue-900">
                  <span>
                    Total ({totalPins} PIN{totalPins !== 1 ? "s" : ""}):
                  </span>
                  <span>
                    <span className="text-blue-900">
                      ₨{totals.pkr.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                    </span>
                    <span className="text-gray-400 mx-1">/</span>
                    <span className="text-emerald-700">
                      ${totals.usd.toFixed(2)}
                    </span>
                  </span>
                </div>
                <p className="text-blue-600 text-xs mt-1">
                  Server price is authoritative — total shown on success may
                  differ slightly if prices changed.
                </p>
              </div>
            )}
          </div>

          {/* Payment details */}
          <div className="bg-white rounded-2xl shadow-lg p-6">
            <h2 className="text-xl font-bold text-gray-800 mb-4">
              Payment Details
            </h2>

            {accountDetailsList.length > 0 && (
              <div className="mb-6 p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                <h3 className="text-lg font-semibold text-yellow-800 mb-3">
                  Send Payment To:
                </h3>
                <div className="space-y-3">
                  {accountDetailsList.map((acc, idx) => (
                    <div
                      key={acc.id ?? idx}
                      className="grid grid-cols-1 md:grid-cols-3 gap-3 p-3 bg-white/60 rounded"
                    >
                      <div>
                        <p className="text-sm font-medium text-yellow-800 mb-1">
                          Account Title:
                        </p>
                        <p className="font-semibold text-yellow-900">
                          {acc.account_title}
                        </p>
                      </div>
                      <div>
                        <p className="text-sm font-medium text-yellow-800 mb-1">
                          Account Number:
                        </p>
                        <p className="font-mono font-semibold text-yellow-900">
                          {acc.account_number}
                        </p>
                      </div>
                      {acc.bank && (
                        <div>
                          <p className="text-sm font-medium text-yellow-800 mb-1">
                            Bank:
                          </p>
                          <p className="font-semibold text-yellow-900">
                            {acc.bank}
                          </p>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            )}

            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Transaction ID <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                value={transactionId}
                onChange={(e) => setTransactionId(e.target.value)}
                className={`w-full px-4 py-3 border rounded-lg focus:ring-2 focus:ring-blue-500 ${
                  fieldErrors.transaction_id
                    ? "border-red-400"
                    : "border-gray-300"
                }`}
                placeholder="Enter your transaction ID"
              />
              {fieldErrors.transaction_id && (
                <p className="text-sm text-red-600 mt-1">
                  {fieldErrors.transaction_id}
                </p>
              )}
            </div>

            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Your Account Number <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                value={transactionAccountNumber}
                onChange={(e) => setTransactionAccountNumber(e.target.value)}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                placeholder="Enter your account number"
              />
            </div>

            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Your Account Title <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                value={transactionAccountTitle}
                onChange={(e) => setTransactionAccountTitle(e.target.value)}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                placeholder="Enter your account title"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Payment Screenshot <span className="text-red-500">*</span>
              </label>
              <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center hover:border-blue-400 transition cursor-pointer">
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleScreenshotChange}
                  className="hidden"
                  id="pin-screenshot-upload"
                />
                <label
                  htmlFor="pin-screenshot-upload"
                  className="cursor-pointer"
                >
                  {screenshotPreview ? (
                    <div>
                      <img
                        src={screenshotPreview}
                        alt="Screenshot preview"
                        className="max-h-48 mx-auto rounded-lg"
                      />
                      {screenshot && (
                        <p className="text-xs text-gray-500 mt-2">
                          {screenshot.name} (
                          {(screenshot.size / 1024).toFixed(0)} KB)
                        </p>
                      )}
                    </div>
                  ) : (
                    <div>
                      <Upload className="w-10 h-10 text-gray-400 mx-auto mb-2" />
                      <p className="text-gray-600">
                        Click to upload screenshot
                      </p>
                      <p className="text-sm text-gray-400">
                        JPG, PNG, WEBP (Max 5MB)
                      </p>
                    </div>
                  )}
                </label>
              </div>
              {fieldErrors.transaction_screenshot && (
                <p className="text-sm text-red-600 mt-1">
                  {fieldErrors.transaction_screenshot}
                </p>
              )}
            </div>
          </div>

          {error && (
            <div className="flex items-center gap-2 p-4 bg-red-50 border border-red-200 rounded-lg">
              <AlertCircle className="w-5 h-5 text-red-500 flex-shrink-0" />
              <p className="text-red-700">{error}</p>
            </div>
          )}

          <button
            type="submit"
            disabled={submitting || totalPins === 0}
            className="w-full py-4 bg-gradient-to-r from-blue-600 to-blue-700 text-white font-bold rounded-xl hover:from-blue-700 hover:to-blue-800 disabled:opacity-50 flex items-center justify-center gap-2"
          >
            {submitting ? (
              <>
                <Loader2 className="w-5 h-5 animate-spin" />
                Submitting…
              </>
            ) : (
              `Submit PIN Purchase Request${totalPins > 0 ? ` (${totalPins} PIN${totalPins !== 1 ? "s" : ""})` : ""}`
            )}
          </button>
        </form>
      </div>
    </div>
  );
};

export default BuyPin;
