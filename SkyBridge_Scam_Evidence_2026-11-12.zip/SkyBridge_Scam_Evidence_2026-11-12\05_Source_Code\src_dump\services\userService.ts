import { apiClient } from "./apiClient";
import { API_ENDPOINTS } from "../config/api";

// API response interface (matches the exact API structure)
export interface ApiUserProfile {
  id: number;
  name: string;
  email: string;
  phone?: string;
  country?: string;
  phone_number?: string;
  referral_code?: string;
  account_number?: string;
  account_title?: string;
  payment_methods?: string[];
  status?: string;
  created_at?: string;
  profile_picture?: string;
  bep20_address?: string;
  plan?: string;
  plan_id?: number;
  plan_name?: string;
  plan_price_pkr?: number;
}

// User profile interface (for internal use with camelCase)
export interface UserProfile {
  id: number;
  name: string;
  email: string;
  phone?: string;
  country?: string;
  referralCode?: string;
  account_number?: string;
  account_title?: string;
  payment_methods?: string[];
  status?: string;
  created_at?: string;
  profile_picture?: string;
  bep20_address?: string;
  plan?: string;
  plan_name?: string;
  plan_id?: number;
  plan_price_pkr?: number;
}

// API response interface for user profile
export interface UserProfileResponse {
  success: boolean;
  message: string;
  data: UserProfile;
}

// Referral count interfaces
interface ReferralCountData {
  total_referrals: number;
}

interface ReferralCountResponse {
  success: boolean;
  data: ReferralCountData;
  message?: string;
}

// Today's referral count interfaces
export interface TodayReferralCountData {
  referral_code: string;
  date: string;
  today_referrals: number;
  today_approved_referrals: number;
  today_pending_referrals: number;
}

interface TodayReferralCountResponse {
  success: boolean;
  message: string;
  data: TodayReferralCountData;
}

// Claim reward interfaces
interface ClaimRewardResponse {
  success: boolean;
  message: string;
  data?: any;
}

// Account details interface
export interface AccountDetails {
  id?: number;
  account_number?: string;
  account_title?: string;
  bank?: string;
  type?: string;
  [key: string]: any;
}

class UserService {
  private static instance: UserService;
  private cachedProfile: UserProfile | null = null;
  private profilePromise: Promise<UserProfile> | null = null;

  private constructor() {}

  public static getInstance(): UserService {
    if (!UserService.instance) {
      UserService.instance = new UserService();
    }
    return UserService.instance;
  }

  /**
   * Clear cached profile (call on logout or profile update)
   */
  public clearProfileCache(): void {
    this.cachedProfile = null;
    this.profilePromise = null;
  }

  /**
   * Fetch user profile data from the API (cached — only 1 call per session)
   * @param forceRefresh Force a fresh API call ignoring cache
   * @returns Promise<UserProfile>
   */
  public async getUserProfile(forceRefresh = false): Promise<UserProfile> {
    if (!forceRefresh && this.cachedProfile) {
      return this.cachedProfile;
    }
    // Deduplicate concurrent calls — if a request is in-flight, reuse it
    if (!forceRefresh && this.profilePromise) {
      return this.profilePromise;
    }
    this.profilePromise = this._fetchProfile();
    try {
      const profile = await this.profilePromise;
      this.cachedProfile = profile;
      return profile;
    } finally {
      this.profilePromise = null;
    }
  }

  private async _fetchProfile(): Promise<UserProfile> {
    try {
      const response = await apiClient.get<ApiUserProfile>(
        API_ENDPOINTS.USER.PROFILE,
      );

      // The API returns the user data directly, not wrapped in a success/data structure
      if (response.data) {
        // Map the API response to our UserProfile interface
        const userData = response.data;
        return {
          id: userData.id,
          name: userData.name,
          email: userData.email,
          phone: userData.phone ?? userData.phone_number,
          country: userData.country,
          referralCode: userData.referral_code, // Convert snake_case to camelCase
          account_number: userData.account_number,
          account_title: userData.account_title,
          payment_methods: userData.payment_methods,
          status: userData.status,
          created_at: userData.created_at,
          profile_picture: userData.profile_picture,
          bep20_address: userData.bep20_address,
          plan: userData.plan,
          plan_name: userData.plan_name,
          plan_id: userData.plan_id,
          plan_price_pkr: userData.plan_price_pkr,
        };
      } else {
        throw new Error("No user data received from API");
      }
    } catch (error: any) {
      console.error("Error fetching user profile:", error);
      throw new Error(error.message || "Failed to fetch user profile");
    }
  }

  /**
   * Update user profile data
   * @param profileData Partial user profile data to update
   * @returns Promise<UserProfile>
   */
  public async updateUserProfile(
    profileData: Partial<UserProfile>,
  ): Promise<UserProfile> {
    try {
      const response = await apiClient.put<UserProfileResponse>(
        API_ENDPOINTS.USER.PROFILE,
        profileData,
      );

      if (response.success && response.data) {
        this.clearProfileCache();
        return response.data.data;
      } else {
        throw new Error(
          response.data?.message || "Failed to update user profile",
        );
      }
    } catch (error: any) {
      console.error("Error updating user profile:", error);
      throw new Error(error.message || "Failed to update user profile");
    }
  }

  /**
   * Get user referral count
   * @returns Promise<number>
   */
  public async getReferralCount(): Promise<number> {
    try {
      const response = await apiClient.get<ReferralCountResponse>(
        API_ENDPOINTS.USER.REFERRAL_COUNT,
      );

      if (response.success && response.data) {
        return response.data.total_referrals;
      } else {
        throw new Error(response.message || "Failed to fetch referral count");
      }
    } catch (error: any) {
      console.error("Error fetching referral count:", error);
      throw new Error(error.message || "Failed to fetch referral count");
    }
  }

  // NEW: Get full referral summary including approved_referrals
  public async getReferralSummary(): Promise<ReferralSummaryData> {
    try {
      const response = await apiClient.get<ReferralSummaryResponse>(
        API_ENDPOINTS.USER.REFERRAL_COUNT,
      );

      if (response.success && response.data) {
        return response.data;
      } else {
        throw new Error(response.message || "Failed to fetch referral summary");
      }
    } catch (error: any) {
      console.error("Error fetching referral summary:", error);
      throw new Error(error.message || "Failed to fetch referral summary");
    }
  }

  /**
   * Get today's referral count
   * @returns Promise<TodayReferralCountData>
   */
  public async getTodayReferralCount(): Promise<TodayReferralCountData> {
    try {
      const response = await apiClient.get<TodayReferralCountResponse>(
        API_ENDPOINTS.USER.TODAY_REFERRAL_COUNT,
      );

      if (response.success && response.data) {
        return response.data;
      } else {
        throw new Error(
          response.message || "Failed to fetch today's referral count",
        );
      }
    } catch (error: any) {
      console.error("Error fetching today's referral count:", error);
      throw new Error(
        error.message || "Failed to fetch today's referral count",
      );
    }
  }

  /**
   * Get account details by type
   * GET /api/account?type=registration_page
   */
  public async getAccountDetails(type?: string): Promise<AccountDetails[]> {
    try {
      const endpoint = type
        ? `${API_ENDPOINTS.ACCOUNT}?type=${type}`
        : API_ENDPOINTS.ACCOUNT;
      const response = await apiClient.get<AccountDetails[]>(endpoint);
      return (response.data as AccountDetails[]) || [];
    } catch (error: any) {
      console.error("Error fetching account details:", error);
      throw new Error(error.message || "Failed to fetch account details");
    }
  }

  /**
   * Claim reward for a specific level
   * @param levelId - The ID of the level to claim reward for
   * @returns Promise<{ success: boolean; message: string }>
   */
  public async claimReward(
    level: number,
  ): Promise<{ success: boolean; message: string }> {
    try {
      const response = await apiClient.post<ClaimRewardResponse>(
        API_ENDPOINTS.USER.CLAIM_REWARD,
        { level },
      );

      // Prefer validation error message if present
      const serverErrors: any = (response as any)?.errors;
      const validationMsg =
        serverErrors?.level && Array.isArray(serverErrors.level)
          ? serverErrors.level[0]
          : undefined;

      return {
        success: response.success,
        message:
          validationMsg ||
          response.message ||
          (response.success
            ? "Reward claimed successfully!"
            : "Failed to claim reward"),
      };
    } catch (error: any) {
      console.error("Error claiming reward:", error);
      return {
        success: false,
        message: error.message || "Failed to claim reward",
      };
    }
  }
}

export const userService = UserService.getInstance();
export default userService;
// Add summary types for referral details
export interface ReferralSummaryData {
  referral_code: string;
  total_referrals: number;
  approved_referrals: number;
  pending_referrals: number;
  claimed_rewards: number[];
  total_claimed_rewards: number;
}

interface ReferralSummaryResponse {
  success: boolean;
  message: string;
  data: ReferralSummaryData;
}
