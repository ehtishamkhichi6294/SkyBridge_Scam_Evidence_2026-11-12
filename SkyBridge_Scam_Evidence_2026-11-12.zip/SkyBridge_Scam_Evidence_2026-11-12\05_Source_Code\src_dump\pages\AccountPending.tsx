import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { CheckCircle, Clock, ArrowLeft, Heart, Globe } from "lucide-react";
import { WHATSAPP_CHANNEL_URL } from "../constants/appLinks";

const AccountPending: React.FC = () => {
  // Read user name from localStorage (user or pending fallback) and keep it in state to avoid loss in StrictMode
  const [userName, setUserName] = useState<string>("");

  useEffect(() => {
    try {
      const raw = localStorage.getItem("user");
      if (raw) {
        const u = JSON.parse(raw);
        const name = u?.name || u?.user?.name || "";
        if (name) {
          setUserName(name);
          return;
        }
      }
      const pendingName = localStorage.getItem("pending_user_name") || "";
      if (pendingName) {
        setUserName(pendingName);
      }
    } catch {
      // ignore parsing/storage errors
    }
  }, []);

  // Keep pending_user_name until navigation; removal handled on login click to avoid losing name in development StrictMode
  useEffect(() => {
    // no-op
  }, [userName]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-sky-50 via-white to-sky-100 flex items-center justify-center p-4">
      <div className="w-full max-w-md bg-white/90 backdrop-blur-sm rounded-2xl shadow-sky-lg border border-sky-200/50 overflow-hidden">
        {/* Header with Sky Bridge Branding */}
        <div className="bg-gradient-to-r from-sky-600 to-sky-700 text-white text-center py-6">
          <div className="flex items-center justify-center mb-2">
            <div className="w-8 h-8 bg-white/20 rounded-full flex items-center justify-center mr-2">
              <Globe className="w-5 h-5 text-white" />
            </div>
            <h1 className="text-2xl font-bold">SKYBRIDGE</h1>
          </div>
          <div className="text-sky-100 text-sm">INTERNATIONAL</div>
        </div>

        {/* Success Message */}
        <div className="p-8 text-center">
          <div className="mb-6">
            <div className="w-20 h-20 bg-gradient-to-br from-green-100 to-emerald-100 rounded-full flex items-center justify-center mx-auto mb-4 border border-green-200">
              <CheckCircle className="w-12 h-12 text-green-600" />
            </div>
            <h2 className="text-2xl font-bold bg-gradient-to-r from-green-600 to-emerald-600 bg-clip-text text-transparent mb-2">
              {userName
                ? `${userName}, You're Near to Success!`
                : "You're Near to Success!"}
            </h2>
          </div>

          {/* Processing Message */}
          <div className="bg-gradient-to-br from-sky-50 to-sky-100 rounded-xl p-6 mb-6 border border-sky-200">
            <div className="flex items-center justify-center mb-3">
              <Clock className="w-6 h-6 text-sky-600 mr-2" />
              <span className="text-lg font-semibold text-sky-900">
                Account Processing
              </span>
            </div>
            <p className="text-sky-700 text-sm leading-relaxed">
              <span className="font-semibold text-sky-800">
                SkyBridge International
              </span>{" "}
              is processing your details. After that you will be able to use{" "}
              <span className="font-semibold text-sky-800">SkyBridge</span>{" "}
              platform.
            </p>
          </div>

          {/* 24 Hour Notice */}
          <div className="bg-gradient-to-br from-blue-50 to-purple-50 border border-blue-200 rounded-xl p-4 mb-6">
            <div className="flex items-center justify-center mb-2">
              <div className="w-8 h-8 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full flex items-center justify-center mr-2">
                <span className="text-white font-bold text-sm">24</span>
              </div>
              <span className="font-semibold text-blue-800">
                Hours Activation Time
              </span>
            </div>
            <p className="text-blue-700 text-sm">
              {userName ? (
                <>
                  Dear{" "}
                  <span className="font-semibold text-blue-800">
                    {userName}
                  </span>
                  , your account will be activated within 24 hours.
                </>
              ) : (
                "Your account will be activated within 24 hours."
              )}
            </p>
          </div>

          {/* Heart Icon */}
          <div className="mb-6">
            <Heart className="w-12 h-12 text-sky-500 mx-auto fill-current" />
          </div>

          {/* WhatsApp Channel — shown after registration completes */}
          <div className="mb-6 rounded-xl border border-green-200 bg-gradient-to-br from-green-50 to-emerald-50 p-4">
            <p className="text-sm font-semibold text-green-900 mb-1">
              Stay updated on WhatsApp
            </p>
            <p className="text-xs text-green-700 mb-3 leading-relaxed">
              Follow our official channel for announcements, proofs, and
              competition updates.
            </p>
            <a
              href={WHATSAPP_CHANNEL_URL}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full inline-flex items-center justify-center gap-2 bg-gradient-to-r from-green-500 to-green-600 text-white py-3 px-6 rounded-xl font-semibold hover:from-green-600 hover:to-green-700 transition-all duration-200 shadow-md hover:shadow-lg transform hover:scale-[1.02] active:scale-95"
            >
              <svg
                className="w-5 h-5"
                fill="currentColor"
                viewBox="0 0 24 24"
                aria-hidden="true"
              >
                <path d="M20.52 3.48A11.82 11.82 0 0012.04 0C5.47 0 .04 5.43.04 12a11.83 11.83 0 001.57 5.93L0 24l6.24-1.64A11.9 11.9 0 0012.05 24c6.57 0 11.99-5.43 11.99-12a11.82 11.82 0 00-3.52-8.52zM12.05 22.06a9.93 9.93 0 01-5.08-1.39l-.36-.21-3.7.97.99-3.6-.23-.37A9.96 9.96 0 012.1 12c0-5.48 4.46-9.94 9.94-9.94a9.9 9.9 0 016.99 2.9 9.9 9.9 0 012.9 7.04c-.01 5.48-4.47 9.94-9.88 9.94zm5.68-7.45c-.31-.16-1.84-.9-2.12-1.01-.28-.1-.49-.16-.7.16-.2.31-.8 1.01-.99 1.22-.18.2-.37.23-.68.08-.31-.16-1.32-.49-2.51-1.56-.93-.82-1.56-1.83-1.75-2.14-.18-.31-.02-.48.13-.63.13-.13.31-.34.46-.51.16-.17.2-.29.31-.49.1-.2.05-.37-.03-.52-.08-.16-.7-1.68-.96-2.3-.25-.6-.51-.52-.7-.53-.18 0-.39 0-.6 0-.2 0-.52.07-.79.37-.27.31-1.04 1.01-1.04 2.47s1.07 2.87 1.22 3.07c.16.2 2.11 3.2 5.1 4.49.71.31 1.27.49 1.7.63.71.23 1.36.2 1.87.13.57-.09 1.84-.75 2.1-1.47.26-.72.26-1.33.18-1.47-.09-.14-.28-.23-.59-.38z" />
              </svg>
              Follow WhatsApp Channel
            </a>
          </div>

          {/* Action Buttons */}
          <div className="space-y-3">
            <Link
              to="/login"
              className="w-full bg-gradient-to-r from-sky-600 to-sky-700 text-white py-3 px-6 rounded-xl font-semibold hover:from-sky-700 hover:to-sky-800 transition-all duration-200 block text-center shadow-sky hover:shadow-sky-lg transform hover:scale-105"
              onClick={() => {
                try {
                  localStorage.removeItem("pending_user_name");
                } catch {}
              }}
            >
              Go to Login
            </Link>

            <Link
              to="/"
              className="w-full bg-sky-100 text-sky-700 py-3 px-6 rounded-xl font-semibold hover:bg-sky-200 transition-all duration-200 flex items-center justify-center border border-sky-300"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Home
            </Link>
          </div>

          {/* Additional Info */}
          <div className="mt-6 pt-6 border-t border-sky-200">
            <p className="text-xs text-sky-600">
              Need help? Contact our support team at{" "}
              <a
                href="mailto:support@skybridge.com"
                className="text-sky-700 hover:text-sky-800 font-medium"
              >
                support@skybridge.com
              </a>
            </p>
            <p className="text-xs text-sky-600 mt-2">
              WhatsApp Support:{" "}
              <a
                href="https://wa.me/923143542482"
                target="_blank"
                rel="noopener noreferrer"
                className="text-sky-700 hover:text-sky-800 font-medium"
              >
                03143542482
              </a>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AccountPending;
