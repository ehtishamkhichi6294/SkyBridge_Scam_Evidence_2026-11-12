SKYBRIDGE INTERNATIONAL — EVIDENCE PACKAGE
==========================================
Case reference: SBI-2026-11-12
Prepared: 12 November 2026
Classification: PRIVATE — INVESTIGATION MATERIAL

WHAT THIS IS
------------
This folder contains a factual investigation of two linked "earn money watching
ads" websites:

  1. https://skybridgeinternationa.netlify.app/   (Netlify prototype)
  2. https://sky-bridge-international.com/        (production site)
     API: https://backend.sky-bridge-international.com/api
     Admin shell: https://sky-bridge-international.com/admin
                  https://admin.sky-bridge-international.com/

The main report is:

  01_Report/SkyBridge_Investigation_Report.docx

Start there. It explains the scam mechanics, the evidence, the payment rails,
the WHOIS/domain record, the infrastructure, and how to report.

IMPORTANT — WHAT WAS AND WAS NOT DONE
-------------------------------------
- No payment was sent to any account or crypto wallet.
- No production account was created. A controlled signup test with dummy data
  and a clearly marked "TEST — NO PAYMENT" image was rejected by the backend
  because registration requires a valid 9-character referral code belonging to
  an existing user. No real member's code was used.
- No administrator login was attempted. The public admin shell, its missing
  JavaScript bundle, and the backend 404 responses were documented instead.
- The only account created was the investigator's own disposable test account
  on the Netlify prototype: 03001234567 / test1234. It was activated with the
  hardcoded code found in the page source, without payment.
- Public data was collected passively: public pages, public APIs, DNS, RDAP/
  WHOIS, TLS certificates, HTTP headers, and reverse-IP lookups.

WHY THE ADMIN LOGIN WAS NOT ATTEMPTED
-------------------------------------
Unauthorised access to an admin panel is a crime in its own right (Pakistan
PECA; US CFAA; similar laws elsewhere). It would also alert the operators,
contaminate the evidence, and give them a "we were hacked" defence. The
stronger case is built from their own public source code, payment instructions,
and fabricated social proof. If law enforcement needs admin-side evidence, the
correct route is a preservation letter and subpoena to Netlify, Cloudflare,
Contabo, and Spaceship.

PRODUCTION SIGNUP TEST — RESULT
-------------------------------
A controlled test was made against the real production API
(https://backend.sky-bridge-international.com/api/auth/signup) using dummy
details, the cheapest plan (Basic, PKR 950 / USD 3.33), and a white/red image
that says "TEST REGISTRATION — NO PAYMENT WAS MADE". No money was sent and no
real payment receipt was used. The backend rejected all three attempts:

  1. No referral code      -> 422 "The referral code field is required."
  2. TESTCODE2026 (12 ch)  -> 422 "The referral code field must be 9 characters."
  3. TEST12345 (9 ch)      -> 422 "The selected referral code is invalid."

The referral code is validated against real users, so no standalone account can
be created. The test was stopped rather than use a real member's code, because
that would credit a third party (possibly a victim) and contaminate the
evidence. This is itself a key finding: every production account must be
sponsored by an existing member, making the recruitment chain mandatory.
Full log: 11_Production_Test_Account/PRODUCTION_SIGNUP_TEST.txt.

FOLDER MAP
----------
01_Report
    SkyBridge_Investigation_Report.docx  — the full dossier
    README_FIRST.txt                     — this file

02_Screenshots_Main
    Full-page screenshots of the production site: home, about, login, register,
    forgot-password, account-pending, /plans redirect.

03_Screenshots_Netlify
    Screenshots of the Netlify prototype: register, login, payment page,
    dashboard, ads, withdraw-locked, unlock modal, withdraw modal, profile,
    notifications, blocked page.

04_Admin_Login_Pages
    The public admin shells, backend 404 pages, and screenshots. The /admin
    shell is titled "Complete Admin Panel System" but its JS/CSS bundles 404.

05_Source_Code
    netlify_index.html       — full 944,709-byte single-file Netlify app
    main_app.js              — production React bundle
    main_app.js.map          — exposed source map (1,407,603 bytes)
    main_app.css             — production CSS
    main_shell.html          — production HTML shell
    src_dump/                — 68 original React/TypeScript files

06_API_Data
    Raw public API responses: plans, registration accounts, PIN accounts,
    crypto networks, leaderboard, products, health, headers.

07_Images_Audio
    Branding images, the Netlify payment-page audio, the Y & K Partners logo,
    the 10 YouTube "ad" thumbnails, and product images.

08_Infrastructure
    DNS, RDAP/WHOIS, TLS certificates, HTTP headers, IP geolocation, reverse-IP
    neighbours, related-site captures, and the user-supplied who.is result.

09_Hashes_Manifest
    SHA256_MANIFEST.txt, screenshot capture logs, and the Netlify capture log.

10_Original_Captures
    The original dashboard capture from the first investigation session.

11_Production_Test_Account
    The controlled production signup test: the clearly marked "NO PAYMENT"
    image, the three 422 responses, and PRODUCTION_SIGNUP_TEST.txt. No account
    was created.

KEY FINDINGS (SHORT VERSION)
----------------------------
1. The Netlify app is 100% client-side. It has no server, no payment processor,
   and no ledger. Passwords are stored in plaintext in localStorage under
   "pepsiState". The activation code 59985046 and withdrawal-unlock code
   09633567 are hardcoded in the page. The "live withdrawal" ticker is 15
   random names with random amounts.
2. The production site is a React SPA + Laravel API. It exposes a source map,
   public payment-account endpoints, a BEP20 wallet, 50 products, and a
   leaderboard of 20 users with names, countries, photos, and referral sales —
   all without authentication.
3. The fee structure is two-stage: pay to activate (₨500 Netlify; ₨950–₨6,000
   production), then pay again to unlock withdrawals (₨1,200 Netlify; 5% fee
   and tiered minimums production). Withdrawals are delayed, auto-cancelled,
   or never paid.
4. The production "community" is hardcoded: 12,450 members, 1,234 daily posts,
   5,678 likes, 890 shares, and 50 canned testimonials claiming up to $2,000
   per month.
5. The domain was registered on 2025-09-30, but the site claims "proven track
   record since 2020" and a © 2024 footer. The registrant is hidden behind
   "WITHHELD FOR PRIVACY LLC" (Spaceship privacy service).
6. Hosting: Contabo VPS 62.169.29.98, Lauterbourg, France; Cloudflare DNS;
   LiteSpeed; Let's Encrypt TLS. Reverse IP shows 18 other hostnames, including
   apexcryptomarket.site (another login/register trading platform) and
   formonixsoftwares.com (a software-house domain).
7. Developer credit: "Y & K Partners", WhatsApp 923260538041. The modal says
   "I am the developer..." — a solo freelancer brand, not a registered company.

KEY CONTACTS / FINANCIAL RAILS (SEE THE REPORT FOR FULL DETAIL)
--------------------------------------------------------------
Production:
  UBL            0561338978648   SkyBridge International
  Easypaisa      03124208928     Muhammad Javeed
  JazzCash       03268544344     Muhammad Awais Javeed
  BEP20          0xd68758b6141e6af2d22cabe90660a4399c459080   ($3.33)
  Support WA     923143542482
  Developer WA   923260538041
Netlify:
  JazzCash       03319313212     ameer ali
  EasyPaisa      03418151224     Moran bai
  Support WA     923127273415
  Admin phone    03714101801
  Blocked page   +92 332 0784379

IF YOU HAVE PAID
----------------
1. Contact your bank / Easypaisa / JazzCash immediately. Report the transaction
   as fraudulent and ask for a freeze/recall. Keep the transaction ID.
2. Do not send more money. Do not share OTPs or passwords. Do not confront the
   operators.
3. Preserve the chat, receipts, screenshots, and URLs. Export the WhatsApp chat.
4. Report to Pakistan's FIA Cybercrime Wing / NR3C: https://complaint.fia.gov.pk/
   Also file a local police complaint and report the receiving accounts to the
   bank and the State Bank of Pakistan.
5. Report the hosting/content:
   Netlify:    https://www.netlify.com/abuse/  / abuse@netlify.com
   Cloudflare: https://abuse.cloudflare.com    / abuse@cloudflare.com
   Contabo:    abuse@contabo.com
   Spaceship:  abuse@spaceship.com             / +1.9854014545
6. Report the YouTube channel, WhatsApp channel/numbers, and the domain to
   Google Safe Browsing, Gridinsoft, and ScamAdviser.
7. If significant money is involved, consult a lawyer about a freezing order
   and a disclosure/subpoena request to the banks, Cloudflare, Contabo,
   Spaceship, and Netlify. For crypto, use a blockchain-analytics firm.

HOW TO VERIFY THE EVIDENCE
--------------------------
Every file is listed in 09_Hashes_Manifest/SHA256_MANIFEST.txt. To verify one:

  Get-FileHash -Algorithm SHA256 <file>

Compare the full hash with the manifest. The manifest itself has a master hash
at the top (or a separate .sha256 file). Do not rely on truncated hashes.

LEGAL NOTE
----------
This is an investigative record, not legal advice. Names on payment accounts may
belong to the operators, paid mules, or unwitting third parties. Do not publicly
accuse any individual without verification. Consult a qualified lawyer in your
jurisdiction before filing or publishing allegations.

— End of README —
