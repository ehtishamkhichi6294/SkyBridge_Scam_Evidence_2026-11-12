import React, { useState, useEffect, useMemo, useRef } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../contexts/AuthContext";
import { RegisterRequest } from "../services";
import {
  User,
  Mail,
  Phone,
  Lock,
  Eye,
  EyeOff,
  Globe,
  CreditCard,
  CheckCircle,
  ArrowRight,
  ArrowLeft,
  Smartphone,
  Camera,
  FileText,
  AlertCircle,
  Package,
  Star,
  Sparkles,
  TrendingUp,
  Crown,
  Check,
} from "lucide-react";
import { userService, AccountDetails } from "../services/userService";
import { normalizeEmailToASCII } from "../utils/emailUtils";
import { API_CONFIG, API_ENDPOINTS } from "../config/api";
import {
  getDisplayNameForPlan,
  getPlanContentByPricePkr,
} from "../constants/plans";

function formatPlanLabel(planName: string | undefined): string {
  const name = getDisplayNameForPlan(planName);
  if (!name) return "";
  return /plan$/i.test(name.trim()) ? name.trim() : `${name} Plan`;
}

interface PlanOption {
  id: number;
  name: string;
  price_pkr: number;
  price_usd: string;
}

interface FormData {
  // Step 1 - Plan Selection
  planId: number | null;
  // Step 2
  name: string;
  email: string;
  password: string;
  confirmPassword: string;
  referralCode: string;
  country: string;
  // Step 2
  phoneNumber: string;
  confirmPhoneNumber: string;
  paymentMethods: string[];
  accountTitle: string;
  bep20Address?: string;
  confirmBep20Address?: string;
  trc20Address?: string;
  // Step 3
  screenshot: File | null;
  transactionId: string;
  transactionAccountNumber: string;
  transactionAccountTitle: string;
}

const Register: React.FC = () => {
  const [currentStep, setCurrentStep] = useState(1);
  const [plans, setPlans] = useState<PlanOption[]>([]);
  const [formData, setFormData] = useState<FormData>({
    planId: null,
    name: "",
    email: "",
    password: "",
    confirmPassword: "",
    referralCode: "",
    country: "Pakistan",
    phoneNumber: "",
    confirmPhoneNumber: "",
    paymentMethods: [],
    accountTitle: "",
    bep20Address: "",
    confirmBep20Address: "",
    trc20Address: "",
    screenshot: null,
    transactionId: "",
    transactionAccountNumber: "",
    transactionAccountTitle: "",
  });
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string>("");
  const [toast, setToast] = useState<{
    message: string;
    type: "success" | "error";
  } | null>(null);
  const [fieldErrors, setFieldErrors] = useState<Record<string, string>>({});
  // Account details state (array - multiple accounts per type)
  const [accountDetailsList, setAccountDetailsList] = useState<
    AccountDetails[]
  >([]);
  const [accountError, setAccountError] = useState<string | null>(null);
  // Crypto networks state
  const [cryptoNetworks, setCryptoNetworks] = useState<any[]>([]);
  const { register } = useAuth();
  const navigate = useNavigate();

  const continueButtonRef = useRef<HTMLDivElement>(null);

  const selectedPlan = useMemo(() => {
    if (formData.planId == null) return null;
    return plans.find((p) => Number(p.id) === Number(formData.planId)) ?? null;
  }, [plans, formData.planId]);

  useEffect(() => {
    if (currentStep === 1 && formData.planId != null && continueButtonRef.current) {
      continueButtonRef.current.scrollIntoView({ behavior: "smooth", block: "end" });
    }
  }, [formData.planId, currentStep]);

  const selectedPlanLabel = selectedPlan
    ? formatPlanLabel(selectedPlan.name)
    : "";

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const raw = params.get("refCode") || "";
    const code = raw.replace(/^"+|"+$/g, "");
    if (code) {
      setFormData((prev) => ({ ...prev, referralCode: code }));
    }
    // Clear any stale pending name on mount (optional)
    try {
      localStorage.removeItem("pending_user_name");
    } catch {}
  }, []);
  // Fetch receiver account details for registration page
  useEffect(() => {
    let mounted = true;
    (async () => {
      try {
        const details =
          await userService.getAccountDetails("registration_page");
        if (mounted) setAccountDetailsList(details);
      } catch (err: any) {
        if (mounted)
          setAccountError(err?.message || "Failed to load account details");
      }
    })();
    return () => {
      mounted = false;
    };
  }, []);

  // Fetch crypto networks
  useEffect(() => {
    let mounted = true;
    (async () => {
      try {
        const response = await fetch(
          `${API_CONFIG.BASE_URL}${API_ENDPOINTS.CRYPTO_NETWORKS}`,
        );
        const result = await response.json();
        if (mounted && result.success && result.data) {
          setCryptoNetworks(result.data.filter((n: any) => n.is_active));
        }
      } catch (err: any) {
        console.error("Failed to load crypto networks:", err);
      }
    })();
    return () => {
      mounted = false;
    };
  }, []);

  // Fetch available plans
  useEffect(() => {
    let mounted = true;
    (async () => {
      try {
        const response = await fetch(
          `${API_CONFIG.BASE_URL}${API_ENDPOINTS.PLANS}`,
        );
        const result = await response.json();
        if (mounted && result.success && result.data) {
          setPlans(result.data);
        }
      } catch (err: any) {
        console.error("Failed to load plans:", err);
      }
    })();
    return () => {
      mounted = false;
    };
  }, []);

  const countries = [
    "Afghanistan",
    "Albania",
    "Algeria",
    "Argentina",
    "Armenia",
    "Australia",
    "Austria",
    "Azerbaijan",
    "Bahrain",
    "Bangladesh",
    "Belarus",
    "Belgium",
    "Bolivia",
    "Bosnia and Herzegovina",
    "Brazil",
    "Bulgaria",
    "Cambodia",
    "Canada",
    "Chile",
    "China",
    "Colombia",
    "Croatia",
    "Czech Republic",
    "Denmark",
    "Dominican Republic",
    "Ecuador",
    "Egypt",
    "Estonia",
    "Ethiopia",
    "Finland",
    "France",
    "Georgia",
    "Germany",
    "Ghana",
    "Greece",
    "Guatemala",
    "Hungary",
    "Iceland",
    "India",
    "Indonesia",
    "Iran",
    "Iraq",
    "Ireland",
    "Israel",
    "Italy",
    "Japan",
    "Jordan",
    "Kazakhstan",
    "Kenya",
    "Kuwait",
    "Kyrgyzstan",
    "Latvia",
    "Lebanon",
    "Libya",
    "Lithuania",
    "Luxembourg",
    "Malaysia",
    "Mexico",
    "Morocco",
    "Nepal",
    "Netherlands",
    "New Zealand",
    "Nigeria",
    "North Macedonia",
    "Norway",
    "Oman",
    "Pakistan",
    "Palestine",
    "Peru",
    "Philippines",
    "Poland",
    "Portugal",
    "Qatar",
    "Romania",
    "Russia",
    "Saudi Arabia",
    "Serbia",
    "Singapore",
    "Slovakia",
    "Slovenia",
    "South Africa",
    "South Korea",
    "Spain",
    "Sri Lanka",
    "Sweden",
    "Switzerland",
    "Syria",
    "Taiwan",
    "Tajikistan",
    "Thailand",
    "Tunisia",
    "Turkey",
    "Turkmenistan",
    "UAE",
    "Ukraine",
    "United Kingdom",
    "United States",
    "Uruguay",
    "Uzbekistan",
    "Venezuela",
    "Vietnam",
    "Yemen",
    "Zimbabwe",
  ];

  const pakistanPaymentMethods = [
    {
      id: "jazzcash",
      name: "JazzCash",
      icon: "📱",
      accountNumber: formData.phoneNumber || "03XXXXXXXXX",
    },
    {
      id: "easypaisa",
      name: "EasyPaisa",
      icon: "💳",
      accountNumber: formData.phoneNumber || "03XXXXXXXXX",
    },
    {
      id: "sadapay",
      name: "SadaPay",
      icon: "🏦",
      accountNumber: formData.phoneNumber || "03XXXXXXXXX",
    },
    {
      id: "Upaisa",
      name: "Upaisa",
      icon: "👛",
      accountNumber: formData.phoneNumber || "03XXXXXXXXX",
    },
    {
      id: "nayapay",
      name: "NayaPay",
      icon: "💰",
      accountNumber: formData.phoneNumber || "03XXXXXXXXX",
    },
  ];

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>,
  ) => {
    if (error) setError("");
    if (fieldErrors[(e.target as any).name]) {
      setFieldErrors((prev) => {
        const { [e.target.name]: _, ...rest } = prev;
        return rest;
      });
    }

    let value = e.target.value;

    if (e.target.name === "email") {
      value = normalizeEmailToASCII(value);
      value = value.replace(/\s/g, "").replace(/[^A-Za-z0-9@._-]/g, "");
    }

    if (e.target.name === "password" || e.target.name === "confirmPassword") {
      value = value.replace(/\s/g, "");
    }

    if (
      e.target.name === "phoneNumber" ||
      e.target.name === "confirmPhoneNumber"
    ) {
      value = value.replace(/[^\d+]/g, "");
    }

    // No spaces or special symbols: transaction account number (digits only)
    if (e.target.name === "transactionAccountNumber") {
      value = value.replace(/\D/g, "");
    }

    // No spaces or special symbols: transaction ID (letters and numbers only)
    if (e.target.name === "transactionId") {
      value = value.replace(/[^A-Za-z0-9]/g, "");
    }

    setFormData({
      ...formData,
      [e.target.name]: value,
    });
  };

  const handleReferralPaste = (e: React.ClipboardEvent<HTMLInputElement>) => {
    const text = e.clipboardData.getData("text");
    if (!text) return;
    e.preventDefault();
    let code = text;
    try {
      const url = new URL(text);
      const param = url.searchParams.get("refCode");
      if (param) code = param;
    } catch {}
    const match = text.match(/refCode=([^&]+)/i);
    if (match) code = match[1];
    code = code.replace(/^"+|"+$/g, "");
    setFormData((prev) => ({ ...prev, referralCode: code }));
    setFieldErrors((prev) => {
      const { referralCode, ...rest } = prev;
      return rest;
    });
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (error) setError("");
    if (!e.target.files || !e.target.files[0]) return;

    const file = e.target.files[0];
    const allowedTypes = [
      "image/jpeg",
      "image/jpg",
      "image/png",
      "image/gif",
      "image/webp",
    ];
    const maxSize = 10 * 1024 * 1024; // 10MB

    if (!allowedTypes.includes(file.type)) {
      showToast(
        "Please upload a valid image file (JPEG, PNG, GIF, or WebP)",
        "error",
      );
      return;
    }

    if (file.size > maxSize) {
      showToast("File size must be less than 10MB", "error");
      return;
    }

    setFormData({ ...formData, screenshot: file });
    showToast("Image uploaded successfully", "success");
  };

  const showToast = (
    message: string,
    type: "success" | "error" = "success",
  ) => {
    setToast({ message, type });
    const ms = type === "error" ? 5000 : 3500;
    setTimeout(() => setToast(null), ms);
  };

  const handlePaymentMethodSelection = (methodId: string) => {
    const current = formData.paymentMethods;
    let updated;
    if (current.includes(methodId)) {
      updated = current.filter((id) => id !== methodId);
    } else {
      if (current.length < 2) {
        updated = [...current, methodId];
      } else {
        updated = [current[1], methodId];
      }
    }
    setFormData({ ...formData, paymentMethods: updated });
  };

  const validateStep1 = () => {
    if (
      !formData.name ||
      !formData.email ||
      !formData.password ||
      !formData.confirmPassword
    ) {
      const msg = "Please fill in all required fields";
      setError(msg);
      showToast(msg, "error");
      return false;
    }
    if (formData.password !== formData.confirmPassword) {
      const msg = "Passwords do not match";
      setError(msg);
      showToast(msg, "error");
      return false;
    }
    if (formData.password.length < 8) {
      const msg = "Password must be at least 8 characters long";
      setError(msg);
      showToast(msg, "error");
      return false;
    }
    return true;
  };

  const validateStep2 = () => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(formData.email)) {
      const msg = "Please enter a valid email address";
      setError(msg);
      showToast(msg, "error");
      return false;
    }

    if (formData.country === "Pakistan") {
      // Pakistani users validation
      if (
        !formData.phoneNumber ||
        !formData.confirmPhoneNumber ||
        !formData.accountTitle
      ) {
        const msg = "Please fill in all required fields";
        setError(msg);
        showToast(msg, "error");
        return false;
      }
      if (formData.phoneNumber !== formData.confirmPhoneNumber) {
        const msg = "Phone numbers do not match";
        setError(msg);
        showToast(msg, "error");
        return false;
      }
      if (formData.paymentMethods.length === 0) {
        const msg = "Please select at least one payment method";
        setError(msg);
        showToast(msg, "error");
        return false;
      }
    } else {
      // International users validation
      if (!formData.bep20Address) {
        const msg = "Please enter your BEP20 wallet address";
        setError(msg);
        showToast(msg, "error");
        return false;
      }
      if (!formData.confirmBep20Address) {
        const msg = "Please confirm your BEP20 wallet address";
        setError(msg);
        showToast(msg, "error");
        return false;
      }
      if (formData.bep20Address !== formData.confirmBep20Address) {
        const msg = "BEP20 addresses do not match";
        setError(msg);
        showToast(msg, "error");
        return false;
      }
    }
    return true;
  };

  const validateStep3 = () => {
    if (!formData.screenshot || !formData.transactionId) {
      const msg = "Please fill in all required fields and upload screenshot";
      setError(msg);
      showToast(msg, "error");
      return false;
    }

    // For Pakistani users, validate transaction account fields
    if (formData.country === "Pakistan") {
      if (
        !formData.transactionAccountNumber ||
        !formData.transactionAccountTitle
      ) {
        const msg = "Please fill in transaction account title and number";
        setError(msg);
        showToast(msg, "error");
        return false;
      }
    }

    const allowedTypes = [
      "image/jpeg",
      "image/jpg",
      "image/png",
      "image/gif",
      "image/webp",
    ];
    if (!allowedTypes.includes(formData.screenshot.type)) {
      const msg = "Please upload a valid image file (JPEG, PNG, GIF, or WebP)";
      setError(msg);
      showToast(msg, "error");
      return false;
    }
    const maxSize = 10 * 1024 * 1024; // 10MB
    if (formData.screenshot.size > maxSize) {
      const msg = "Image file size must be less than 10MB";
      setError(msg);
      showToast(msg, "error");
      return false;
    }
    return true;
  };

  const validatePlanStep = () => {
    if (!formData.planId) {
      const msg = "Please select a plan to continue";
      setError(msg);
      showToast(msg, "error");
      return false;
    }
    return true;
  };

  const nextStep = () => {
    if (currentStep === 1 && validatePlanStep()) setCurrentStep(2);
    else if (currentStep === 2 && validateStep1()) setCurrentStep(3);
    else if (currentStep === 3 && validateStep2()) setCurrentStep(4);
  };

  const prevStep = () => {
    if (currentStep > 1) setCurrentStep(currentStep - 1);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validateStep3() || !formData.planId) return;

    setIsLoading(true);
    setError("");

    try {
      // Normalize email to ASCII before sending to API
      const normalizedEmail = normalizeEmailToASCII(formData.email);

      const registrationData: RegisterRequest = {
        name: formData.name,
        email: normalizedEmail,
        password: formData.password,
        confirmPassword: formData.confirmPassword,
        referralCode: formData.referralCode,
        country: formData.country,
        planId: formData.planId!,
        phoneNumber: formData.phoneNumber,
        confirmPhoneNumber: formData.confirmPhoneNumber,
        paymentMethods: formData.paymentMethods,
        accountTitle: formData.accountTitle,
        bep20Address: formData.bep20Address,
        trc20Address: formData.trc20Address,
        screenshot: formData.screenshot,
        transactionId: formData.transactionId,
        transactionAccountNumber: formData.transactionAccountNumber,
        transactionAccountTitle: formData.transactionAccountTitle,
      };

      console.log("📤 Sending registration data to API:", registrationData);

      const response = await register(registrationData);

      console.log("✅ API Response:", response);

      if (response.success) {
        try {
          localStorage.setItem("pending_user_name", formData.name || "");
        } catch {}
        showToast("Account created successfully! Welcome to SkyBridge.", "success");
        setTimeout(() => {
          // Always show the post-registration screen (WhatsApp channel join, pending notice)
          navigate("/account-pending");
        }, 1500);
      } else {
        let msg = response.error || "Registration failed. Please try again.";
        if (
          response.fieldErrors &&
          Object.values(response.fieldErrors).length > 0
        ) {
          msg = Object.values(response.fieldErrors)[0] || msg;
        }
        setError(msg);
        if (response.fieldErrors) {
          setFieldErrors(response.fieldErrors);
        }
        showToast(msg, "error");
      }
    } catch (err: any) {
      console.error("❌ Registration error:", err);
      const msg = err?.message || "Registration failed. Please try again.";
      setError(msg);
      showToast(msg, "error");
    } finally {
      setIsLoading(false);
    }
  };

  const renderStepIndicator = () => (
    <div className="flex items-center justify-center mb-6 sm:mb-8">
      {[1, 2, 3, 4].map((step) => (
        <div key={step} className="flex items-center">
          <div
            className={`w-8 h-8 sm:w-10 sm:h-10 rounded-full flex items-center justify-center font-semibold text-sm sm:text-base ${
              currentStep >= step
                ? "bg-blue-600 text-white"
                : "bg-gray-200 text-gray-500"
            }`}
          >
            {currentStep > step ? (
              <CheckCircle className="w-4 h-4 sm:w-6 sm:h-6" />
            ) : (
              step
            )}
          </div>
          {step < 4 && (
            <div
              className={`w-6 sm:w-12 h-1 mx-1 sm:mx-2 ${
                currentStep > step ? "bg-blue-600" : "bg-gray-200"
              }`}
            />
          )}
        </div>
      ))}
    </div>
  );

  const renderPlanStep = () => (
    <div className="space-y-4 sm:space-y-6">
      <div className="text-center mb-4 sm:mb-6">
        <h2 className="text-xl sm:text-2xl font-bold text-gray-800">
          Select Your Plan
        </h2>
        <p className="text-sm sm:text-base text-gray-600">
          Choose the plan that suits you best
        </p>
      </div>
      {plans.length === 0 ? (
        <div className="flex justify-center py-8">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {plans.map((plan) => {
            const isSelected =
              formData.planId != null &&
              Number(formData.planId) === Number(plan.id);
            const displayName = getDisplayNameForPlan(plan.name);
            const ui = getPlanContentByPricePkr(plan.price_pkr) ?? {
              colorClass: "bg-gray-600",
              courses: [],
              earningOpportunities: [],
              bonusesRewards: [],
            };
            const PlanIcon =
              displayName === "Basic"
                ? Star
                : displayName === "Standard"
                  ? Sparkles
                  : displayName === "Prime"
                    ? TrendingUp
                    : displayName === "Premium"
                      ? Crown
                      : Package;
            return (
              <div
                key={plan.id}
                className={`relative rounded-2xl border-2 transition-all overflow-hidden bg-white flex flex-col ${
                  isSelected
                    ? "border-blue-500 shadow-xl ring-2 ring-blue-200"
                    : "border-gray-200 hover:border-blue-300 hover:shadow-lg"
                }`}
              >
                {isSelected && (
                  <div className="absolute top-4 right-4 z-10">
                    <CheckCircle className="w-6 h-6 text-blue-600" />
                  </div>
                )}
                <div
                  className={`text-white p-6 pb-10 ${ui.colorClass}`}
                  onClick={() => {
                    setFormData((prev) => ({
                      ...prev,
                      planId: Number(plan.id),
                    }));
                    if (error) setError("");
                  }}
                  role="button"
                  tabIndex={0}
                  onKeyDown={(e) => {
                    if (e.key === "Enter" || e.key === " ") {
                      e.preventDefault();
                      setFormData((prev) => ({
                        ...prev,
                        planId: Number(plan.id),
                      }));
                      if (error) setError("");
                    }
                  }}
                >
                  <div className="flex items-center justify-center gap-2 mb-2">
                    <div className="w-12 h-12 rounded-full bg-white/20 flex items-center justify-center border-2 border-white/50">
                      <PlanIcon className="w-6 h-6 text-white" />
                    </div>
                  </div>
                  <h3 className="text-xl font-bold text-center">
                    {formatPlanLabel(plan.name)}
                  </h3>
                  <p className="text-2xl sm:text-3xl font-extrabold text-center mb-1">
                    ${plan.price_usd}{" "}
                    <span className="text-sm font-normal opacity-90">
                      Lifetime
                    </span>
                  </p>
                  <p className="text-sm text-center opacity-90">
                    {plan.price_pkr.toLocaleString()} PKR
                  </p>
                </div>
                <div className="p-6 space-y-4 flex-grow">
                  <div>
                    <h4 className="font-bold text-gray-800 text-xs uppercase tracking-wide mb-2">
                      Courses Included
                    </h4>
                    <ul className="space-y-1">
                      {ui.courses.map((item, idx) => (
                        <li
                          key={idx}
                          className="flex items-start text-gray-700 text-sm"
                        >
                          <Check className="w-4 h-4 text-green-500 mr-2 flex-shrink-0 mt-0.5" />
                          {item}
                        </li>
                      ))}
                    </ul>
                  </div>
                  <div>
                    <h4 className="font-bold text-gray-800 text-xs uppercase tracking-wide mb-2">
                      Earning Opportunities
                    </h4>
                    <ul className="space-y-1">
                      {ui.earningOpportunities.map((item, idx) => (
                        <li
                          key={idx}
                          className="flex items-start text-gray-700 text-sm"
                        >
                          <Check className="w-4 h-4 text-blue-500 mr-2 flex-shrink-0 mt-0.5" />
                          {item}
                        </li>
                      ))}
                    </ul>
                  </div>
                  <div>
                    <h4 className="font-bold text-gray-800 text-xs uppercase tracking-wide mb-2">
                      Bonuses & Rewards
                    </h4>
                    <ul className="space-y-1">
                      {ui.bonusesRewards.map((item, idx) => (
                        <li
                          key={idx}
                          className="flex items-start text-gray-700 text-sm"
                        >
                          <Check className="w-4 h-4 text-amber-500 mr-2 flex-shrink-0 mt-0.5" />
                          {item}
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
                <div className="p-6 pt-0 mt-auto space-y-3">
                  <button
                    type="button"
                    onClick={() => {
                      setFormData((prev) => ({
                        ...prev,
                        planId: Number(plan.id),
                      }));
                      if (error) setError("");
                    }}
                    className={`w-full py-3 text-white font-semibold rounded-lg transition-opacity hover:opacity-90 ${ui.colorClass}`}
                  >
                    {isSelected ? "Selected" : "Select Plan"}
                  </button>
                  {isSelected && (
                    <div className="p-3 sm:p-4 bg-sky-50 border border-sky-200 rounded-lg">
                      <p className="text-sm leading-relaxed text-sky-800 text-center">
                        Go to the button below and press the{" "}
                        <strong>Continue</strong> button to move to the next
                        step.
                      </p>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );

  const renderStep1 = () => (
    <div className="space-y-4 sm:space-y-6">
      <div className="text-center mb-4 sm:mb-6">
        <h2 className="text-xl sm:text-2xl font-bold text-gray-800">
          Personal Information
        </h2>
        <p className="text-sm sm:text-base text-gray-600">
          Enter your basic details and select payment method
        </p>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 sm:gap-6">
        <div>
          <label className="block text-gray-700 font-medium mb-2">
            Full Name
          </label>
          <div className="relative">
            <User className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            <input
              type="text"
              name="name"
              value={formData.name}
              onChange={handleChange}
              placeholder="Enter your full name"
              className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
              required
            />
          </div>
        </div>
        <div>
          <label className="block text-gray-700 font-medium mb-2">
            Email Address
          </label>
          <div className="relative">
            <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            <input
              type="email"
              name="email"
              value={formData.email}
              onChange={handleChange}
              placeholder="admin@sage.com"
              className={`w-full pl-10 pr-4 py-3 border rounded-lg focus:ring-2 transition-all ${
                fieldErrors.email
                  ? "border-red-500 focus:ring-red-500"
                  : "border-gray-300 focus:ring-blue-500"
              } focus:border-transparent`}
              required
            />
            {fieldErrors.email && (
              <p className="mt-1 text-sm text-red-600">{fieldErrors.email}</p>
            )}
          </div>
        </div>
        <div>
          <label className="block text-gray-700 font-medium mb-2">
            Country
          </label>
          <div className="relative">
            <Globe className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            <select
              name="country"
              value={formData.country}
              onChange={handleChange}
              className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all appearance-none bg-white"
              required
            >
              {countries.map((country) => (
                <option key={country} value={country}>
                  {country}
                </option>
              ))}
            </select>
          </div>
        </div>
        <div>
          <label className="block text-gray-700 font-medium mb-2">
            Referral Code
          </label>
          <input
            type="text"
            name="referralCode"
            value={formData.referralCode}
            onChange={handleChange}
            onPaste={handleReferralPaste}
            placeholder="Enter referral code"
            className={`w-full px-4 py-3 border rounded-lg focus:ring-2 transition-all ${
              fieldErrors.referralCode
                ? "border-red-500 focus:ring-red-500"
                : "border-gray-300 focus:ring-blue-500"
            } focus:border-transparent`}
          />
          {fieldErrors.referralCode && (
            <p className="mt-1 text-sm text-red-600">
              {fieldErrors.referralCode}
            </p>
          )}
        </div>
        <div>
          <label className="block text-gray-700 font-medium mb-2">
            Password
          </label>
          <div className="relative">
            <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            <input
              type={showPassword ? "text" : "password"}
              name="password"
              value={formData.password}
              onChange={handleChange}
              placeholder="••••••••"
              className="w-full pl-10 pr-12 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
              required
            />
            <button
              type="button"
              onClick={() => setShowPassword(!showPassword)}
              className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600"
            >
              {showPassword ? (
                <EyeOff className="w-5 h-5" />
              ) : (
                <Eye className="w-5 h-5" />
              )}
            </button>
          </div>
        </div>
        <div>
          <label className="block text-gray-700 font-medium mb-2">
            Confirm Password
          </label>
          <div className="relative">
            <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            <input
              type={showConfirmPassword ? "text" : "password"}
              name="confirmPassword"
              value={formData.confirmPassword}
              onChange={handleChange}
              onPaste={(e) => e.preventDefault()}
              onCopy={(e) => e.preventDefault()}
              onCut={(e) => e.preventDefault()}
              onContextMenu={(e) => e.preventDefault()}
              placeholder="••••••••"
              className="w-full pl-10 pr-12 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
              required
            />
            <button
              type="button"
              onClick={() => setShowConfirmPassword(!showConfirmPassword)}
              className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600"
            >
              {showConfirmPassword ? (
                <EyeOff className="w-5 h-5" />
              ) : (
                <Eye className="w-5 h-5" />
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );

  const renderStep2 = () => (
    <div className="space-y-6">
      <div className="text-center mb-6">
        <h2 className="text-2xl font-bold text-gray-800">Contact & Payment</h2>
        <p className="text-gray-600">
          {formData.country === "Pakistan"
            ? "Please Provide Your Number In Which You Want To Take Withdrawals"
            : "Provide your cryptocurrency wallet address"}
        </p>
      </div>
      {formData.country === "Pakistan" && (
        <>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-gray-700 font-medium mb-2">
                Account Number
              </label>
              <div className="relative">
                <Phone className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                <input
                  type="tel"
                  name="phoneNumber"
                  value={formData.phoneNumber}
                  onChange={handleChange}
                  placeholder="Enter your phone number (digits only)"
                  className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                  required
                />
              </div>
            </div>
            <div>
              <label className="block text-gray-700 font-medium mb-2">
                Confirm Account Number
              </label>
              <div className="relative">
                <Phone className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                <input
                  type="tel"
                  name="confirmPhoneNumber"
                  value={formData.confirmPhoneNumber}
                  onChange={handleChange}
                  onPaste={(e) => e.preventDefault()}
                  onCopy={(e) => e.preventDefault()}
                  onCut={(e) => e.preventDefault()}
                  onContextMenu={(e) => e.preventDefault()}
                  placeholder="Confirm your phone number (digits only)"
                  className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                  required
                />
              </div>
            </div>
          </div>
          <div>
            <label className="block text-gray-700 font-medium mb-2">
              Account Title
            </label>
            <div className="relative">
              <User className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
              <input
                type="text"
                name="accountTitle"
                value={formData.accountTitle}
                onChange={handleChange}
                placeholder="Enter account holder name"
                className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                required
              />
            </div>
          </div>
          <p className="mt-1 text-xs text-gray-500">
            Payment account holder name as per your bank/mobile wallet
          </p>
        </>
      )}
      <div>
        <label className="block text-gray-700 font-medium mb-4">
          Payment Method
        </label>
        <p className="text-sm text-gray-600 mb-4">
          Please select one or two accounts from the number you entered above:
        </p>
        {formData.country === "Pakistan" ? (
          <>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {pakistanPaymentMethods.map((method) => (
                <div
                  key={method.id}
                  onClick={() => handlePaymentMethodSelection(method.id)}
                  className={`p-4 border-2 rounded-lg cursor-pointer transition-all text-center relative ${
                    formData.paymentMethods.includes(method.id)
                      ? "border-blue-500 bg-blue-50"
                      : "border-gray-200 hover:border-gray-300"
                  }`}
                >
                  <input
                    type="checkbox"
                    checked={formData.paymentMethods.includes(method.id)}
                    onChange={() => handlePaymentMethodSelection(method.id)}
                    className="absolute top-2 right-2 w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 rounded focus:ring-blue-500 focus:ring-2"
                  />
                  <div className="text-2xl mb-2">{method.icon}</div>
                  <div className="font-medium text-sm">{method.name}</div>
                </div>
              ))}
            </div>
            {formData.paymentMethods.length > 0 && (
              <div className="mt-4 space-y-3">
                <div className="p-3 bg-blue-50 border border-blue-200 rounded-lg">
                  <p className="text-sm font-medium text-blue-800 mb-2">
                    Selected Payment Methods ({formData.paymentMethods.length}
                    /2):
                  </p>
                  <div className="space-y-2">
                    {formData.paymentMethods.map((id) => {
                      const method = pakistanPaymentMethods.find(
                        (m) => m.id === id,
                      );
                      return method ? (
                        <div
                          key={id}
                          className="flex items-center justify-between p-2 bg-white rounded border"
                        >
                          <div className="flex items-center space-x-2">
                            <span className="text-lg">{method.icon}</span>
                            <span className="font-medium text-sm">
                              {method.name}
                            </span>
                          </div>
                          <div className="text-right">
                            <p className="text-xs text-gray-600">
                              Account Number:
                            </p>
                            <p className="font-mono text-sm font-bold text-blue-700">
                              {method.accountNumber}
                            </p>
                          </div>
                        </div>
                      ) : null;
                    })}
                  </div>
                </div>
              </div>
            )}
          </>
        ) : (
          <div className="space-y-4">
            <div className="p-4 border-2 border-yellow-200 bg-yellow-50 rounded-lg">
              <div className="flex items-center space-x-3 mb-3">
                <CreditCard className="w-6 h-6 text-yellow-600" />
                <div>
                  <div className="font-medium text-yellow-800">BEP20 (BSC)</div>
                  <div className="text-sm text-yellow-700">
                    Binance Smart Chain wallet address
                  </div>
                </div>
              </div>
              <div className="space-y-3">
                <input
                  type="text"
                  name="bep20Address"
                  value={formData.bep20Address || ""}
                  onChange={handleChange}
                  placeholder="Enter your BEP20 wallet address"
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                  required
                />
                <input
                  type="text"
                  name="confirmBep20Address"
                  value={formData.confirmBep20Address || ""}
                  onChange={handleChange}
                  placeholder="Confirm your BEP20 wallet address"
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                  required
                />
              </div>
            </div>
            <div className="p-3 bg-blue-50 border border-blue-200 rounded-lg">
              <p className="text-sm text-blue-700">
                <strong>Note:</strong> Please provide your BEP20 (Binance Smart
                Chain) wallet address to receive payments. Make sure to
                double-check your address as it cannot be changed later.
              </p>
            </div>
          </div>
        )}
      </div>
      {formData.country === "Pakistan" && (
        <div className="mt-6 p-4 bg-yellow-50 border-l-4 border-yellow-400 rounded-lg">
          <div className="flex items-start">
            <svg
              className="w-5 h-5 text-yellow-400 mt-0.5"
              fill="currentColor"
              viewBox="0 0 20 20"
            >
              <path
                fillRule="evenodd"
                d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z"
                clipRule="evenodd"
              />
            </svg>
            <div className="ml-3">
              <p className="text-sm font-medium text-yellow-800">
                Important Notice
              </p>
              <p className="text-sm text-yellow-700 mt-1">
                Please ensure your phone number is valid and correct. This
                number cannot be changed after registration and will be used for
                important notifications and all withdrawal transactions.
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );

  const renderStep3 = () => {
    const selectedPlan =
      formData.planId != null
        ? plans.find((p) => p.id === formData.planId)
        : null;
    const planDisplayName = selectedPlan
      ? getDisplayNameForPlan(selectedPlan.name)
      : null;
    const selectedPlanUsd =
      selectedPlan != null
        ? typeof selectedPlan.price_usd === "string"
          ? parseFloat(selectedPlan.price_usd)
          : Number(selectedPlan.price_usd)
        : NaN;
    const cryptoPaymentUsd =
      selectedPlan != null && !Number.isNaN(selectedPlanUsd)
        ? selectedPlanUsd
        : (cryptoNetworks[0]?.registration_fee ?? "3.33");

    return (
      <div className="space-y-6">
        <div className="text-center mb-6">
          <h2 className="text-2xl font-bold text-gray-800">Payment Details</h2>
          <p className="text-gray-600">
            Upload transaction screenshot and provide details
          </p>
        </div>

        {selectedPlan && planDisplayName && (
          <div className="p-4 bg-sky-50 border border-sky-200 rounded-lg">
            <h3 className="text-lg font-semibold text-sky-800 mb-2">
              Selected Plan
            </h3>
            <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-sky-900">
              <span className="font-semibold">{planDisplayName} Plan</span>
              <span className="text-sky-700">
                $
                {typeof selectedPlan.price_usd === "string"
                  ? parseFloat(selectedPlan.price_usd)
                  : selectedPlan.price_usd}{" "}
                (Lifetime)
              </span>
              <span className="text-sky-700">
                {typeof selectedPlan.price_pkr === "number"
                  ? selectedPlan.price_pkr.toLocaleString()
                  : String(selectedPlan.price_pkr)}{" "}
                PKR
              </span>
            </div>
          </div>
        )}

        {formData.country === "Pakistan" &&
          formData.paymentMethods.length > 0 && (
            <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
              <h3 className="text-lg font-semibold text-blue-800 mb-3">
                Payment Account Numbers
              </h3>
              <p className="text-sm text-blue-700 mb-3">
                Send your payment to any of these account numbers:
              </p>
              {accountDetailsList.length > 0 ? (
                <div className="space-y-3">
                  {accountDetailsList.map((acc, idx) => (
                    <div
                      key={acc.id ?? idx}
                      className="p-3 bg-yellow-50 border border-yellow-200 rounded"
                    >
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                        <div>
                          <p className="text-sm font-medium text-yellow-800 mb-1">
                            Account Title:
                          </p>
                          <p className="font-semibold text-yellow-900">
                            {acc.account_title}
                          </p>
                        </div>
                        <div>
                          <p className="text-sm font-medium text-yellow-800 mb-1">
                            Account Number:
                          </p>
                          <p className="font-mono font-semibold text-yellow-900">
                            {acc.account_number}
                          </p>
                        </div>
                        <div>
                          <p className="text-sm font-medium text-yellow-800 mb-1">
                            Bank:
                          </p>
                          <p className="font-semibold text-yellow-900">
                            {acc.bank}
                          </p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="p-3 bg-yellow-50 border border-yellow-200 rounded">
                  <p className="text-sm text-yellow-800">
                    {accountError
                      ? "Account details unavailable"
                      : "Loading account details..."}
                  </p>
                </div>
              )}
              <div className="mt-3 p-3 bg-green-50 border border-green-200 rounded">
                <p className="text-sm text-green-800 font-medium">
                  Instructions:
                </p>
                <p className="text-sm text-green-700">
                  1. Send payment to any account above
                  <br />
                  2. Take a screenshot of the transaction
                  <br />
                  3. Upload the screenshot below
                  <br />
                  4. Enter the transaction ID
                  <br />
                  5. Submit Request Within 30 Minutes After Sending Payment
                  <br />
                  6. Payment More Then 48 Hours Old Will Not Accepted
                </p>
              </div>
            </div>
          )}
        {formData.country !== "Pakistan" && formData.bep20Address && (
          <div className="p-4 bg-purple-50 border border-purple-200 rounded-lg">
            <h3 className="text-lg font-semibold text-purple-800 mb-3">
              Crypto Payment Details
            </h3>
            <p className="text-sm text-purple-700 mb-3">
              Send your registration fee to the wallet address below:
            </p>
            <div className="mb-4 p-3 bg-yellow-50 border border-yellow-200 rounded">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {cryptoNetworks.length > 0 ? (
                  <>
                    <div>
                      <p className="text-sm font-medium text-yellow-800 mb-1">
                        🌐 Crypto Network:
                      </p>
                      <p className="font-semibold text-yellow-900">
                        {cryptoNetworks[0].network_name}
                      </p>
                    </div>
                    <div>
                      <p className="text-sm font-medium text-yellow-800 mb-1">
                        💵 Registration Fee:
                      </p>
                      <p className="font-semibold text-yellow-900">
                        ${cryptoPaymentUsd}
                      </p>
                    </div>
                    <div className="md:col-span-2">
                      <p className="text-sm font-medium text-yellow-800 mb-1">
                        💰 Wallet Address:
                      </p>
                      <p className="font-mono font-semibold text-yellow-900 break-all bg-white p-2 rounded">
                        {cryptoNetworks[0].wallet_address}
                      </p>
                    </div>
                  </>
                ) : (
                  <div className="md:col-span-2">
                    <p className="text-sm text-yellow-800">
                      Loading payment details...
                    </p>
                  </div>
                )}
              </div>
            </div>
            <div className="mt-3 p-3 bg-green-50 border border-green-200 rounded">
              <p className="text-sm text-green-800 font-medium">
                📋 Instructions:
              </p>
              <p className="text-sm text-green-700">
                1. Send ${cryptoPaymentUsd} to the wallet address above
                <br />
                2. Take a screenshot of the transaction
                <br />
                3. Upload the screenshot below
                <br />
                4. Enter the transaction ID
              </p>
            </div>
          </div>
        )}
        {formData.country === "Pakistan" && (
          <>
            <div>
              <label className="block text-gray-700 font-medium mb-2">
                Transaction Account Title
              </label>
              <div className="relative">
                <User className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                <input
                  type="text"
                  name="transactionAccountTitle"
                  value={formData.transactionAccountTitle}
                  onChange={handleChange}
                  placeholder="Enter transaction account title"
                  className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                  required
                />
              </div>
            </div>
            <p className="mt-1 text-xs text-gray-500">
              Payment account holder name as per your bank/mobile wallet
            </p>
            <div>
              <label className="block text-gray-700 font-medium mb-2">
                Transaction Account Number
              </label>
              <div className="relative">
                <Smartphone className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                <input
                  type="text"
                  name="transactionAccountNumber"
                  value={formData.transactionAccountNumber}
                  onChange={handleChange}
                  placeholder="Enter transaction account number (digits only)"
                  className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                  required
                />
              </div>
            </div>
            <p className="mt-1 text-xs text-gray-500">
              Account Number From Which Payment Send
            </p>
          </>
        )}
        <div>
          <label className="block text-gray-700 font-medium mb-2">
            Transaction ID
          </label>
          <div className="relative">
            <FileText className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            <input
              type="text"
              name="transactionId"
              value={formData.transactionId}
              onChange={handleChange}
              placeholder="Enter transaction ID (letters & numbers only)"
              className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
              required
            />
          </div>
          <p className="text-sm text-gray-500 required-field-note">
            Note : Transaction I'd Should Be Correct Otherwise Account Request
            Will Be Reject
          </p>
        </div>
        <div>
          <label className="block text-gray-700 font-medium mb-2">
            Transaction Screenshot
          </label>
          <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center">
            <input
              type="file"
              accept="image/*"
              onChange={handleFileChange}
              className="hidden"
              id="screenshot-upload"
            />
            {formData.screenshot ? (
              <div className="space-y-4">
                <div className="relative inline-block">
                  <img
                    src={URL.createObjectURL(formData.screenshot)}
                    alt="Transaction Screenshot Preview"
                    className="max-w-full max-h-64 rounded-lg shadow-md border border-gray-200"
                  />
                  <button
                    type="button"
                    onClick={() =>
                      setFormData({ ...formData, screenshot: null })
                    }
                    className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full w-6 h-6 flex items-center justify-center text-sm hover:bg-red-600 transition-colors"
                  >
                    ×
                  </button>
                </div>
                <div className="text-sm text-gray-600">
                  <p className="font-medium">{formData.screenshot.name}</p>
                  <p>
                    {(formData.screenshot.size / 1024 / 1024).toFixed(2)} MB
                  </p>
                </div>
                <label
                  htmlFor="screenshot-upload"
                  className="inline-block cursor-pointer bg-blue-500 text-white px-4 py-2 rounded-lg hover:bg-blue-600 transition-colors"
                >
                  Change Image
                </label>
              </div>
            ) : (
              <label htmlFor="screenshot-upload" className="cursor-pointer">
                <Camera className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                <div className="text-lg font-medium text-gray-700 mb-2">
                  Upload Screenshot
                </div>
                <div className="text-sm text-gray-500">
                  Click to select transaction screenshot
                </div>
              </label>
            )}
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-sky-500 via-sky-600 to-sky-700 flex items-center justify-center p-3 sm:p-4">
      <div className="w-full max-w-4xl bg-white rounded-xl sm:rounded-2xl shadow-2xl overflow-hidden">
        {toast && (
          <div
            role="alert"
            className={`fixed top-4 right-4 z-[9999] max-w-[calc(100vw-2rem)] sm:max-w-md px-4 py-3 rounded-lg shadow-xl text-white text-sm font-medium ${
              toast.type === "success" ? "bg-green-600" : "bg-red-600"
            }`}
          >
            {toast.message}
          </div>
        )}
        <div className="bg-gradient-to-r from-sky-600 to-sky-700 text-white text-center py-8">
          <h1 className="text-3xl font-bold">Create Account</h1>
          <p className="text-blue-100 mt-2">
            Join SkyBridge International - Step {currentStep} of 4
          </p>
        </div>
        <div className="p-8">
          {renderStepIndicator()}
          {error && (
            <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg flex items-center">
              <AlertCircle className="h-5 w-5 text-red-500 mr-3 flex-shrink-0" />
              <p className="text-red-700 text-sm">{error}</p>
            </div>
          )}
          <form
            onSubmit={
              currentStep === 4 ? handleSubmit : (e) => e.preventDefault()
            }
          >
            {currentStep === 1 && renderPlanStep()}
            {currentStep === 2 && renderStep1()}
            {currentStep === 3 && renderStep2()}
            {currentStep === 4 && renderStep3()}

            <div ref={continueButtonRef} className="mt-8 border-t border-gray-200 pt-6">
              {currentStep === 1 && selectedPlan && selectedPlanLabel && (
                <div className="mb-4 rounded-xl border border-emerald-200 bg-emerald-50 px-4 py-3 text-center sm:text-left">
                  <p className="text-xs font-semibold uppercase tracking-wide text-emerald-700">
                    Selected plan
                  </p>
                  <p className="mt-1 text-lg font-bold text-emerald-900 sm:text-xl">
                    {selectedPlanLabel}
                  </p>
                  <p className="mt-0.5 text-sm text-emerald-700">
                    ${selectedPlan.price_usd} ·{" "}
                    {selectedPlan.price_pkr.toLocaleString()} PKR
                  </p>
                </div>
              )}

              <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                <button
                  type="button"
                  onClick={prevStep}
                  disabled={currentStep === 1}
                  className={`inline-flex w-full sm:w-auto items-center justify-center gap-2 rounded-xl px-6 py-3.5 text-base font-semibold transition-all ${
                    currentStep === 1
                      ? "cursor-not-allowed bg-gray-200 text-gray-400"
                      : "bg-gray-500 text-white hover:bg-gray-600"
                  }`}
                >
                  <ArrowLeft className="h-5 w-5 shrink-0" />
                  <span>Previous</span>
                </button>

                {currentStep < 4 ? (
                  <button
                    type="button"
                    onClick={nextStep}
                    disabled={isLoading}
                    className="inline-flex w-full sm:w-auto sm:min-w-[11rem] items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-sky-600 to-sky-700 px-8 py-3.5 text-base font-semibold text-white shadow-md transition-all hover:from-sky-700 hover:to-sky-800 disabled:cursor-not-allowed disabled:opacity-50"
                  >
                    <span>Continue</span>
                    <ArrowRight className="h-5 w-5 shrink-0" />
                  </button>
                ) : (
                  <button
                    type="submit"
                    disabled={isLoading}
                    className="inline-flex w-full sm:w-auto sm:min-w-[11rem] items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-sky-600 to-sky-700 px-8 py-3.5 text-base font-semibold text-white shadow-md transition-all hover:from-sky-700 hover:to-sky-800 disabled:cursor-not-allowed disabled:opacity-50"
                  >
                    {isLoading ? (
                      <>
                        <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
                        <span>Creating Account...</span>
                      </>
                    ) : (
                      <>
                        <span>Create Account</span>
                        <CheckCircle className="w-5 h-5" />
                      </>
                    )}
                  </button>
                )}
              </div>
            </div>
            <div className="text-center text-gray-600 mt-6">
              Already have an account?{" "}
              <Link
                to="/login"
                className="text-blue-600 hover:text-blue-700 font-medium"
              >
                Sign In
              </Link>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default Register;
