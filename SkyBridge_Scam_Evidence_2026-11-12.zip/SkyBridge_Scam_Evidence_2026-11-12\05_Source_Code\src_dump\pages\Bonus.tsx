import React, { useState, useEffect } from "react";
import {
  Users,
  DollarSign,
  Target,
  TrendingUp,
  CheckCircle,
  Trophy,
  PartyPopper,
  Sparkles,
} from "lucide-react";
import { apiClient } from "../services/apiClient";
import userService from "../services/userService";
import { useAuth } from "../contexts/AuthContext";
import { API_CONFIG } from "../config/api";

interface BonusTier {
  id: number;
  title: string;
  description: string;
  amount: string;
  usersRequired: number;
  userRange: string;
  progress: number;
  isCompleted: boolean;
  color: string;
}

const Bonus: React.FC = () => {
  const { user, token } = useAuth();
  const displayName = user?.name || "User";
  const [todayReferrals, setTodayReferrals] = useState(0);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  // New: modal and completion tracking state
  const [completedTierIds, setCompletedTierIds] = useState<number[]>([]);
  const [modalOpen, setModalOpen] = useState(false);
  const [modalTier, setModalTier] = useState<BonusTier | null>(null);
  const [pendingCompletions, setPendingCompletions] = useState<BonusTier[]>([]);
  const [modalAnimateIn, setModalAnimateIn] = useState(false);
  // Removed: autoCloseTimerRef
  // New: Persistently track tiers whose modal has been shown once
  const [shownTierIds, setShownTierIds] = useState<number[]>([]);
  const [hasShownThisVisit, setHasShownThisVisit] = useState(false);
  const [copied, setCopied] = useState(false);

  const BASE_URL = API_CONFIG.APP_URL;

  const handleCopyReferralLink = () => {
    try {
      let storedUser: any = null;
      try {
        const u = localStorage.getItem("user");
        storedUser = u ? JSON.parse(u) : null;
      } catch (e) {
        storedUser = null;
      }

      const code =
        user?.referralCode ||
        storedUser?.referralCode ||
        storedUser?.referral_code ||
        ""; // Don't fallback to a fake code

      if (!code) {
        alert("Referral code not available");
        return;
      }

      const rawBase =
        typeof window !== "undefined" && window.location?.origin && !window.location.origin.includes("localhost")
          ? window.location.origin
          : (BASE_URL || "https://sky-bridge-international.com");

      const cleanBase = rawBase
        .replace("https://backend.sky-bridge-international.com", "https://sky-bridge-international.com")
        .replace(/\/$/, "");

      const link = `${cleanBase}/register?refCode=${encodeURIComponent(code)}`;

      navigator.clipboard
        .writeText(link)
        .then(() => {
          setCopied(true);
          setTimeout(() => setCopied(false), 1500);
        })
        .catch(() => {
          // Fallback for older browsers or restricted environments
          const textarea = document.createElement("textarea");
          textarea.value = link;
          document.body.appendChild(textarea);
          textarea.select();
          try {
            document.execCommand("copy");
            setCopied(true);
            setTimeout(() => setCopied(false), 1500);
          } catch (e) {
            alert("Failed to copy referral link");
          } finally {
            document.body.removeChild(textarea);
          }
        });
    } catch (err) {
      alert("Failed to copy referral link");
    }
  };

  // Load shown tier ids from localStorage on mount
  useEffect(() => {
    try {
      const saved = localStorage.getItem("shownBonusTierIds");
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) {
          setShownTierIds(parsed.filter((id) => typeof id === "number"));
        }
      }
    } catch (e) {
      // ignore parse errors
    }
  }, []);

  // Fetch today's referral count
  const fetchTodayReferrals = async () => {
    try {
      if (!token) {
        setError("Authentication required. Please login again.");
        setLoading(false);
        return;
      }

      setLoading(true);
      // Update apiClient authentication
      apiClient.setAuthToken(token);

      const data = await userService.getTodayReferralCount();
      // Use approved referrals joined today from API response (with fallbacks for older field names)
      setTodayReferrals(
        Number(
          (data as any)?.today_approved_referral_count ??
            (data as any)?.today_approved_referrals ??
            (data as any)?.today_referrals ??
            0,
        ),
      );
      setError(null);
    } catch (err: any) {
      console.error("Error fetching today referrals:", err);
      if (
        err.message?.includes("401") ||
        err.message?.includes("unauthenticated")
      ) {
        setError("Authentication required. Please login again.");
      } else {
        setError(err.message || "Failed to fetch today's referral count");
      }
    } finally {
      setLoading(false);
    }
  };

  // Set token in apiClient when it changes
  useEffect(() => {
    if (token) {
      apiClient.setAuthToken(token);
    }
  }, [token]);

  // Fetch today's referral count on component mount
  useEffect(() => {
    fetchTodayReferrals();
  }, []);

  // Calculate progress for each tier based on today's referrals
  const calculateTierProgress = (tierIndex: number, usersRequired: number) => {
    let cumulativeRequired = 0;
    for (let i = 0; i <= tierIndex; i++) {
      cumulativeRequired += bonusTiersBase[i].usersRequired;
    }

    const previousRequired = cumulativeRequired - usersRequired;
    const progressInThisTier = Math.max(0, todayReferrals - previousRequired);
    return Math.min(progressInThisTier, usersRequired);
  };

  const bonusTiersBase: BonusTier[] = [
    {
      id: 1,
      title: "First Milestone",
      description: "Add 2 Users",
      amount: "$1.00",
      usersRequired: 2,
      userRange: "1st & 2nd",
      progress: 0,
      isCompleted: false,
      color: "bg-sky-500",
    },
    {
      id: 2,
      title: "Second Milestone",
      description: "Add 2 More Users",
      amount: "$2.00",
      usersRequired: 2,
      userRange: "3rd & 4th",
      progress: 0,
      isCompleted: false,
      color: "bg-red-500",
    },
    {
      id: 3,
      title: "Third Milestone",
      description: "Add 2 More Users",
      amount: "$3.50",
      usersRequired: 2,
      userRange: "5th & 6th",
      progress: 0,
      isCompleted: false,
      color: "bg-yellow-500",
    },
    {
      id: 4,
      title: "Fourth Milestone",
      description: "Add 4 More Users",
      amount: "$6.00",
      usersRequired: 4,
      userRange: "7th to 10th",
      progress: 0,
      isCompleted: false,
      color: "bg-gray-800",
    },
    {
      id: 5,
      title: "Fifth Milestone",
      description: "Add 5 More Users",
      amount: "$9.00",
      usersRequired: 5,
      userRange: "11th to 15th",
      progress: 0,
      isCompleted: false,
      color: "bg-emerald-500",
    },
    {
      id: 6,
      title: "Final Milestone",
      description: "Add 5 More Users",
      amount: "$12.00",
      usersRequired: 5,
      userRange: "16th to 20th",
      progress: 0,
      isCompleted: false,
      color: "bg-indigo-500",
    },
  ];

  // Update bonus tiers with real progress data
  const bonusTiers: BonusTier[] = bonusTiersBase.map((tier, index) => {
    const progress = calculateTierProgress(index, tier.usersRequired);
    const isCompleted = progress >= tier.usersRequired;

    return {
      ...tier,
      progress,
      isCompleted,
    };
  });

  // Detect newly completed tiers and queue ALL not-yet-shown modals
  useEffect(() => {
    const newlyCompleted = bonusTiers.filter(
      (t) => t.isCompleted && !shownTierIds.includes(t.id),
    );

    if (newlyCompleted.length > 0) {
      setPendingCompletions((prev) => {
        const prevIds = new Set(prev.map((p) => p.id));
        const toAdd = newlyCompleted.filter((t) => !prevIds.has(t.id));
        // show in ascending order by tier id
        const merged = [...prev, ...toAdd].sort((a, b) => a.id - b.id);
        return merged;
      });
    }

    // Keep a record of all currently completed tiers
    const currentCompletedIds = bonusTiers
      .filter((t) => t.isCompleted)
      .map((t) => t.id);
    setCompletedTierIds((prev) =>
      Array.from(new Set([...prev, ...currentCompletedIds])),
    );
  }, [todayReferrals, shownTierIds]);

  // Open modal when there is a pending completion
  useEffect(() => {
    if (!modalOpen && pendingCompletions.length > 0) {
      setModalTier(pendingCompletions[0]);
      setModalOpen(true);
      // Trigger entrance animation after mount
      setTimeout(() => setModalAnimateIn(true), 20);
    }
  }, [pendingCompletions, modalOpen]);

  // Auto-close timer removed per request

  const closeModal = () => {
    // Trigger exit animation
    setModalAnimateIn(false);
    setTimeout(() => {
      // Mark current tier as shown once and persist
      if (modalTier) {
        setShownTierIds((prev) => {
          const next = Array.from(new Set([...prev, modalTier.id]));
          try {
            localStorage.setItem("shownBonusTierIds", JSON.stringify(next));
          } catch (e) {
            // ignore storage errors
          }
          return next;
        });
      }

      // Advance the queue by one
      setPendingCompletions((prev) => prev.slice(1));
      setModalOpen(false);
      setModalTier(null);
    }, 200);
  };

  const totalBonus = "$12.00";
  const totalUsers = 20;
  const currentUsers = todayReferrals;

  const getProgressPercentage = (tier: BonusTier) => {
    return Math.min((tier.progress / tier.usersRequired) * 100, 100);
  };

  // Helper: cumulative joinings required up to a given tier id
  const getCumulativeRequired = (tierId: number) => {
    const index = bonusTiersBase.findIndex((t) => t.id === tierId);
    if (index === -1) return 0;
    return bonusTiersBase
      .slice(0, index + 1)
      .reduce((sum, t) => sum + t.usersRequired, 0);
  };

  const getStatusIcon = (tier: BonusTier) => {
    if (tier.isCompleted) {
      return (
        <div className="w-6 h-6 bg-green-500 rounded-full flex items-center justify-center">
          <svg
            className="w-4 h-4 text-white"
            fill="currentColor"
            viewBox="0 0 20 20"
          >
            <path
              fillRule="evenodd"
              d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"
              clipRule="evenodd"
            />
          </svg>
        </div>
      );
    }
    return (
      <div
        className={`w-6 h-6 ${tier.color} rounded-full flex items-center justify-center text-white text-sm font-bold`}
      >
        {tier.id}
      </div>
    );
  };

  // Loading state
  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 p-6">
        <div className="max-w-4xl mx-auto">
          <div className="bg-white rounded-lg shadow-sm p-6 mb-6">
            <div className="animate-pulse">
              <div className="h-8 bg-gray-200 rounded w-1/3 mb-4"></div>
              <div className="h-4 bg-gray-200 rounded w-1/2"></div>
            </div>
          </div>
          <div className="bg-white rounded-lg shadow-sm p-6">
            <div className="animate-pulse space-y-4">
              <div className="h-6 bg-gray-200 rounded w-1/4"></div>
              <div className="h-4 bg-gray-200 rounded w-1/2"></div>
              <div className="space-y-3">
                <div className="h-16 bg-gray-200 rounded"></div>
                <div className="h-16 bg-gray-200 rounded"></div>
                <div className="h-16 bg-gray-200 rounded"></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-4xl mx-auto">
        {/* Error Message */}
        {error && (
          <div className="bg-red-50 border border-red-200 rounded-lg p-4 mb-6">
            <div className="flex items-center">
              <div className="text-red-600 mr-3">⚠️</div>
              <div>
                <h3 className="text-red-800 font-medium">Error Loading Data</h3>
                <p className="text-red-600 text-sm">{error}</p>
              </div>
            </div>
          </div>
        )}

        {/* Header */}
        <div className="bg-white rounded-lg shadow-sm p-6 mb-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-gray-900 mb-2">
                Referral Bonus Program
              </h1>
              <p className="text-gray-600">
                Earn bonuses by referring new users to our platform
              </p>
            </div>
            <div className="text-right">
              <div className="flex items-center space-x-4">
                <div>
                  <div className="text-2xl font-bold text-green-600">
                    {"12 $"}
                  </div>
                  <div className="text-sm text-gray-500">
                    Total Possible Bonus
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Bonus Tiers List */}
        <div className="bg-white rounded-lg shadow-sm">
          <div className="p-6 border-b border-gray-200">
            <h2 className="text-xl font-semibold text-gray-900">
              Bonus Milestones
            </h2>
            <p className="text-gray-600 mt-1">
              Complete each milestone to earn your bonus
            </p>
          </div>

          <div className="divide-y divide-gray-200">
            {bonusTiers.map((tier) => (
              <div
                key={tier.id}
                className="p-6 hover:bg-gray-50 transition-colors"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4">
                    {getStatusIcon(tier)}
                    <div>
                      <h3 className="text-lg font-semibold text-gray-900">
                        {tier.title}
                      </h3>
                      <p className="text-gray-600">
                        {tier.description} ({tier.userRange})
                      </p>
                    </div>
                  </div>

                  <div className="text-right">
                    <div className="text-2xl font-bold text-green-600">
                      Get {tier.amount} Extra Bonus
                    </div>
                    <div className="text-sm text-gray-500">
                      {tier.usersRequired} users required
                    </div>
                  </div>
                </div>

                {/* Progress Bar */}
                <div className="mt-4">
                  <div className="flex justify-between text-sm text-gray-600 mb-2">
                    <span>
                      Progress: {tier.progress}/{tier.usersRequired} users
                    </span>
                    <span>{Math.round(getProgressPercentage(tier))}%</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div
                      className={`h-2 rounded-full transition-all duration-300 ${tier.color}`}
                      style={{ width: `${getProgressPercentage(tier)}%` }}
                    ></div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Summary Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
          <div className="bg-white rounded-lg shadow-sm p-6">
            <div className="flex items-center">
              <div className="p-3 bg-blue-100 rounded-lg">
                <Users className="w-6 h-6 text-blue-600" />
              </div>
              <div className="ml-4">
                <div className="text-2xl font-bold text-gray-900">
                  {currentUsers}/{totalUsers}
                </div>
                <div className="text-sm text-gray-500">Today's Referrals</div>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow-sm p-6">
            <div className="flex items-center">
              <div className="p-3 bg-green-100 rounded-lg">
                <DollarSign className="w-6 h-6 text-green-600" />
              </div>
              <div className="ml-4">
                <div className="text-2xl font-bold text-gray-900">
                  $
                  {bonusTiers
                    .filter((tier) => tier.isCompleted)
                    .reduce((sum, tier) => {
                      return sum + parseFloat(tier.amount.replace("$", ""));
                    }, 0)
                    .toFixed(2)}
                </div>
                <div className="text-sm text-gray-500">Earned Today</div>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow-sm p-6">
            <div className="flex items-center">
              <div className="p-3 bg-purple-100 rounded-lg">
                <Target className="w-6 h-6 text-purple-600" />
              </div>
              <div className="ml-4">
                <div className="text-2xl font-bold text-gray-900">
                  {Math.round((currentUsers / totalUsers) * 100)}%
                </div>
                <div className="text-sm text-gray-500">Overall Progress</div>
              </div>
            </div>
          </div>
        </div>

        {/* How It Works */}
        <div className="bg-white rounded-lg shadow-sm mt-6 p-6">
          <h2 className="text-xl font-semibold text-gray-900 mb-4">
            How It Works
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div className="flex items-start space-x-3">
                <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center text-blue-600 font-semibold text-sm">
                  1
                </div>
                <div>
                  <h4 className="font-semibold text-gray-900">Refer Users</h4>
                  <p className="text-gray-600 text-sm">
                    Share your referral link with friends and family
                  </p>
                </div>
              </div>
              <div className="flex items-start space-x-3">
                <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center text-green-600 font-semibold text-sm">
                  2
                </div>
                <div>
                  <h4 className="font-semibold text-gray-900">Users Join</h4>
                  <p className="text-gray-600 text-sm">
                    When they sign up using your link, you get credit
                  </p>
                </div>
              </div>
            </div>
            <div className="space-y-4">
              <div className="flex items-start space-x-3">
                <div className="w-8 h-8 bg-purple-100 rounded-full flex items-center justify-center text-purple-600 font-semibold text-sm">
                  3
                </div>
                <div>
                  <h4 className="font-semibold text-gray-900">
                    Reach Milestones
                  </h4>
                  <p className="text-gray-600 text-sm">
                    Complete each milestone to unlock bonuses
                  </p>
                </div>
              </div>
              <div className="flex items-start space-x-3">
                <div className="w-8 h-8 bg-orange-100 rounded-full flex items-center justify-center text-orange-600 font-semibold text-sm">
                  4
                </div>
                <div>
                  <h4 className="font-semibold text-gray-900">Earn Bonuses</h4>
                  <p className="text-gray-600 text-sm">
                    Get paid instantly when you complete milestones
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Call to Action */}
        <div className="bg-gradient-to-r from-blue-600 to-purple-600 rounded-lg shadow-sm mt-6 p-6 text-white">
          <div className="text-center">
            <TrendingUp className="w-12 h-12 mx-auto mb-4" />
            <h2 className="text-2xl font-bold mb-2">Start Earning Today!</h2>
            <p className="mb-4">
              Share your referral link and start earning bonuses with every new
              user
            </p>
            <button
              onClick={handleCopyReferralLink}
              className="bg-white text-blue-600 px-6 py-3 rounded-lg font-semibold hover:bg-gray-100 transition-colors"
            >
              {copied ? "Copied!" : "Copy Referral Link"}
            </button>
          </div>
        </div>

        {/* Congratulations Modal */}
        {modalOpen && modalTier && (
          <div className="fixed inset-0 z-50 flex items-center justify-center">
            {/* Backdrop */}
            <div
              className={`absolute inset-0 bg-black/60 backdrop-blur-sm transition-opacity duration-300 ${
                modalAnimateIn ? "opacity-100" : "opacity-0"
              }`}
              onClick={closeModal}
            />

            {/* Modal Content */}
            <div className="relative z-10 w-full max-w-md">
              {/* Fancy gradient border */}
              <div
                className={`p-1 rounded-2xl bg-gradient-to-br from-blue-600 via-purple-600 to-pink-500 shadow-2xl transition-all duration-300 ease-out ${
                  modalAnimateIn
                    ? "opacity-100 scale-100 translate-y-0"
                    : "opacity-0 scale-95 translate-y-2"
                }`}
              >
                <div className="rounded-2xl bg-white">
                  <div className="p-8 text-center">
                    <div className="flex justify-center items-center mb-4">
                      <div className="relative">
                        <div className="w-20 h-20 rounded-full bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center shadow-lg animate-pulse">
                          <CheckCircle className="w-12 h-12 text-white" />
                        </div>
                        {/* Decorative sparkles */}
                        <Sparkles className="absolute -top-2 -right-2 w-6 h-6 text-pink-500 animate-bounce" />
                        <Sparkles className="absolute -bottom-2 -left-2 w-5 h-5 text-yellow-400 animate-bounce" />
                      </div>
                    </div>

                    {/* Modal Header */}
                    <h3 className="text-2xl font-extrabold text-gray-900 mb-2">
                      Congratulations {displayName}!
                    </h3>
                    {/* Modal Message */}
                    <p className="text-gray-600 mb-6">
                      You Complete{" "}
                      <span className="font-semibold text-gray-900">
                        {getCumulativeRequired(modalTier.id)}
                      </span>{" "}
                      Direct Sales Today &amp; Get{" "}
                      <span className="font-semibold text-green-600">
                        {modalTier.amount.replace("$", "")}$$
                      </span>{" "}
                      Bonus🤩
                      {modalTier.userRange && (
                        <span className="block text-sm text-gray-500 mt-1">
                          Milestone: {modalTier.title} ({modalTier.userRange})
                        </span>
                      )}
                    </p>

                    <div className="flex items-center justify-center gap-3 mb-6">
                      <Trophy className="w-6 h-6 text-yellow-500" />
                      <span className="text-lg font-semibold text-gray-900">
                        Bonus Earned:
                      </span>
                      <span className="text-xl font-bold text-green-600">
                        {modalTier.amount}
                      </span>
                    </div>

                    <button
                      onClick={closeModal}
                      className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-blue-600 text-white font-semibold shadow hover:bg-blue-700 active:scale-[0.98] transition-all"
                    >
                      Continue
                      <PartyPopper className="w-5 h-5" />
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default Bonus;
