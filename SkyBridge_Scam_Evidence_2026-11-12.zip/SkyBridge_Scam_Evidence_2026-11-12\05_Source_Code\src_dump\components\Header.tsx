import React, { useMemo, useState, useEffect, useRef } from "react";
import {
  Menu,
  Bell,
  ChevronDown,
  DollarSign,
  Crown,
  Star,
  Sparkles,
  TrendingUp,
} from "lucide-react";
import { useAuth } from "../contexts/AuthContext";
import { useCurrency } from "../contexts/CurrencyContext";
import { useSidebar } from "../contexts/SideBarContect";
import { Link, useNavigate, useLocation } from "react-router-dom";
import { userService } from "../services/userService";
import { NotificationService } from "../services/notificationService";

// Import logo images
import companyLogo from "../assets/images/logo.png";

const Header: React.FC = () => {
  const { user, logout, isAuthenticated } = useAuth();
  const { currency, setCurrency } = useCurrency();
  const { toggleSidebar } = useSidebar();
  const navigate = useNavigate();
  const location = useLocation();

  // Nav avatar: prefer profile from API (fetched once), fallback to auth user
  const [profileImageUrl, setProfileImageUrl] = useState<string | null>(null);
  const [headerPlan, setHeaderPlan] = useState<string | null>(null);
  const [avatarLoadError, setAvatarLoadError] = useState(false);
  const profileFetchedRef = useRef(false);
  const [notificationCount, setNotificationCount] = useState(0);

  // Fetch profile once when header is shown and user is authenticated (so nav shows image)
  useEffect(() => {
    if (!isAuthenticated) {
      setProfileImageUrl(null);
      setHeaderPlan(null);
      profileFetchedRef.current = false;
      return;
    }
    if (profileFetchedRef.current) return;
    profileFetchedRef.current = true;

    let mounted = true;
    (async () => {
      try {
        const profile = await userService.getUserProfile();
        if (!mounted) return;
        const raw = profile?.profile_picture;
        const url = raw || null;
        setProfileImageUrl(url);
        setHeaderPlan(profile?.plan || null);
      } catch {
        if (mounted) {
          setProfileImageUrl(null);
          setHeaderPlan(null);
        }
      }
    })();
    return () => {
      mounted = false;
    };
  }, [isAuthenticated]);

  // Keep the unread badge in sync: refetch on every route change so the dot
  // clears once the user opens (and the Notifications page marks read) the list.
  useEffect(() => {
    if (!isAuthenticated) {
      setNotificationCount(0);
      return;
    }

    // On the notifications page everything is read — clear optimistically.
    if (location.pathname === "/notifications") {
      setNotificationCount(0);
      return;
    }

    let mounted = true;
    (async () => {
      try {
        const count = await NotificationService.getUnreadCount();
        if (mounted) setNotificationCount(count);
      } catch {
        if (mounted) setNotificationCount(0);
      }
    })();
    return () => {
      mounted = false;
    };
  }, [isAuthenticated, location.pathname]);

  const getDisplayableImageUrl = (imageData: string | undefined): string => {
    if (!imageData) return "";
    return imageData;
  };

  const displayName = user?.name || "";
  const userPlan = headerPlan ?? user?.plan ?? null;
  const avatarUrl = useMemo(() => {
    if (profileImageUrl) return profileImageUrl;
    const raw = user?.profileImage;
    if (!raw) return null;
    return getDisplayableImageUrl(raw) || null;
  }, [profileImageUrl, user?.profileImage]);

  // Reset avatar error when URL changes so a new image can load
  useEffect(() => {
    setAvatarLoadError(false);
  }, [avatarUrl]);

  // Routes where header should be hidden
  const hideHeaderRoutes = ["/login", "/register", "/account-pending"];

  // Check if current route should hide header (exact match or starts with the route)
  const shouldHideHeader = hideHeaderRoutes.some(
    (route) =>
      location.pathname === route || location.pathname.startsWith(route + "/"),
  );

  // Check if current route is dashboard to show currency dropdown
  const isDashboard =
    location.pathname === "/dashboard" || location.pathname === "/";

  const handleLogout = () => {
    logout();
    navigate("/login");
  };

  // Don't render header on specified routes
  if (shouldHideHeader) {
    return null;
  }

  return (
    <header className="w-full fixed top-0 left-0 right-0 z-30">
      {/* Promotional Banner */}
      <div className="bg-gradient-to-r from-sky-500 to-sky-600 text-white text-center py-1 px-4">
        <p className="text-xs sm:text-sm font-medium px-2">
          <span className="block sm:hidden">
            Don't wait for opportunities, create them with
            <br />
            SkyBridge International
          </span>
          <span className="hidden sm:inline">
            Don't wait for opportunities, create them with SkyBridge
            International.
          </span>
        </p>
      </div>

      {/* Main Header */}
      <div className="bg-white shadow-lg">
        <div className="max-w-7xl mx-auto px-2 sm:px-4 lg:px-6 xl:px-8">
          <div className="flex justify-between items-center h-16 sm:h-20 lg:h-24">
            {/* Left side - Logo and Navigation */}
            <div className="flex items-center space-x-1 sm:space-x-3 lg:space-x-6">
              {/* Logo */}
              <Link to="/" className="flex items-center min-w-0 flex-shrink">
                <div className="flex items-center space-x-1 sm:space-x-2">
                  {/* Company Logo - Adjusted sizing to make title smaller */}
                  <div className="flex">
                    <div className="flex">
                      <img
                        src={companyLogo}
                        alt="SkyBridge International"
                        className="h-14 w-auto sm:h-16 md:h-20 lg:h-24 xl:h-28 max-w-[220px] sm:max-w-[260px] md:max-w-[340px] lg:max-w-[420px] xl:max-w-[480px] object-contain"
                      />
                    </div>
                  </div>
                </div>
              </Link>
            </div>

            {/* Right side - User menu */}
            <div className="flex items-center space-x-1 sm:space-x-2 lg:space-x-3">
              {isAuthenticated ? (
                <>
                  {/* Currency Dropdown - Responsive visibility */}
                  {isDashboard && (
                    <div className="relative group">
                      <button className="flex items-center space-x-1 px-2 py-1.5 rounded-lg bg-gray-100 hover:bg-gray-200 border border-gray-300 transition-colors">
                        <DollarSign className="h-4 w-4 sm:h-5 sm:w-5 text-gray-700" />
                        <span className="text-xs sm:text-sm font-medium text-gray-700 hidden xs:inline">
                          {currency}
                        </span>
                        <ChevronDown className="h-4 w-4 sm:h-5 sm:w-5 text-gray-700 hidden sm:block" />
                      </button>

                      {/* Currency dropdown menu */}
                      <div className="absolute right-0 mt-2 w-32 bg-white rounded-md shadow-lg py-1 z-50 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-200 border border-gray-200">
                        <button
                          onClick={() => setCurrency("USD")}
                          className={`block w-full text-left px-3 py-2 text-xs sm:text-sm hover:bg-gray-100 ${
                            currency === "USD"
                              ? "bg-sky-50 text-sky-700 font-medium"
                              : "text-gray-700"
                          }`}
                        >
                          <div className="flex items-center justify-between">
                            <span>USD ($)</span>
                            {currency === "USD" && (
                              <span className="text-sky-500">✓</span>
                            )}
                          </div>
                        </button>
                        <button
                          onClick={() => setCurrency("PKR")}
                          className={`block w-full text-left px-3 py-2 text-xs sm:text-sm hover:bg-gray-100 ${
                            currency === "PKR"
                              ? "bg-sky-50 text-sky-700 font-medium"
                              : "text-gray-700"
                          }`}
                        >
                          <div className="flex items-center justify-between">
                            <span>PKR (₨)</span>
                            {currency === "PKR" && (
                              <span className="text-sky-500">✓</span>
                            )}
                          </div>
                        </button>
                      </div>
                    </div>
                  )}

                  {/* Plan Badge */}
                  {userPlan && (
                    <Link
                      to="/plans"
                      className="hidden sm:flex items-center space-x-1 px-2 py-1.5 rounded-lg bg-gradient-to-r from-purple-500 to-purple-600 text-white text-xs font-semibold hover:from-purple-600 hover:to-purple-700 transition-all duration-300 shadow-md hover:shadow-lg"
                      title="View Plans"
                    >
                      {userPlan === "basic" && <Star className="w-3 h-3" />}
                      {userPlan === "standard" && (
                        <Sparkles className="w-3 h-3" />
                      )}
                      {userPlan === "prime" && (
                        <TrendingUp className="w-3 h-3" />
                      )}
                      {userPlan === "premium" && <Crown className="w-3 h-3" />}
                      <span className="hidden md:inline">
                        {userPlan === "basic" && "Basic"}
                        {userPlan === "standard" && "Standard"}
                        {userPlan === "prime" && "Prime"}
                        {userPlan === "premium" && "Premium"}
                        {!["basic", "standard", "prime", "premium"].includes(
                          userPlan,
                        ) && userPlan}
                      </span>
                    </Link>
                  )}

                  {/* Notifications */}
                  <Link
                    to="/notifications"
                    className="p-1.5 text-gray-700 hover:text-sky-600 relative transition-colors duration-200"
                    aria-label={
                      notificationCount > 0
                        ? `${notificationCount} unread notifications`
                        : "Notifications"
                    }
                  >
                    <Bell
                      className={`h-5 w-5 sm:h-6 sm:w-6 origin-top ${
                        notificationCount > 0 ? "animate-bell-swing" : ""
                      }`}
                    />
                    {notificationCount > 0 && (
                      <span className="absolute -top-1.5 -right-1.5 flex">
                        {/* Pulsing ring to draw the eye to the unread count */}
                        <span className="absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75 animate-ping" />
                        <span className="relative inline-flex min-w-[18px] h-[18px] px-1 items-center justify-center bg-red-500 text-white text-[10px] sm:text-xs font-bold rounded-full">
                          {notificationCount > 99 ? "99+" : notificationCount}
                        </span>
                      </span>
                    )}
                  </Link>

                  {/* User Profile - Improved mobile experience */}
                  <div className="relative group">
                    <button
                      className="flex items-center space-x-1 p-1 sm:p-1.5 rounded-full hover:bg-gray-100 transition-colors duration-200"
                      aria-label="User menu"
                    >
                      {avatarUrl && !avatarLoadError ? (
                        <img
                          src={avatarUrl}
                          alt={displayName || "User"}
                          className="w-10 h-10 sm:w-12 sm:h-12 rounded-full object-cover flex-shrink-0"
                          onError={() => setAvatarLoadError(true)}
                        />
                      ) : (
                        <div className="w-10 h-10 sm:w-12 sm:h-12 bg-sky-100 rounded-full flex items-center justify-center flex-shrink-0">
                          <span className="text-sky-700 text-sm font-medium">
                            {(() => {
                              const name = (displayName || "").trim();
                              const parts = name.split(/\s+/).filter(Boolean);
                              const initials = parts
                                .slice(0, 3)
                                .map((p) => p[0])
                                .join("")
                                .toUpperCase();
                              return initials || "U";
                            })()}
                          </span>
                        </div>
                      )}
                      <ChevronDown className="h-4 w-4 sm:h-5 sm:w-5 text-gray-700 hidden xs:block" />
                    </button>

                    {/* User dropdown menu */}
                    <div className="absolute right-0 mt-2 w-40 sm:w-48 bg-white rounded-md shadow-lg py-1 z-50 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-200 border border-gray-200">
                      {userPlan && (
                        <div className="px-3 sm:px-4 py-2 border-b border-gray-200">
                          <div className="flex items-center space-x-2">
                            <span className="text-xs text-gray-500">Plan:</span>
                            <span className="text-xs font-semibold text-purple-600">
                              {userPlan === "basic" && "Basic"}
                              {userPlan === "standard" && "Standard"}
                              {userPlan === "prime" && "Prime"}
                              {userPlan === "premium" && "Premium"}
                              {![
                                "basic",
                                "standard",
                                "prime",
                                "premium",
                              ].includes(userPlan) && userPlan}
                            </span>
                          </div>
                        </div>
                      )}
                      <Link
                        to="/profile-info"
                        className="block px-3 sm:px-4 py-2 text-xs sm:text-sm text-gray-700 hover:bg-gray-100"
                      >
                        Profile
                      </Link>
                      <Link
                        to="/dashboard"
                        className="block px-3 sm:px-4 py-2 text-xs sm:text-sm text-gray-700 hover:bg-gray-100"
                      >
                        Dashboard
                      </Link>
                      <button
                        onClick={handleLogout}
                        className="block w-full text-left px-3 sm:px-4 py-2 text-xs sm:text-sm text-gray-700 hover:bg-gray-100"
                      >
                        Sign Out
                      </button>
                    </div>
                  </div>
                  {/* Mobile Menu Button - Show only on mobile for authenticated users */}
                  <button
                    onClick={toggleSidebar}
                    className="lg:hidden p-1.5 rounded-md text-gray-700 hover:text-sky-600 hover:bg-gray-100 transition-colors duration-200"
                    aria-label="Toggle sidebar"
                  >
                    <Menu className="h-6 w-6 sm:h-7 sm:w-7" />
                  </button>
                </>
              ) : (
                <div className="flex items-center space-x-2 sm:space-x-3">
                  <Link
                    to="/login"
                    className="text-gray-700 hover:text-sky-600 font-medium text-xs sm:text-sm px-2 py-1 rounded transition-colors duration-200"
                  >
                    Login
                  </Link>
                  <Link
                    to="/register"
                    className="bg-gradient-to-r from-sky-500 to-sky-600 text-white px-3 sm:px-6 py-2 sm:py-2.5 rounded-lg hover:from-sky-600 hover:to-sky-700 font-semibold text-xs sm:text-sm transition-all duration-300 shadow-lg hover:shadow-xl transform hover:scale-105 whitespace-nowrap border border-sky-400/20"
                  >
                    Get Started
                  </Link>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;
