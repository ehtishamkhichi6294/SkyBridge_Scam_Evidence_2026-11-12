import { API_CONFIG, API_ENDPOINTS } from '../config/api';

// Response interface for API calls
export interface ApiResponse<T = any> {
  data: T;
  message?: string;
  success: boolean;
  status: number;
}

// Error interface for API errors
export interface ApiError {
  message: string;
  status: number;
  data?: any;
}

// HTTP Methods
type HttpMethod = 'GET' | 'POST' | 'PUT' | 'DELETE' | 'PATCH';

// Request options interface
interface RequestOptions {
  headers?: Record<string, string>;
  timeout?: number;
  signal?: AbortSignal;
}

class ApiClient {
  private baseURL: string;
  private defaultHeaders: Record<string, string>;
  private timeout: number;

  constructor() {
    this.baseURL = API_CONFIG.BASE_URL;
    this.defaultHeaders = { ...API_CONFIG.HEADERS };
    this.timeout = API_CONFIG.TIMEOUT;
    
    // Automatically set auth token if available in localStorage
    this.initializeAuthToken();
  }

  // Initialize auth token from localStorage
  private initializeAuthToken() {
    const token = localStorage.getItem('token') || localStorage.getItem('access_token');
    if (token) {
      this.setAuthToken(token);
    }
  }

  // Set authorization token
  setAuthToken(token: string) {
    this.defaultHeaders['Authorization'] = `Bearer ${token}`;
  }

  // Remove authorization token
  removeAuthToken() {
    delete this.defaultHeaders['Authorization'];
  }

  // Refresh auth token from localStorage
  refreshAuthToken() {
    this.initializeAuthToken();
  }

  // Build full URL
  private buildUrl(endpoint: string): string {
    return `${this.baseURL}${endpoint}`;
  }

  // Handle response
  private async handleResponse<T>(response: Response): Promise<ApiResponse<T>> {
    const contentType = response.headers.get('content-type');
    let data: any;

    if (contentType && contentType.includes('application/json')) {
      data = await response.json();
    } else {
      data = await response.text();
    }

    if (!response.ok) {
      // Expired or revoked token: drop the dead session and send the user to log in again.
      // A 401 from the login call itself is just wrong credentials — leave that to the form.
      if (
        response.status === 401 &&
        this.defaultHeaders['Authorization'] &&
        !response.url.endsWith(API_ENDPOINTS.AUTH.LOGIN)
      ) {
        ['user', 'token', 'access_token'].forEach((key) => localStorage.removeItem(key));
        this.removeAuthToken();
        window.location.href = '/login';
      }
      
      const error: ApiError = {
        message: data.message || `HTTP Error: ${response.status}`,
        status: response.status,
        data: data,
      };
      throw error;
    }

    return {
      data: data.data || data,
      message: data.message,
      success: true,
      status: response.status,
    };
  }

  // Generic request method
  private async request<T>(
    method: HttpMethod,
    endpoint: string,
    body?: any,
    options: RequestOptions = {}
  ): Promise<ApiResponse<T>> {
    const url = this.buildUrl(endpoint);
    // Start with default headers and merge with custom headers
    const headers: Record<string, string> = { ...this.defaultHeaders, ...options.headers };

    // For GET requests, remove Content-Type to avoid unnecessary CORS preflight
    // Authorization header will still trigger preflight, which is expected
    if (method === 'GET') {
      delete headers['Content-Type'];
    }

    // Create AbortController for timeout
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), options.timeout || this.timeout);

    try {
      const config: RequestInit = {
        method,
        headers,
        signal: options.signal || controller.signal,
      };

      // Add body for non-GET requests
      if (method !== 'GET' && body) {
        if (body instanceof FormData) {
          // Remove Content-Type header for FormData (browser will set it with boundary)
          delete headers['Content-Type'];
          config.body = body;
        } else {
          // Ensure JSON requests set the proper Content-Type
          headers['Content-Type'] = 'application/json';
          config.body = JSON.stringify(body);
        }
      }

      const response = await fetch(url, config);
      clearTimeout(timeoutId);

      return await this.handleResponse<T>(response);
    } catch (error) {
      clearTimeout(timeoutId);

      if (error instanceof Error) {
        if (error.name === 'AbortError') {
          throw {
            message: 'Request timeout. The server took too long to respond.',
            status: 408,
          } as ApiError;
        }
        // Make "Failed to fetch" error more user-friendly
        if (error.message === 'Failed to fetch') {
          throw {
            message: 'Unable to connect to server. Please check your internet connection or try again later.',
            status: 0,
          } as ApiError;
        }
        throw {
          message: error.message || 'Network error',
          status: 0,
        } as ApiError;
      }

      throw error;
    }
  }

  // HTTP Methods
  async get<T>(endpoint: string, options?: RequestOptions): Promise<ApiResponse<T>> {
    return this.request<T>('GET', endpoint, undefined, options);
  }

  async post<T>(endpoint: string, body?: any, options?: RequestOptions): Promise<ApiResponse<T>> {
    return this.request<T>('POST', endpoint, body, options);
  }

  async put<T>(endpoint: string, body?: any, options?: RequestOptions): Promise<ApiResponse<T>> {
    return this.request<T>('PUT', endpoint, body, options);
  }

  async patch<T>(endpoint: string, body?: any, options?: RequestOptions): Promise<ApiResponse<T>> {
    return this.request<T>('PATCH', endpoint, body, options);
  }

  async delete<T>(endpoint: string, options?: RequestOptions): Promise<ApiResponse<T>> {
    return this.request<T>('DELETE', endpoint, undefined, options);
  }
}

// Create and export a singleton instance
export const apiClient = new ApiClient();

// Export the class for testing or custom instances
export default ApiClient;