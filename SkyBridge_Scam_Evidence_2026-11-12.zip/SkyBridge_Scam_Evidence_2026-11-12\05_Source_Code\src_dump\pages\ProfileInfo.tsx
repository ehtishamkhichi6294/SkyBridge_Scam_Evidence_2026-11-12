import React, { useState, useEffect } from "react";
import { useAuth } from "../contexts/AuthContext";
import { userService, UserProfile } from "../services/userService";
import { apiClient } from "../services/apiClient";
import { API_CONFIG, API_ENDPOINTS } from "../config/api";
import { resolveProfilePictureUrl } from "../utils/imageUtils";
import {
  CheckCircle,
  User,
  Mail,
  Globe,
  Copy,
  Lock,
  Eye,
  EyeOff,
  X,
  AlertCircle,
  Shield,
  Loader2,
  CreditCard,
  Building,
} from "lucide-react";

const ProfileInfo: React.FC = () => {
  const { user } = useAuth();
  // Profile data state
  const [profileData, setProfileData] = useState<UserProfile | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  // Edit Profile Modal State
  const [showEditProfileModal, setShowEditProfileModal] = useState(false);
  const [editForm, setEditForm] = useState({
    fullName: "",
    country: "",
    phone: "",
    profilePictureUrl: "",
  });
  const [profilePictureFile, setProfilePictureFile] = useState<File | null>(
    null,
  );
  const [isEditing, setIsEditing] = useState(false);
  const [editSuccess, setEditSuccess] = useState(false);
  const [editError, setEditError] = useState("");
  const [isUploadingImage, setIsUploadingImage] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  // Change Password Modal State
  const [showChangePasswordModal, setShowChangePasswordModal] = useState(false);
  const [passwordForm, setPasswordForm] = useState({
    currentPassword: "",
    newPassword: "",
    confirmPassword: "",
  });
  const [showPasswords, setShowPasswords] = useState({
    current: false,
    new: false,
    confirm: false,
  });
  const [passwordErrors, setPasswordErrors] = useState<string[]>([]);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitSuccess, setSubmitSuccess] = useState(false);
  const [submitError, setSubmitError] = useState("");

  // Fetch user profile data on component mount
  useEffect(() => {
    const fetchUserProfile = async () => {
      try {
        setIsLoading(true);
        setError(null);
        const profile = await userService.getUserProfile(true);
        console.log("profile", profile);
        setProfileData(profile);
        // Initialize edit form
        if (profile) {
          setEditForm({
            fullName: profile.name || "",
            country: profile.country || "",
            phone: profile.phone || "",
            profilePictureUrl: profile.profile_picture || "",
          });
        }
      } catch (err: any) {
        console.error("Failed to fetch user profile:", err);
        setError(err.message || "Failed to load profile data");
        // Fallback to auth context user data if API fails
        if (user) {
          setProfileData({
            id: typeof user.id === "number" ? user.id : 0,
            name: user.name || "",
            email: user.email || "",
            phone: user.phone || "",
            country: user.country || "",
            referralCode: user.referralCode || "",
          });
        }
      } finally {
        setIsLoading(false);
      }
    };
    fetchUserProfile();
  }, [user]);

  const BASE_URL = API_CONFIG.APP_URL;

  const handleCopyReferralCode = () => {
    const code = profileData?.referralCode;
    if (!code) {
      alert("Referral code not available");
      return;
    }

    const rawBase =
      typeof window !== "undefined" && window.location?.origin && !window.location.origin.includes("localhost")
        ? window.location.origin
        : (BASE_URL || "https://sky-bridge-international.com");

    const cleanBase = rawBase
      .replace("https://backend.sky-bridge-international.com", "https://sky-bridge-international.com")
      .replace(/\/$/, "");

    const link = `${cleanBase}/register?refCode=${encodeURIComponent(code)}`;

    navigator.clipboard
      .writeText(link)
      .then(() => {
        alert("Referral link copied: " + link);
      })
      .catch(() => {
        // Fallback
        const textarea = document.createElement("textarea");
        textarea.value = link;
        document.body.appendChild(textarea);
        textarea.select();
        try {
          document.execCommand("copy");
          alert("Referral link copied: " + link);
        } catch (e) {
          alert("Failed to copy referral link");
        } finally {
          document.body.removeChild(textarea);
        }
      });
  };

  const getDisplayableImageUrl = (imageData: string | undefined): string =>
    resolveProfilePictureUrl(imageData);

  // Handle image upload - keep File for FormData, show preview
  const handleImageUpload = async (file: File) => {
    if (!file.type.startsWith("image/")) {
      setEditError("Please select a valid image file (JPG, PNG, GIF, etc.)");
      return;
    }
    if (file.size > 5 * 1024 * 1024) {
      setEditError("Image must be less than 5MB");
      return;
    }

    setIsUploadingImage(true);
    setUploadProgress(0);
    setEditError("");

    try {
      setUploadProgress(20);

      // Create preview URL for display
      const previewUrl = URL.createObjectURL(file);

      setUploadProgress(70);

      setProfilePictureFile(file);
      setEditForm((prev) => ({
        ...prev,
        profilePictureUrl: previewUrl,
      }));
      setUploadProgress(100);
      setTimeout(() => setUploadProgress(0), 500);
    } catch (error: any) {
      setEditError("Failed to process image. Please try a different image.");
      setUploadProgress(0);
    } finally {
      setIsUploadingImage(false);
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      handleImageUpload(file);
    }
  };

  // Password validation
  const validatePassword = (password: string): string[] => {
    const errors: string[] = [];
    if (password.length < 8) errors.push("At least 8 characters");
    if (!/[A-Z]/.test(password)) errors.push("One uppercase letter");
    if (!/[a-z]/.test(password)) errors.push("One lowercase letter");
    if (!/\d/.test(password)) errors.push("One number");
    if (!/[!@#$%^&*(),.?":{}|<>]/.test(password))
      errors.push("One special character");
    return errors;
  };

  const handlePasswordFormChange = (field: string, value: string) => {
    setPasswordForm((prev) => ({ ...prev, [field]: value }));
    if (field === "newPassword") {
      setPasswordErrors(validatePassword(value));
    }
    setSubmitError("");
  };

  const togglePasswordVisibility = (field: "current" | "new" | "confirm") => {
    setShowPasswords((prev) => ({ ...prev, [field]: !prev[field] }));
  };

  const handlePasswordSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (
      !passwordForm.currentPassword ||
      !passwordForm.newPassword ||
      !passwordForm.confirmPassword
    ) {
      setSubmitError("All fields are required");
      return;
    }
    if (passwordForm.newPassword !== passwordForm.confirmPassword) {
      setSubmitError("New passwords do not match");
      return;
    }
    if (passwordErrors.length > 0) {
      setSubmitError("Please fix password requirements");
      return;
    }

    setIsSubmitting(true);
    setSubmitError("");
    setSubmitSuccess(false);

    try {
      await apiClient.post(API_ENDPOINTS.USER.CHANGE_PASSWORD, {
        current_password: passwordForm.currentPassword,
        new_password: passwordForm.newPassword,
        new_password_confirmation: passwordForm.confirmPassword,
      });
      setSubmitSuccess(true);
      setPasswordForm({
        currentPassword: "",
        newPassword: "",
        confirmPassword: "",
      });
      setTimeout(() => {
        setShowChangePasswordModal(false);
        setSubmitSuccess(false);
      }, 2000);
    } catch (error: any) {
      const msg =
        error?.data?.errors && Object.keys(error.data.errors).length > 0
          ? (() => {
              const v = Object.values(error.data.errors)[0];
              return Array.isArray(v) ? v[0] : String(v);
            })()
          : error?.message;
      setSubmitError(msg || "An unexpected error occurred. Please try again.");
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleEditFormChange = (field: string, value: string) => {
    setEditForm((prev) => ({ ...prev, [field]: value }));
    setEditError("");
  };

  const handleProfileUpdate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editForm.fullName) {
      setEditError("Full Name is required");
      return;
    }

    setIsEditing(true);
    setEditError("");
    setEditSuccess(false);

    try {
      const formData = new FormData();
      formData.append("_method", "PUT");
      formData.append("full_name", editForm.fullName);

      if (profilePictureFile) {
        formData.append("profile_picture", profilePictureFile);
      }

      const res = await apiClient.post<{
        name?: string;
        country?: string;
        phone_number?: string;
        profile_picture?: string;
      }>(API_ENDPOINTS.USER.PROFILE, formData);
      const data = res.data;
      setProfileData((prev) => ({
        ...prev!,
        name: data?.name ?? editForm.fullName,
        country: data?.country ?? prev?.country,
        phone: data?.phone_number ?? prev?.phone,
        profile_picture: data?.profile_picture ?? prev?.profile_picture,
      }));
      setEditSuccess(true);

      setTimeout(() => {
        setShowEditProfileModal(false);
        setEditSuccess(false);
        window.location.reload();
      }, 1000);
    } catch (error: any) {
      const msg =
        error?.data?.errors && Object.keys(error.data.errors).length > 0
          ? (() => {
              const v = Object.values(error.data.errors)[0];
              return Array.isArray(v) ? v[0] : String(v);
            })()
          : error?.message;
      setEditError(msg || "An unexpected error occurred. Please try again.");
    } finally {
      setIsEditing(false);
    }
  };

  const closePasswordModal = () => {
    setShowChangePasswordModal(false);
    setPasswordForm({
      currentPassword: "",
      newPassword: "",
      confirmPassword: "",
    });
    setPasswordErrors([]);
    setSubmitError("");
    setSubmitSuccess(false);
    setShowPasswords({ current: false, new: false, confirm: false });
  };

  const closeEditProfileModal = () => {
    setShowEditProfileModal(false);
    setEditForm({
      fullName: profileData?.name || "",
      country: profileData?.country || "",
      phone: profileData?.phone || "",
      profilePictureUrl: profileData?.profile_picture || "",
    });
    setEditError("");
    setEditSuccess(false);
    setIsEditing(false);
  };

  // ✅ FIXED: Removed setPreviewImage and corrected key name
  const openEditProfileModal = () => {
    setEditForm({
      fullName: profileData?.name || "",
      country: profileData?.country || "",
      phone: profileData?.phone || "",
      profilePictureUrl: profileData?.profile_picture || "", // ✅ Correct key
    });
    // ❌ REMOVED: setPreviewImage(...) — this was causing the error!
    setEditError("");
    setEditSuccess(false);
    setIsEditing(false);
    setShowEditProfileModal(true);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-sky-50 to-blue-100 p-4 sm:p-6">
        <div className="max-w-4xl mx-auto">
          <div className="mb-6 sm:mb-8">
            <h1 className="text-2xl sm:text-4xl font-bold bg-gradient-to-r from-sky-600 to-blue-600 bg-clip-text text-transparent">
              Profile Information
            </h1>
            <p className="text-gray-600 mt-2 text-sm sm:text-base">
              Manage your account details and settings
            </p>
          </div>
          <div className="bg-white rounded-xl sm:rounded-2xl shadow-xl border border-gray-100 p-8">
            <div className="flex items-center justify-center py-12">
              <div className="text-center">
                <Loader2 className="w-8 h-8 sm:w-12 sm:h-12 text-sky-600 animate-spin mx-auto mb-4" />
                <p className="text-gray-600 text-sm sm:text-base">
                  Loading profile information...
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-sky-50 to-blue-100 p-4 sm:p-6">
      <div className="max-w-4xl mx-auto">
        <div className="mb-6 sm:mb-8">
          <h1 className="text-2xl sm:text-4xl font-bold bg-gradient-to-r from-sky-600 to-blue-600 bg-clip-text text-transparent">
            Profile Information
          </h1>
          <p className="text-gray-600 mt-2 text-sm sm:text-base">
            Manage your account details and settings
          </p>
        </div>

        {error && (
          <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-xl">
            <div className="flex items-center space-x-2">
              <AlertCircle className="w-5 h-5 text-red-600" />
              <span className="text-red-800 font-semibold">
                Error loading profile: {error}
              </span>
            </div>
          </div>
        )}

        <div className="bg-white rounded-xl sm:rounded-2xl shadow-xl border border-gray-100 p-4 sm:p-6 md:p-8">
          <div className="flex flex-col sm:flex-row items-center justify-between mb-6 sm:mb-8">
            <div className="flex items-center space-x-3 sm:space-x-4 mb-4 sm:mb-0">
              <div className="w-12 h-12 sm:w-16 sm:h-16 bg-gradient-to-br from-sky-500 to-blue-600 rounded-full flex items-center justify-center overflow-hidden">
                {profileData?.profile_picture ? (
                  <img
                    src={getDisplayableImageUrl(profileData.profile_picture)}
                    alt="Profile"
                    className="w-full h-full object-cover rounded-full"
                    onError={(e) => {
                      e.currentTarget.style.display = "none";
                    }}
                  />
                ) : (
                  <User className="w-6 h-6 sm:w-8 sm:h-8 text-white" />
                )}
              </div>
              <div>
                <h2 className="text-xl sm:text-2xl font-bold text-gray-900">
                  {profileData?.name}
                </h2>
                <p className="text-gray-600 text-sm sm:text-base">
                  {profileData?.email}
                </p>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 gap-4 sm:gap-6 md:gap-8">
            <div className="bg-gradient-to-br from-sky-50 to-blue-50 rounded-lg sm:rounded-xl p-4 sm:p-6 border border-sky-100">
              <div className="flex items-center space-x-2 sm:space-x-3 mb-2 sm:mb-3">
                <User className="w-4 h-4 sm:w-5 sm:h-5 text-sky-600" />
                <label className="text-xs sm:text-sm font-semibold text-sky-700 uppercase tracking-wide">
                  Full Name
                </label>
              </div>
              <p className="text-lg sm:text-xl font-bold text-gray-900">
                {profileData?.name}
              </p>
            </div>
            <div className="bg-gradient-to-br from-sky-50 to-blue-50 rounded-lg sm:rounded-xl p-4 sm:p-6 border border-sky-100">
              <div className="flex items-center space-x-2 sm:space-x-3 mb-2 sm:mb-3">
                <Mail className="w-4 h-4 sm:w-5 sm:h-5 text-sky-600" />
                <label className="text-xs sm:text-sm font-semibold text-sky-700 uppercase tracking-wide">
                  Email Address
                </label>
              </div>
              <p className="text-lg sm:text-xl font-bold text-gray-900 break-all">
                {profileData?.email}
              </p>
            </div>
            <div className="bg-gradient-to-br from-sky-50 to-blue-50 rounded-lg sm:rounded-xl p-4 sm:p-6 border border-sky-100">
              <div className="flex items-center space-x-2 sm:space-x-3 mb-2 sm:mb-3">
                <Globe className="w-4 h-4 sm:w-5 sm:h-5 text-sky-600" />
                <label className="text-xs sm:text-sm font-semibold text-sky-700 uppercase tracking-wide">
                  Country
                </label>
              </div>
              <p className="text-lg sm:text-xl font-bold text-gray-900">
                {profileData?.country}
              </p>
            </div>
            {profileData?.account_title && (
              <div className="bg-gradient-to-br from-sky-50 to-blue-50 rounded-lg sm:rounded-xl p-4 sm:p-6 border border-sky-100">
                <div className="flex items-center space-x-2 sm:space-x-3 mb-2 sm:mb-3">
                  <Building className="w-4 h-4 sm:w-5 sm:h-5 text-sky-600" />
                  <label className="text-xs sm:text-sm font-semibold text-sky-700 uppercase tracking-wide">
                    Account Title
                  </label>
                </div>
                <p className="text-lg sm:text-xl font-bold text-gray-900">
                  {profileData?.account_title}
                </p>
              </div>
            )}
            <div className="bg-gradient-to-br from-sky-50 to-blue-50 rounded-lg sm:rounded-xl p-4 sm:p-6 border border-sky-100">
              <div className="flex items-center space-x-2 sm:space-x-3 mb-2 sm:mb-3">
                <Copy className="w-4 h-4 sm:w-5 sm:h-5 text-sky-600" />
                <label className="text-xs sm:text-sm font-semibold text-sky-700 uppercase tracking-wide">
                  Referral Code
                </label>
              </div>
              <div className="flex flex-col sm:flex-row items-stretch sm:items-center space-y-3 sm:space-y-0 sm:space-x-3">
                <code className="px-3 py-2 sm:px-4 sm:py-3 bg-white border-2 border-sky-200 rounded-lg sm:rounded-xl text-base sm:text-xl font-mono text-gray-900 font-bold text-center sm:text-left break-all">
                  {profileData?.referralCode}
                </code>
                <button
                  onClick={handleCopyReferralCode}
                  className="px-4 py-2 sm:px-6 sm:py-3 bg-gradient-to-r from-sky-500 to-blue-600 text-white rounded-lg sm:rounded-xl hover:from-sky-600 hover:to-blue-700 transition-all duration-300 font-semibold shadow-lg hover:shadow-xl transform hover:scale-105 text-sm sm:text-base"
                >
                  Copy
                </button>
              </div>
            </div>
            {profileData?.account_number && (
              <div className="bg-gradient-to-br from-sky-50 to-blue-50 rounded-lg sm:rounded-xl p-4 sm:p-6 border border-sky-100">
                <div className="flex items-center space-x-2 sm:space-x-3 mb-2 sm:mb-3">
                  <CreditCard className="w-4 h-4 sm:w-5 sm:h-5 text-sky-600" />
                  <label className="text-xs sm:text-sm font-semibold text-sky-700 uppercase tracking-wide">
                    Account Number
                  </label>
                </div>
                <p className="text-lg sm:text-xl font-bold text-gray-900">
                  {profileData?.account_number}
                </p>
              </div>
            )}
          </div>

          <div className="mt-6 sm:mt-8 pt-4 sm:pt-6 border-t border-gray-200">
            <div className="flex flex-col sm:flex-row gap-3 sm:gap-4">
              <button
                onClick={openEditProfileModal}
                className="px-4 py-2 sm:px-6 sm:py-3 bg-gradient-to-r from-sky-500 to-blue-600 text-white rounded-lg sm:rounded-xl hover:from-sky-600 hover:to-blue-700 transition-all duration-300 font-semibold shadow-lg hover:shadow-xl transform hover:scale-105 text-sm sm:text-base"
              >
                Edit Profile
              </button>
              <button
                onClick={() => setShowChangePasswordModal(true)}
                className="px-4 py-2 sm:px-6 sm:py-3 bg-white border-2 border-sky-200 text-sky-700 rounded-lg sm:rounded-xl hover:bg-sky-50 transition-all duration-300 font-semibold text-sm sm:text-base"
              >
                Change Password
              </button>
            </div>
          </div>
        </div>

        {/* Edit Profile Modal */}
        {showEditProfileModal && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-3 sm:p-4 z-50">
            <div className="bg-white rounded-xl sm:rounded-2xl shadow-2xl max-w-md w-full max-h-[90vh] overflow-y-auto">
              <div className="flex items-center justify-between p-4 sm:p-6 border-b border-gray-200">
                <div className="flex items-center space-x-2 sm:space-x-3">
                  <div className="w-8 h-8 sm:w-10 sm:h-10 bg-gradient-to-br from-sky-500 to-blue-600 rounded-full flex items-center justify-center">
                    <User className="w-4 h-4 sm:w-5 sm:h-5 text-white" />
                  </div>
                  <h3 className="text-lg sm:text-xl font-bold text-gray-900">
                    Edit Profile
                  </h3>
                </div>
                <button
                  onClick={closeEditProfileModal}
                  className="p-1 sm:p-2 hover:bg-gray-100 rounded-full transition-colors"
                >
                  <X className="w-4 h-4 sm:w-5 sm:h-5 text-gray-500" />
                </button>
              </div>
              <form onSubmit={handleProfileUpdate} className="p-4 sm:p-6">
                {editSuccess && (
                  <div className="mb-4 sm:mb-6 p-3 sm:p-4 bg-green-50 border border-green-200 rounded-lg sm:rounded-xl">
                    <div className="flex items-center space-x-2">
                      <CheckCircle className="w-4 h-4 sm:w-5 sm:h-5 text-green-600" />
                      <span className="text-green-800 font-semibold text-sm sm:text-base">
                        Profile updated successfully!
                      </span>
                    </div>
                  </div>
                )}
                {editError && (
                  <div className="mb-4 sm:mb-6 p-3 sm:p-4 bg-red-50 border border-red-200 rounded-lg sm:rounded-xl">
                    <div className="flex items-center space-x-2">
                      <AlertCircle className="w-4 h-4 sm:w-5 sm:h-5 text-red-600" />
                      <span className="text-red-800 font-semibold text-sm sm:text-base">
                        {editError}
                      </span>
                    </div>
                  </div>
                )}
                <div className="space-y-4 sm:space-y-6">
                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-3">
                      Profile Picture
                    </label>
                    <div className="flex flex-col items-center space-y-3">
                      {editForm.profilePictureUrl ? (
                        <div className="w-32 h-32 sm:w-40 sm:h-40 rounded-full border-4 border-sky-300 overflow-hidden bg-gray-100 shadow-lg">
                          <img
                            src={editForm.profilePictureUrl}
                            alt="Preview"
                            className="w-full h-full object-cover"
                            onError={(e) => {
                              e.currentTarget.src =
                                "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='100' height='100'%3E%3Crect fill='%23f3f4f6' width='100' height='100'/%3E%3Ctext x='50%25' y='50%25' dominant-baseline='middle' text-anchor='middle' fill='%239ca3af' font-size='12'%3ENo Image%3C/text%3E%3C/svg%3E";
                            }}
                          />
                        </div>
                      ) : (
                        <div className="w-32 h-32 sm:w-40 sm:h-40 rounded-full border-4 border-dashed border-gray-300 bg-gray-50 flex items-center justify-center">
                          <div className="text-center">
                            <User className="w-12 h-12 text-gray-400 mx-auto mb-2" />
                            <p className="text-xs text-gray-500">No image</p>
                          </div>
                        </div>
                      )}
                      <input
                        type="file"
                        accept="image/*"
                        onChange={handleFileSelect}
                        className="hidden"
                        id="profile-image-upload"
                        disabled={isUploadingImage || isEditing}
                      />
                      <label
                        htmlFor="profile-image-upload"
                        className={`cursor-pointer px-6 py-3 rounded-xl font-semibold text-sm transition-all duration-300 ${
                          isUploadingImage || isEditing
                            ? "bg-gray-300 text-gray-500 cursor-not-allowed"
                            : "bg-gradient-to-r from-sky-500 to-blue-600 text-white hover:from-sky-600 hover:to-blue-700 shadow-lg hover:shadow-xl transform hover:scale-105"
                        }`}
                      >
                        {isUploadingImage ? (
                          <span className="flex items-center space-x-2">
                            <Loader2 className="w-4 h-4 animate-spin" />
                            <span>Uploading...</span>
                          </span>
                        ) : editForm.profilePictureUrl ? (
                          "Change Photo"
                        ) : (
                          "Upload Photo"
                        )}
                      </label>
                      {isUploadingImage && (
                        <div className="w-full max-w-xs">
                          <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                            <div
                              className="h-full bg-gradient-to-r from-sky-500 to-blue-600 transition-all duration-300"
                              style={{ width: `${uploadProgress}%` }}
                            />
                          </div>
                        </div>
                      )}
                      <p className="text-xs text-gray-500">
                        Max 10MB • JPG, PNG, GIF
                      </p>
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                      Full Name
                    </label>
                    <input
                      type="text"
                      value={editForm.fullName}
                      onChange={(e) =>
                        handleEditFormChange("fullName", e.target.value)
                      }
                      className="w-full px-3 py-2 sm:px-4 sm:py-3 border-2 border-gray-200 rounded-lg sm:rounded-xl focus:border-sky-500 focus:outline-none transition-colors text-sm sm:text-base"
                      placeholder="Enter your full name"
                      disabled={isEditing}
                    />
                  </div>
                </div>
                <div className="flex flex-col sm:flex-row space-y-3 sm:space-y-0 sm:space-x-4 mt-6 sm:mt-8">
                  <button
                    type="button"
                    onClick={closeEditProfileModal}
                    className="px-4 py-2 sm:px-6 sm:py-3 bg-gray-100 text-gray-700 rounded-lg sm:rounded-xl hover:bg-gray-200 transition-colors font-semibold text-sm sm:text-base"
                    disabled={isEditing}
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={isEditing}
                    className="px-4 py-2 sm:px-6 sm:py-3 bg-gradient-to-r from-sky-500 to-blue-600 text-white rounded-lg sm:rounded-xl hover:from-sky-600 hover:to-blue-700 transition-all duration-300 font-semibold shadow-lg hover:shadow-xl transform hover:scale-105 disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none text-sm sm:text-base"
                  >
                    {isEditing ? (
                      <div className="flex items-center justify-center space-x-2">
                        <div className="w-3 h-3 sm:w-4 sm:h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                        <span>Saving...</span>
                      </div>
                    ) : editSuccess ? (
                      "Saved!"
                    ) : (
                      "Save Changes"
                    )}
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* Change Password Modal */}
        {showChangePasswordModal && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-3 sm:p-4 z-50">
            <div className="bg-white rounded-xl sm:rounded-2xl shadow-2xl max-w-md w-full max-h-[90vh] overflow-y-auto">
              <div className="flex items-center justify-between p-4 sm:p-6 border-b border-gray-200">
                <div className="flex items-center space-x-2 sm:space-x-3">
                  <div className="w-8 h-8 sm:w-10 sm:h-10 bg-gradient-to-br from-sky-500 to-blue-600 rounded-full flex items-center justify-center">
                    <Lock className="w-4 h-4 sm:w-5 sm:h-5 text-white" />
                  </div>
                  <h3 className="text-lg sm:text-xl font-bold text-gray-900">
                    Change Password
                  </h3>
                </div>
                <button
                  onClick={closePasswordModal}
                  className="p-1 sm:p-2 hover:bg-gray-100 rounded-full transition-colors"
                >
                  <X className="w-4 h-4 sm:w-5 sm:h-5 text-gray-500" />
                </button>
              </div>
              <form onSubmit={handlePasswordSubmit} className="p-4 sm:p-6">
                {submitSuccess && (
                  <div className="mb-4 sm:mb-6 p-3 sm:p-4 bg-green-50 border border-green-200 rounded-lg sm:rounded-xl">
                    <div className="flex items-center space-x-2">
                      <CheckCircle className="w-4 h-4 sm:w-5 sm:h-5 text-green-600" />
                      <span className="text-green-800 font-semibold text-sm sm:text-base">
                        Password changed successfully!
                      </span>
                    </div>
                  </div>
                )}
                {submitError && (
                  <div className="mb-4 sm:mb-6 p-3 sm:p-4 bg-red-50 border border-red-200 rounded-lg sm:rounded-xl">
                    <div className="flex items-center space-x-2">
                      <AlertCircle className="w-4 h-4 sm:w-5 sm:h-5 text-red-600" />
                      <span className="text-red-800 font-semibold text-sm sm:text-base">
                        {submitError}
                      </span>
                    </div>
                  </div>
                )}
                <div className="space-y-4 sm:space-y-6">
                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                      Current Password
                    </label>
                    <div className="relative">
                      <input
                        type={showPasswords.current ? "text" : "password"}
                        value={passwordForm.currentPassword}
                        onChange={(e) =>
                          handlePasswordFormChange(
                            "currentPassword",
                            e.target.value,
                          )
                        }
                        className="w-full px-3 py-2 sm:px-4 sm:py-3 pr-10 sm:pr-12 border-2 border-gray-200 rounded-lg sm:rounded-xl focus:border-sky-500 focus:outline-none transition-colors text-sm sm:text-base"
                        placeholder="Enter your current password"
                        disabled={isSubmitting || submitSuccess}
                      />
                      <button
                        type="button"
                        onClick={() => togglePasswordVisibility("current")}
                        className="absolute right-2 sm:right-3 top-1/2 transform -translate-y-1/2 p-1 hover:bg-gray-100 rounded"
                      >
                        {showPasswords.current ? (
                          <EyeOff className="w-4 h-4 sm:w-5 sm:h-5 text-gray-500" />
                        ) : (
                          <Eye className="w-4 h-4 sm:w-5 sm:h-5 text-gray-500" />
                        )}
                      </button>
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                      New Password
                    </label>
                    <div className="relative">
                      <input
                        type={showPasswords.new ? "text" : "password"}
                        value={passwordForm.newPassword}
                        onChange={(e) =>
                          handlePasswordFormChange(
                            "newPassword",
                            e.target.value,
                          )
                        }
                        className="w-full px-3 py-2 sm:px-4 sm:py-3 pr-10 sm:pr-12 border-2 border-gray-200 rounded-lg sm:rounded-xl focus:border-sky-500 focus:outline-none transition-colors text-sm sm:text-base"
                        placeholder="Enter your new password"
                        disabled={isSubmitting || submitSuccess}
                      />
                      <button
                        type="button"
                        onClick={() => togglePasswordVisibility("new")}
                        className="absolute right-2 sm:right-3 top-1/2 transform -translate-y-1/2 p-1 hover:bg-gray-100 rounded"
                      >
                        {showPasswords.new ? (
                          <EyeOff className="w-4 h-4 sm:w-5 sm:h-5 text-gray-500" />
                        ) : (
                          <Eye className="w-4 h-4 sm:w-5 sm:h-5 text-gray-500" />
                        )}
                      </button>
                    </div>
                    {passwordForm.newPassword && (
                      <div className="mt-2 sm:mt-3 p-2 sm:p-3 bg-gray-50 rounded-lg">
                        <div className="flex items-center space-x-2 mb-1 sm:mb-2">
                          <Shield className="w-3 h-3 sm:w-4 sm:h-4 text-gray-600" />
                          <span className="text-xs sm:text-sm font-semibold text-gray-700">
                            Password Requirements
                          </span>
                        </div>
                        <div className="grid grid-cols-1 gap-1">
                          {[
                            {
                              check: passwordForm.newPassword.length >= 8,
                              text: "At least 8 characters",
                            },
                            {
                              check: /[A-Z]/.test(passwordForm.newPassword),
                              text: "One uppercase letter",
                            },
                            {
                              check: /[a-z]/.test(passwordForm.newPassword),
                              text: "One lowercase letter",
                            },
                            {
                              check: /\d/.test(passwordForm.newPassword),
                              text: "One number",
                            },
                            {
                              check: /[!@#$%^&*(),.?":{}|<>]/.test(
                                passwordForm.newPassword,
                              ),
                              text: "One special character",
                            },
                          ].map((req, index) => (
                            <div
                              key={index}
                              className="flex items-center space-x-2"
                            >
                              <div
                                className={`w-1.5 h-1.5 sm:w-2 sm:h-2 rounded-full ${
                                  req.check ? "bg-green-500" : "bg-gray-300"
                                }`}
                              ></div>
                              <span
                                className={`text-xs ${
                                  req.check ? "text-green-700" : "text-gray-500"
                                }`}
                              >
                                {req.text}
                              </span>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                      Confirm New Password
                    </label>
                    <div className="relative">
                      <input
                        type={showPasswords.confirm ? "text" : "password"}
                        value={passwordForm.confirmPassword}
                        onChange={(e) =>
                          handlePasswordFormChange(
                            "confirmPassword",
                            e.target.value,
                          )
                        }
                        onPaste={(e) => e.preventDefault()}
                        onCopy={(e) => e.preventDefault()}
                        onCut={(e) => e.preventDefault()}
                        className="w-full px-3 py-2 sm:px-4 sm:py-3 pr-10 sm:pr-12 border-2 border-gray-200 rounded-lg sm:rounded-xl focus:border-sky-500 focus:outline-none transition-colors text-sm sm:text-base"
                        placeholder="Confirm your new password"
                        disabled={isSubmitting || submitSuccess}
                      />
                      <button
                        type="button"
                        onClick={() => togglePasswordVisibility("confirm")}
                        className="absolute right-2 sm:right-3 top-1/2 transform -translate-y-1/2 p-1 hover:bg-gray-100 rounded"
                      >
                        {showPasswords.confirm ? (
                          <EyeOff className="w-4 h-4 sm:w-5 sm:h-5 text-gray-500" />
                        ) : (
                          <Eye className="w-4 h-4 sm:w-5 sm:h-5 text-gray-500" />
                        )}
                      </button>
                    </div>
                    {passwordForm.confirmPassword &&
                      passwordForm.newPassword !==
                        passwordForm.confirmPassword && (
                        <p className="mt-1 sm:mt-2 text-xs sm:text-sm text-red-600">
                          Passwords do not match
                        </p>
                      )}
                  </div>
                </div>
                <div className="flex flex-col sm:flex-row space-y-3 sm:space-y-0 sm:space-x-4 mt-6 sm:mt-8">
                  <button
                    type="button"
                    onClick={closePasswordModal}
                    className="px-4 py-2 sm:px-6 sm:py-3 bg-gray-100 text-gray-700 rounded-lg sm:rounded-xl hover:bg-gray-200 transition-colors font-semibold text-sm sm:text-base"
                    disabled={isSubmitting}
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={
                      isSubmitting ||
                      submitSuccess ||
                      passwordErrors.length > 0 ||
                      !passwordForm.currentPassword ||
                      !passwordForm.newPassword ||
                      !passwordForm.confirmPassword ||
                      passwordForm.newPassword !== passwordForm.confirmPassword
                    }
                    className="px-4 py-2 sm:px-6 sm:py-3 bg-gradient-to-r from-sky-500 to-blue-600 text-white rounded-lg sm:rounded-xl hover:from-sky-600 hover:to-blue-700 transition-all duration-300 font-semibold shadow-lg hover:shadow-xl transform hover:scale-105 disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none text-sm sm:text-base"
                  >
                    {isSubmitting ? (
                      <div className="flex items-center justify-center space-x-2">
                        <div className="w-3 h-3 sm:w-4 sm:h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                        <span>Changing...</span>
                      </div>
                    ) : submitSuccess ? (
                      "Success!"
                    ) : (
                      "Change Password"
                    )}
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default ProfileInfo;
