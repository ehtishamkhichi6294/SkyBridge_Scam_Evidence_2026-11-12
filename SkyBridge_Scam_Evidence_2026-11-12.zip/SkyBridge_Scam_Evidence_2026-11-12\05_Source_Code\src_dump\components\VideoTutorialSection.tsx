import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Play, Video } from "lucide-react";
import { VIDEO_TUTORIAL_WATCH_URL } from "../constants/appLinks";

interface VideoTutorialSectionProps {
  className?: string;
  compact?: boolean;
  buttonOnly?: boolean;
  buttonClassName?: string;
  /** Navigate to a route on press instead of opening the video */
  navigateTo?: string;
  buttonLabel?: string;
  /**
   * Max times the button can open the video before it is hidden.
   * Omit (or pass undefined) for no limit.
   */
  maxViews?: number;
}

const TUTORIAL_VIEW_COUNT_KEY = "skybridge_video_tutorial_view_count";

const getTutorialOpenCount = () => {
  if (typeof window === "undefined") return 0;
  return Number(localStorage.getItem(TUTORIAL_VIEW_COUNT_KEY) ?? 0);
};

const incrementTutorialOpenCount = (maxViews: number) => {
  if (typeof window === "undefined") return 0;
  const next = Math.min(maxViews, getTutorialOpenCount() + 1);
  localStorage.setItem(TUTORIAL_VIEW_COUNT_KEY, String(next));
  return next;
};

const VideoTutorialSection: React.FC<VideoTutorialSectionProps> = ({
  className = "",
  compact = false,
  buttonOnly = false,
  buttonClassName = "",
  navigateTo,
  buttonLabel = "Watch Tutorials",
  maxViews,
}) => {
  const navigate = useNavigate();
  const [openCount, setOpenCount] = useState<number>(getTutorialOpenCount);

  const hasViewLimit = typeof maxViews === "number" && maxViews > 0;
  if (hasViewLimit && openCount >= maxViews) return null;

  const handlePress = () => {
    if (navigateTo) {
      navigate(navigateTo);
      return;
    }
    if (hasViewLimit) setOpenCount(incrementTutorialOpenCount(maxViews));
    window.open(VIDEO_TUTORIAL_WATCH_URL, "_blank", "noopener,noreferrer");
  };

  const watchButton = (
    <button
      type="button"
      onClick={handlePress}
      className={
        buttonClassName ||
        "inline-flex items-center justify-center gap-2 px-4 sm:px-5 py-2 sm:py-2.5 rounded-full bg-white border border-sky-600 text-sky-600 font-medium text-xs sm:text-sm hover:bg-sky-50 transition-all active:scale-95 shrink-0"
      }
    >
      <span className="inline-flex items-center justify-center w-5 h-5 rounded-full bg-sky-600 shrink-0">
        <Play className="w-2.5 h-2.5 fill-white text-white ml-0.5" />
      </span>
      {buttonLabel}
    </button>
  );

  if (buttonOnly) return watchButton;

  return (
    <div
      className={`rounded-2xl border border-sky-200 bg-gradient-to-r from-sky-50 via-white to-cyan-50 shadow-sm ${
        compact ? "p-4" : "p-5 sm:p-6"
      } ${className}`}
    >
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div className="flex items-start gap-3">
          <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-red-500 to-red-600 flex items-center justify-center shadow-md shrink-0">
            <Video className="w-5 h-5 text-white" />
          </div>
          <div>
            <h3 className="text-base sm:text-lg font-bold text-gray-900">
              Video Tutorial
            </h3>
            <p className="text-sm text-gray-600 mt-0.5">
              Learn how to use SkyBridge with our step-by-step video guide.
            </p>
          </div>
        </div>
        {watchButton}
      </div>
    </div>
  );
};

export default VideoTutorialSection;
