import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { Mail, Lock, Eye, EyeOff, AlertCircle, CheckCircle } from 'lucide-react';
import { normalizeEmailToASCII } from '../utils/emailUtils';

const Login: React.FC = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const { login } = useAuth();
  const navigate = useNavigate();

  const getReadableLoginError = (rawError?: string) => {
    const message = (rawError || '').toString().trim();
    if (!message) return 'Login failed. Please try again.';

    const lower = message.toLowerCase();
    if (lower.includes('invalid credentials')) {
      return "Your Gmail I'd Or Password Is Wrong";
    }

    const isTimeout = lower.includes('timeout');
    const isNetworkLike =
      isTimeout ||
      lower.includes('network') ||
      lower.includes('failed to fetch') ||
      lower.includes('unable to connect');

    if (isNetworkLike) {
      return `${message} Please check your connection and try again.`;
    }

    return message;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError('');
    setSuccess('');
    
    try {
      // Normalize email to ASCII before sending to API
      const normalizedEmail = normalizeEmailToASCII(email);
      const result = await login(normalizedEmail, password);
      
      if (result.success) {
        setSuccess((result.message || 'Login successful.').toString());
        setTimeout(() => navigate('/dashboard'), 700);
      } else {
        setError(getReadableLoginError(result.message || result.error));
      }
    } catch (error: unknown) {
      console.error('Login error:', error);
      const message =
        typeof error === 'object' && error !== null && 'message' in error
          ? String((error as { message?: unknown }).message ?? '')
          : '';
      setError(getReadableLoginError(message));
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-sky-500 via-sky-600 to-sky-700 flex items-center justify-center p-3 sm:p-4">
      <div className="w-full max-w-4xl bg-white rounded-xl sm:rounded-2xl shadow-2xl overflow-hidden">
        <div className="flex flex-col lg:flex-row">
          {/* Left side - Illustration */}
          <div className="lg:w-1/2 bg-gradient-to-br from-sky-600 to-sky-700 p-6 sm:p-8 flex items-center justify-center">
            <div className="text-center text-white">
              {/* SVG Illustration */}
              <div className="mb-8">
                <svg viewBox="0 0 400 300" className="w-full h-64 lg:h-80">
                  {/* Background shapes */}
                  <defs>
                    <linearGradient id="bgGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                      <stop offset="0%" stopColor="#E0F2FE" />
                      <stop offset="100%" stopColor="#BAE6FD" />
                    </linearGradient>
                  </defs>
                  
                  {/* Background circles */}
                  <circle cx="100" cy="80" r="40" fill="#DBEAFE" opacity="0.6" />
                  <circle cx="320" cy="120" r="30" fill="#BFDBFE" opacity="0.8" />
                  <circle cx="80" cy="200" r="25" fill="#93C5FD" opacity="0.5" />
                  
                  {/* Mobile device */}
                  <rect x="150" y="80" width="100" height="160" rx="15" fill="#1E40AF" />
                  <rect x="160" y="90" width="80" height="140" rx="8" fill="#FFFFFF" />
                  
                  {/* Screen content */}
                  <rect x="170" y="100" width="60" height="4" rx="2" fill="#E5E7EB" />
                  <rect x="170" y="110" width="40" height="4" rx="2" fill="#E5E7EB" />
                  <circle cx="200" cy="140" r="15" fill="#3B82F6" />
                  <rect x="180" y="165" width="40" height="6" rx="3" fill="#10B981" />
                  <rect x="180" y="180" width="30" height="6" rx="3" fill="#F59E0B" />
                  
                  {/* Person figure */}
                  <circle cx="280" cy="140" r="20" fill="#F3F4F6" />
                  <circle cx="280" cy="135" r="8" fill="#6B7280" />
                  <rect x="270" y="160" width="20" height="40" rx="10" fill="#3B82F6" />
                  <rect x="265" y="170" width="10" height="25" rx="5" fill="#F3F4F6" />
                  <rect x="285" y="170" width="10" height="25" rx="5" fill="#F3F4F6" />
                  <rect x="275" y="200" width="10" height="20" rx="5" fill="#6B7280" />
                  
                  {/* Security shield */}
                  <path d="M120 160 L130 150 L140 160 L135 180 L125 180 Z" fill="#10B981" />
                  <circle cx="130" cy="165" r="3" fill="#FFFFFF" />
                  
                  {/* Key icon */}
                  <circle cx="320" cy="200" r="8" fill="#F59E0B" />
                  <rect x="325" y="195" width="15" height="4" rx="2" fill="#F59E0B" />
                  <rect x="335" y="193" width="3" height="2" fill="#F59E0B" />
                  <rect x="335" y="197" width="3" height="2" fill="#F59E0B" />
                  
                  {/* Plant decoration */}
                  <ellipse cx="60" cy="250" rx="15" ry="8" fill="#22C55E" />
                  <path d="M55 245 Q60 235 65 245" fill="#16A34A" />
                  <path d="M50 248 Q55 238 60 248" fill="#16A34A" />
                  <path d="M60 248 Q65 238 70 248" fill="#16A34A" />
                </svg>
              </div>
              
              <h2 className="text-2xl lg:text-3xl font-bold text-white mb-4">
                Secure Access to Your Account
              </h2>
              <p className="text-white text-lg">
                Your trusted platform for digital earning opportunities
              </p>
            </div>
          </div>

          {/* Right Side - Login Form */}
          <div className="lg:w-1/2 p-6 sm:p-8 lg:p-12 flex items-center justify-center">
            <div className="w-full max-w-md">
              <div className="text-center mb-6 sm:mb-8">
                <h1 className="text-2xl sm:text-3xl font-bold text-gray-800 mb-2">Welcome!</h1>
                <p className="text-sm sm:text-base text-gray-600">Sign in to your Account</p>
              </div>

              {/* Error Display */}
              {error && (
                <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-lg flex items-center space-x-2 text-red-700">
                  <AlertCircle className="w-5 h-5 flex-shrink-0" />
                  <span className="text-sm">{error}</span>
                </div>
              )}

              {/* Success Display */}
              {success && (
                <div className="mb-4 p-3 bg-green-50 border border-green-200 rounded-lg flex items-center space-x-2 text-green-700">
                  <CheckCircle className="w-5 h-5 flex-shrink-0" />
                  <span className="text-sm">{success}</span>
                </div>
              )}

              <form onSubmit={handleSubmit} className="space-y-4 sm:space-y-6">
                {/* Email Field */}
                <div>
                  <div className="relative">
                    <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                    <input
                      type="email"
                      value={email}
                      onChange={(e) => {
                        // Normalize email to ASCII as user types
                        const normalizedEmail = normalizeEmailToASCII(e.target.value);
                        setEmail(normalizedEmail);
                        if (error) setError('');
                        if (success) setSuccess('');
                      }}
                      className="w-full pl-10 pr-4 py-3 sm:py-4 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all text-sm sm:text-base"
                      placeholder="Email Address"
                      required
                    />
                  </div>
                </div>

                {/* Password Field */}
                <div>
                  <div className="relative">
                    <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                    <input
                      type={showPassword ? 'text' : 'password'}
                      value={password}
                      onChange={(e) => {
                        setPassword(e.target.value);
                        if (error) setError('');
                        if (success) setSuccess('');
                      }}
                      className="w-full pl-10 pr-12 py-3 sm:py-4 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all text-sm sm:text-base"
                      placeholder="Password"
                      required
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600"
                    >
                      {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                    </button>
                  </div>
                </div>

                {/* Forgot Password */}
                <div className="text-right">
                  <Link to="/forgot-password" className="text-blue-600 hover:text-blue-700 text-sm">
                    Forgot Password?
                  </Link>
                </div>

                {/* Sign In Button */}
                <button
                  type="submit"
                  disabled={isLoading}
                  className="w-full bg-blue-600 text-white py-3 sm:py-4 rounded-xl font-semibold text-base sm:text-lg hover:bg-blue-700 transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {isLoading ? 'SIGNING IN...' : 'SIGN IN'}
                </button>

                {/* Sign Up Button */}
                <Link
                  to="/register"
                  className="w-full block text-center bg-gray-100 text-gray-700 py-3 sm:py-4 rounded-xl font-semibold text-base sm:text-lg hover:bg-gray-200 transition-all duration-200"
                >
                  SIGN UP
                </Link>
              </form>

             
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Login;