import React from "react";
import AboutContent from "../components/AboutContent";
import FloatingPartnerLinks from "../components/FloatingPartnerLinks";

const About: React.FC = () => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-sky-50 via-blue-50 to-cyan-50">
      <AboutContent />
      <FloatingPartnerLinks />
    </div>
  );
};

export default About;
