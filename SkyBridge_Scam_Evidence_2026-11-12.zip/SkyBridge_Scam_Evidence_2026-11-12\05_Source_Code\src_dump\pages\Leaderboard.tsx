import React, { useState, useEffect, useMemo } from "react";
import { LeaderboardPodium } from "../components/LeaderboardPodium";
import { apiClient } from "../services";
import {
  getAvatarFallbackUrl,
  resolveProfilePictureUrl,
} from "../utils/imageUtils";

type FilterPeriod = "today" | "last_month" | "all_time";

interface Leader {
  position: number;
  name: string;
  income: number;
  image: string;
  countryFlag: string;
  country: string;
}

const getFlagUrl = (country: string) => {
  const map: Record<string, string> = {
    Pakistan: "https://flagcdn.com/w40/pk.png",
    India: "https://flagcdn.com/w40/in.png",
    Bangladesh: "https://flagcdn.com/w40/bd.png",
  };
  return map[country] ?? "https://flagcdn.com/w40/un.png";
};

function LeaderAvatar({
  src,
  alt,
  sizeClass,
  ringClass = "ring-2 ring-white",
}: {
  src: string;
  alt: string;
  sizeClass: string;
  ringClass?: string;
}) {
  const fallback = getAvatarFallbackUrl(alt);
  return (
    <div
      className={`relative shrink-0 flex-none overflow-hidden rounded-full bg-sky-100 shadow-md ${sizeClass} ${ringClass}`}
    >
      <img
        src={src || fallback}
        alt={alt}
        className="h-full w-full object-cover object-center"
        loading="lazy"
        referrerPolicy="no-referrer"
        onError={(e) => {
          const target = e.currentTarget;
          target.onerror = null;
          target.src = fallback;
        }}
      />
    </div>
  );
}

function LeaderListRow({ leader }: { leader: Leader }) {
  const rankStyles =
    leader.position === 4
      ? "bg-gradient-to-br from-slate-500 to-slate-700 text-white"
      : "bg-gray-200 text-gray-700";

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-200 px-3 py-2.5 hover:shadow-md transition-shadow">
      <div className="flex items-center justify-between gap-2">
        <div className="flex items-center gap-2 min-w-0 flex-1">
          <div
            className={`w-8 h-8 shrink-0 rounded-md flex items-center justify-center text-sm font-bold ${rankStyles}`}
          >
            {leader.position}
          </div>
          <div className="w-5 h-5 rounded overflow-hidden ring-1 ring-gray-200 shrink-0">
            <img
              src={leader.countryFlag || getFlagUrl(leader.country)}
              alt=""
              className="w-full h-full object-cover"
            />
          </div>
          <LeaderAvatar
            src={leader.image}
            alt={leader.name}
            sizeClass="w-10 h-10"
          />
          <p className="text-sm font-semibold text-gray-900 break-words min-w-0 flex-1">
            {leader.name}
          </p>
        </div>
        <p className="text-base font-bold text-gray-900 whitespace-nowrap shrink-0">
          ${leader.income.toFixed(2)}
        </p>
      </div>
    </div>
  );
}

const Leaderboard = () => {
  const [filterPeriod, setFilterPeriod] = useState<FilterPeriod>("today");
  const [leaders, setLeaders] = useState<Leader[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const sortedLeaders = useMemo(() => {
    return [...leaders].sort((a, b) => b.income - a.income);
  }, [leaders]);

  const topThree = sortedLeaders.slice(0, 3);
  const rest = sortedLeaders.slice(3);

  useEffect(() => {
    const fetchLeaders = async () => {
      try {
        setLoading(true);
        setError(null);
        apiClient.refreshAuthToken();

        const query = `?filter=${filterPeriod}`;
        const res = await apiClient.get<Record<string, unknown>>(`/leaderboard${query}`);
        const responseData = res.data as Record<string, unknown>;
        const apiLeaders = (
          (responseData?.leaders ||
            (responseData?.data as Record<string, unknown>)?.leaders ||
            []) as Record<string, unknown>[]
        );

        const mapped: Leader[] = apiLeaders.map((item, index: number) => {
          const name =
            String(item.name ?? item.full_name ?? `Leader ${index + 1}`);
          const user = item.user as Record<string, unknown> | undefined;
          const rawImgCandidates = [
            item.profile_picture,
            item.profile_picture_url,
            item.profile_photo,
            item.image,
            item.avatar,
            item.avatar_url,
            user?.profile_picture,
            user?.profile_picture_url,
          ];
          let image = "";
          for (const c of rawImgCandidates) {
            if (typeof c === "string" && c.trim()) {
              const resolved = resolveProfilePictureUrl(c);
              if (resolved) {
                image = resolved;
                break;
              }
            }
          }
          if (!image) image = getAvatarFallbackUrl(name);

          const parsedIncomeRaw = item.total_earned ?? item.income;
          const parsedIncome =
            typeof parsedIncomeRaw === "string"
              ? parseFloat(parsedIncomeRaw)
              : Number(parsedIncomeRaw);

          const country = typeof item.country === "string" ? item.country : "";
          const countryFlag =
            typeof item.country_flag === "string"
              ? item.country_flag
              : getFlagUrl(country);

          return {
            position: typeof item.position === "number" ? item.position : index + 1,
            name,
            income: isNaN(parsedIncome) ? 0 : parsedIncome,
            image,
            countryFlag,
            country,
          } as Leader;
        });

        setLeaders(mapped);
      } catch (err: unknown) {
        setError(err instanceof Error ? err.message : "Failed to load leaderboard");
      } finally {
        setLoading(false);
      }
    };

    fetchLeaders();
  }, [filterPeriod]);

  const pageHeader = (
    <div className="flex items-center justify-between mb-4">
      <h1 className="text-2xl sm:text-4xl font-bold bg-gradient-to-r from-sky-600 to-sky-700 bg-clip-text text-transparent">
        Leaderboard
      </h1>
      <span
        className={`w-2 h-2 rounded-full ${
          error
            ? "bg-red-500"
            : loading
              ? "bg-emerald-500 animate-pulse"
              : "bg-emerald-500"
        }`}
      />
    </div>
  );

  const filterBar = (
    <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-4">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-3 gap-2">
        <h2 className="text-lg font-semibold text-gray-900">
          Filter Top Leaders
        </h2>
        <span className="px-2 py-1 bg-emerald-100 text-emerald-700 text-xs font-medium rounded-full self-start sm:self-auto">
          Top {sortedLeaders.length}
        </span>
      </div>
      <div className="flex flex-wrap gap-3">
        <button
          onClick={() => setFilterPeriod("today")}
          className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
            filterPeriod === "today"
              ? "bg-emerald-500 text-white shadow-sm"
              : "bg-gray-100 text-gray-700 hover:bg-gray-200"
          }`}
        >
          Today
        </button>
        <button
          onClick={() => setFilterPeriod("last_month")}
          className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
            filterPeriod === "last_month"
              ? "bg-red-500 text-white shadow-sm"
              : "bg-gray-100 text-gray-700 hover:bg-gray-200"
          }`}
        >
          Last Month
        </button>
        <button
          onClick={() => setFilterPeriod("all_time")}
          className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
            filterPeriod === "all_time"
              ? "bg-sky-500 text-white shadow-sm"
              : "bg-gray-100 text-gray-700 hover:bg-gray-200"
          }`}
        >
          All Time
        </button>
      </div>
    </div>
  );

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <div className="space-y-6 p-4 max-w-4xl mx-auto w-full">
          {pageHeader}
          {filterBar}
          <div className="bg-white rounded-xl border border-gray-200 p-6 animate-pulse h-48" />
          <div className="space-y-4">
            {[1, 2, 3].map((i) => (
              <div
                key={i}
                className="bg-white rounded-xl shadow-sm border border-gray-200 p-4"
              >
                <div className="flex items-center gap-3">
                  <div className="w-11 h-11 bg-gray-200 rounded-lg animate-pulse" />
                  <div className="w-7 h-7 bg-gray-200 rounded-md animate-pulse" />
                  <div className="w-14 h-14 bg-gray-200 rounded-full animate-pulse" />
                  <div className="h-4 bg-gray-200 rounded w-32 animate-pulse" />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-gray-50">
        <div className="space-y-6 p-4 max-w-4xl mx-auto w-full">
          {pageHeader}
          {filterBar}
          <div className="bg-red-50 border-l-4 border-red-500 p-4">
            <h2 className="text-xl font-bold text-red-800">
              Error Loading Leaderboard
            </h2>
            <p className="text-red-700 mt-2">{error}</p>
            <button
              onClick={() => window.location.reload()}
              className="mt-3 px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700"
            >
              Retry
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="space-y-4 p-4 max-w-4xl mx-auto w-full">
        {pageHeader}
        {filterBar}

        {sortedLeaders.length > 0 ? (
          <>
            {topThree.length > 0 && (
              <LeaderboardPodium
                title="Top Earners"
                badgeLabel="Top"
                badgeClassName="bg-emerald-100 text-emerald-700"
                leaders={topThree.map((leader) => ({
                  id: leader.name,
                  name: leader.name,
                  amount: `$${leader.income.toFixed(2)}`,
                  image: leader.image,
                }))}
                totalCount={sortedLeaders.length}
              />
            )}

            {rest.length > 0 && (
              <div className="space-y-3">
                <h3 className="text-sm font-semibold text-gray-600 px-1">
                  Rank 4 onwards
                </h3>
                {rest.map((leader, index) => (
                  <LeaderListRow
                    key={`${leader.name}-${index + 4}`}
                    leader={leader}
                  />
                ))}
              </div>
            )}
          </>
        ) : (
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-8 text-center">
            <div className="w-16 h-16 bg-gradient-to-r from-sky-600 to-sky-700 rounded-full flex items-center justify-center text-white font-bold text-xl mb-3 mx-auto">
              <svg
                className="w-8 h-8"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"
                />
              </svg>
            </div>
            <h3 className="text-lg font-medium text-gray-900 mb-1">
              No Leaders Found
            </h3>
            <p className="text-gray-500">
              No top earners found for the selected time period. Try selecting a
              different filter.
            </p>
          </div>
        )}
      </div>
    </div>
  );
};

export default Leaderboard;
