import React from 'react';
import { Outlet } from 'react-router-dom';
import Sidebar from './Sidebar';
import { useSidebar } from '../contexts/SideBarContect';

const Layout: React.FC = () => {
  const { isSidebarOpen, closeSidebar } = useSidebar();

  return (
    <div className="flex min-h-screen min-h-0 w-full bg-sky-gradient lg:min-h-screen">
      <Sidebar isOpen={isSidebarOpen} onClose={closeSidebar} />

      <div
        className="flex min-h-0 min-w-0 flex-1 w-full flex-col lg:min-h-screen"
        onClick={closeSidebar}
        role="presentation"
      >
        <main className="min-h-0 w-full max-w-full flex-1 overflow-x-hidden md:p-4 lg:p-6 xl:p-8">
          <Outlet />
        </main>
      </div>
    </div>
  );
};

export default Layout;
