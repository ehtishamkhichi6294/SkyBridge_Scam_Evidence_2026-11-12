import React, { useState, useEffect } from "react";
import { Bell, AlertCircle, Loader2, ExternalLink } from "lucide-react";
import { NotificationService } from "../services/notificationService";
import { parseEmojis } from "../utils/emojiUtils";

// Align with backend payload
// { id, title, description, time, created_at, updated_at, link? }
type BackendNotification = {
  id: number;
  title: string;
  description: string;
  type?: string;
  time: string; // ISO string
  created_at: string;
  updated_at: string;
  link?: string; // optional URL – opens in new tab when clicked
};
// Detects http(s) URLs in text and returns React nodes with clickable links (open in new tab)
function renderTextWithLinks(text: string): React.ReactNode {
  if (!text) return text;
  const urlRegex = /https?:\/\/[^\s<>"]+/g;
  const parts: React.ReactNode[] = [];
  let lastIndex = 0;
  let match;
  let key = 0;
  while ((match = urlRegex.exec(text)) !== null) {
    if (match.index > lastIndex) {
      parts.push(
        <React.Fragment key={`t-${key++}`}>
          {parseEmojis(text.slice(lastIndex, match.index))}
        </React.Fragment>
      );
    }
    const url = match[0];
    parts.push(
      <a
        key={`l-${key++}`}
        href={url}
        target="_blank"
        rel="noopener noreferrer"
        className="text-blue-600 hover:underline break-all"
      >
        {url}
      </a>
    );
    lastIndex = urlRegex.lastIndex;
  }
  if (lastIndex < text.length) {
    parts.push(
      <React.Fragment key={`t-${key++}`}>
        {parseEmojis(text.slice(lastIndex))}
      </React.Fragment>
    );
  }
  return parts.length === 0 ? parseEmojis(text) : parts;
}

// Colors per notification type: badge (bg + text) and card accent (border + icon)
const NOTIFICATION_TYPE_STYLES: Record<
  string,
  { badge: string; border: string; icon: string }
> = {
  success: {
    badge: "bg-green-100 text-green-800",
    border: "border-l-green-500",
    icon: "text-green-600",
  },
  warning: {
    badge: "bg-amber-100 text-amber-800",
    border: "border-l-amber-500",
    icon: "text-amber-600",
  },
  info: {
    badge: "bg-blue-100 text-blue-800",
    border: "border-l-blue-500",
    icon: "text-blue-600",
  },
  reward: {
    badge: "bg-purple-100 text-purple-800",
    border: "border-l-purple-500",
    icon: "text-purple-600",
  },
  payment: {
    badge: "bg-emerald-100 text-emerald-800",
    border: "border-l-emerald-500",
    icon: "text-emerald-600",
  },
  referral: {
    badge: "bg-indigo-100 text-indigo-800",
    border: "border-l-indigo-500",
    icon: "text-indigo-600",
  },
};

function getNotificationStyle(type: string | undefined) {
  const key = (type || "info").toLowerCase();
  return NOTIFICATION_TYPE_STYLES[key] ?? NOTIFICATION_TYPE_STYLES.info;
}

const Notifications: React.FC = () => {
  const [notifications, setNotifications] = useState<BackendNotification[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [currentPage, setCurrentPage] = useState(1);
  const [lastPage, setLastPage] = useState(1);

  // Fetch notifications from API
  const fetchNotifications = async (page: number = 1) => {
    try {
      setLoading(true);
      setError(null);
      const response = await NotificationService.getNotifications(page);

      if (response.success && response.data) {
        const list = (response.data.data ||
          []) as unknown as BackendNotification[];
        setNotifications(list);
        setCurrentPage(response.data.current_page || 1);
        setLastPage(response.data.last_page || 1);
      } else {
        setError("Failed to fetch notifications");
      }
    } catch (err: any) {
      console.error("Error fetching notifications:", err);
      setError(err.message || "Failed to fetch notifications");
    } finally {
      setLoading(false);
    }
  };

  // Load notifications on component mount, and clear the unread badge by
  // advancing the server-side read watermark for this user.
  useEffect(() => {
    fetchNotifications(1);
    NotificationService.markAllAsRead().catch(() => {
      // Non-fatal: the list still renders even if marking read fails.
    });
  }, []);

  const deleteNotificationLocal = (id: number) => {
    setNotifications((prev) => prev.filter((notif) => notif.id !== id));
  };

  const handleDeleteNotification = async (id: number) => {
    try {
      await NotificationService.deleteNotification(String(id));
    } catch (err) {
      console.error("Error deleting notification:", err);
      // Keep UI responsive even if server call fails
    }
    deleteNotificationLocal(id);
  };

  const formatDateTime = (iso?: string) => {
    if (!iso) return "";
    try {
      const d = new Date(iso);
      return d.toLocaleString();
    } catch {
      return iso;
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Notifications</h1>
          <p className="text-sm text-gray-600 mt-1">
            You have {notifications.length} notification(s)
          </p>
        </div>
        <div className="mt-4 sm:mt-0">
          <button
            onClick={() => fetchNotifications(currentPage)}
            disabled={loading}
            className="inline-flex items-center px-4 py-2 bg-blue-600 text-white text-sm font-medium rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
          >
            {loading ? (
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
            ) : (
              <Bell className="w-4 h-4 mr-2" />
            )}
            {loading ? "Refreshing..." : "Refresh"}
          </button>
        </div>
      </div>

      {/* Notifications List */}
      <div className="space-y-4">
        {loading ? (
          <div className="text-center py-12">
            <Loader2 className="w-8 h-8 text-blue-600 mx-auto mb-4 animate-spin" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">
              Loading notifications...
            </h3>
            <p className="text-gray-600">
              Please wait while we fetch your notifications.
            </p>
          </div>
        ) : error ? (
          <div className="text-center py-12">
            <AlertCircle className="w-12 h-12 text-red-500 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">
              Error loading notifications
            </h3>
            <p className="text-gray-600 mb-4">{error}</p>
            <button
              onClick={() => fetchNotifications(currentPage)}
              className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
            >
              Try Again
            </button>
          </div>
        ) : notifications.length === 0 ? (
          <div className="text-center py-12">
            <Bell className="w-12 h-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">
              No notifications
            </h3>
            <p className="text-gray-600">You have no notifications yet.</p>
          </div>
        ) : (
          notifications.map((notification) => {
            const style = getNotificationStyle(notification.type);
            return (
            <div
              key={notification.id}
              className={`border rounded-lg p-4 transition-all hover:shadow-md bg-white border-gray-200 border-l-4 ${style.border}`}
            >
              <div className="flex items-start justify-between">
                <div className="flex items-start space-x-3 flex-1">
                  <div className={`flex-shrink-0 mt-1 ${style.icon}`}>
                    <Bell className="w-5 h-5" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center space-x-2 flex-wrap">
                      <h3 className="text-sm font-semibold text-gray-900">
                        {renderTextWithLinks(notification.title)}
                      </h3>
                      <span className={`text-[11px] px-2 py-0.5 rounded-full font-medium capitalize ${style.badge}`}>
                        {(notification.type || "info").toLowerCase()}
                      </span>
                    </div>
                    <p className="text-sm mt-1 text-gray-800 whitespace-pre-wrap">
                      {renderTextWithLinks(notification.description)}
                    </p>
                    <p className="text-xs text-gray-600 mt-2">
                      {formatDateTime(notification.time)}
                    </p>
                    {notification.link && (
                      <a
                        href={notification.link}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center mt-3 px-3 py-1.5 text-sm font-medium text-blue-600 bg-blue-50 rounded-lg hover:bg-blue-100 transition-colors"
                      >
                        <ExternalLink className="w-4 h-4 mr-1.5" />
                        Open link
                      </a>
                    )}
                  </div>
                </div>
              </div>
            </div>
          );
          })
        )}

        {/* Pagination */}
        {!loading && !error && lastPage > 1 && (
          <div className="flex justify-center items-center space-x-4 mt-8">
            <button
              onClick={() => fetchNotifications(currentPage - 1)}
              disabled={currentPage <= 1}
              className="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              Previous
            </button>
            <span className="text-sm text-gray-700">
              Page {currentPage} of {lastPage}
            </span>
            <button
              onClick={() => fetchNotifications(currentPage + 1)}
              disabled={currentPage >= lastPage}
              className="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              Next
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default Notifications;
