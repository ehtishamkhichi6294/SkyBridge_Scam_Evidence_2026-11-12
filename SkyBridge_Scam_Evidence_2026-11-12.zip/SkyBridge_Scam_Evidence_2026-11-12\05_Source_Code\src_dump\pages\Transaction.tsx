import React, { useState, useEffect } from "react";
import {
  ArrowUpRight,
  ArrowDownLeft,
  Search,
  DollarSign,
  TrendingUp,
  TrendingDown,
  Eye,
  RefreshCw,
  AlertCircle,
  CheckCircle,
  Clock,
  XCircle,
  FileText,
  X,
  Wallet,
  Sparkles,
} from "lucide-react";
import { API_CONFIG } from "../config/api";

interface Transaction {
  id: string;
  amount: number;
  status: "completed" | "pending" | "failed";
  date: string; // ISO date string
  time: string; // HH:MM format
  description: string;
  message?: string;
  method?: string;
  reference?: string;
  fee?: number;
  type?: string;
}

interface TransactionsAPIResponse {
  success: boolean;
  message: string;
  data: {
    user_id?: number;
    transactions: Array<{
      id?: string;
      amount: number | string;
      status?: string;
      created_at: string; // ISO date-time
      description?: string;
      message?: string;
      method?: string;
      reference?: string;
      fee?: number | string;
    }>;
  };
}

const Transaction: React.FC = () => {
  const [allTransactions, setAllTransactions] = useState<Transaction[]>([]); // Store all transactions
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [page, setPage] = useState(1);
  const perPage = 10; // Fixed per page
  const [lastPage, setLastPage] = useState(1);
  const [total, setTotal] = useState(0);

  // Filter states (currently used for client-side filtering)
  const [filter] = useState<
    "all" | "deposit" | "withdrawal" | "reward" | "referral" | "bonus"
  >("all");
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedTransaction, setSelectedTransaction] =
    useState<Transaction | null>(null);

  // Reset to page 1 when search term changes to ensure proper pagination
  useEffect(() => {
    // When a user starts typing a search we jump to page 1.
    // IMPORTANT: don't include `page` in the dependency array — including it would
    // immediately reset the page back to 1 whenever `page` changes while a search
    // term is active, preventing the user from navigating search result pages.
    if (searchTerm) {
      setPage(1);
    }
  }, [searchTerm]);

  useEffect(() => {
    const fetchTransactions = async () => {
      try {
        setLoading(true);
        setError(null);

        const token = localStorage.getItem("access_token");
        if (!token) {
          throw new Error("Authentication required. Please log in.");
        }

        const API_BASE_URL = API_CONFIG.BASE_URL;
        // API doesn't support pagination, so we fetch all transactions
        const url = `${API_BASE_URL}/user/transactions?page=1&per_page=10`;
        const response = await fetch(url, {
          method: "GET",
          headers: {
            Authorization: `Bearer ${token}`,
            Accept: "application/json",
          },
        });

        if (!response.ok) {
          throw new Error(`HTTP ${response.status}: ${response.statusText}`);
        }

        const data: TransactionsAPIResponse = await response.json();

        if (!data.success || !Array.isArray(data.data.transactions)) {
          throw new Error("Invalid API response format");
        }

        // Map API data to our Transaction type
        const mappedTransactions = data.data.transactions.map((item, index) => {
          const createdAt = new Date(item.created_at);

          const description = (
            item.description ??
            item.message ??
            ""
          ).toString();
          const message = (item.message ?? "").toString();

          const amountRaw: any = item.amount;
          const amountNum =
            typeof amountRaw === "number" ? amountRaw : parseFloat(amountRaw);

          const feeRaw: any = item.fee;
          const feeNum =
            feeRaw == null
              ? undefined
              : typeof feeRaw === "number"
                ? feeRaw
                : parseFloat(feeRaw);

          // Infer type from description since API doesn't always provide it
          const inferredType = ((item as any).type ??
            (description.toLowerCase().includes("referral")
              ? "referral"
              : description.toLowerCase().includes("bonus")
                ? "bonus"
                : description.toLowerCase().includes("withdraw")
                  ? "withdrawal"
                  : description.toLowerCase().includes("deposit")
                    ? "deposit"
                    : description.toLowerCase().includes("ad earning")
                      ? "reward"
                      : "reward")) as "deposit" | "withdrawal" | "reward" | "referral" | "bonus";

          // Infer status from amount (negative = withdrawal/pending, positive = completed)
          // Or default to completed for positive amounts
          const normalizedStatus: "completed" | "pending" | "failed" =
            (item.status === "completed" || item.status === "pending" || item.status === "failed")
              ? item.status
              : (amountNum < 0 ? "pending" : "completed");

          return {
            id: item.id || `txn-${index}-${createdAt.getTime()}`,
            type: inferredType,
            amount: Number.isFinite(amountNum) ? amountNum : 0,
            status: normalizedStatus,
            date: `${createdAt.getFullYear()}-${String(createdAt.getMonth() + 1).padStart(2, "0")}-${String(createdAt.getDate()).padStart(2, "0")}`, // YYYY-MM-DD
            time: createdAt.toLocaleTimeString([], {
              hour: "2-digit",
              minute: "2-digit",
            }), // HH:MM
            description,
            message,
            method: item.method,
            reference: item.reference,
            fee: feeNum,
          };
        });

        // Store all transactions
        setAllTransactions(mappedTransactions);

        // Calculate pagination info from total transactions
        const totalTransactions = mappedTransactions.length;
        const calculatedLastPage = Math.ceil(totalTransactions / perPage);

        setTotal(totalTransactions);
        setLastPage(calculatedLastPage);

        // Log for debugging
        console.log(`Fetched ${totalTransactions} transactions, Total Pages: ${calculatedLastPage}`);
      } catch (err: any) {
        setError(err.message || "Failed to load transactions");
      } finally {
        setLoading(false);
      }
    };

    fetchTransactions();
  }, []); // Fetch once on mount, pagination is client-side

  const getTransactionIcon = (type: string | undefined) => {
    if (!type) return <DollarSign className="w-4 h-4 sm:w-5 sm:h-5 text-gray-600" />;
    switch (type) {
      case "deposit":
        return (
          <ArrowDownLeft className="w-4 h-4 sm:w-5 sm:h-5 text-green-600" />
        );
      case "withdrawal":
        return <ArrowUpRight className="w-4 h-4 sm:w-5 sm:h-5 text-red-600" />;
      case "reward":
        return <TrendingUp className="w-4 h-4 sm:w-5 sm:h-5 text-purple-600" />;
      case "referral":
        return <TrendingUp className="w-4 h-4 sm:w-5 sm:h-5 text-sky-600" />;
      case "bonus":
        return <TrendingUp className="w-4 h-4 sm:w-5 sm:h-5 text-amber-600" />;
      default:
        return <DollarSign className="w-4 h-4 sm:w-5 sm:h-5 text-gray-600" />;
    }
  };

  const getStatusDisplay = (status: string) => {
    const normalizedStatus = (status || "").toLowerCase();
    switch (normalizedStatus) {
      case "completed":
        return {
          icon: CheckCircle,
          bgColor: "bg-emerald-100",
          textColor: "text-emerald-700",
          borderColor: "border-emerald-300",
          iconColor: "text-emerald-600",
        };
      case "pending":
        return {
          icon: Clock,
          bgColor: "bg-amber-100",
          textColor: "text-amber-700",
          borderColor: "border-amber-300",
          iconColor: "text-amber-600",
        };
      case "failed":
        return {
          icon: XCircle,
          bgColor: "bg-red-100",
          textColor: "text-red-700",
          borderColor: "border-red-300",
          iconColor: "text-red-600",
        };
      default:
        return {
          icon: Clock,
          bgColor: "bg-gray-100",
          textColor: "text-gray-700",
          borderColor: "border-gray-300",
          iconColor: "text-gray-600",
        };
    }
  };



  const formatDescription = (text?: string) =>
    (text ?? "").replace(
      /Daily ad earning from multiple cycles/gi,
      "Ad Watching Earning"
    );

  // Return highlight text like: "Earn 310 PKR By Watching Ad"
  const getHighlightText = (txn?: Transaction | null) => {
    const raw = (txn?.message ?? txn?.description ?? "").toString();
    const text = raw.replace(/\s+/g, " ").trim();

    // Prefer strict PKR extraction when available
    const pkrMatch = text.match(/earn\s*(\d+(?:\.\d+)?)\s*pkr\b/i);
    if (pkrMatch?.[1]) {
      const amount = pkrMatch[1];
      return `Earn ${amount} PKR By Watching Ad`;
    }

    // Fallback: any "earn <number>" gets shown as-is
    const earnMatch = text.match(/\bearn\s*\d+\b.*$/i);
    if (earnMatch?.[0]) return earnMatch[0];

    return null;
  };

  // Apply client-side filtering for display
  const filteredTransactions = allTransactions.filter((transaction) => {
    const matchesType = filter === "all" || transaction.type === filter;
    // Search across all transaction fields from API
    const searchFields = [
      transaction.description,
      transaction.message,
      transaction.method,
      transaction.reference,
      transaction.type,
      transaction.status,
      transaction.id,
      transaction.date,
      transaction.time
    ].filter(Boolean).join(' ').toLowerCase();

    const matchesSearch = searchTerm === "" || searchFields.includes(searchTerm.toLowerCase());
    return matchesType && matchesSearch;
  });

  // Calculate pagination for filtered results
  const filteredCount = filteredTransactions.length;
  const filteredLastPage = Math.ceil(filteredCount / perPage);

  // Get transactions for current page (client-side pagination)
  const startIndex = (page - 1) * perPage;
  const endIndex = startIndex + perPage;
  const displayedTransactions = filteredTransactions.slice(startIndex, endIndex);

  // Update pagination based on filtered results
  useEffect(() => {
    setLastPage(filteredLastPage);
    setTotal(filteredCount);
    // Reset to page 1 if current page exceeds available pages
    if (page > filteredLastPage && filteredLastPage > 0) {
      setPage(1);
    }
  }, [filteredLastPage, filteredCount, page]);



  // Get search label based on search term
  const getSearchLabel = () => {
    const search = searchTerm.toLowerCase().trim();

    if (!search) return 'Total Income';

    if (search.includes('reward')) return 'Total Rewards';
    if (search.includes('refund')) return 'Total Refunds';
    if (search.includes('ad')) return 'Total Ad Earnings';
    if (search.includes('referral') || search.includes('reffral')) return 'Total Referral Income';
    if (search.includes('withdrawal')) return 'Total Withdrawals';

    return 'Total Income';
  };

  // Calculate total based on filtered transactions (search results)
  const calculateTotalAmount = () => {
    const search = searchTerm.toLowerCase().trim();

    // If no search term, return sum of all positive amounts
    if (!search) {
      return allTransactions
        .filter(txn => txn.amount > 0)
        .reduce((sum, txn) => sum + txn.amount, 0);
    }

    // For generic search terms (like 'a', 'email', 'refunds', etc.)
    // Calculate total from the already filtered transactions
    // This includes all matching records regardless of type
    return filteredTransactions
      .reduce((sum, txn) => sum + Math.abs(txn.amount), 0);
  };

  const totalIncome = calculateTotalAmount();


  const totalOutgoing = allTransactions
    .filter((t) => t.amount < 0)
    .reduce((sum, t) => sum + Math.abs(t.amount), 0);

  const pendingTransactions = allTransactions.filter(
    (t) => t.status === "pending"
  ).length;

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-sky-50 to-indigo-50">
        <div className="max-w-7xl mx-auto space-y-6 p-4 sm:p-6 lg:p-8">
          {/* Header Skeleton */}
          <div>
            <div className="h-6 bg-gray-200 rounded-full w-40 mb-3"></div>
            <div className="h-10 bg-gray-200 rounded w-64 mb-2"></div>
            <div className="h-4 bg-gray-200 rounded w-96"></div>
          </div>

          {/* Summary Cards Skeleton */}
          <div className="grid grid-cols-2 gap-4">
            {[...Array(4)].map((_, i) => (
              <div
                key={i}
                className="bg-white rounded-xl shadow-sm border border-gray-200 p-5"
              >
                <div className="flex items-center justify-between">
                  <div className="flex-1">
                    <div className="h-3 bg-gray-200 rounded w-20 mb-2"></div>
                    <div className="h-8 bg-gray-200 rounded w-32"></div>
                  </div>
                  <div className="w-10 h-10 bg-gray-200 rounded-lg"></div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-sky-50 to-indigo-50">
        <div className="max-w-7xl mx-auto space-y-6 p-4 sm:p-6 lg:p-8">
          {/* Header */}
          <div className="mb-8">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-sky-100 text-sky-700 border border-sky-200 text-xs sm:text-sm font-semibold mb-3">
              <FileText className="w-4 h-4" />
              <span>Transaction History</span>
            </div>
            <h1 className="text-2xl sm:text-3xl lg:text-4xl font-extrabold bg-gradient-to-r from-sky-600 to-sky-700 bg-clip-text text-transparent tracking-tight">
              Transaction History
            </h1>
            <p className="text-gray-600 mt-2 text-sm sm:text-base">
              View and manage all your financial transactions
            </p>
          </div>

          {/* Error Message */}
          <div className="bg-red-50 border-l-4 border-red-500 rounded-lg p-5 shadow-sm">
            <div className="flex items-start space-x-3">
              <AlertCircle className="w-5 h-5 text-red-600 mt-0.5 flex-shrink-0" />
              <div className="flex-1">
                <h3 className="text-red-800 font-semibold mb-1">Error Loading Transactions</h3>
                <p className="text-red-700 text-sm">{error}</p>
                <button
                  onClick={() => window.location.reload()}
                  className="mt-4 px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors font-medium"
                >
                  Retry
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-sky-50 to-indigo-50">
      <div className="max-w-7xl mx-auto space-y-6 p-4 sm:p-6 lg:p-8">
        {/* Modern Header */}
        <div className="mb-8">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-sky-100 text-sky-700 border border-sky-200 text-xs sm:text-sm font-semibold mb-3">
            <FileText className="w-4 h-4" />
            <span>Transaction History</span>
          </div>
          <h1 className="text-2xl sm:text-3xl lg:text-4xl font-extrabold bg-gradient-to-r from-sky-600 to-sky-700 bg-clip-text text-transparent tracking-tight">
            Transaction History
          </h1>
          <p className="text-gray-600 mt-2 text-sm sm:text-base max-w-2xl">
            View and manage all your financial transactions in one place
          </p>
        </div>

        {/* Summary Cards */}
        <div className="grid grid-cols-2 gap-4">
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-5 hover:shadow-md transition-shadow">
            <div className="flex items-center justify-between">
              <div className="flex-1">
                <p className="text-xs sm:text-sm font-medium text-gray-600 mb-1">
                  {getSearchLabel()}
                </p>
                <p className="text-xl sm:text-2xl font-bold text-green-600">
                  ${totalIncome.toFixed(2)}
                </p>
              </div>
              <div className="w-12 h-12 rounded-lg bg-green-100 flex items-center justify-center">
                <TrendingUp className="w-6 h-6 text-green-600" />
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-5 hover:shadow-md transition-shadow">
            <div className="flex items-center justify-between">
              <div className="flex-1">
                <p className="text-xs sm:text-sm font-medium text-gray-600 mb-1">
                  Total Outgoing
                </p>
                <p className="text-xl sm:text-2xl font-bold text-red-600">
                  ${totalOutgoing.toFixed(2)}
                </p>
              </div>
              <div className="w-12 h-12 rounded-lg bg-red-100 flex items-center justify-center">
                <TrendingDown className="w-6 h-6 text-red-600" />
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-5 hover:shadow-md transition-shadow">
            <div className="flex items-center justify-between">
              <div className="flex-1">
                <p className="text-xs sm:text-sm font-medium text-gray-600 mb-1">
                  Net Balance
                </p>
                <p
                  className={`text-xl sm:text-2xl font-bold ${totalIncome - totalOutgoing >= 0
                      ? "text-green-600"
                      : "text-red-600"
                    }`}
                >
                  ${(totalIncome - totalOutgoing).toFixed(2)}
                </p>
              </div>
              <div className="w-12 h-12 rounded-lg bg-sky-100 flex items-center justify-center">
                <DollarSign className="w-6 h-6 text-sky-600" />
              </div>
            </div>
          </div>


          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-5 hover:shadow-md transition-shadow">
            <div className="flex items-center justify-between">
              <div className="flex-1">
                <p className="text-xs sm:text-sm font-medium text-gray-600 mb-1">
                Pending
                </p>
                <p
                  className={`text-xl sm:text-2xl font-bold ${totalIncome - totalOutgoing >= 0
                      ? "text-green-600"
                      : "text-red-600"
                    }`}
                >
                 0
                </p>
              </div>
              <div className="w-12 h-12 rounded-lg bg-sky-100 flex items-center justify-center">
                <RefreshCw className="w-6 h-6 text-sky-600" />
              </div>
            </div>
          </div>
        </div>

        {/* Filters and Search */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-5 space-y-4">
          {/* Search Bar */}
          <div className="relative">
            <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input
              type="text"
              placeholder="Search transactions by description, ID, method, reference, type, status, date, or time..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-12 pr-4 py-3 border-2 border-gray-200 rounded-xl focus:ring-2 focus:ring-sky-500 focus:border-sky-500 transition-all text-sm sm:text-base"
            />
          </div>
        </div>

        {/* Transactions List - Mobile Cards */}
        <div className="bg-white rounded-xl shadow-lg border border-gray-200 overflow-hidden">
          <div className="p-5 sm:p-6 border-b border-gray-200 bg-gradient-to-r from-gray-50 to-white">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-purple-500 to-purple-600 flex items-center justify-center">
                <Wallet className="w-5 h-5 text-white" />
              </div>
              <h2 className="text-xl sm:text-2xl font-bold text-gray-900">
                All Transactions
              </h2>
            </div>
          </div>

          <div className="sm:hidden">
            {/* Mobile View - Cards */}
            <div className="divide-y divide-gray-200">
              {displayedTransactions.map((transaction) => (
                <div key={transaction.id} className="p-4 hover:bg-gray-50 transition-colors">
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex items-center space-x-3 flex-1 min-w-0">
                      <div className="flex-shrink-0">
                        {getTransactionIcon(transaction.type || "reward")}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="text-sm font-semibold text-gray-900 truncate">
                          {/* {transaction.id} */}
                        </div>
                        <div className="text-xs text-gray-500 capitalize mt-0.5">
                          {transaction.type}
                        </div>
                      </div>
                    </div>
                    <div
                      className={`text-base font-bold flex-shrink-0 ml-2 ${transaction.amount >= 0
                          ? "text-green-600"
                          : "text-red-600"
                        }`}
                    >
                      {transaction.amount >= 0 ? "+" : ""}$
                      {Math.abs(transaction.amount).toFixed(2)}
                    </div>
                  </div>

                  <div className="text-xs text-gray-600 mb-3 line-clamp-2">
                    {transaction.description.replace(/Daily ad earning from multiple cycles/gi, "Ad Watching Earning")}
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <span className="text-xs text-gray-500">
                        {transaction.date}
                      </span>
                    </div>
                    <button
                      onClick={() => setSelectedTransaction(transaction)}
                      className="text-sky-600 hover:text-sky-800 text-xs font-medium flex items-center gap-1"
                    >
                      <Eye className="w-3.5 h-3.5" />
                      <span>View</span>
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Desktop View - Table */}
          <div className="hidden sm:block overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gradient-to-r from-gray-50 to-gray-100">
                <tr>
                  <th className="px-6 py-4 text-left text-xs font-bold text-gray-700 uppercase tracking-wider">
                    Transaction
                  </th>
                  <th className="px-6 py-4 text-left text-xs font-bold text-gray-700 uppercase tracking-wider">
                    Amount
                  </th>
                  <th className="px-6 py-4 text-left text-xs font-bold text-gray-700 uppercase tracking-wider">
                    Date & Time
                  </th>
                  <th className="px-6 py-4 text-left text-xs font-bold text-gray-700 uppercase tracking-wider">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {displayedTransactions.map((transaction) => (
                  <tr key={transaction.id} className="hover:bg-sky-50/50 transition-colors">
                    <td className="px-6 py-4">
                      <div className="flex items-center">
                        <div className="flex-shrink-0 mr-3">
                          {getTransactionIcon(transaction.type || "reward")}
                        </div>
                        <div className="min-w-0">
                          <div className="text-sm font-semibold text-gray-900 truncate">
                            {/* {transaction.id} */}
                          </div>
                          <div className="text-sm text-gray-500 truncate max-w-md">
                            {transaction.description.replace(/Daily ad earning from multiple cycles/gi, "Ad Watching Earning")}
                          </div>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div
                        className={`text-base font-bold ${transaction.amount >= 0
                            ? "text-green-600"
                            : "text-red-600"
                          }`}
                      >
                        {transaction.amount >= 0 ? "+" : ""}$
                        {Math.abs(transaction.amount).toFixed(2)}
                      </div>
                      {transaction.fee && (
                        <div className="text-xs text-gray-500 mt-1">
                          Fee: ${transaction.fee.toFixed(2)}
                        </div>
                      )}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm font-medium text-gray-900">
                        {transaction.date}
                      </div>
                      <div className="text-sm text-gray-500">
                        {transaction.time}
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <button
                        onClick={() => setSelectedTransaction(transaction)}
                        className="px-3 py-1.5 text-xs font-medium text-sky-600 hover:text-sky-800 hover:bg-sky-50 rounded-lg border border-sky-200 transition-all flex items-center gap-1.5"
                      >
                        <Eye className="w-3.5 h-3.5" />
                        <span>View</span>
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {displayedTransactions.length === 0 && (
            <div className="text-center py-12 sm:py-16">
              <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <DollarSign className="w-8 h-8 text-gray-400" />
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">
                No transactions found
              </h3>
              <p className="text-gray-600 text-sm">
                Try adjusting your search terms or check back later.
              </p>
            </div>
          )}

          {/* Pagination - Only show if there are transactions and more than one page */}
          {total > 0 && lastPage > 1 && (
            <div className="flex flex-col sm:flex-row items-center justify-between gap-3 p-4 sm:p-6 border-t border-gray-200 bg-gradient-to-r from-gray-50 to-white">
              <div className="text-sm font-medium text-gray-700 bg-white px-4 py-2 rounded-lg border border-gray-200">
                {(() => {
                  const start = total === 0 ? 0 : (page - 1) * perPage + 1;
                  const end = Math.min(page * perPage, total);
                  return `Showing ${start}-${end} of ${total}`;
                })()}
              </div>
              <div className="flex items-center gap-2">
                <select
                  value={10}
                  disabled
                  className="border-2 border-gray-200 rounded-lg px-3 py-1.5 text-sm bg-gray-50 text-gray-500 cursor-not-allowed font-medium"
                >
                  <option value={10}>10 / page</option>
                </select>
                <div className="flex items-center gap-1">
                  <button
                    disabled={page === 1}
                    onClick={() => setPage(1)}
                    className={`px-3 py-1.5 text-sm font-medium rounded-lg border-2 transition-all ${page === 1
                        ? "text-gray-400 border-gray-200 cursor-not-allowed"
                        : "text-gray-700 border-gray-300 hover:bg-gray-50 hover:border-gray-400"
                      }`}
                  >
                    First
                  </button>
                  <button
                    disabled={page === 1}
                    onClick={() => setPage((p) => Math.max(1, p - 1))}
                    className={`px-3 py-1.5 text-sm font-medium rounded-lg border-2 transition-all ${page === 1
                        ? "text-gray-400 border-gray-200 cursor-not-allowed"
                        : "text-gray-700 border-gray-300 hover:bg-gray-50 hover:border-gray-400"
                      }`}
                  >
                    ← Prev
                  </button>
                  {Array.from({ length: Math.min(5, lastPage) }).map((_, idx) => {
                    const windowStart = Math.max(1, Math.min(page - 2, lastPage - 4));
                    const pageNum = windowStart + idx;
                    if (pageNum > lastPage) return null;
                    const isActive = pageNum === page;
                    return (
                      <button
                        key={pageNum}
                        onClick={() => setPage(pageNum)}
                        className={`px-4 py-1.5 text-sm font-semibold rounded-lg border-2 transition-all ${isActive
                            ? "bg-gradient-to-r from-sky-600 to-sky-700 text-white border-sky-600 shadow-md"
                            : "text-gray-700 border-gray-300 hover:bg-gray-50 hover:border-gray-400"
                          }`}
                      >
                        {pageNum}
                      </button>
                    );
                  })}
                  <button
                    disabled={page === lastPage || lastPage === 0}
                    onClick={() => setPage((p) => Math.min(lastPage, p + 1))}
                    className={`px-3 py-1.5 text-sm font-medium rounded-lg border-2 transition-all ${page === lastPage || lastPage === 0
                        ? "text-gray-400 border-gray-200 cursor-not-allowed"
                        : "text-gray-700 border-gray-300 hover:bg-gray-50 hover:border-gray-400"
                      }`}
                  >
                    Next →
                  </button>
                  <button
                    disabled={page === lastPage || lastPage === 0}
                    onClick={() => setPage(lastPage)}
                    className={`px-3 py-1.5 text-sm font-medium rounded-lg border-2 transition-all ${page === lastPage || lastPage === 0
                        ? "text-gray-400 border-gray-200 cursor-not-allowed"
                        : "text-gray-700 border-gray-300 hover:bg-gray-50 hover:border-gray-400"
                      }`}
                  >
                    Last
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Transaction Detail Modal */}
        {selectedTransaction && (
          <div className="fixed inset-0 bg-transparent flex items-center justify-center p-3 sm:p-4 z-50">
            <div className="bg-white rounded-2xl max-w-md w-full shadow-2xl max-h-[90vh] overflow-y-auto">
              {/* Modal Header */}
              <div className="sticky top-0 bg-white border-b border-gray-100 px-4 py-3 flex items-center justify-between rounded-t-2xl">
                <h3 className="text-base font-bold text-gray-900">
                  Transaction Details
                </h3>
                <button
                  onClick={() => setSelectedTransaction(null)}
                  className="w-7 h-7 rounded-lg hover:bg-gray-100 flex items-center justify-center text-gray-400 hover:text-gray-600 transition-colors"
                >
                  <X className="wz-4 h-4" />
                </button>
              </div>

              <div className="p-4">
                {/* Top Row: Type + Status */}
                <div className="flex items-center justify-between gap-3">
                  <div className="flex items-center gap-2 text-sm text-gray-700 min-w-0">
                    {getTransactionIcon(selectedTransaction.type || "reward")}
                    <span className="capitalize font-semibold truncate">
                      {selectedTransaction.type || "reward"}
                    </span>
                  </div>
                </div>

                {/* Highlight banner (Ad earning / Earn PKR) */}
                {(() => {
                  const highlight = getHighlightText(selectedTransaction);
                  if (!highlight) return null;
                  return (
                    <div className="mt-3 bg-red-600 text-white rounded-lg px-3 py-2 shadow-md">
                      <div className="flex items-center gap-2">
                        <Sparkles className="w-4 h-4 flex-shrink-0" />
                        <div className="text-sm font-bold leading-snug flex-1 min-w-0">
                          <span className="block break-words">{highlight}</span>
                        </div>
                        <span className="text-base leading-none flex-shrink-0">🥳</span>
                      </div>
                    </div>
                  );
                })()}

                {/* Details rows (match screenshot layout) */}
                <div className="mt-4 bg-gray-50 rounded-lg overflow-hidden border border-gray-200">
                  <div className="px-3 py-2 flex items-center justify-between gap-3 border-b border-gray-200 bg-white">
                    <span className="text-xs text-gray-500 font-medium">
                      Amount:
                    </span>
                    <span
                      className={`text-sm font-bold text-right ${selectedTransaction.amount >= 0
                          ? "text-green-600"
                          : "text-red-600"
                        }`}
                    >
                      {selectedTransaction.amount >= 0 ? "+" : ""}$
                      {Math.abs(selectedTransaction.amount).toFixed(2)}
                    </span>
                  </div>

                  <div className="px-3 py-2 flex items-center justify-between gap-3 border-b border-gray-200">
                    <span className="text-xs text-gray-500 font-medium">
                      Date:
                    </span>
                    <span className="text-xs text-gray-900 font-semibold text-right">
                      {selectedTransaction.date} {selectedTransaction.time}
                    </span>
                  </div>

                  <div className="px-3 py-2 flex items-start justify-between gap-3">
                    <span className="text-xs text-gray-500 font-medium pt-0.5">
                      Description:
                    </span>
                    <span className="text-xs text-gray-900 font-semibold text-right max-w-[70%] break-words">
                      {formatDescription(selectedTransaction.description)}
                    </span>
                  </div>
                </div>

                {/* Optional fields */}
                {(selectedTransaction.method ||
                  selectedTransaction.reference ||
                  selectedTransaction.fee) && (
                    <div className="mt-3 space-y-2">
                      {selectedTransaction.method && (
                        <div className="flex items-center justify-between gap-3">
                          <span className="text-xs text-gray-500 font-medium">
                            Method:
                          </span>
                          <span className="text-xs text-gray-900 font-semibold text-right">
                            {selectedTransaction.method}
                          </span>
                        </div>
                      )}

                      {selectedTransaction.reference && (
                        <div className="flex items-start justify-between gap-3">
                          <span className="text-xs text-gray-500 font-medium pt-0.5">
                            Reference:
                          </span>
                          <span className="text-xs text-gray-900 font-mono break-all text-right max-w-[70%]">
                            {selectedTransaction.reference}
                          </span>
                        </div>
                      )}

                      {selectedTransaction.fee != null && (
                        <div className="flex items-center justify-between gap-3">
                          <span className="text-xs text-gray-500 font-medium">
                            Fee:
                          </span>
                          <span className="text-xs text-gray-900 font-semibold text-right">
                            ${selectedTransaction.fee.toFixed(2)}
                          </span>
                        </div>
                      )}
                    </div>
                  )}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default Transaction;