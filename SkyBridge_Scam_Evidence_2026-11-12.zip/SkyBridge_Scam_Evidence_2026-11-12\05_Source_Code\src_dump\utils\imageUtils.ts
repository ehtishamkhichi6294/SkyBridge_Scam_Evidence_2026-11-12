import { API_CONFIG } from "../config/api";

/** Backend host (without /api suffix) — where /uploads/* files are served. */
export function getStorageBaseUrl(): string {
  return (API_CONFIG.BASE_URL || "").replace(/\/api\/?$/i, "").replace(/\/$/, "");
}

/**
 * Resolve profile/storage image URLs from the API to a URL the browser can load.
 * Rewrites localhost backend hosts to VITE_APP_URL and supports relative /storage paths.
 */
export function resolveProfilePictureUrl(
  url: string | undefined | null,
): string {
  if (!url || typeof url !== "string") return "";

  const trimmed = url.trim().replace(/\\\//g, "/");
  if (!trimmed) return "";

  const appBase = getStorageBaseUrl();

  if (trimmed.startsWith("http://") || trimmed.startsWith("https://")) {
    try {
      const parsed = new URL(trimmed);
      if (
        parsed.hostname === "localhost" ||
        parsed.hostname === "127.0.0.1"
      ) {
        return `${appBase}${parsed.pathname}${parsed.search}`;
      }
      return trimmed;
    } catch {
      return trimmed;
    }
  }

  const path = trimmed.startsWith("/") ? trimmed : `/${trimmed}`;
  return `${appBase}${path}`;
}

export function getAvatarFallbackUrl(name: string): string {
  return `https://ui-avatars.com/api/?name=${encodeURIComponent(
    name || "User",
  )}&background=0D8ABC&color=fff&size=256`;
}
