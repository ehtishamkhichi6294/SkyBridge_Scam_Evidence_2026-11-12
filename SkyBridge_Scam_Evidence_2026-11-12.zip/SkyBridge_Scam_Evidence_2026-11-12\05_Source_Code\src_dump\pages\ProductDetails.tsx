import React, { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { ShoppingBag, ArrowLeft, Play, Image as ImageIcon, Download } from "lucide-react";
// Image downloads disabled: thumbnail clicks now select the image instead of downloading
import { useCurrency } from "../contexts/CurrencyContext";
import { productService, type Product } from "../services";
import { parseEmojis } from "../utils/emojiUtils";

// Extended product type for display
type DisplayProduct = Product & {
  price: number;
  image?: string;
  earningPerSale?: number;
  inStock?: boolean;
};

const ProductDetails: React.FC = () => {
  const navigate = useNavigate();
  const { id } = useParams<{ id: string }>();
  const { formatCurrency } = useCurrency();
  const [product, setProduct] = useState<DisplayProduct | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [selectedImageIndex, setSelectedImageIndex] = useState<number>(0);

  const downloadVideo = () => {
    if (product?.video) {
      const link = document.createElement('a');
      link.href = product.video;
      link.download = `${product.name || 'product'}-video.mp4`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    }
  };

  useEffect(() => {
    const fetchProduct = async () => {
      if (!id) {
        setError("Product ID is missing");
        setLoading(false);
        return;
      }

      try {
        setLoading(true);
        setError(null);
        const response = await productService.getProductById(id);
        if (response.success && response.data) {
          const apiProduct = response.data;
          const priceNum = parseFloat(apiProduct.price || "0");
          const profitPercentage = parseFloat(apiProduct.user_profit_percentage || "0");
          const earningPerSale = (priceNum * profitPercentage) / 100;
          
          const originalPriceNum = (apiProduct as any).original_price
            ? parseFloat((apiProduct as any).original_price) || priceNum
            : priceNum;

          const mappedProduct = {
            ...apiProduct,
            image: apiProduct.images && apiProduct.images.length > 0 ? apiProduct.images[0] : undefined,
            price: priceNum,
            original_price: originalPriceNum,
            earningPerSale: earningPerSale,
            inStock: apiProduct.is_out_of_stock ? false : true,
          } as DisplayProduct;
          
          setProduct(mappedProduct);
          setSelectedImageIndex(0); // Reset to first image when product changes
        } else {
          setError("Product not found");
        }
      } catch (err: any) {
        setError(err.message || "Failed to load product details");
        console.error("Error fetching product:", err);
      } finally {
        setLoading(false);
      }
    };

    fetchProduct();
  }, [id]);

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-sky-50 to-indigo-50 flex items-center justify-center px-4">
        <div className="max-w-md w-full bg-white rounded-2xl shadow-sm border border-slate-200 p-6 text-center">
          <p className="text-sm text-gray-500 mb-4">Loading product details...</p>
        </div>
      </div>
    );
  }

  if (error || !product) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-sky-50 to-indigo-50 flex items-center justify-center px-4">
        <div className="max-w-md w-full bg-white rounded-2xl shadow-sm border border-slate-200 p-6 text-center">
          <p className="text-sm text-gray-500 mb-4">
            {error || "Product details are not available. Please go back to the store and open the product again."}
          </p>
          <button
            type="button"
            onClick={() => navigate("/ecommerce-store")}
            className="inline-flex items-center justify-center px-4 py-2 rounded-lg bg-sky-600 text-white text-sm font-semibold hover:bg-sky-700"
          >
            <ArrowLeft className="w-4 h-4 mr-2" /> Back to Store
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-sky-50 to-indigo-50">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <button
          type="button"
          onClick={() => navigate(-1)}
          className="inline-flex items-center text-sm text-sky-700 hover:text-sky-800 mb-4"
        >
          <ArrowLeft className="w-4 h-4 mr-1" /> Back to products
        </button>

        <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
          {/* Main Image Display - taller area, show full image without cropping */}
          <div className="relative w-full h-80 sm:h-96 bg-gradient-to-br from-sky-100 via-slate-100 to-indigo-100 flex items-center justify-center text-sky-500 overflow-hidden group">
            {product.inStock === false && (
              <span className="absolute top-3 right-3 z-10 px-3 py-1.5 bg-red-600 text-white text-xs sm:text-sm font-bold rounded-full shadow">
                Out of Stock
              </span>
            )}
            {product.images && product.images.length > 0 ? (
              <>
                <img 
                  src={product.images[selectedImageIndex]} 
                  alt={`${product.name} - Image ${selectedImageIndex + 1}`}
                  className="max-w-full max-h-full object-contain"
                  onError={(e) => {
                    const target = e.target as HTMLImageElement;
                    target.style.display = 'none';
                    target.parentElement?.classList.add('flex', 'items-center', 'justify-center');
                  }}
                />
              </>
            ) : (
              <ShoppingBag className="w-16 h-16" />
            )}
          </div>

          {/* Image Thumbnail Gallery */}
          {product.images && product.images.length > 1 && (
            <div className="px-6 py-4 border-t border-slate-200 bg-slate-50">
              <div className="flex items-center gap-2 mb-3">
                <ImageIcon className="w-4 h-4 text-sky-600" />
                <h3 className="text-sm font-semibold text-gray-700">Product Images ({product.images.length})</h3>
              </div>
              <div className="grid grid-cols-4 sm:grid-cols-6 gap-3">
                {product.images.map((imageUrl, index) => (
                  <div className="relative group" key={index}>
                    <div
                      className={`relative w-full h-full aspect-square rounded-lg overflow-hidden border-2 transition-all ${
                        selectedImageIndex === index
                          ? 'border-sky-500 ring-2 ring-sky-200'
                          : 'border-slate-200 hover:border-sky-300'
                      }`}
                      onClick={(e) => {
                        e.preventDefault();
                        e.stopPropagation();
                        setSelectedImageIndex(index);
                      }}
                    >
                      <img
                        src={imageUrl}
                        alt={`${product.name} thumbnail ${index + 1}`}
                        className="w-full h-full object-cover cursor-pointer"
                        onError={(e) => {
                          const target = e.target as HTMLImageElement;
                          target.src = '';
                          target.parentElement?.classList.add('bg-slate-200');
                        }}
                        onClick={(e) => {
                          e.preventDefault();
                          e.stopPropagation();
                          setSelectedImageIndex(index);
                        }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Video Display */}
          {product.video && (
            <div className="px-6 py-4 border-t border-slate-200 bg-slate-50">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  <Play className="w-4 h-4 text-sky-600" />
                  <h3 className="text-sm font-semibold text-gray-700">Product Video</h3>
                </div>
                <button
                  onClick={downloadVideo}
                  className="flex items-center gap-2 px-3 py-1.5 text-sm font-medium text-white bg-sky-600 hover:bg-sky-700 rounded-md transition-colors"
                >
                  <Download className="w-4 h-4" />
                  Download Video
                </button>
              </div>
              <div className="aspect-video bg-black rounded-lg overflow-hidden">
                <video
                  src={product.video}
                  controls
                  controlsList="nofullscreen noremoteplayback"
                  disablePictureInPicture={true}
                  disableRemotePlayback={true}
                  className="w-full h-full"
                  poster={product.images && product.images.length > 0 ? product.images[0] : undefined}
                >
                  Your browser does not support the video tag.
                </video>
              </div>
            </div>
          )}
          <div className="p-6 sm:p-8">
            <h1 className="text-2xl sm:text-3xl font-extrabold text-gray-900 mb-2">
              {product.name}
            </h1>
            <p className="text-sm sm:text-base text-gray-600 mb-4 whitespace-pre-line leading-relaxed">
              {parseEmojis(product.description)}
            </p>

            <div className="flex flex-wrap items-center gap-4 mb-6">
              <div>
                {(() => {
                  // Backend: price = discounted price, original_price = base price
                  const originalPrice = (product as any).original_price
                    ? Number((product as any).original_price) || Number(product.price) || 0
                    : Number(product.price) || 0;
                  const discountedPrice = Number(product.price) || originalPrice;

                  // Prefer explicit discount_percentage; if missing, derive from original/discounted
                  let rawDiscount: number | string | undefined = (product as any).discount_percentage;
                  if (
                    rawDiscount == null &&
                    originalPrice &&
                    discountedPrice &&
                    originalPrice > discountedPrice
                  ) {
                    rawDiscount = ((originalPrice - discountedPrice) / originalPrice) * 100;
                  } else if (rawDiscount == null) {
                    rawDiscount = 0;
                  }

                  const discountPercent =
                    typeof rawDiscount === "string"
                      ? parseFloat(rawDiscount) || 0
                      : Number(rawDiscount) || 0;
                  const hasDiscount =
                    !!discountPercent && discountPercent > 0 && discountedPrice < originalPrice;

                  if (!hasDiscount) {
                    return (
                      <>
                        <p className="text-xs text-gray-500">Price</p>
                        <p className="text-2xl font-extrabold text-sky-700">
                          {formatCurrency(originalPrice)}
                        </p>
                      </>
                    );
                  }

                  return (
                    <>
                      {/* Original price (struck-through) */}
                      <p className="text-xs text-gray-500 line-through">
                        {formatCurrency(originalPrice)}
                      </p>

                      {/* Discount badge */}
                      <span className="inline-flex items-center px-2 py-0.5 rounded-full bg-green-50 text-green-700 text-xs font-semibold border border-green-200 mt-1 mb-1 w-fit">
                        {discountPercent.toFixed(2)}% OFF
                      </span>

                      {/* Discounted price */}
                      <p className="text-xs text-gray-500">Discounted Price</p>
                      <p className="text-2xl font-extrabold text-sky-700">
                        {formatCurrency(discountedPrice)}
                      </p>
                    </>
                  );
                })()}
              </div>
              <span
                className={`px-3 py-1 rounded-full text-xs font-semibold border ${
                  (product.inStock !== false)
                    ? "bg-emerald-50 text-emerald-700 border-emerald-200"
                    : "bg-red-50 text-red-700 border-red-200"
                }`}
              >
                {(product.inStock !== false) ? "In Stock" : "Out of Stock"}
              </span>
            </div>

            {product.earningPerSale && (
              <div className="mb-6 rounded-xl bg-emerald-50 border border-emerald-200 p-4">
                <p className="text-sm font-semibold text-emerald-900">
                  💰 Earning Opportunity
                </p>
                <p className="text-sm text-emerald-700 mt-1">
                  If you sell this product, you will earn <span className="font-bold">{formatCurrency(product.earningPerSale)}</span>
                </p>
              </div>
            )}

            {!product.inStock && (
              <div className="rounded-xl bg-red-50 border border-red-200 p-4 text-sm text-red-700 font-semibold">
                This product is currently out of stock and cannot be purchased.
              </div>
            )}

            {product.inStock && (
              <div className="rounded-xl bg-slate-50 border border-slate-200 p-4 text-sm text-gray-600">
                <p>
                  To buy this product, go back to the store and click the
                  <span className="font-semibold"> Request Purchase</span> button on the
                  product card. You will need to pay delivery charges first and send your
                  payment screenshot along with your address details.
                </p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProductDetails;
