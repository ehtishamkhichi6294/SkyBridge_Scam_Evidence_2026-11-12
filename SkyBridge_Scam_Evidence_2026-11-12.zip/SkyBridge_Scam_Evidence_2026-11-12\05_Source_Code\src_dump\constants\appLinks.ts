/** Shared external links used across the app */

export const WHATSAPP_CHANNEL_URL =
  "https://whatsapp.com/channel/0029VbC8jz9It5rv89vDrx16";

/**
 * YouTube tutorial — set VIDEO_TUTORIAL_YOUTUBE_ID to a real video ID to embed in-app.
 * Until then the modal opens the SkyBridge YouTube channel.
 */
export const VIDEO_TUTORIAL_YOUTUBE_ID = "TmHmVUHVxGs";
export const VIDEO_TUTORIAL_CHANNEL_URL =
  "https://youtube.com/@sky.bridgeinternational";
export const VIDEO_TUTORIAL_EMBED_URL = VIDEO_TUTORIAL_YOUTUBE_ID
  ? `https://www.youtube.com/embed/${VIDEO_TUTORIAL_YOUTUBE_ID}?autoplay=1&rel=0`
  : "";
/** Opened in a new tab when the user presses "Watch Tutorial" */
export const VIDEO_TUTORIAL_WATCH_URL = VIDEO_TUTORIAL_YOUTUBE_ID
  ? `https://www.youtube.com/watch?v=${VIDEO_TUTORIAL_YOUTUBE_ID}`
  : VIDEO_TUTORIAL_CHANNEL_URL;
