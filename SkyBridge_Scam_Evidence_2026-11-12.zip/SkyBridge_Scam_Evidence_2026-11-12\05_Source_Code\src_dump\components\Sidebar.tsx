import React, { useEffect } from "react";
import { NavLink, useNavigate } from "react-router-dom";
import {
  LayoutDashboard,
  Users,
  Wallet,
  Gift,
  Award,
  DollarSign,
  X,
  MessageCircle,
  BookOpen,
  UserCheck,
  Store,
  User,
  Receipt,
  UserPlus,
  Crown,
  KeyRound,
  ClipboardList,
  CreditCard,
  LogOut,
  Info,
  Trophy,
} from "lucide-react";
import { useAuth } from "../contexts/AuthContext";
interface SidebarProps {
  isOpen: boolean;
  onClose: () => void;
}

const Sidebar: React.FC<SidebarProps> = ({ isOpen, onClose }) => {
  const navigate = useNavigate();
  const { logout } = useAuth();

  const handleLogout = () => {
    onClose();
    logout();
    navigate("/login");
  };

  const navItems = [
    { path: "/dashboard", icon: LayoutDashboard, label: "Dashboard" },
    { path: "/profile-info", icon: User, label: "Profile Info" },
    {
      path: "/change-account-details",
      icon: CreditCard,
      label: "Account Details",
    },
    { path: "/upgrade-plan", icon: Crown, label: "Upgrade Plan" },
    { path: "/buy-pin", icon: KeyRound, label: "Buy PIN" },
    { path: "/leaderboard", icon: Users, label: "Leader Board" },
    {
      path: "/affiliate-leaderboard",
      icon: UserPlus,
      label: "Affiliate Leaderboard",
    },
    { path: "/competition", icon: Trophy, label: "Competition & Trips" },
    { path: "/withdraw", icon: Wallet, label: "Withdraw" },
    { path: "/transactions", icon: Receipt, label: "Transactions" },
    { path: "/affiliate-course", icon: BookOpen, label: "Affiliate Course" },
    { path: "/my-team", icon: UserCheck, label: "My Team" },
    { path: "/ecommerce-store", icon: Store, label: "E-Commerce Store" },
    { path: "/ads-earning", icon: DollarSign, label: "Ads Earning" },
    { path: "/rewards", icon: Award, label: "Rewards List" },
    { path: "/bonus", icon: Gift, label: "Bonus" },
    {
      path: "/sky-bridge-community",
      icon: MessageCircle,
      label: "SkyBridge Community",
    },
    { path: "/pin-requests", icon: ClipboardList, label: "PIN Requests" },
    { path: "/my-pins", icon: KeyRound, label: "My PINs" },
    {
      path: "/pin/create-account",
      icon: UserPlus,
      label: "Create Account with PIN",
    },
    { path: "/about-us", icon: Info, label: "About Us" },
  ];

  const handleItemClick = () => {
    onClose();
  };

  // Mobile drawer only (below lg): lock body scroll so the menu list can scroll independently
  useEffect(() => {
    if (!isOpen) return;
    const mq = window.matchMedia("(max-width: 1023px)");
    const apply = () => {
      if (mq.matches) document.body.style.overflow = "hidden";
      else document.body.style.overflow = "";
    };
    apply();
    mq.addEventListener("change", apply);
    return () => {
      mq.removeEventListener("change", apply);
      document.body.style.overflow = "";
    };
  }, [isOpen]);

  return (
    <>
      {/* Mobile overlay */}
      {isOpen && (
        <div
          className="fixed inset-0 bg-black bg-opacity-50 z-40 lg:hidden"
          onClick={onClose}
        />
      )}

      {/* Sidebar: full viewport height; nav list scrolls; footer stays pinned */}
      <aside
        className={`
        fixed top-0 left-0 z-50 flex w-72 sm:w-80 flex-col border-r border-sky-200/50 bg-white/95 shadow-sky-lg backdrop-blur-md
        transition-transform duration-300 ease-in-out
        h-[100dvh] max-h-screen min-h-0
        ${isOpen ? "translate-x-0" : "-translate-x-full"}
        lg:static lg:z-auto lg:h-auto lg:min-h-screen lg:max-h-none lg:translate-x-0 lg:shrink-0
      `}
      >
        <div className="flex shrink-0 border-b border-sky-200/50 p-4 sm:p-6 lg:p-8">
          <div className="flex w-full items-center justify-between">
            <div>
              <h1 className="text-2xl sm:text-3xl font-bold text-sky-gradient">
                SkyBridge
              </h1>
              <p className="text-sky-600 text-xs sm:text-sm mt-1">
                International Platform
              </p>
            </div>
            <button
              type="button"
              onClick={onClose}
              className="p-2 sm:p-3 rounded-xl hover:bg-sky-100 lg:hidden transition-all duration-200"
              aria-label="Close menu"
            >
              <X className="w-5 h-5 sm:w-6 sm:h-6 text-sky-600" />
            </button>
          </div>
        </div>

        <div className="flex min-h-0 flex-1 flex-col">
          <nav
            className="min-h-0 flex-1 overflow-y-auto overflow-x-hidden overscroll-y-contain px-3 py-3 sm:px-4 sm:py-4 lg:px-6 lg:py-6 touch-pan-y [-webkit-overflow-scrolling:touch]"
            aria-label="Main navigation"
          >
            <ul className="space-y-3 pb-2">
              {navItems.map((item) => (
                <li key={item.path}>
                  <NavLink to={item.path} end onClick={handleItemClick}>
                    {({ isActive }) => (
                      <div
                        className={`
                        group flex items-center space-x-2 sm:space-x-3 lg:space-x-4 px-2 sm:px-3 lg:px-6 py-2 sm:py-3 lg:py-4 rounded-lg sm:rounded-xl lg:rounded-2xl transition-all duration-200 transform hover:scale-105
                        ${
                          isActive
                            ? "gradient-sky text-white shadow-sky shadow-sky-500/25"
                            : "text-sky-600 hover:bg-gradient-to-r hover:from-sky-50 hover:to-sky-100 hover:text-sky-900"
                        }
                      `}
                      >
                        <item.icon
                          className={`w-4 h-4 sm:w-5 sm:h-5 lg:w-6 lg:h-6 ${isActive ? "text-white" : "text-sky-500 group-hover:text-sky-700"}`}
                        />
                        <span className="font-semibold text-xs sm:text-sm lg:text-lg">
                          {item.label}
                        </span>
                        {isActive && (
                          <div className="ml-auto h-2 w-2 rounded-full bg-white" />
                        )}
                      </div>
                    )}
                  </NavLink>
                </li>
              ))}
            </ul>
          </nav>

          <div className="shrink-0 border-t border-sky-200/50 p-3 sm:p-4 lg:p-6 lg:pt-4">
            <button
              type="button"
              onClick={handleLogout}
              className="group flex w-full items-center space-x-2 sm:space-x-3 lg:space-x-4 rounded-lg sm:rounded-xl lg:rounded-2xl px-2 sm:px-3 lg:px-6 py-2 sm:py-3 lg:py-4 text-left text-red-600 transition-all duration-200 hover:bg-red-50 hover:text-red-700"
            >
              <LogOut className="h-4 w-4 shrink-0 sm:h-5 sm:w-5 lg:h-6 lg:w-6 text-red-500 group-hover:text-red-600" />
              <span className="font-semibold text-xs sm:text-sm lg:text-lg">
                Logout
              </span>
            </button>
          </div>
        </div>
      </aside>
    </>
  );
};

export default Sidebar;
