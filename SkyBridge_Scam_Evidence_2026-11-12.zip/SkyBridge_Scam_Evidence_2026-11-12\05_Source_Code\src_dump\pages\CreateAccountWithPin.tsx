import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import {
  UserPlus,
  Loader2,
  Gift,
  Copy,
  Check,
  AlertCircle,
} from "lucide-react";
import { toast } from "react-toastify";
import {
  pinService,
  AccountPin,
  PinServiceError,
  TodayPinOffer,
} from "../services/pinService";
import { userService } from "../services/userService";
import { copyToClipboard } from "../utils/clipboard";
import { getDisplayNameForPlan } from "../constants/plans";

interface SuccessData {
  email: string;
  password: string;
  cashback?: {
    offer_title: string;
    discount_amount_usd: string;
  } | null;
}

const CreateAccountWithPin: React.FC = () => {
  const [pins, setPins] = useState<AccountPin[]>([]);
  const [offers, setOffers] = useState<TodayPinOffer[]>([]);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [selectedPinCode, setSelectedPinCode] = useState("");
  const [fullName, setFullName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [passwordConfirmation, setPasswordConfirmation] = useState("");
  const [country, setCountry] = useState("");
  const [referralCode, setReferralCode] = useState("");
  const [accountNumber, setAccountNumber] = useState("");
  const [accountTitle, setAccountTitle] = useState("");
  const [paymentMethods, setPaymentMethods] = useState("");
  const [bep20Address, setBep20Address] = useState("");
  const [fieldErrors, setFieldErrors] = useState<Record<string, string>>({});
  const [error, setError] = useState("");
  const [success, setSuccess] = useState<SuccessData | null>(null);
  const [credentialsCopied, setCredentialsCopied] = useState(false);

  const loadData = async () => {
    setLoading(true);
    try {
      const [pinsRes, offersRes, profile] = await Promise.all([
        pinService.getPins({ status: "unused", page: 1 }),
        pinService.getTodaySignupOffers(),
        userService.getUserProfile(),
      ]);
      const unused = pinsRes?.data?.data ?? [];
      setPins(unused);
      setOffers(offersRes?.data ?? []);
      if (profile?.referralCode) {
        setReferralCode(profile.referralCode);
      }
      if (unused.length > 0 && !selectedPinCode) {
        setSelectedPinCode(unused[0].pin_code);
      }
    } catch {
      toast.error("Failed to load PIN data");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    void loadData();
  }, []);

  const resetForm = () => {
    setFullName("");
    setEmail("");
    setPassword("");
    setPasswordConfirmation("");
    setCountry("");
    setReferralCode("");
    setAccountNumber("");
    setAccountTitle("");
    setPaymentMethods("");
    setBep20Address("");
    setSuccess(null);
    setFieldErrors({});
    setError("");
    void loadData();
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setFieldErrors({});

    if (!selectedPinCode) {
      setError("Please select a PIN");
      return;
    }

    setSubmitting(true);
    try {
      const res = await pinService.createAccountWithPin({
        fullName: fullName.trim(),
        email: email.trim(),
        password,
        passwordConfirmation,
        country: country.trim(),
        referralCode: referralCode.trim(),
        pinCode: selectedPinCode,
        accountNumber: accountNumber.trim() || undefined,
        accountTitle: accountTitle.trim() || undefined,
        paymentMethods: paymentMethods.trim() || undefined,
        bep20Address: bep20Address.trim() || undefined,
      });
      const data = res.data as {
        user?: { email: string };
        cashback?: SuccessData["cashback"];
      };
      setSuccess({
        email: data?.user?.email ?? email,
        password,
        cashback: data?.cashback ?? null,
      });
      toast.success("Account created and activated successfully");
    } catch (err) {
      if (err instanceof PinServiceError) {
        setFieldErrors(err.fieldErrors);
        const pinErr =
          err.fieldErrors.pin_code ||
          err.fieldErrors.email ||
          err.fieldErrors.referral_code;
        setError(pinErr || err.message);
      } else {
        setError(err instanceof Error ? err.message : "Failed to create account");
      }
    } finally {
      setSubmitting(false);
    }
  };

  const handleCopyCredentials = async () => {
    if (!success) return;
    const text = `Email: ${success.email}\nPassword: ${success.password}`;
    const ok = await copyToClipboard(text);
    if (ok) {
      setCredentialsCopied(true);
      toast.success("Credentials copied");
      setTimeout(() => setCredentialsCopied(false), 2000);
    }
  };

  const estimateCashback = (offer: TodayPinOffer) => {
    const pct = Number(offer.discount_percentage);
    const usd = Number(offer.plan?.price_usd ?? 0);
    return ((usd * pct) / 100).toFixed(2);
  };

  if (loading) {
    return (
      <div className="flex justify-center py-16">
        <Loader2 className="w-8 h-8 animate-spin text-blue-600" />
      </div>
    );
  }

  if (success) {
    return (
      <div className="p-4 sm:p-6 max-w-lg mx-auto">
        <SuccessPanel
          success={success}
          credentialsCopied={credentialsCopied}
          onCopy={handleCopyCredentials}
          onCreateAnother={resetForm}
        />
      </div>
    );
  }

  return (
    <div className="p-4 sm:p-6 max-w-xl mx-auto">
      <h1 className="text-2xl font-bold text-gray-900 flex items-center gap-2 mb-2">
        <UserPlus className="w-7 h-7 text-blue-600" />
        Create Account with PIN
      </h1>
      <p className="text-gray-600 mb-6 text-sm">
        Use one of your unused PINs to register a new user (auto-activated).
      </p>

      {offers.length > 0 && (
        <div className="mb-6 p-4 bg-amber-50 border border-amber-200 rounded-xl">
          <p className="font-semibold text-amber-900 flex items-center gap-2 mb-2">
            <Gift className="w-5 h-5" />
            Today&apos;s cashback offers (yours if a buyer uses your PIN today):
          </p>
          <ul className="text-sm text-amber-800 space-y-1 list-disc list-inside">
            {offers.map((o) => (
              <li key={o.id}>
                {getDisplayNameForPlan(o.plan?.name ?? "")} plan — {o.discount_percentage}%
                (~${estimateCashback(o)} on a ${o.plan?.price_usd} plan)
              </li>
            ))}
          </ul>
        </div>
      )}

      {pins.length === 0 ? (
        <div className="text-center py-12 bg-white rounded-xl border border-gray-200">
          <p className="text-gray-600 mb-4">You have no unused PINs.</p>
          <Link
            to="/buy-pin"
            className="inline-block px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
          >
            Buy PIN
          </Link>
        </div>
      ) : (
        <form onSubmit={handleSubmit} className="space-y-4 bg-white rounded-xl border border-gray-200 p-6 shadow-sm">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Select PIN <span className="text-red-500">*</span>
            </label>
            <select
              value={selectedPinCode}
              onChange={(e) => setSelectedPinCode(e.target.value)}
              className={`w-full px-4 py-3 border rounded-lg focus:ring-2 focus:ring-blue-500 ${
                fieldErrors.pin_code ? "border-red-400" : "border-gray-300"
              }`}
            >
              {pins.map((p) => (
                <option key={p.id} value={p.pin_code}>
                  {p.pin_code} — {getDisplayNameForPlan(p.plan?.name ?? "")}
                </option>
              ))}
            </select>
            {fieldErrors.pin_code && (
              <p className="text-sm text-red-600 mt-1">{fieldErrors.pin_code}</p>
            )}
          </div>

          <FormField label="Full name" value={fullName} onChange={setFullName} error={fieldErrors.full_name} required />
          <FormField label="Email" type="email" value={email} onChange={setEmail} error={fieldErrors.email} required />
          <FormField label="Password" type="password" value={password} onChange={setPassword} error={fieldErrors.password} required />
          <FormField
            label="Confirm password"
            type="password"
            value={passwordConfirmation}
            onChange={setPasswordConfirmation}
            error={fieldErrors.password_confirmation}
            required
            disablePaste
          />
          <FormField label="Country" value={country} onChange={setCountry} error={fieldErrors.country} required />

          {country.trim().toLowerCase() === "pakistan" ? (
            <>
              <FormField
                label="Account number"
                value={accountNumber}
                onChange={(v) => setAccountNumber(v.replace(/\D/g, ""))}
                error={fieldErrors.account_number}
                required
                type="tel"
              />
              <FormField
                label="Account title"
                value={accountTitle}
                onChange={setAccountTitle}
                error={fieldErrors.account_title}
                required
              />
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Payment method <span className="text-red-500">*</span>
                </label>
                <select
                  value={paymentMethods}
                  onChange={(e) => setPaymentMethods(e.target.value)}
                  className={`w-full px-4 py-3 border rounded-lg focus:ring-2 focus:ring-blue-500 bg-white ${
                    fieldErrors.payment_methods ? "border-red-400" : "border-gray-300"
                  }`}
                >
                  <option value="">Select payment method</option>
                  <option value="JazzCash">JazzCash</option>
                  <option value="EasyPaisa">EasyPaisa</option>
                  <option value="NayaPay">NayaPay</option>
                  <option value="SadaPay">SadaPay</option>
                  <option value="Upaisa">Upaisa</option>
                </select>
                {fieldErrors.payment_methods && (
                  <p className="text-sm text-red-600 mt-1">{fieldErrors.payment_methods}</p>
                )}
              </div>
            </>
          ) : (
            <FormField
              label="BEP20 wallet address"
              value={bep20Address}
              onChange={setBep20Address}
              error={fieldErrors.bep20_address}
              required
            />
          )}

          <FormField
            label="Referral code (9 characters)"
            value={referralCode}
            onChange={setReferralCode}
            error={fieldErrors.referral_code}
            required
            maxLength={9}
          />

          {error && (
            <div className="flex items-center gap-2 p-3 bg-red-50 border border-red-200 rounded-lg text-red-700 text-sm">
              <AlertCircle className="w-4 h-4 shrink-0" />
              {error}
            </div>
          )}

          <button
            type="submit"
            disabled={submitting}
            className="w-full py-3 bg-blue-600 text-white font-semibold rounded-lg hover:bg-blue-700 disabled:opacity-50 flex items-center justify-center gap-2"
          >
            {submitting ? (
              <>
                <Loader2 className="w-5 h-5 animate-spin" />
                Creating…
              </>
            ) : (
              "Create Account"
            )}
          </button>
        </form>
      )}
    </div>
  );
};

function FormField({
  label,
  value,
  onChange,
  error,
  required,
  type = "text",
  maxLength,
  disablePaste = false,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  error?: string;
  required?: boolean;
  type?: string;
  maxLength?: number;
  disablePaste?: boolean;
}) {
  const blockClipboard = (e: React.ClipboardEvent) => e.preventDefault();
  return (
    <div>
      <label className="block text-sm font-medium text-gray-700 mb-1">
        {label} {required && <span className="text-red-500">*</span>}
      </label>
      <input
        type={type}
        value={value}
        maxLength={maxLength}
        onChange={(e) => onChange(e.target.value)}
        onPaste={disablePaste ? blockClipboard : undefined}
        onCopy={disablePaste ? blockClipboard : undefined}
        onCut={disablePaste ? blockClipboard : undefined}
        className={`w-full px-4 py-3 border rounded-lg focus:ring-2 focus:ring-blue-500 ${
          error ? "border-red-400" : "border-gray-300"
        }`}
      />
      {error && <p className="text-sm text-red-600 mt-1">{error}</p>}
    </div>
  );
}

function SuccessPanel({
  success,
  credentialsCopied,
  onCopy,
  onCreateAnother,
}: {
  success: SuccessData;
  credentialsCopied: boolean;
  onCopy: () => void;
  onCreateAnother: () => void;
}) {
  return (
    <div className="bg-white rounded-xl border border-gray-200 p-6 shadow-sm text-center">
      <Check className="w-12 h-12 text-green-500 mx-auto mb-4" />
      <h2 className="text-xl font-bold text-gray-900 mb-2">Account Created</h2>
      <p className="text-gray-600 text-sm mb-4">
        Share these credentials with the new user so they can log in.
      </p>
      <div className="text-left bg-gray-50 rounded-lg p-4 font-mono text-sm space-y-2">
        <p>
          <span className="text-gray-500">Email:</span> {success.email}
        </p>
        <p>
          <span className="text-gray-500">Password:</span> {success.password}
        </p>
      </div>
      <button
        type="button"
        onClick={onCopy}
        className="mt-4 inline-flex items-center gap-2 px-4 py-2 bg-gray-100 rounded-lg hover:bg-gray-200 text-sm font-medium"
      >
        {credentialsCopied ? (
          <Check className="w-4 h-4 text-green-600" />
        ) : (
          <Copy className="w-4 h-4" />
        )}
        Copy credentials
      </button>
      {success.cashback && (
        <div className="mt-4 p-3 bg-green-50 border border-green-200 rounded-lg text-left text-sm text-green-800">
          You earned ${success.cashback.discount_amount_usd} cashback (Offer:{" "}
          {success.cashback.offer_title})
        </div>
      )}
      <button
        type="button"
        onClick={onCreateAnother}
        className="mt-6 w-full py-3 bg-blue-600 text-white font-semibold rounded-lg hover:bg-blue-700"
      >
        Create another
      </button>
    </div>
  );
}

export default CreateAccountWithPin;
