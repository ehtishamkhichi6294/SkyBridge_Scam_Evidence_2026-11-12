import React, { useState, useRef } from "react";
import { useNavigate } from "react-router-dom";
import {
  Mail,
  KeyRound,
  AlertCircle,
  CheckCircle,
  Loader2,
  ArrowLeft,
  CreditCard,
} from "lucide-react";
import { useAuth } from "../contexts/AuthContext";
import { apiClient } from "../services/apiClient";
import { userService } from "../services/userService";
import { API_ENDPOINTS } from "../config/api";
import { toast } from "react-toastify";

type Step = 1 | 2 | 3;

const PAYMENT_METHODS = [
  { id: "jazzcash",  name: "JazzCash",  icon: "📱" },
  { id: "easypaisa", name: "EasyPaisa", icon: "💳" },
  { id: "sadapay",   name: "SadaPay",   icon: "🏦" },
  { id: "Upaisa",    name: "Upaisa",    icon: "👛" },
  { id: "nayapay",   name: "NayaPay",   icon: "💰" },
];

const ChangeAccountDetails: React.FC = () => {
  const navigate  = useNavigate();
  const { user, refreshUser } = useAuth();

  const u           = user as unknown as Record<string, unknown>;
  const isPakistani = u?.country === "Pakistan";

  const [step, setStep] = useState<Step>(1);

  // Step 1
  const [step1Loading, setStep1Loading] = useState(false);
  const [step1Error,   setStep1Error]   = useState("");

  // Step 2
  const [otp,         setOtp]         = useState("");
  const [step2Loading, setStep2Loading] = useState(false);
  const [step2Error,   setStep2Error]   = useState("");
  const [resetToken,   setResetToken]   = useState("");
  const otpRef = useRef<HTMLInputElement>(null);

  // Step 3 — Pakistani fields
  const [accountNumber,    setAccountNumber]    = useState("");
  const [accountTitle,     setAccountTitle]     = useState("");
  const [selectedMethods,  setSelectedMethods]  = useState<string[]>([]);

  // Step 3 — International fields
  const [bep20Address,        setBep20Address]        = useState("");
  const [confirmBep20Address, setConfirmBep20Address] = useState("");

  const [step3Loading,  setStep3Loading]  = useState(false);
  const [step3Error,    setStep3Error]    = useState("");
  const [fieldErrors,   setFieldErrors]   = useState<Record<string, string>>({});

  const userEmail = user?.email ?? "";

  // ── Step 1: Send OTP ──────────────────────────────────────────────────────
  const handleSendOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    setStep1Error("");
    setStep1Loading(true);
    try {
      await apiClient.post(API_ENDPOINTS.AUTH.PASSWORD_RESET_REQUEST_OTP, { email: userEmail });
      setStep(2);
      setTimeout(() => otpRef.current?.focus(), 100);
      toast.info(`Verification code sent to ${userEmail}`);
    } catch (err: unknown) {
      const status = (err as Record<string, unknown>)?.status;
      if (status === 429) {
        setStep1Error("Too many attempts. Please try again later.");
      } else {
        setStep(2);
        setTimeout(() => otpRef.current?.focus(), 100);
      }
    } finally {
      setStep1Loading(false);
    }
  };

  // ── Step 2: Verify OTP ────────────────────────────────────────────────────
  const handleVerifyOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    setStep2Error("");
    if (otp.trim().length !== 6) { setStep2Error("Please enter the 6-digit code"); return; }
    setStep2Loading(true);
    try {
      const res = await apiClient.post<{ reset_token: string }>(
        API_ENDPOINTS.AUTH.PASSWORD_RESET_VERIFY_OTP,
        { email: userEmail, otp_code: otp.trim() },
      );
      const token = (res.data as Record<string, unknown>)?.reset_token as string | undefined;
      if (!token) throw new Error("Invalid response from server");

      setResetToken(token);

      // Pre-fill current values
      if (isPakistani) {
        setAccountNumber(String(u?.account_number ?? ""));
        setAccountTitle(String(u?.account_title ?? ""));
        const methods = u?.payment_methods;
        if (Array.isArray(methods)) setSelectedMethods(methods as string[]);
      } else {
        setBep20Address(String(u?.bep20_address ?? ""));
      }

      setStep(3);
    } catch (err: unknown) {
      const e = err as Record<string, unknown>;
      const msg = String((e?.data as Record<string, unknown>)?.message || e?.message || "Verification failed");
      if (msg.includes("Too many failed")) {
        setStep2Error(msg);
        toast.error("Too many failed attempts — please request a new code.");
        setTimeout(() => { setStep(1); setOtp(""); setStep2Error(""); }, 2500);
      } else {
        setStep2Error(msg);
      }
    } finally {
      setStep2Loading(false);
    }
  };

  // ── Step 3: Submit ────────────────────────────────────────────────────────
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setStep3Error("");
    setFieldErrors({});

    if (isPakistani) {
      if (!accountNumber.trim())      { setStep3Error("Account number is required"); return; }
      if (!accountTitle.trim())       { setStep3Error("Account title is required"); return; }
      if (selectedMethods.length === 0) { setStep3Error("Please select a payment method"); return; }
    } else {
      if (!bep20Address.trim())       { setStep3Error("BEP20 address is required"); return; }
      if (bep20Address.trim() !== confirmBep20Address.trim()) {
        setStep3Error("BEP20 addresses do not match");
        return;
      }
    }

    setStep3Loading(true);
    try {
      const payload: Record<string, string> = { reset_token: resetToken };

      if (isPakistani) {
        payload.account_number  = accountNumber.trim();
        payload.account_title   = accountTitle.trim();
        payload.payment_methods = selectedMethods.join(",");
      } else {
        payload.bep20_address = bep20Address.trim();
      }

      await apiClient.post(API_ENDPOINTS.USER.CHANGE_ACCOUNT_DETAILS, payload);

      userService.clearProfileCache();

      if (isPakistani) {
        refreshUser({
          account_number:  payload.account_number,
          account_title:   payload.account_title,
          payment_methods: selectedMethods,
        });
      } else {
        refreshUser({
          bep20_address:   payload.bep20_address,
          payment_methods: ["BEP20 (BSC)"],
        });
      }

      toast.success("Account details updated successfully!");
      navigate("/profile-info");
    } catch (err: unknown) {
      const e    = err as Record<string, unknown>;
      const errs = (e?.data as Record<string, unknown>)?.errors as Record<string, string[]> | undefined;
      if (errs) {
        const flat: Record<string, string> = {};
        Object.entries(errs).forEach(([k, v]) => { flat[k] = Array.isArray(v) ? v[0] : String(v); });
        setFieldErrors(flat);
        setStep3Error(flat.account_number || flat.bep20_address || flat.payment_methods || "Please fix the errors above.");
      } else {
        const msg = String((e?.data as Record<string, unknown>)?.message || e?.message || "Update failed");
        if (msg.includes("expired") || msg.includes("Invalid")) {
          setStep3Error(msg);
          toast.error("Session expired — please verify your email again.");
          setTimeout(() => { setStep(1); setOtp(""); setResetToken(""); setStep3Error(""); }, 2500);
        } else {
          setStep3Error(msg);
        }
      }
    } finally {
      setStep3Loading(false);
    }
  };

  const toggleMethod = (id: string) => {
    setSelectedMethods([id]);
  };

  const clearFieldError = (key: string) => {
    setFieldErrors((p) => { const copy = { ...p }; delete copy[key]; return copy; });
  };

  // ── Render ────────────────────────────────────────────────────────────────
  return (
    <div className="min-h-screen bg-gray-50 py-6 px-4">
      <div className="max-w-lg mx-auto">
        {/* Header */}
        <div className="flex items-center gap-3 mb-6">
          <button type="button" onClick={() => navigate(-1)} className="p-2 rounded-lg hover:bg-gray-200 transition">
            <ArrowLeft className="w-5 h-5 text-gray-600" />
          </button>
          <div>
            <h1 className="text-2xl font-bold text-gray-900 flex items-center gap-2">
              <CreditCard className="w-6 h-6 text-sky-600" />
              Change Account Details
            </h1>
            <p className="text-sm text-gray-500 mt-0.5">
              {isPakistani ? "Update account number, title & payment methods" : "Update your BEP20 wallet address"}
            </p>
          </div>
        </div>

        {/* Progress bar */}
        <div className="flex gap-1 mb-6">
          {([1, 2, 3] as Step[]).map((s) => (
            <div key={s} className={`flex-1 h-1.5 rounded-full transition-colors duration-300 ${step >= s ? "bg-sky-500" : "bg-gray-200"}`} />
          ))}
        </div>

        <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6">

          {/* ── Step 1 ── */}
          {step === 1 && (
            <form onSubmit={handleSendOtp} className="space-y-5">
              <div className="text-center mb-2">
                <div className="inline-flex items-center justify-center w-14 h-14 rounded-full bg-sky-100 mb-3">
                  <Mail className="w-7 h-7 text-sky-600" />
                </div>
                <h2 className="text-xl font-bold text-gray-800">Verify Your Email</h2>
                <p className="text-sm text-gray-500 mt-1">We'll send a 6-digit code to confirm your identity.</p>
              </div>

              {step1Error && (
                <div className="flex items-start gap-2 p-3 bg-red-50 border border-red-200 rounded-lg text-red-700 text-sm">
                  <AlertCircle className="w-4 h-4 mt-0.5 shrink-0" />{step1Error}
                </div>
              )}

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Your Registered Email</label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 w-5 h-5" />
                  <input
                    type="email"
                    value={userEmail}
                    readOnly
                    className="w-full pl-10 pr-4 py-3 border border-gray-200 rounded-xl bg-gray-50 text-gray-600 text-sm cursor-not-allowed"
                  />
                </div>
              </div>

              <button type="submit" disabled={step1Loading}
                className="w-full bg-sky-600 text-white py-3 rounded-xl font-semibold hover:bg-sky-700 transition disabled:opacity-50 flex items-center justify-center gap-2">
                {step1Loading ? <><Loader2 className="w-5 h-5 animate-spin" />Sending…</> : "Send Verification Code"}
              </button>
            </form>
          )}

          {/* ── Step 2 ── */}
          {step === 2 && (
            <form onSubmit={handleVerifyOtp} className="space-y-5">
              <div className="text-center mb-2">
                <div className="inline-flex items-center justify-center w-14 h-14 rounded-full bg-sky-100 mb-3">
                  <KeyRound className="w-7 h-7 text-sky-600" />
                </div>
                <h2 className="text-xl font-bold text-gray-800">Enter Code</h2>
                <p className="text-sm text-gray-500 mt-1">
                  6-digit code sent to <span className="font-medium">{userEmail}</span>
                </p>
              </div>

              {step2Error && (
                <div className="flex items-start gap-2 p-3 bg-red-50 border border-red-200 rounded-lg text-red-700 text-sm">
                  <AlertCircle className="w-4 h-4 mt-0.5 shrink-0" />{step2Error}
                </div>
              )}

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">6-Digit Code</label>
                <input
                  ref={otpRef}
                  type="text"
                  inputMode="numeric"
                  maxLength={6}
                  value={otp}
                  onChange={(e) => { setOtp(e.target.value.replace(/\D/g, "").slice(0, 6)); if (step2Error) setStep2Error(""); }}
                  className="w-full px-4 py-4 border border-gray-300 rounded-xl focus:ring-2 focus:ring-sky-500 text-center text-2xl font-mono tracking-widest"
                  placeholder="000000"
                />
                <p className="text-xs text-gray-400 mt-1">Code expires in 10 minutes.</p>
              </div>

              <button type="submit" disabled={step2Loading || otp.length !== 6}
                className="w-full bg-sky-600 text-white py-3 rounded-xl font-semibold hover:bg-sky-700 transition disabled:opacity-50 flex items-center justify-center gap-2">
                {step2Loading ? <><Loader2 className="w-5 h-5 animate-spin" />Verifying…</> : "Verify Code"}
              </button>

              <p className="text-center text-sm text-gray-500">
                Didn't get the code?{" "}
                <button type="button" onClick={() => { setStep(1); setOtp(""); setStep2Error(""); }}
                  className="text-sky-600 hover:text-sky-700 font-medium">Resend</button>
              </p>
            </form>
          )}

          {/* ── Step 3 ── */}
          {step === 3 && (
            <form onSubmit={handleSubmit} className="space-y-5">
              <div className="text-center mb-2">
                <div className="inline-flex items-center justify-center w-14 h-14 rounded-full bg-green-100 mb-3">
                  <CheckCircle className="w-7 h-7 text-green-600" />
                </div>
                <h2 className="text-xl font-bold text-gray-800">Update Details</h2>
                <p className="text-sm text-gray-500 mt-1">Email verified. Update your account details below.</p>
              </div>

              {step3Error && (
                <div className="flex items-start gap-2 p-3 bg-red-50 border border-red-200 rounded-lg text-red-700 text-sm">
                  <AlertCircle className="w-4 h-4 mt-0.5 shrink-0" />{step3Error}
                </div>
              )}

              {/* ── Pakistani form ── */}
              {isPakistani && (
                <>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Account Title <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="text"
                      value={accountTitle}
                      onChange={(e) => { setAccountTitle(e.target.value); if (step3Error) setStep3Error(""); }}
                      className={`w-full px-4 py-3 border rounded-xl focus:ring-2 focus:ring-sky-500 text-sm ${fieldErrors.account_title ? "border-red-400" : "border-gray-300"}`}
                      placeholder="Account holder name"
                      required
                    />
                    {fieldErrors.account_title && <p className="text-xs text-red-600 mt-1">{fieldErrors.account_title}</p>}
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Account Number <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="text"
                      value={accountNumber}
                      onChange={(e) => { setAccountNumber(e.target.value); clearFieldError("account_number"); if (step3Error) setStep3Error(""); }}
                      className={`w-full px-4 py-3 border rounded-xl focus:ring-2 focus:ring-sky-500 text-sm ${fieldErrors.account_number ? "border-red-400" : "border-gray-300"}`}
                      placeholder="e.g. 03001234567"
                      required
                    />
                    {fieldErrors.account_number && <p className="text-xs text-red-600 mt-1">{fieldErrors.account_number}</p>}
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Payment Method <span className="text-red-500">*</span>
                    </label>
                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                      {PAYMENT_METHODS.map((method) => {
                        const active = selectedMethods.includes(method.id);
                        return (
                          <button key={method.id} type="button" onClick={() => toggleMethod(method.id)}
                            className={`flex items-center gap-2 px-3 py-2.5 rounded-xl border-2 text-sm font-medium transition-all ${
                              active ? "border-sky-500 bg-sky-50 text-sky-700" : "border-gray-200 bg-white text-gray-600 hover:border-sky-300"
                            }`}>
                            <span>{method.icon}</span>
                            <span>{method.name}</span>
                            {active && <CheckCircle className="w-3.5 h-3.5 ml-auto text-sky-500 shrink-0" />}
                          </button>
                        );
                      })}
                    </div>
                  </div>
                </>
              )}

              {/* ── International form ── */}
              {!isPakistani && (
                <>
                  <div className="p-3 bg-blue-50 border border-blue-200 rounded-xl text-sm text-blue-800">
                    <strong>BEP20 (BSC)</strong> wallet address — make sure this is a valid Binance Smart Chain address.
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      BEP20 Wallet Address <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="text"
                      value={bep20Address}
                      onChange={(e) => { setBep20Address(e.target.value); clearFieldError("bep20_address"); if (step3Error) setStep3Error(""); }}
                      className={`w-full px-4 py-3 border rounded-xl focus:ring-2 focus:ring-sky-500 text-sm font-mono ${fieldErrors.bep20_address ? "border-red-400" : "border-gray-300"}`}
                      placeholder="0x..."
                      required
                    />
                    {fieldErrors.bep20_address && <p className="text-xs text-red-600 mt-1">{fieldErrors.bep20_address}</p>}
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Confirm BEP20 Address <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="text"
                      value={confirmBep20Address}
                      onChange={(e) => { setConfirmBep20Address(e.target.value); if (step3Error) setStep3Error(""); }}
                      onPaste={(e) => e.preventDefault()}
                      className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-sky-500 text-sm font-mono"
                      placeholder="Re-enter BEP20 address"
                      required
                    />
                    {bep20Address && confirmBep20Address && bep20Address !== confirmBep20Address && (
                      <p className="text-xs text-red-600 mt-1">Addresses do not match</p>
                    )}
                    {bep20Address && confirmBep20Address && bep20Address === confirmBep20Address && (
                      <p className="text-xs text-green-600 mt-1 flex items-center gap-1">
                        <CheckCircle className="w-3.5 h-3.5" /> Addresses match
                      </p>
                    )}
                  </div>
                </>
              )}

              <button type="submit" disabled={step3Loading}
                className="w-full bg-sky-600 text-white py-3 rounded-xl font-semibold hover:bg-sky-700 transition disabled:opacity-50 flex items-center justify-center gap-2">
                {step3Loading ? <><Loader2 className="w-5 h-5 animate-spin" />Saving…</> : "Save Changes"}
              </button>
            </form>
          )}

        </div>
      </div>
    </div>
  );
};

export default ChangeAccountDetails;
