import { apiClient } from './apiClient';
import { API_ENDPOINTS } from '../config/api';
import type { Product } from './productService';

export interface PurchaseRequestProduct {
  id: number;
  admin_id: number;
  name: string;
  price: string;
  user_profit_percentage: string;
  category: string;
  description: string;
  images: string[];
  video?: string;
  created_at: string;
  updated_at: string;
}

export interface PurchaseRequest {
  id: number;
  user_id: number;
  product_id: number;
  full_name: string;
  phone_number: string;
  address: string;
  second_phone_number?: string;
  note?: string;
  payment_screenshot?: string;
  status: 'pending' | 'approved' | 'rejected';
  rejection_reason?: string | null;
  created_at: string;
  updated_at: string;
  product: PurchaseRequestProduct;
  // Computed/display properties
  productName?: string;
  createdAt?: string;
  fullName?: string;
  phone?: string;
  secondPhoneNumber?: string;
}

export interface CreatePurchaseRequestData {
  productId: number;
  fullName: string;
  phone: string;
  address: string;
  secondPhoneNumber?: string;
  note?: string;
  paymentScreenshot?: File;
}

export interface CreatePurchaseRequestResponse {
  id: number;
  productName: string;
  createdAt: string;
  status: string;
}

export interface PaginationLink {
  url: string | null;
  label: string;
  page: number | null;
  active: boolean;
}

export interface PaginatedPurchaseRequestsResponse {
  current_page: number;
  data: PurchaseRequest[];
  first_page_url: string;
  from: number;
  last_page: number;
  last_page_url: string;
  links: PaginationLink[];
  next_page_url: string | null;
  path: string;
  per_page: number;
  prev_page_url: string | null;
  to: number;
  total: number;
}

export interface EarningsResponse {
  total_earnings: number;
}

export const purchaseRequestService = {
  async createPurchaseRequest(data: CreatePurchaseRequestData) {
    const formData = new FormData();
    
    formData.append('product_id', data.productId.toString());
    formData.append('full_name', data.fullName);
    formData.append('phone_number', data.phone);
    formData.append('address', data.address);
    if (data.secondPhoneNumber) {
      formData.append('second_phone_number', data.secondPhoneNumber);
    }
    
    if (data.note) {
      formData.append('note', data.note);
    }
    
    if (data.paymentScreenshot) {
      formData.append('payment_screenshot', data.paymentScreenshot);
    }

    // apiClient automatically handles FormData and removes Content-Type header
    return apiClient.post<CreatePurchaseRequestResponse>(
      API_ENDPOINTS.PURCHASE_REQUESTS,
      formData
    );
  },

  async getPurchaseHistory(page: number = 1) {
    const endpoint = `${API_ENDPOINTS.PURCHASE_REQUESTS}${page > 1 ? `?page=${page}` : ''}`;
    return apiClient.get<PaginatedPurchaseRequestsResponse>(endpoint);
  },

  async getEarnings() {
    return apiClient.get<{ data: EarningsResponse }>(API_ENDPOINTS.PURCHASE_REQUESTS_EARNINGS);
  },
};

