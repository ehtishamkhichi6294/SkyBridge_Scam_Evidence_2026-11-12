import React from "react";
import ykPartnersLogo from "../assets/images/yk-partners-logo.svg";

export const YK_WHATSAPP_NUMBER = "923260538041";

export const YK_WHATSAPP_MESSAGE = `Hi,

I'd like to discuss a project that I need to have developed by you. Please let me know when you're available so we can talk about the requirements.`;

export const buildWhatsAppUrl = (phone: string, message: string) =>
  `https://wa.me/${phone}?text=${encodeURIComponent(message)}`;

export const YK_PARTNERS_WHATSAPP_URL = buildWhatsAppUrl(
  YK_WHATSAPP_NUMBER,
  YK_WHATSAPP_MESSAGE
);

interface YKPartnersButtonProps {
  className?: string;
  compact?: boolean;
  onClick?: () => void;
}

const YKPartnersButton: React.FC<YKPartnersButtonProps> = ({
  className = "",
  compact = false,
  onClick,
}) => {
  const content = (
    <>
      <img
        src={ykPartnersLogo}
        alt="Y & K Partners"
        className={`shrink-0 rounded-full object-cover ${
          compact ? "h-9 w-9 sm:h-10 sm:w-10" : "h-10 w-10 sm:h-11 sm:w-11"
        }`}
      />
      <span
        className={`font-semibold text-sky-900 ${
          compact
            ? "hidden text-xs sm:inline sm:text-sm"
            : "text-sm sm:text-base"
        }`}
      >
        Y & K Partners
      </span>
    </>
  );

  const sharedClass = `inline-flex items-center rounded-full border border-sky-200 bg-white shadow-md transition-all duration-300 hover:scale-105 hover:shadow-lg active:scale-95 ${
    compact
      ? "gap-2 px-2 py-1.5 sm:gap-3 sm:px-4 sm:py-2"
      : "gap-3 px-4 py-2 sm:px-5 sm:py-2.5"
  } ${className}`;

  if (onClick) {
    return (
      <button
        type="button"
        onClick={onClick}
        title="Y & K Partners — Learn about our development services"
        className={sharedClass}
      >
        {content}
      </button>
    );
  }

  return (
    <a
      href={YK_PARTNERS_WHATSAPP_URL}
      target="_blank"
      rel="noopener noreferrer"
      title={`Y & K Partners — ${YK_WHATSAPP_MESSAGE}`}
      className={sharedClass}
    >
      {content}
    </a>
  );
};

export default YKPartnersButton;
