import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import {
  ClipboardList,
  Loader2,
  ChevronLeft,
  ChevronRight,
  Clock,
  CheckCircle,
  XCircle,
} from "lucide-react";
import { toast } from "react-toastify";
import { useCurrency } from "../contexts/CurrencyContext";
import { pinService, PinPurchaseRequest } from "../services/pinService";
import { getDisplayNameForPlan } from "../constants/plans";

type StatusFilter = "all" | "pending" | "approved" | "rejected";

const PinRequests: React.FC = () => {
  const { currency, formatCurrency } = useCurrency();
  const [requests, setRequests] = useState<PinPurchaseRequest[]>([]);
  const [statusFilter, setStatusFilter] = useState<StatusFilter>("all");
  const [loading, setLoading] = useState(true);
  const [currentPage, setCurrentPage] = useState(1);
  const [lastPage, setLastPage] = useState(1);

  useEffect(() => {
    void fetchRequests();
  }, [statusFilter, currentPage]);

  const fetchRequests = async () => {
    setLoading(true);
    try {
      const res = await pinService.getPinRequests({
        status: statusFilter === "all" ? undefined : statusFilter,
        page: currentPage,
      });
      setRequests(res?.data?.data ?? []);
      setLastPage(res?.data?.last_page ?? 1);
    } catch {
      toast.error("Failed to load PIN requests");
    } finally {
      setLoading(false);
    }
  };

  const formatAmount = (req: PinPurchaseRequest) => {
    if (currency === "PKR" && req.amount_pkr != null) {
      return `₨${Number(req.amount_pkr).toLocaleString("en-US", { minimumFractionDigits: 2 })}`;
    }
    if (req.amount_usd != null) {
      return formatCurrency(Number(req.amount_usd));
    }
    if (req.plan?.price_usd != null) {
      return formatCurrency(Number(req.plan.price_usd));
    }
    return "—";
  };

  const formatDate = (d: string) =>
    new Date(d).toLocaleDateString("en-US", {
      year: "numeric",
      month: "short",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });

  const statusBadge = (status: PinPurchaseRequest["status"]) => {
    const cfg = {
      pending: {
        label: "Pending",
        className: "bg-yellow-100 text-yellow-800",
        icon: Clock,
      },
      approved: {
        label: "Approved",
        className: "bg-green-100 text-green-800",
        icon: CheckCircle,
      },
      rejected: {
        label: "Rejected",
        className: "bg-red-100 text-red-800",
        icon: XCircle,
      },
    }[status];
    const Icon = cfg.icon;
    return (
      <span
        className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-medium ${cfg.className}`}
      >
        <Icon className="w-3.5 h-3.5" />
        {cfg.label}
      </span>
    );
  };

  const filters: StatusFilter[] = ["all", "pending", "approved", "rejected"];

  return (
    <div className="p-4 sm:p-6 max-w-5xl mx-auto">
      <h1 className="text-2xl font-bold text-gray-900 flex items-center gap-2 mb-6">
        <ClipboardList className="w-7 h-7 text-blue-600" />
        PIN Requests
      </h1>

      <div className="flex flex-wrap gap-2 mb-6">
        {filters.map((s) => (
          <button
            key={s}
            type="button"
            onClick={() => {
              setStatusFilter(s);
              setCurrentPage(1);
            }}
            className={`px-4 py-2 rounded-lg text-sm font-medium ${
              statusFilter === s
                ? "bg-blue-600 text-white"
                : "bg-gray-100 text-gray-700 hover:bg-gray-200"
            }`}
          >
            {s === "all" ? "All" : s.charAt(0).toUpperCase() + s.slice(1)}
          </button>
        ))}
      </div>

      {loading ? (
        <div className="flex justify-center py-12">
          <Loader2 className="w-8 h-8 animate-spin text-blue-600" />
        </div>
      ) : requests.length === 0 ? (
        <p className="text-center text-gray-500 py-12">No PIN requests found.</p>
      ) : (
        <div className="space-y-4">
          {requests.map((req) => (
            <div
              key={req.id}
              className="bg-white rounded-xl border border-gray-200 p-4 shadow-sm"
            >
              <div className="flex flex-wrap items-start justify-between gap-2 mb-2">
                <div>
                  <p className="font-semibold text-gray-900">
                    {getDisplayNameForPlan(req.plan?.name ?? "")}
                  </p>
                  <p className="text-sm text-gray-500">{formatAmount(req)}</p>
                </div>
                {statusBadge(req.status)}
              </div>
              <p className="text-sm text-gray-600 font-mono mb-1">
                TX: {req.transaction_id}
              </p>
              <p className="text-xs text-gray-400">{formatDate(req.created_at)}</p>
              {req.status === "rejected" && req.admin_notes && (
                <p className="mt-2 text-sm text-red-600">{req.admin_notes}</p>
              )}
              {req.status === "approved" && (
                <p className="mt-2 text-sm text-green-700">
                  PIN generated —{" "}
                  <Link to="/my-pins" className="underline font-medium">
                    view in My PINs
                  </Link>
                </p>
              )}
            </div>
          ))}

          {lastPage > 1 && (
            <div className="flex items-center justify-center gap-2 pt-4">
              <button
                type="button"
                onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
                disabled={currentPage === 1}
                className="p-2 rounded-lg bg-gray-100 hover:bg-gray-200 disabled:opacity-50"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>
              <span className="text-sm text-gray-600">
                Page {currentPage} of {lastPage}
              </span>
              <button
                type="button"
                onClick={() => setCurrentPage((p) => Math.min(lastPage, p + 1))}
                disabled={currentPage === lastPage}
                className="p-2 rounded-lg bg-gray-100 hover:bg-gray-200 disabled:opacity-50"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default PinRequests;
