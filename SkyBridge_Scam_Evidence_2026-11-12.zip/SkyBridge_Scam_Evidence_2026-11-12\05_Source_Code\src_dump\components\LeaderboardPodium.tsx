import { getAvatarFallbackUrl } from "../utils/imageUtils";

export interface PodiumLeaderDisplay {
  id: string;
  name: string;
  subtitle?: string;
  amount: string;
  image: string;
}

const PODIUM_CONFIG = {
  1: {
    sizeClass: "w-24 h-24 sm:w-28 sm:h-28 md:w-32 md:h-32 lg:w-36 lg:h-36",
    ringClass: "ring-[3px] ring-amber-400 shadow-lg",
    liftClass: "mb-0",
  },
  2: {
    sizeClass: "w-20 h-20 sm:w-24 sm:h-24 md:w-28 md:h-28",
    ringClass: "ring-2 ring-slate-400 shadow-md",
    liftClass: "mb-4 sm:mb-6 md:mb-8",
  },
  3: {
    sizeClass: "w-16 h-16 sm:w-20 sm:h-20 md:w-24 md:h-24",
    ringClass: "ring-2 ring-amber-700/70 shadow-md",
    liftClass: "mb-4 sm:mb-6 md:mb-8",
  },
} as const;

function CrownMedal() {
  return (
    <span
      className="mb-1 flex flex-col items-center text-4xl leading-none drop-shadow-sm sm:text-5xl"
      role="img"
      aria-label="1st place"
    >
      👑
    </span>
  );
}

function NumberMedal({ rank }: { rank: 2 | 3 }) {
  const isSilver = rank === 2;
  const medalFill = isSilver ? "#e5e7eb" : "#d97706";
  const medalStroke = isSilver ? "#9ca3af" : "#b45309";
  const ribbonFill = "#2563eb";
  const textFill = isSilver ? "#334155" : "#78350f";

  return (
    <span
      className="mb-1 flex h-9 w-8 flex-col items-center sm:h-10 sm:w-9"
      role="img"
      aria-label={`${rank}${rank === 2 ? "nd" : "rd"} place`}
    >
      <svg
        viewBox="0 0 36 44"
        className="h-full w-full drop-shadow-sm"
        aria-hidden="true"
      >
        <path
          d="M10 30 L7 44 L14 34 L18 44 L22 34 L29 44 L26 30 Z"
          fill={ribbonFill}
        />
        <circle
          cx="18"
          cy="15"
          r="13"
          fill={medalFill}
          stroke={medalStroke}
          strokeWidth="2"
        />
        <text
          x="18"
          y="20"
          textAnchor="middle"
          fontSize="14"
          fontWeight="700"
          fill={textFill}
        >
          {rank}
        </text>
      </svg>
    </span>
  );
}

function RankMedal({ rank }: { rank: 1 | 2 | 3 }) {
  if (rank === 1) return <CrownMedal />;
  return <NumberMedal rank={rank} />;
}

function LeaderAvatar({
  src,
  alt,
  sizeClass,
  ringClass,
}: {
  src: string;
  alt: string;
  sizeClass: string;
  ringClass: string;
}) {
  const fallback = getAvatarFallbackUrl(alt);

  return (
    <div
      className={`relative shrink-0 flex-none overflow-hidden rounded-full bg-sky-100 ${sizeClass} ${ringClass}`}
    >
      <img
        src={src || fallback}
        alt={alt}
        className="h-full w-full object-cover object-center"
        loading="lazy"
        referrerPolicy="no-referrer"
        onError={(e) => {
          const target = e.currentTarget;
          target.onerror = null;
          target.src = fallback;
        }}
      />
    </div>
  );
}

function PodiumCard({
  leader,
  rank,
}: {
  leader: PodiumLeaderDisplay;
  rank: 1 | 2 | 3;
}) {
  const { sizeClass, ringClass, liftClass } = PODIUM_CONFIG[rank];

  return (
    <div
      className={`flex min-w-0 max-w-[32%] flex-col items-center shrink-0 ${liftClass}`}
    >
      <RankMedal rank={rank} />
      <LeaderAvatar
        src={leader.image}
        alt={leader.name}
        sizeClass={sizeClass}
        ringClass={ringClass}
      />
      <p
        className="mt-2 w-full px-0.5 text-center text-[11px] font-bold leading-tight text-gray-900 break-words sm:text-sm"
        title={leader.name}
      >
        {leader.name}
      </p>
      {leader.subtitle && (
        <p
          className="w-full px-0.5 text-center text-[10px] text-gray-500 break-words"
          title={leader.subtitle}
        >
          {leader.subtitle}
        </p>
      )}
      <p className="mt-0.5 whitespace-nowrap text-center text-xs font-extrabold text-gray-900 sm:text-sm">
        {leader.amount}
      </p>
    </div>
  );
}

interface LeaderboardPodiumProps {
  title: string;
  badgeLabel: string;
  badgeClassName: string;
  leaders: PodiumLeaderDisplay[];
  totalCount: number;
}

export function LeaderboardPodium({
  title,
  badgeLabel,
  badgeClassName,
  leaders,
  totalCount,
}: LeaderboardPodiumProps) {
  const top3 = leaders.slice(0, 3);
  if (top3.length === 0) return null;

  const [first, second, third] = top3;

  return (
    <div className="rounded-xl border border-gray-200 bg-white px-2 pt-3 pb-4 shadow-sm sm:px-6 sm:pt-4 sm:pb-5">
      <div className="mb-2 flex items-center justify-between gap-2 px-1 sm:mb-3">
        <h2 className="text-base font-semibold text-gray-900 sm:text-lg">
          {title}
        </h2>
        <span
          className={`shrink-0 rounded-full px-2 py-1 text-xs font-medium ${badgeClassName}`}
        >
          {badgeLabel} {totalCount}
        </span>
      </div>
      <div className="flex items-end justify-center gap-2 sm:gap-3">
        {second && <PodiumCard leader={second} rank={2} />}
        {first && <PodiumCard leader={first} rank={1} />}
        {third && <PodiumCard leader={third} rank={3} />}
      </div>
    </div>
  );
}
