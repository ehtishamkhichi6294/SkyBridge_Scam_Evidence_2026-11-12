import React, { createContext, useContext, useState, useEffect } from "react";
import { User } from "../types";
import { authService } from "../services/authService";
import { apiClient } from "../services/apiClient";
import { userService } from "../services/userService";

interface AuthContextType {
  user: User | null;
  isAuthenticated: boolean;
  login: (
    email: string,
    password: string,
  ) => Promise<{ success: boolean; error?: string; message?: string }>;
  register: (
    userData: any,
  ) => Promise<{
    success: boolean;
    error?: string;
    fieldErrors?: Record<string, string>;
  }>;
  logout: () => void;
  token: string | null;
  refreshUser: (patch: Record<string, unknown>) => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
};

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({
  children,
}) => {
  const [user, setUser] = useState<User | null>(null);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [token, setToken] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Check for stored auth data using authService
    const currentUser = authService.getCurrentUser();
    const currentToken = authService.getToken();

    if (currentUser && currentToken) {
      setUser(currentUser);
      setToken(currentToken);
      setIsAuthenticated(true);
      // Set token in apiClient for all future requests
      apiClient.setAuthToken(currentToken);
    }
    setLoading(false);
  }, []);

  const login = async (
    email: string,
    password: string,
  ): Promise<{ success: boolean; error?: string; message?: string }> => {
    try {
      const result = await authService.login(email, password);

      if (result.success && result.user) {
        const currentToken = authService.getToken();
        setUser(result.user);
        setToken(currentToken);
        setIsAuthenticated(true);

        // Set token in apiClient for all future requests
        if (currentToken) {
          apiClient.setAuthToken(currentToken);
        }

        return { success: true, message: result.message || "Login successful" };
      } else {
        return {
          success: false,
          error: result.error || "Login failed",
          message: result.message,
        };
      }
    } catch (error: any) {
      return {
        success: false,
        error: error.message || "Login failed",
        message: error.message || "Login failed",
      };
    }
  };

  const register = async (
    userData: any,
  ): Promise<{
    success: boolean;
    error?: string;
    fieldErrors?: Record<string, string>;
  }> => {
    try {
      const result = await authService.register(userData);

      if (result.success && result.user) {
        const currentToken = authService.getToken();

        // Only set authenticated state when a token is available
        if (currentToken) {
          setUser(result.user);
          setToken(currentToken);
          setIsAuthenticated(true);
          apiClient.setAuthToken(currentToken);
        } else {
          // Ensure we are not treating the user as authenticated without a token
          setUser(null);
          setToken(null);
          setIsAuthenticated(false);
          apiClient.removeAuthToken();
        }

        return { success: true };
      } else {
        return {
          success: false,
          error: result.error || "Registration failed",
          fieldErrors: result.fieldErrors,
        };
      }
    } catch (error: any) {
      return { success: false, error: error.message || "Registration failed" };
    }
  };

  const refreshUser = (patch: Record<string, unknown>) => {
    const updated = authService.patchStoredUser(patch);
    if (updated) setUser(updated);
  };

  const logout = () => {
    authService.logout();
    userService.clearProfileCache();
    setUser(null);
    setToken(null);
    setIsAuthenticated(false);
    // Remove token from apiClient
    apiClient.removeAuthToken();
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-green-600"></div>
      </div>
    );
  }

  return (
    <AuthContext.Provider
      value={{
        user,
        isAuthenticated,
        login,
        register,
        logout,
        token,
        refreshUser,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};
