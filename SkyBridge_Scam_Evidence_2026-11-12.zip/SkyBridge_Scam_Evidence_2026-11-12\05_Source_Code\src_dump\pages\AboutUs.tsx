import React from "react";
import AboutContent from "../components/AboutContent";

const AboutUs: React.FC = () => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-sky-50 via-blue-50 to-cyan-50 -m-4 lg:-m-6 xl:-m-8">
      <AboutContent />
    </div>
  );
};

export default AboutUs;
