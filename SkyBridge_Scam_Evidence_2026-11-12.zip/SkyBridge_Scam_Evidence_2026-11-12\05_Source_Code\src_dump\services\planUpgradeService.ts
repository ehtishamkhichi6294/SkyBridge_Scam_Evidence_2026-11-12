import { apiClient } from "./apiClient";
import { API_ENDPOINTS } from "../config/api";
import type { PlanUpgradeHistoryItem } from "../constants/plans";

function unwrapHistoryPayload(payload: unknown): unknown[] {
  if (Array.isArray(payload)) return payload;
  if (!payload || typeof payload !== "object") return [];

  const obj = payload as Record<string, unknown>;
  if (Array.isArray(obj.data)) return obj.data;
  if (Array.isArray(obj.history)) return obj.history;
  if (Array.isArray(obj.requests)) return obj.requests;
  if (obj.data && typeof obj.data === "object") {
    const nested = obj.data as Record<string, unknown>;
    if (Array.isArray(nested.data)) return nested.data;
    if (Array.isArray(nested.history)) return nested.history;
    if (Array.isArray(nested.requests)) return nested.requests;
  }
  return [];
}

function normalizeHistoryItem(raw: unknown): PlanUpgradeHistoryItem | null {
  if (!raw || typeof raw !== "object") return null;
  const item = raw as Record<string, unknown>;

  const planRelation =
    (item.plan as PlanUpgradeHistoryItem["plan"]) ??
    (item.requested_plan as PlanUpgradeHistoryItem["plan"]) ??
    (item.to_plan as PlanUpgradeHistoryItem["plan"]) ??
    (item.new_plan as PlanUpgradeHistoryItem["plan"]) ??
    null;

  const planId =
    item.plan_id ??
    item.planId ??
    item.requested_plan_id ??
    item.requestedPlanId ??
    item.to_plan_id ??
    item.new_plan_id ??
    (typeof planRelation === "object" && planRelation
      ? planRelation.id
      : undefined);

  const planName =
    item.plan_name ??
    item.planName ??
    item.requested_plan_name ??
    item.requestedPlanName ??
    (typeof planRelation === "string"
      ? planRelation
      : typeof planRelation === "object" && planRelation
        ? planRelation.name || planRelation.title
        : undefined);

  return {
    ...(item as PlanUpgradeHistoryItem),
    id: Number(item.id) || 0,
    plan_id: planId as number | string | undefined,
    plan_name: typeof planName === "string" ? planName : undefined,
    plan: planRelation,
    status: String(item.status || "pending"),
    transaction_id:
      (item.transaction_id as string | undefined) ||
      (item.transactionId as string | undefined) ||
      (item.trx_id as string | undefined),
    created_at:
      (item.created_at as string | undefined) ||
      (item.createdAt as string | undefined),
  };
}

export const planUpgradeService = {
  async getHistory(): Promise<PlanUpgradeHistoryItem[]> {
    const response = await apiClient.get<unknown>(
      API_ENDPOINTS.PLAN_UPGRADE_HISTORY,
    );

    return unwrapHistoryPayload(response.data)
      .map(normalizeHistoryItem)
      .filter((item): item is PlanUpgradeHistoryItem => item != null);
  },
};
